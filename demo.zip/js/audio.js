/* Entendência — áudio 16-bit procedural (WebAudio). Trilhas e efeitos originais, gerados por código (sem arquivos de áudio).
   Estilo: lead em onda pulso (12,5/25/50%), baixo em triângulo, arpejo, "cordas" (triângulos desafinados) e bateria de ruído,
   como nas trilhas de 16 bits. Cada momento do jogo tem a sua música. Tecla M liga/desliga o som. */
(function () {
'use strict';
var SEMI = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };
function midi(n) { var m = /^([A-G][#b]?)(-?\d)$/.exec(n); return m ? 12 * (+m[2] + 1) + SEMI[m[1]] : 0; }
function hz(m) { return 440 * Math.pow(2, (m - 69) / 12); }
function parse(str) { var ev = [], t = 0; (str || '').split(/\s+/).forEach(function (tok) { if (!tok) return; var p = tok.split(':'), l = +p[1] || 2; if (p[0] !== '-') ev.push({ t: t, m: midi(p[0]), l: l }); t += l; }); return ev; }
function chord(name) { var m = /^([A-G][#b]?)(m?)$/.exec(name); var r = SEMI[m[1]]; return { r: r, iv: m[2] ? [0, 3, 7] : [0, 4, 7] }; }

var DRUMS = { rock: 'k.h.s.h.k.h.s.h.', bounce: 'k.hhs.h.k.hhs.hh', march: 'k.s.k.s.k.s.k.sh', soft: 'h...h...h...h...', drive: 'k.hks.hhk.hks.hh', none: '', calm: 'k.......h...s...', baiao: 'z..zt.t.z..zt.t.', xote: 'z..tz.t.z.zt..t.', modinha: '....', ciranda: 'z...z.t.z...z.t.', samba: 'u.p.p.puu.p.p.pu', maracatu: 'z.tzz.t.z.tzz.t.', frevo: 'ptptptptptptptpt', dobrado: 'k.c.k.c.k.c.kcc.', choro: 'u.p..pu.u.p..pu.', coco: 'z..t..z.t..z..t.', carimbo: 'z.t.z.tzz.t.z.tt', siriri: 'z.tzt.tzz.tzt.t.', obra: 'z.m.z.m.zzm.z.mm' };

/* ------------------ trilhas (8 compassos de 16 passos; cada passo = 1/16) ------------------ */
var SONGS = {
  titulo_chip: { bpm: 112, lead: 'p25', chords: 'C G Am F C G F G', drums: 'rock', bass: 'eighth', arp: 1, pad: 0, echo: 0.15,
    mel: 'E5:4 G5:4 C6:4 G5:4 D5:4 G5:4 B5:4 G5:4 C5:4 E5:4 A5:4 E5:4 C5:4 F5:4 A5:4 C6:4 E5:2 G5:2 C6:4 E6:4 C6:4 D6:4 B5:4 G5:4 D5:4 A5:4 C6:4 F6:4 C6:4 D6:4 B5:4 G5:6 -:2' },
  mapa_chip: { bpm: 124, lead: 'p25', chords: 'G Em C D G Em C D', drums: 'bounce', bass: 'eighth', arp: 1, pad: 0, echo: 0.12,
    mel: 'G5:2 B5:2 D6:4 B5:2 G5:2 D5:4 E5:2 G5:2 B5:4 G5:2 E5:2 B4:4 E5:2 G5:2 C6:4 G5:2 E5:2 C5:4 F#5:2 A5:2 D6:4 A5:2 F#5:2 D5:4 B5:4 D6:4 G6:4 D6:4 G5:4 B5:4 E6:4 B5:4 C6:4 E6:4 G6:4 E6:4 D6:4 C6:4 B5:4 A5:4' },
  vila_chip: { bpm: 112, lead: 'p50', chords: 'F Dm Bb C F Am Bb C', drums: 'rock', bass: 'eighth', arp: 1, pad: 1, echo: 0.1,
    mel: 'A5:4 C6:2 A5:2 F5:4 C5:4 D5:4 F5:2 A5:2 D6:4 A5:4 Bb5:4 D6:2 Bb5:2 F5:4 D5:4 C5:4 E5:4 G5:4 C6:4 A5:4 C6:4 F6:4 C6:4 A5:4 C6:2 E6:2 C6:4 A5:4 D6:4 Bb5:4 F5:4 Bb5:4 C6:4 G5:4 E5:6 -:2' },
  salao_chip: { bpm: 96, lead: 'p25', chords: 'Dm Dm Bb C Dm Gm Bb A', drums: 'soft', bass: 'half', arp: 1, pad: 1, echo: 0.3,
    mel: 'D5:6 F5:2 A5:4 -:4 G5:4 F5:4 E5:4 D5:4 D5:4 F5:4 Bb5:6 -:2 A5:4 G5:4 E5:4 C5:4 F5:6 A5:2 D6:4 -:4 C6:4 Bb5:4 G5:4 D5:4 D5:4 F5:4 Bb5:4 D6:4 C#6:8 A5:8' },
  vila: { bpm: 108, lead: 'p50', chords: 'G F C G G F C G', drums: 'baiao', bass: 'eighth', arp: 0, pad: 0, echo: 0.08, sanfona: 1, terca: 1, cava: 1,
    mel: 'G5:3 A5:1 B5:2 D6:2 C6:2 B5:2 A5:4 A5:3 C6:1 F6:2 E6:2 C6:2 A5:2 F5:4 G5:3 E5:1 G5:2 C6:2 E6:2 D6:2 C6:4 B5:2 A5:2 G5:4 A5:2 B5:2 D6:4 D6:3 B5:1 G5:2 B5:2 D6:2 G6:2 D6:4 C6:3 A5:1 F5:2 A5:2 C6:2 F6:2 C6:4 E6:3 D6:1 C6:2 G5:2 E5:2 G5:2 C6:4 D6:2 C6:2 B5:2 A5:2 G5:6 -:2' },
  varanda: { bpm: 72, lead: 'triangle', chords: 'D A Bm G D A G A', drums: 'modinha', bass: 'half', arp: 0, pad: 0, echo: 0.3, violao: 1, terca: 1,
    mel: 'F#5:4 A5:4 D6:6 -:2 C#6:4 E6:4 A5:6 -:2 D6:4 B5:4 F#5:6 -:2 G5:4 B5:4 D6:4 B5:4 A5:4 F#5:4 D5:6 -:2 E5:4 A5:4 C#6:6 -:2 B5:4 D6:4 G6:4 F#6:4 E6:8 C#6:8' },
  titulo: { bpm: 96, lead: 'p50', chords: 'G C D G Em C D G', drums: 'ciranda', bass: 'eighth', arp: 0, pad: 0, echo: 0.15, sanfona: 1, terca: 1,
    mel: 'B5:4 D6:4 G6:4 D6:4 C6:4 E6:4 G6:4 E6:4 A5:4 D6:4 F#6:4 D6:4 B5:6 D6:2 G6:8 G5:4 B5:4 E6:4 B5:4 E6:4 C6:4 G5:4 E5:4 F#5:4 A5:4 D6:4 C6:4 B5:8 G5:8' },
  mapa: { bpm: 120, lead: 'p50', chords: 'C G Am F C G F G', drums: 'xote', bass: 'eighth', arp: 0, pad: 0, echo: 0.15, sanfona: 1, terca: 1, cava: 1,
    mel: 'E6:2 G6:2 E6:2 C6:2 E6:4 G6:4 D6:2 G6:2 D6:2 B5:2 D6:4 G6:4 E6:2 A6:2 E6:2 C6:2 A5:4 C6:4 A5:2 C6:2 F6:2 C6:2 A5:4 F5:4 G5:2 C6:2 E6:2 G6:2 C7:4 G6:4 B5:2 D6:2 G6:2 D6:2 B5:4 G5:4 A5:4 C6:4 F6:4 E6:4 D6:4 B5:4 G5:8' },
  salao: { bpm: 90, lead: 'p25', chords: 'Dm Dm C Dm Dm Am C Dm', drums: 'soft', bass: 'half', arp: 0, pad: 1, echo: 0.15, terca: 1, berimbau: 1,
    mel: 'D5:6 F5:2 A5:4 G5:2 F5:2 E5:4 F5:4 D5:8 E5:6 G5:2 C6:4 B5:2 G5:2 A5:4 F5:4 D5:8 D6:6 C6:2 A5:4 F5:4 C6:4 A5:4 E5:8 G5:4 E5:4 C5:4 E5:4 F5:4 E5:4 D5:8' },
  rio: { bpm: 118, lead: 'p25', chords: 'D G A D D G A D', drums: 'carimbo', bass: 'eighth', arp: 0, pad: 0, echo: 0.15, terca: 1, cava: 1,
    mel: 'F#5:2 A5:2 D6:4 A5:2 F#5:2 D6:4 G5:2 B5:2 D6:4 B5:2 G5:2 G6:4 A5:2 C#6:2 E6:4 C#6:2 A5:2 E6:4 D6:4 A5:4 F#5:8 A5:2 D6:2 F#6:4 D6:2 A5:2 F#6:4 B5:2 D6:2 G6:4 D6:2 B5:2 G5:4 C#6:2 E6:2 A6:4 E6:2 C#6:2 A5:4 D6:8 F#5:4 A5:4' },
  igarape: { bpm: 88, lead: 'triangle', chords: 'Bm G D A Bm G A D', drums: 'ciranda', bass: 'half', arp: 0, pad: 0, echo: 0.35, violao: 1, terca: 1,
    mel: 'D6:4 F#6:4 B6:6 -:2 B5:4 D6:4 G6:6 -:2 A5:4 D6:4 F#6:6 -:2 E6:4 C#6:4 A5:6 -:2 F#6:4 D6:4 B5:6 -:2 G6:4 D6:4 B5:6 -:2 C#6:4 E6:4 A6:6 -:2 F#6:8 D6:8' },
  sertao: { bpm: 112, lead: 'p50', chords: 'Em D C D Em D C Em', drums: 'coco', bass: 'eighth', arp: 0, pad: 0, echo: 0.12, sanfona: 1, terca: 1,
    mel: 'E5:4 G5:4 B5:4 G5:4 D6:4 A5:4 F#5:8 E5:4 G5:4 C6:4 G5:4 F#5:4 A5:4 D6:8 B5:4 G5:4 E5:8 A5:4 F#5:4 D5:8 C6:4 G5:4 E5:4 C5:4 E5:8 B4:8' },
  pantanal: { bpm: 120, lead: 'p50', chords: 'C F G C C F G C', drums: 'siriri', bass: 'eighth', arp: 0, pad: 0, echo: 0.1, sanfona: 1, terca: 1, cava: 1,
    mel: 'E6:2 G6:2 E6:2 C6:2 G5:4 E5:4 F6:2 A6:2 F6:2 C6:2 A5:4 F5:4 G5:2 B5:2 D6:2 G6:2 D6:4 B5:4 E6:4 C6:4 G5:8 G6:2 E6:2 C6:2 E6:2 G6:4 C7:4 A6:2 F6:2 C6:2 F6:2 A6:4 F6:4 D6:2 G6:2 B6:2 G6:2 D6:4 B5:4 C6:4 E6:4 C6:8' },
  mata: { bpm: 100, lead: 'triangle', chords: 'Am F Dm E Am F E Am', drums: 'choro', bass: 'half', arp: 0, pad: 0, echo: 0.3, violao: 1, terca: 1, cava: 1,
    mel: 'A5:4 C6:4 E6:6 -:2 F6:4 E6:4 C6:6 -:2 D6:4 F6:4 A6:6 -:2 G#5:4 B5:4 E6:6 -:2 C6:4 E6:4 A6:6 -:2 A5:4 C6:4 F6:6 -:2 B5:4 D6:4 G#6:6 -:2 E6:8 A5:8' },
  costa: { bpm: 108, lead: 'p25', chords: 'D G A D Bm G A D', drums: 'coco', bass: 'eighth', arp: 0, pad: 0, echo: 0.2, sanfona: 1, terca: 1, cava: 1,
    mel: 'F#5:4 A5:4 D6:4 A5:4 G5:4 B5:4 D6:4 B5:4 A5:4 C#6:4 E6:4 C#6:4 D6:8 A5:8 B5:4 D6:4 F#6:4 D6:4 G6:4 D6:4 B5:8 E6:4 C#6:4 A5:8 D6:4 F#6:4 D6:8' },
  convites: { bpm: 104, lead: 'p50', chords: 'C Am Dm G C Am Dm G', drums: 'samba', bass: 'eighth', arp: 0, pad: 0, echo: 0.15, terca: 1, cava: 1,
    mel: 'G5:2 E6:2 D6:2 C6:2 G5:2 E5:2 G5:4 A5:2 C6:2 E6:2 C6:2 A5:4 E5:4 F5:2 A5:2 D6:2 A5:2 F5:4 D5:4 G5:2 B5:2 D6:2 G6:2 D6:4 B5:4 E6:2 G6:2 E6:2 C6:2 G5:4 E5:4 C6:2 E6:2 A6:2 E6:2 C6:4 A5:4 D6:2 F6:2 A6:2 F6:2 D6:4 A5:4 B5:4 D6:4 G6:8' },
  roda: { bpm: 92, lead: 'p25', chords: 'Am F C G Am F G Am', drums: 'maracatu', bass: 'half', arp: 0, pad: 1, echo: 0.15, terca: 1, sanfona: 1,
    mel: 'A5:4 C6:4 E6:8 F6:4 E6:4 C6:8 G5:4 C6:4 E6:4 G6:4 D6:4 B5:4 G5:8 E6:4 C6:4 A5:8 A5:4 C6:4 F6:8 G6:4 D6:4 B5:8 A5:4 C6:4 A5:8' },
  rota: { bpm: 150, lead: 'p25', chords: 'E C#m A B E C#m A B', drums: 'frevo', bass: 'eighth', arp: 0, pad: 0, echo: 0.15, cava: 1,
    mel: 'E6:2 G#6:2 B6:2 G#6:2 E6:2 B5:2 G#5:2 B5:2 C#6:2 E6:2 G#6:2 E6:2 C#6:2 G#5:2 E5:2 G#5:2 A5:2 C#6:2 E6:2 C#6:2 A5:2 E5:2 A5:2 C#6:2 B5:2 D#6:2 F#6:2 D#6:2 B5:2 F#5:2 B5:2 D#6:2 G#6:2 B6:2 E7:4 B6:2 G#6:2 E6:4 E6:2 G#6:2 C#7:4 G#6:2 E6:2 C#6:4 C#6:2 E6:2 A6:4 E6:2 C#6:2 A5:4 B5:2 D#6:2 F#6:2 B6:2 F#6:4 B5:4' },
  mapaleo: { bpm: 84, lead: 'p50', chords: 'G Em Am D G Bm Am D', drums: 'choro', bass: 'half', arp: 0, pad: 1, echo: 0.15, terca: 1, cava: 1,
    mel: 'B5:3 D6:1 G6:4 F#6:2 E6:2 D6:4 E6:3 G6:1 B6:4 A6:2 G6:2 E6:4 C6:3 E6:1 A6:4 G6:2 E6:2 C6:4 D6:2 F#6:2 A6:4 F#6:2 D6:2 A5:4 G6:3 F#6:1 E6:4 D6:2 B5:2 G5:4 F#6:3 D6:1 B5:4 D6:2 F#6:2 B6:4 A6:4 E6:4 C6:4 A5:4 A5:4 D6:4 F#6:8' },
  fila: { bpm: 104, lead: 'p12', chords: 'Cm Cm Ab G Cm Fm G Cm', drums: 'dobrado', bass: 'eighth', arp: 0, pad: 0, echo: 0.05,
    mel: 'C5:2 -:2 C5:2 -:2 Eb5:2 -:2 G5:4 F5:2 -:2 F5:2 -:2 Ab5:2 -:2 G5:4 Ab5:2 -:2 Ab5:2 -:2 C6:2 -:2 Eb6:4 D6:2 -:2 B5:2 -:2 G5:2 -:2 D5:4 C5:2 -:2 Eb5:2 -:2 G5:2 -:2 C6:4 Ab5:2 -:2 F5:2 -:2 C5:2 -:2 Ab4:4 G5:2 -:2 B5:2 -:2 D6:2 -:2 G6:4 Eb6:4 C6:4 G5:4 C5:4' },
  nascente: { berimbau: 1, bpm: 84, lead: 'triangle', chords: 'Dm Dm Bb Am Dm Gm Bb A', drums: 'coco', bass: 'whole', arp: 1, pad: 1, echo: 0.55,
    mel: 'D5:4 -:4 F5:4 -:4 A5:6 G5:2 F5:8 D5:4 -:4 Bb5:4 -:4 A5:8 E5:8 F5:4 A5:4 D6:8 C6:4 Bb5:4 G5:8 Bb5:4 D6:4 F6:4 D6:4 C#6:8 A5:8' },
  canteiro: { bpm: 108, lead: 'p12', chords: 'Am Am F E Am Dm E Am', drums: 'obra', bass: 'eighth', arp: 0, pad: 0, echo: 0.1,
    mel: 'A5:4 -:4 C6:4 -:4 B5:4 A5:4 E5:8 F5:4 -:4 A5:4 -:4 G#5:8 B5:8 A5:4 C6:4 E6:8 D6:4 F6:4 A5:8 G#5:4 B5:4 D6:8 C6:8 A5:8' },
  mapa_pronto: { sanfona: 1, terca: 1, bpm: 120, lead: 'p25', chords: 'Em Em C B Em Am B Em', drums: 'maracatu', bass: 'eighth', arp: 1, pad: 1, echo: 0.15,
    mel: 'E5:2 E5:2 G5:4 B5:4 G5:4 E5:2 E5:2 F#5:4 A5:4 F#5:4 C5:2 C5:2 E5:4 G5:4 E5:4 B4:2 B4:2 D#5:4 F#5:4 D#5:4 E6:4 D6:4 B5:4 G5:4 A5:4 C6:4 E6:4 C6:4 B5:4 D#6:4 F#6:4 D#6:4 E6:12 -:4' },
  convites_chip: { bpm: 116, lead: 'p50', chords: 'C Am F G C Em F G', drums: 'bounce', bass: 'eighth', arp: 1, pad: 0, echo: 0.1,
    mel: 'G5:4 E5:2 G5:2 C6:4 G5:4 A5:4 C6:2 A5:2 E5:4 C5:4 A5:4 F5:2 A5:2 C6:4 A5:4 B5:4 D6:2 B5:2 G5:4 D5:4 E5:4 G5:2 C6:2 E6:4 C6:4 G5:4 B5:2 E6:2 B5:4 G5:4 A5:4 C6:2 F6:2 C6:4 A5:4 D6:4 B5:4 G5:8' },
  roda_chip: { bpm: 100, lead: 'p25', chords: 'Am F C G Am F G C', drums: 'calm', bass: 'half', arp: 1, pad: 1, echo: 0.25,
    mel: 'A5:8 E5:8 F5:4 A5:4 C6:8 E5:4 G5:4 C6:4 E6:4 D6:8 B5:8 C6:4 A5:4 E5:8 C6:4 A5:4 F5:4 C6:4 B5:4 D6:4 G6:8 E6:8 C6:8' },
  varanda_chip: { bpm: 76, lead: 'p50', chords: 'A F#m D E A F#m D E', drums: 'none', bass: 'whole', arp: 0, pad: 1, echo: 0.35,
    mel: 'E5:6 C#5:2 A4:4 -:4 F#5:4 A5:4 C#6:6 -:2 B5:4 A5:4 F#5:4 D5:4 E5:8 B4:8 C#5:4 E5:4 A5:4 C#6:4 B5:4 A5:4 F#5:8 D5:4 F#5:4 A5:4 B5:4 C#6:4 B5:4 A5:8' },
  rota_chip: { bpm: 140, lead: 'p25', chords: 'E C#m A B E C#m A B', drums: 'drive', bass: 'eighth', arp: 1, pad: 0, echo: 0.08,
    mel: 'E5:2 G#5:2 B5:2 G#5:2 E6:4 B5:4 C#6:2 B5:2 G#5:2 E5:2 C#5:4 G#5:4 A5:2 C#6:2 E6:2 C#6:2 A5:4 E5:4 B5:2 D#6:2 F#6:2 D#6:2 B5:4 F#5:4 G#5:2 B5:2 E6:2 G#6:2 E6:4 B5:4 C#6:2 E6:2 G#6:2 E6:2 C#6:4 G#5:4 A5:2 B5:2 C#6:2 E6:2 A6:4 E6:4 F#6:4 D#6:4 B5:8' },
  fila_chip: { bpm: 104, lead: 'p12', chords: 'Cm Cm Ab G Cm Fm G Cm', drums: 'march', bass: 'eighth', arp: 0, pad: 0, echo: 0.05,
    mel: 'C5:2 -:2 C5:2 -:2 Eb5:2 -:2 G5:4 F5:2 -:2 F5:2 -:2 Ab5:2 -:2 G5:4 Ab5:2 -:2 Ab5:2 -:2 C6:2 -:2 Eb6:4 D6:2 -:2 B5:2 -:2 G5:2 -:2 D5:4 C5:2 -:2 Eb5:2 -:2 G5:2 -:2 C6:4 Ab5:2 -:2 F5:2 -:2 C5:2 -:2 Ab4:4 G5:2 -:2 B5:2 -:2 D6:2 -:2 G6:4 Eb6:4 C6:4 G5:4 C5:4' },
  mapaleo_chip: { bpm: 100, lead: 'p50', chords: 'G D Em C G D C D', drums: 'calm', bass: 'half', arp: 1, pad: 1, echo: 0.2,
    mel: 'B5:6 A5:2 G5:8 A5:6 G5:2 F#5:8 G5:6 B5:2 E6:8 D6:6 C6:2 G5:8 B5:4 D6:4 G6:8 F#6:6 E6:2 D6:8 E6:4 C6:4 G5:8 A5:8 D6:8' },
  nascente_chip: { bpm: 84, lead: 'p25', chords: 'Dm Dm Bb Am Dm Gm Bb A', drums: 'none', bass: 'whole', arp: 1, pad: 1, echo: 0.55,
    mel: 'D5:4 -:4 F5:4 -:4 A5:6 G5:2 F5:8 D5:4 -:4 Bb5:4 -:4 A5:8 E5:8 F5:4 A5:4 D6:8 C6:4 Bb5:4 G5:8 Bb5:4 D6:4 F6:4 D6:4 C#6:8 A5:8' },
  canteiro_chip: { bpm: 108, lead: 'p12', chords: 'Am Am F E Am Dm E Am', drums: 'march', bass: 'eighth', arp: 0, pad: 0, echo: 0.1,
    mel: 'A5:4 -:4 C6:4 -:4 B5:4 A5:4 E5:8 F5:4 -:4 A5:4 -:4 G#5:8 B5:8 A5:4 C6:4 E6:8 D6:4 F6:4 A5:8 G#5:4 B5:4 D6:8 C6:8 A5:8' },
  mapa_pronto_chip: { bpm: 120, lead: 'p25', chords: 'Em Em C B Em Am B Em', drums: 'drive', bass: 'eighth', arp: 1, pad: 1, echo: 0.15,
    mel: 'E5:2 E5:2 G5:4 B5:4 G5:4 E5:2 E5:2 F#5:4 A5:4 F#5:4 C5:2 C5:2 E5:4 G5:4 E5:4 B4:2 B4:2 D#5:4 F#5:4 D#5:4 E6:4 D6:4 B5:4 G5:4 A5:4 C6:4 E6:4 C6:4 B5:4 D#6:4 F#6:4 D#6:4 E6:12 -:4' }
};
var JINGLES = {
  vitoria: { bpm: 132, notes: 'C5:2 E5:2 G5:2 C6:4 -:1 G5:1 C6:2 E6:6 -:2 D6:2 G6:10', wave: 'p25' },
  lua: { bpm: 100, notes: 'E5:3 G5:3 C6:3 E6:8', wave: 'p50' },
  roda: { bpm: 96, notes: 'C5:4 E5:4 G5:4 C6:6 E6:2 G6:12', wave: 'p25' }
};

/* ------------------ motor ------------------ */
var ctx = null, master, musicG, sfxG, dly, dlyG, noiseBuf, waves = {}, cur = null, timer = null, muted = false, mv = 1, sv = 1, ducked = false, step = 0, nextT = 0, song = null, key = null;
try { var _a = JSON.parse(localStorage.getItem('entendencia_audio') || '{}'); if (typeof _a.m === 'number') mv = _a.m; if (typeof _a.s === 'number') sv = _a.s; muted = !!_a.mute; } catch (e) {}
function saveAudio() { try { localStorage.setItem('entendencia_audio', JSON.stringify({ m: mv, s: sv, mute: muted })); } catch (e) {} }
function pulseWave(d) { var n = 32, re = new Float32Array(n), im = new Float32Array(n); for (var i = 1; i < n; i++) im[i] = (2 / (i * Math.PI)) * Math.sin(i * Math.PI * d); return ctx.createPeriodicWave(re, im); }
function init() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; ctx = new AC();
  master = ctx.createGain(); master.gain.value = muted ? 0 : 0.8; master.connect(ctx.destination);
  musicG = ctx.createGain(); musicG.gain.value = 0.5 * mv; musicG.connect(master);
  sfxG = ctx.createGain(); sfxG.gain.value = 0.7 * sv; sfxG.connect(master);
  dly = ctx.createDelay(1); dly.delayTime.value = 0.27; var fb = ctx.createGain(); fb.gain.value = 0.38; dlyG = ctx.createGain(); dlyG.gain.value = 0.15;
  dlyG.connect(dly); dly.connect(fb); fb.connect(dly); dly.connect(musicG);
  waves.p12 = pulseWave(0.125); waves.p25 = pulseWave(0.25); waves.p50 = pulseWave(0.5);
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); var d = noiseBuf.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
}
function voice(type, f, t, dur, vol, bus, send, vib) {
  var o = ctx.createOscillator(); if (waves[type]) o.setPeriodicWave(waves[type]); else o.type = type; o.frequency.setValueAtTime(f, t);
  var g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(vol * 0.55, t + Math.min(0.12, dur * 0.5)); g.gain.setValueAtTime(vol * 0.55, t + Math.max(0.02, dur - 0.05)); g.gain.linearRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(bus || musicG); if (send) { var s = ctx.createGain(); s.gain.value = send; g.connect(s); s.connect(dlyG); }
  if (vib) { var l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = 5.5; lg.gain.value = 9; l.connect(lg); lg.connect(o.detune); l.start(t + 0.12); l.stop(t + dur + 0.05); }
  o.start(t); o.stop(t + dur + 0.05);
}
function sweep(type, f0, f1, t, dur, vol, bus) {
  var o = ctx.createOscillator(); if (waves[type]) o.setPeriodicWave(waves[type]); else o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  var g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.connect(g); g.connect(bus || sfxG); o.start(t); o.stop(t + dur + 0.02);
}
function noise(t, dur, vol, hp, lp, bus) {
  var s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; var f = ctx.createBiquadFilter(); f.type = hp ? 'highpass' : 'bandpass'; f.frequency.value = hp || lp || 1800;
  var g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); s.connect(f); f.connect(g); g.connect(bus || musicG); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
}
function kick(t, bus) { sweep('sine', 160, 42, t, 0.13, 0.55, bus || musicG); }
function schedule(s, t) {
  var sg = song, b = Math.floor(s / 16), st = s % 16, ch = sg.ch[b % sg.ch.length], sd = 60 / sg.bpm / 4;
  var e = sg.lead[s];
  if (e) {
    var vb = sg.sanfona ? e.l >= 3 : e.l >= 6;
    voice(sg.wave, hz(e.m), t, e.l * sd * 0.92, sg.sanfona ? 0.14 : 0.17, musicG, sg.echo, vb);
    if (sg.sanfona) voice('p25', hz(e.m) * 1.006, t, e.l * sd * 0.92, 0.07, musicG, 0, vb);           // palheta desafinada da sanfona
    if (sg.terca) { var lo = below(e.m, ch); if (lo) voice(sg.wave, hz(lo), t, e.l * sd * 0.9, 0.09, musicG, sg.echo); } // viola/voz em terças paralelas
  }
  if (sg.violao && [0, 3, 6, 8, 11, 14].indexOf(st) >= 0) { var nt = [0, 2, 1, 2, 1, 2][[0, 3, 6, 8, 11, 14].indexOf(st)]; voice('p25', hz(48 + ch.r + ch.iv[nt] + (st > 7 ? 12 : 0)), t, sd * 2.6, 0.09, musicG, sg.echo); } // violão arpejado
  if (sg.cava && st % 2 === 1) voice('p12', hz(72 + ch.r + ch.iv[(st >> 1) % 3]), t, sd * 0.7, 0.035, musicG, 0); // cavaquinho
  // baixo (triângulo)
  var root = 36 + ch.r;
  if (sg.bass === 'eighth' && st % 2 === 0) { var deg = [0, 0, 7, 0, 0, 12, 7, 0][st / 2]; voice('triangle', hz(root + deg), t, sd * 1.8, 0.3); }
  else if (sg.bass === 'half' && st % 8 === 0) voice('triangle', hz(root + (st === 8 ? 7 : 0)), t, sd * 7, 0.3);
  else if (sg.bass === 'whole' && st === 0) voice('triangle', hz(root), t, sd * 15, 0.28);
  // arpejo
  if (sg.arp) { var iv = ch.iv, idx = [0, 1, 2, 1][st % 4]; voice('p12', hz(60 + ch.r + iv[idx] + (st % 8 > 3 ? 12 : 0)), t, sd * 0.8, 0.045, musicG, sg.echo); }
  // cordas/pad
  if (sg.pad && st === 0) ch.iv.forEach(function (iv) { [0, 0.4].forEach(function (dt) { voice('triangle', hz(48 + ch.r + iv) * (1 + dt * 0.004), t, sd * 15.5, 0.05); }); });
  if (sg.berimbau && (st === 0 || st === 6 || st === 10)) sweep('sine', hz(50 + ch.r), hz(50 + ch.r) * 0.93, t, 0.4, 0.2, musicG); // berimbau
  // bateria
  var p = sg.drums[st]; if (p === 'k') kick(t); else if (p === 's') { noise(t, 0.13, 0.28, 0, 1900); sweep('triangle', 220, 120, t, 0.08, 0.2, musicG); } else if (p === 'h') noise(t, 0.04, 0.12, 7000); else if (p === 'o') noise(t, 0.14, 0.1, 6000);
  else if (p === 'z') { sweep('sine', 130, 55, t, 0.16, 0.5, musicG); noise(t, 0.03, 0.1, 0, 600); } // zabumba
  else if (p === 'u') sweep('sine', 100, 48, t, 0.22, 0.5, musicG); // surdo
  else if (p === 'p') { noise(t, 0.05, 0.13, 5500); voice('sine', 3000, t, 0.04, 0.03, musicG, 0); } // pandeiro
  else if (p === 'c') { noise(t, 0.08, 0.2, 0, 2400); noise(t + 0.04, 0.05, 0.12, 0, 2400); } // caixa
  else if (p === 'm') { noise(t, 0.05, 0.22, 0, 1200); sweep('triangle', 1800, 1500, t, 0.16, 0.12, musicG); } // marreta
  else if (p === 't') { voice('sine', 4200, t, 0.09, 0.07, musicG, 0); voice('sine', 6300, t, 0.07, 0.04, musicG, 0); } // triângulo
  if (sg.name === 'fila' && st % 4 === 2) noise(t, 0.02, 0.1, 5000); // máquina de escrever
  if (sg.name === 'canteiro' && st === 8 && b % 2 === 0) sweep('triangle', 1800, 1500, t, 0.18, 0.12, musicG); // martelada
}
function below(m, ch) { for (var d = 2; d <= 5; d++) { var pc = ((m - d) % 12 + 12) % 12; if (ch.iv.some(function (v) { return (v + ch.r) % 12 === pc; })) return m - d; } return 0; }
function tick() {
  if (!ctx || !song) return;
  var sd = 60 / song.bpm / 4;
  while (nextT < ctx.currentTime + 0.18) { schedule(step, nextT); nextT += sd; step = (step + 1) % song.len; }
}
function build(name) {
  var d = SONGS[name]; if (!d) return null; var ev = parse(d.mel), lead = {}; ev.forEach(function (e) { lead[e.t] = e; });
  return { name: name, bpm: d.bpm, wave: d.lead, ch: d.chords.split(' ').map(chord), drums: DRUMS[d.drums] || '', bass: d.bass, arp: d.arp, pad: d.pad, echo: d.echo, lead: lead, len: 128, sanfona: d.sanfona, terca: d.terca, cava: d.cava, violao: d.violao, berimbau: d.berimbau };
}
var Snd = {
  muted: function () { return muted; },
  init: init,
  songs: function () { return Object.keys(SONGS); },
  play: function (name) {
    key = name; if (!ctx) return; if (cur === name) return; cur = name;
    var apply = function () { song = build(name); step = 0; nextT = ctx.currentTime + 0.1; musicG.gain.cancelScheduledValues(ctx.currentTime); musicG.gain.setValueAtTime(0.0001, ctx.currentTime); musicG.gain.linearRampToValueAtTime((ducked ? 0.22 : 0.5) * mv, ctx.currentTime + 0.4); if (!timer) timer = setInterval(tick, 25); };
    if (song) { musicG.gain.cancelScheduledValues(ctx.currentTime); musicG.gain.setValueAtTime(musicG.gain.value, ctx.currentTime); musicG.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.25); setTimeout(apply, 260); } else apply();
  },
  stop: function () { cur = null; key = null; if (ctx && song) { musicG.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.3); setTimeout(function () { song = null; }, 320); } },
  duck: function (on) { ducked = on; if (ctx && song) { musicG.gain.cancelScheduledValues(ctx.currentTime); musicG.gain.linearRampToValueAtTime((on ? 0.22 : 0.5) * mv, ctx.currentTime + 0.25); } },
  toggleMute: function () { muted = !muted; saveAudio(); if (ctx) master.gain.linearRampToValueAtTime(muted ? 0 : 0.8, ctx.currentTime + 0.1); return muted; },
  // volume 0..1 da música ('m') e dos efeitos ('s'); salvo no navegador
  getVol: function (k) { return k === 's' ? sv : mv; },
  setVol: function (k, v) {
    v = Math.max(0, Math.min(1, v)); if (k === 's') sv = v; else mv = v; saveAudio();
    if (ctx) { if (k === 's') sfxG.gain.setTargetAtTime(0.7 * sv, ctx.currentTime, 0.03); else if (song) { musicG.gain.cancelScheduledValues(ctx.currentTime); musicG.gain.setTargetAtTime((ducked ? 0.22 : 0.5) * mv, ctx.currentTime, 0.03); } }
  },
  jingle: function (name) {
    if (!ctx || muted) return; var j = JINGLES[name]; if (!j) return; var sd = 60 / j.bpm / 4, t = ctx.currentTime + 0.05, ev = parse(j.notes), end = 0;
    ev.forEach(function (e) { voice(j.wave, hz(e.m), t + e.t * sd, e.l * sd * 0.95, 0.22, sfxG, 0.2); voice('triangle', hz(e.m - 12), t + e.t * sd, e.l * sd * 0.95, 0.18, sfxG); end = Math.max(end, (e.t + e.l) * sd); });
    Snd.duck(true); setTimeout(function () { Snd.duck(false); }, end * 1000 + 300);
  },
  sfx: function (n) {
    if (!ctx || muted) return; var t = ctx.currentTime + 0.001;
    switch (n) {
      case 'jump': sweep('p25', 300, 760, t, 0.16, 0.2); break;
      case 'land': noise(t, 0.05, 0.1, 0, 300, sfxG); break;
      case 'saber': voice('p50', hz(83), t, 0.07, 0.2, sfxG); voice('p50', hz(88), t + 0.07, 0.22, 0.2, sfxG); break;
      case 'blip': voice('p25', 520 + Math.random() * 120, t, 0.045, 0.1, sfxG); break;
      case 'move': voice('p12', hz(76), t, 0.04, 0.12, sfxG); break;
      case 'good': [72, 76, 79, 84].forEach(function (m, i) { voice('p25', hz(m), t + i * 0.06, 0.16, 0.18, sfxG); }); break;
      case 'bad': sweep('p50', 220, 90, t, 0.3, 0.22); sweep('triangle', 160, 60, t + 0.05, 0.3, 0.2); break;
      case 'ask': voice('p50', hz(79), t, 0.08, 0.15, sfxG); voice('p50', hz(84), t + 0.08, 0.14, 0.15, sfxG); break;
      case 'verter': for (var i = 0; i < 6; i++) voice('p12', hz(76 + i * 2), t + i * 0.045, 0.1, 0.15, sfxG, 0.2); break;
      case 'check': [84, 88, 91].forEach(function (m, i) { voice('p25', hz(m), t + i * 0.07, 0.3, 0.14, sfxG, 0.3); }); break;
      case 'fall': sweep('p25', 600, 80, t, 0.5, 0.2); break;
      case 'door': noise(t, 0.25, 0.14, 0, 700, sfxG); sweep('triangle', 200, 400, t, 0.2, 0.15); break;
      case 'page': noise(t, 0.09, 0.12, 3500, 0, sfxG); noise(t + 0.08, 0.09, 0.1, 4500, 0, sfxG); break;
      case 'scratch': for (var k = 0; k < 4; k++) noise(t + k * 0.05, 0.05, 0.12, 2500 + k * 700, 0, sfxG); break;
      case 'poof': noise(t, 0.2, 0.16, 0, 900, sfxG); sweep('p25', 500, 900, t, 0.15, 0.1); break;
      case 'stamp': noise(t, 0.08, 0.3, 0, 500, sfxG); sweep('triangle', 120, 50, t, 0.12, 0.3); break;
      case 'lua': this.jingle('lua'); break;
    }
  }
};
window.Snd = Snd;
})();
