/* "Conheça Veredália": conteúdo da tela inicial (história, finalidades, personagens, reinos, línguas).
   Fonte: docs/proposta_jogos/ENTENDENCIA_biblia_do_jogo.md + o que está implementado no jogo.
   Cada seção é HTML simples; a tela inicial (index.html) monta as abas. */
window.MUNDO = [
  { id: 'historia', t: 'A história', h: `
<h3>O nome: Entendência</h3>
<p><b>Entendência</b> vem de <i>entender</i> e do sufixo <i>-ência</i>, como convivência e vivência. Tem três sentidos: a <b>tendência a se entender</b> (a força que faz vozes diferentes procurarem uma à outra); a <b>arte de entender</b> (o ofício de quem traduz entre saberes sem apagar nenhum deles); e a <b>água</b>, que no mito de Veredália corre nas veredas quando as pessoas se entendem e seca quando elas se desentendem.</p>
<p class="q">"Entender não é falar igual. É deixar o outro dizer do jeito dele e, mesmo assim, chegar junto." <span>Dona Cota</span></p>

<h3>Veredália</h3>
<p>Veredália é um mundo de muitas paisagens, os <b>Nove Domínios</b>, cada um com um bioma do Brasil. No coração fica o <b>Planalto das Veredas</b> (Cerrado), o berço das águas: faixas úmidas de capim e buriti, de onde as nascentes descem para todas as direções. No centro do planalto fica a <b>Praça das Águas</b> e, sobre ela, a <b>Torre Inacabada</b>. Cada vila fala do seu jeito: o sertanejo, o ribeirinho, o praiano, o pantaneiro, o quilombola, o indígena, o cidadão da capital. Durante muito tempo todos se entenderam, porque se escutavam.</p>

<h3>A Água-Fala</h3>
<p>Debaixo da Praça das Águas havia o <b>Olho-d'Água</b>, uma nascente funda. Quem bebia dela <b>em roda</b>, com outras pessoas, passava a entender de dentro o que o outro dizia, mesmo numa língua que nunca ouvira. Chamavam essa água de <b>Água-Fala</b>. O segredo do mundo é este: a Entendência nasce da <b>roda</b>, nunca de uma pessoa sozinha.</p>

<h3>Como tudo se perdeu</h3>
<div class="tl">
  <div><b>O Tempo da Fala.</b> Os povos falavam línguas diferentes e se reuniam na Praça das Águas, em <b>Rodas</b>, onde cada um falava na sua língua e todos entendiam. Quem cuidava das Rodas eram os <b>Entendentes</b>.</div>
  <div><b>O Tempo da Torre.</b> O jovem <b>Rei Cassiano</b>, cansado de tanta discussão, quis uma torre tão alta que todos a vissem e <i>uma só língua para ninguém mais brigar</i>. Para erguê-la, drenaram o Olho-d'Água. Quem bebeu da água encanada passou a entender só a língua da Torre. A Torre subiu.</div>
  <div><b>O Tempo da Confusão.</b> A água secou e os rios enfraqueceram em todos os domínios. A Torre parou, inacabada. As línguas se quebraram em pedaços e cada poder pegou um pedaço e o chamou de "a língua certa": nasceram os <b>Reinos</b>. Quem manda na Torre se chama <b>o Monólogo</b>, e uma <b>Nuvem do Apagamento</b> cobre as vilas: o que ninguém registra, some. O último Entendente, <b>Iolanda</b>, tentou refazer a Roda sozinha e a Névoa a engoliu.</div>
  <div><b>O Tempo da Roda.</b> É o tempo que o jogo constrói, com você.</div>
</div>

<h3>Onde o jogo começa</h3>
<p><b>Vila Mutirão</b> é uma vila pequena nos Baixios que há sete anos não faz Roda, desde o dia em que a vila chama de <i>A Cerca</i>. Na noite em que o jogo começa, o <b>Projeto Mirante</b>, de Concretália, é anunciado: "revitalizar" a vila com torres de apartamento, o que significa tirar as casas. O Regente de Mandorra diz que "o caso está em análise", a rádio de Ecoalto chama a vila de "foco de problemas" e a água começa a parar nos quintais, com a Febre à espreita. <b>Dona Cota</b>, a antiga professora, entrega a você uma cabaça com as últimas gotas da Água-Fala: o <b>Cantil</b>.</p>

<h3>Os três atos</h3>
<p><b>Ato I, A Confusão (Marcos 1 a 3).</b> Você descobre que a própria vila fala várias línguas e as pessoas não se entendem. Aprende o ofício, reconhece o território e reúne os primeiros aliados.<br>
<b>Ato II, A Tradução (Marcos 4 a 6).</b> Você sai de casa, visita aliados, lida com boatos, aprende a ler dados e relatos, entra em deliberação e enfrenta as primeiras crises. No fim, desce à Névoa Muda e encontra o que ficou sem resposta.<br>
<b>Ato III, A Obra Comum (Marcos 7 a 9).</b> Com as línguas entendidas, as vozes se juntam num Plano Popular. É preciso enfrentar a Porta Fechada, a tentação, o Corte e a Torre.</p>

<h3>O fim, e o recomeço</h3>
<p>Você atravessa <b>9 Luas</b>, junta as <b>9 gotas</b> (uma de cada Domínio) e chega ao Olho-d'Água, onde a Roda Aberta pode enfim se reunir. A Torre não é derrubada: <b>abre-se por dentro e vira Roda</b>, um anfiteatro onde todas as línguas têm assento. A Água-Fala volta a descer por todos os rios. Então vem a <b>Devolutiva</b>: contar a todos o que foi decidido e por quê. A história não acaba aí: o ciclo recomeça mais fundo, com ameaças novas e mais sutis. O jogo nunca termina em "fim de jogo" definitivo.</p>
<p>O final tem quatro caminhos de vitória, conforme o que a comunidade construiu: <b>Reconhecimento</b> (o nome da vila passa a aparecer nos mapas, escrito por ela), <b>Autonomia</b> (as obras se sustentam com meios próprios), <b>Coalizão</b> (uma rede de territórios muda uma regra que vale para todos) e <b>Sonho</b> (o Plano Popular se realiza no mapa).</p>` },

  { id: 'finalidades', t: 'Para que serve', h: `
<h3>A finalidade do jogo</h3>
<p>Entendência é um jogo de <b>governança participativa</b>, parte do projeto <b>Vigiante</b> (Fiocruz Brasília). Ele ensina pela prática, sem sermão, o caminho que uma comunidade percorre para <b>se articular, reconhecer o seu território, vigiar o que a ameaça, ler os dados, decidir em grupo, planejar, agir e exigir, e devolver o resultado a todos</b>. Quem joga treina escuta, tradução entre saberes, cuidado com os dados pessoais, checagem de fonte, deliberação e prestação de contas.</p>

<h3>Cinco ideias que guiam tudo</h3>
<ul>
<li><b>Entender não é uniformizar.</b> A diferença entre as línguas é riqueza; o problema é a falta de pontes.</li>
<li><b>A comunidade é a heroína.</b> Você é ponte, não salvador. Ninguém entende sozinho.</li>
<li><b>O poder cede quando a regra muda, não quando é derrotado.</b> Os conflitos se resolvem com prova, voz, lei, rede e meios, nunca com violência.</li>
<li><b>O território se aprende a ler.</b> O mapa faz parte da história e do método.</li>
<li><b>A decisão é do grupo.</b> O dado informa, a Roda decide.</li>
</ul>

<h3>Os nove Marcos: a história e o método</h3>
<p>Cada Marco é um capítulo da história e uma etapa real do método do Vigiante. Eles abrem em ordem: a porta seguinte só destranca quando o Marco anterior termina.</p>
<table>
<tr><th>Marco</th><th>Etapa do método</th><th>O desafio</th></tr>
<tr><td>1. A Roda</td><td>Articulação</td><td>A Reunião que Não Acontece</td></tr>
<tr><td>2. O Método</td><td>Formação e ética</td><td>O Formulário Gigante</td></tr>
<tr><td>3. Território Usado</td><td>Cartografia social</td><td>O Mapa que Já Vem Pronto</td></tr>
<tr><td>4. O Rumor</td><td>Vigilância e coleta</td><td>O Boato</td></tr>
<tr><td>5. A Leitura</td><td>Sala de Situação</td><td>O Gráfico que Mente</td></tr>
<tr><td>6. A Sala</td><td>Deliberação</td><td>A Fila das 72 Horas</td></tr>
<tr><td>7. O Plano</td><td>Plano Popular</td><td>O Orçamento que Acabou</td></tr>
<tr><td>8. A Porta</td><td>Mobilização, ação e exigibilidade</td><td>A Porta Fechada</td></tr>
<tr><td>9. A Devolutiva</td><td>Reflexividade e novo ciclo</td><td>O Monólogo e o Esquecimento</td></tr>
</table>

<h3>Agenda 2030 e Cartografia Social</h3>
<p>Cada fase traz um <b>problema real do território</b>. São <b>36 problemas</b> que reúnem os <b>159 fatores</b> da Cartografia Social do Vigiante, organizados em <b>6 eixos</b> e ligados aos <b>18 Objetivos de Desenvolvimento Sustentável</b> (os 17 da ONU mais o ODS 18, Igualdade Racial, do Brasil). Ao entrar numa fase, você classifica o problema como <b>Ameaça, Vulnerabilidade, Resiliência ou Incerteza</b> e diz o quanto ele é urgente; ao concluir, escolhe quem puxa a ação e em que prazo. Cada problema resolvido rende o <b>Selo do ODS</b> (tecla <b>O</b>).</p>
<div class="grid">
<div class="card" style="border-color:#F0871E"><b>Eixo 1 · O Suor que não nos Sustenta</b>Trabalho, renda, economia solidária e agricultura familiar</div>
<div class="card" style="border-color:#E2211C"><b>Eixo 2 · A Vida em Risco</b>Saúde, corpo político, saneamento e adoecimento social</div>
<div class="card" style="border-color:#7A2C8E"><b>Eixo 3 · Nossos Corpos Silenciados</b>Gênero, raça, direitos fundamentais e empoderamento</div>
<div class="card" style="border-color:#4C9F38"><b>Eixo 4 · A Terra de Quem?</b>Soberania territorial, meio ambiente, biodiversidade e clima</div>
<div class="card" style="border-color:#1868A8"><b>Eixo 5 · A Cidade Negada</b>Infraestrutura, educação, cultura e território urbano-rural</div>
<div class="card" style="border-color:#158A8A"><b>Eixo 6 · A Voz na Mesa</b>Participação social, governança, transparência e parcerias</div>
</div>

<h3>O que se ganha e o que se perde</h3>
<p><b>Saberes</b> (entender e provar), <b>Meios</b> (água, remédios, sementes, internet, transporte), <b>Rede</b> (laços e confiança), <b>Ânimo</b> (o fôlego coletivo; festa e descanso o restauram), <b>Visibilidade</b> (o quanto a comunidade é vista; o que o Apagamento ataca) e <b>Entendimento</b> (a água que volta a correr). <b>O dinheiro nunca é placar</b>: o que mede o avanço é a Visibilidade e o Entendimento.</p>

<h3>Cuidados</h3>
<p>O jogo não tem violência: ninguém "vence" um reino na força. Os territórios, nomes e pessoas são <b>fictícios e inspirados</b>, e não substituem as comunidades reais. Povos indígenas, quilombolas, ribeirinhos, pescadores, quebradeiras de coco e outras comunidades tradicionais só entram com co-criação e consulta.</p>` },

  { id: 'personagens', t: 'Personagens', h: `
<h3>Quem caminha com você</h3>
<div class="grid">
<div class="card"><b>O Entendente (você)</b>Uma pessoa que carrega a antiga arte de fazer vozes diferentes se entenderem. Não é guerreiro nem chefe: é <b>ponte</b>. A palavra vale para todos os gêneros. Carrega o <b>Cantil</b>, o <b>Caderno de Traduções</b> e as <b>Lentes</b> de cada língua que aprende.</div>
<div class="card"><b>Arbovia</b>A luz-guia que acompanha você. É a Intérprete: sugere, lembra do Caderno e explica as regras, mas <b>nunca decide</b>. "Posso sugerir uma tradução, mas quem decide é a Roda." Curiosa, leal, de frases curtas; nunca humilha.</div>
<div class="card"><b>Mestra Isabel</b>A Ciência em pessoa, mestra andarilha de cabelo grisalho. Acompanha você em todos os Reinos, na praça do Mapa-Mundo e perto da saída de cada mapa. Ensina o hábito de duvidar com método e escutar com respeito.</div>
<div class="card"><b>Dona Cota</b>Ex-professora e parteira de 74 anos, a memória viva da vila. Cabelo branco em coque, óculos grossos, xale de crochê. Foi ensinada por Iolanda, guardou o Cantil por décadas sem saber para quem, e o entrega a você.</div>
</div>

<h3>Vila Mutirão</h3>
<div class="grid">
<div class="card"><b>Dona Zeni</b>Feirante e cozinheira que sabe a vida de todo mundo. Quer a vila unida; teme que seus "ouvi dizer" machuquem alguém. Aprende a verificar antes de passar adiante.</div>
<div class="card"><b>Duda Aparecida</b>Agente comunitária de saúde há 12 anos, de bicicleta. Conhece cada casa e cada idoso. Fala em termos técnicos que ninguém entende e luta contra o esgotamento.</div>
<div class="card"><b>Rosinha</b>Presidente da Associação de Moradores. Lutou pelo posto, pela escola e pela luz, e cada derrota a endureceu. Quer uma vitória que dure. É a personagem mais exposta à tentação do Favor.</div>
<div class="card"><b>Ed</b>Locutor da Rádio Pé-de-Vereda, uma caixa de som no poste. Sonha ser jornalista. Repete um boato, vê o dano e vira o comunicador da vila.</div>
<div class="card"><b>Seu Aristides</b>Pedreiro que trabalhou onze anos na Torre. Sabe onde a água foi enterrada. Teme ser culpado por ter construído; de silêncio vira testemunha.</div>
<div class="card"><b>Léo</b>Entregador cadeirante e mapeador nato: conhece cada esquina e cada obstáculo. Quer que o mapa mostre quem não passa. Seu feito é o Mapa de Quem Não Passa.</div>
</div>

<h3>Aliados, neutros e gente em risco</h3>
<div class="grid">
<div class="card"><b>Tião Balseiro e Cacilda Remeira</b>Vau do Sabiá, povo do Caminho. Tião tem a balsa e teme o pedágio da Ponte do Progresso; Cacilda leva as notícias e é a primeira aliada de fora.</div>
<div class="card"><b>Alba das Ervas</b>Morro das Mangabas, povo do Cuidado. Raizeira e técnica de enfermagem aposentada, mistura saber de planta e de posto.</div>
<div class="card"><b>Eusébio, Cleonice e Nilda</b>Agrovila Sempre-Viva, povo da Terra. Guardiões das sementes crioulas e a jovem coordenadora que faz a ponte com o mundo de fora.</div>
<div class="card"><b>Dra. Cinthya e Tomás</b>Alto da Chapada, povo do Dado. A hidróloga rigorosa aprende que o número sem o relato é cego; Tomás, seu assistente, vira aprendiz.</div>
<div class="card"><b>Raiza Castanheira</b>Boca do Igarapé, a floresta do Rio-Mundo. Guardiã dos castanhais, defende a floresta em pé contra a desinformação e a grilagem, e pede o reconhecimento da terra. Fala firme, de quem vive do que a mata dá.</div>
<div class="card"><b>Raquel da Reserva</b>Fragmento do Jequitibá, na Mata Atlântica. Bióloga e moradora, liga as pontas entre o viveiro e a cidade. Sabe que dois fragmentos sozinhos morrem e que, ligados, se curam; cobra que o Plano feche todos os vãos do corredor.</div>
<div class="card"><b>Dona Neide</b>Cambista de notícias da Feira do Pequi. Compra e vende boatos; vira aliada se você propuser a Banca Honesta.</div>
<div class="card"><b>Wagner</b>O funcionário do Formulário Gigante, em Mandorra, onde só se fala Oficialês. Mostra que palavras difíceis escondem o que realmente se pede e, aos poucos, vira seu contato dentro da máquina.</div>
<div class="card"><b>Capitão Olegário</b>Chefe do Porto dos Tropeiros. Quem controla a passagem controla o que chega e o que sai.</div>
<div class="card"><b>Mestra Letícia</b>Baixada do Lamaçal, o território mais frágil, primeiro a receber a Maré Parda. Organiza o mutirão de enchente.</div>
<div class="card"><b>Aliados dos Domínios</b>Em cada Reino há gente que guarda um saber do lugar. Conheça todos na aba <i>Os Nove Reinos</i>.</div>
</div>

<h3>Os que mandam</h3>
<p>Os reinos de poder e seus governantes estão na aba <i>Os poderes da Torre</i>. Em cada um há um <b>dissidente</b>: alguém que, por dentro, pode ajudar.</p>` },

  { id: 'reinos', t: 'Os Nove Reinos', h: `
<p>O Mapa-Mundo de Veredália tem nove Reinos (os <b>Domínios</b>). Cada um tem um bioma do Brasil, um povo, uma ameaça, uma <b>gota</b> da Entendência e um <b>Saber-Bioma</b>: um jeito de saber que só aquele lugar ensina. A Roda só se refaz por inteiro quando as nove gotas voltam ao Cantil. Os seis primeiros seguem os Marcos; os três últimos são <b>Reinos livres</b>.</p>
<div class="grid">
<div class="card r"><b>1. Vila Mutirão · Planalto das Veredas</b><i>Cerrado · Marcos 1, 2, 3 e 9</i>Chapadas, veredas e buritis, o berço das águas. É o ponto de partida e o fim do caminho: a Torre fica aqui, e é aqui que se entrega a Devolutiva. Os poderes que mais a pressionam são Concretália e Mandorra. <b>Gota da Vereda · Saber de Nascente:</b> aprender onde a água nasce e como protegê-la.</div>
<div class="card r"><b>2. Boca do Igarapé · O Rio-Mundo</b><i>Amazônia · Marco 4, O Rumor</i>Floresta imensa, várzeas e igarapés que são estradas. Povo ribeirinho em palafitas: <b>Mestre Sebastião</b>, barqueiro e locutor da Rádio-Barco, e <b>Raiza Castanheira</b>, guardiã dos castanhais. Desafio: a grilagem, papéis falsos que fazem terra de gente virar "terra de ninguém". <b>Gota do Rio · Saber de Floresta em Pé.</b> Aqui você aprende a checar uma notícia que leva dias para chegar.</div>
<div class="card r"><b>3. Cacimba Grande · O Sertão que Guarda Chuva</b><i>Caatinga · Marco 5, A Leitura</i>Sol forte, chão rachado, serras azuis e cisternas de telha. <b>Chiquinha da Cisterna</b> cuida da água de todos; <b>Seu Valdemar</b>, o Profeta da Chuva, lê as nuvens e as formigas. Desafio: a seca que vira favor. <b>Gota da Cisterna · Saber da Espera.</b> Aqui o saber do Profeta e o dado da Chapada precisam ser lidos juntos.</div>
<div class="card r"><b>4. Pouso das Garças · A Planície que Respira</b><i>Pantanal · Marco 6, A Sala</i>Planície que enche e seca no seu ritmo. <b>Mestra Tereza</b>, pescadora que lê o pulso das águas, e <b>Seu Alcides</b>, condutor de comitiva. Desafio: barragem e queimadas. <b>Gota da Cheia · Saber da Cheia:</b> viver com o ritmo das águas e dividir o que é comum. As decisões saem com o tempo contra você.</div>
<div class="card r"><b>5. Jequitibá · A Mata que Resta</b><i>Mata Atlântica · Marco 7, O Plano</i>Pedaços de floresta cercados por cidade. <b>Seu Teodoro</b>, viveirista, e <b>Raquel da Reserva</b>, bióloga. Desafio: um loteamento que corta o último corredor entre dois fragmentos. <b>Gota da Muda · Saber de Corredor:</b> dois pedaços sozinhos morrem, ligados se curam. É a lição do Plano Popular e das coalizões.</div>
<div class="card r"><b>6. Enseada do Siri · A Maré e o Mangue</b><i>Zona Costeira e Marinha · Marco 8, A Porta</i>Praias, manguezais e mar aberto. <b>Mestre Nonato</b>, pescador de linha e rede, e <b>Dona Lia</b>, marisqueira. Desafio: um resort que quer fechar a praia e um porto que ameaça o mangue. <b>Gota da Maré · Saber de Maré:</b> esperar e agir na hora certa. A porta fechada aqui é literal.</div>
<div class="card r"><b>7. Coxilha da Fronteira · O Campo sem Cerca</b><i>Pampa · Reino livre</i>Coxilhas, vento e fronteira, onde as línguas se misturam no mesmo dia. <b>Dom Nico</b> fala "misturado" e entende todos; <b>Ana Lídia</b> é professora do campo. Desafio: a monocultura e a cerca. <b>Gota do Vento · Saber de Fronteira:</b> traduzir é misturar sem apagar. É a escola do Entendente.</div>
<div class="card r"><b>8. Babaçual · Mata dos Cocais</b><i>Terra de Passagem · Reino livre</i>Palmeirais de babaçu entre a Amazônia, o Cerrado e a Caatinga. <b>Dona Dalva</b> lidera as quebradeiras de coco, que trabalham em roda. Desafio: cercas que fecham o acesso às palmeiras. <b>Gota do Babaçu · Saber de Coco:</b> o uso comum de um recurso que é de muitas. Ensina a rede entre mulheres.</div>
<div class="card r"><b>9. Planalto Frio · Araucárias e Campos de Altitude</b><i>Terra de Passagem · Reino livre</i>Pinhais, geada e faxinais, onde se cria gado em uso comum e se colhe pinhão. <b>Seu Valdir</b> planta araucárias que não verá adultas. Desafio: corte de verba e madeira retirada sem licença. <b>Gota da Geada · Saber do Tempo Longo:</b> plantar o que os netos vão colher e registrar para que sobreviva à troca de governo.</div>
</div>
<p class="n">Territórios, nomes e pessoas são fictícios e inspirados. Não substituem as comunidades reais; falas e costumes são ponto de partida para oficinas com elas.</p>` },

  { id: 'poderes', t: 'Os poderes da Torre', h: `
<p>Os sete reinos de poder <b>não são vilões de desenho animado</b>. Cada um é a imagem de um poder real, com uma língua própria, um medo que o move e gente por dentro que não concorda com tudo. Você nunca os derrota na força: você <b>muda a regra</b> que lhes dá poder.</p>
<div class="grid">
<div class="card p"><b>Concretália · o Reino do Concreto</b><i>Poder econômico · língua: Projetês</i>Torres, guindastes e tapumes com desenhos do futuro. O <b>Rei Cassiano</b> crê que progresso é concreto e teme ser esquecido como seu avô, de quem só restou uma torre inacabada. Seu enviado é o <b>Sr. Prata</b>. Dissidente: a engenheira <b>Lúcia Prado</b>. Cede quando a vila tem título, voz e rede organizada.</div>
<div class="card p"><b>Mandorra · o Reino do Mando</b><i>Poder político · língua: Oficialês</i>Palácio de arcadas, balcões com senha e a <b>Cadeira Giratória</b>, que muda de ocupante. O <b>Regente Honório</b> crê que "não decidir" é prudência. Dissidente: <b>Fernanda</b>, a escriba. Cede à exigência de vários territórios juntos, com prova pública e plano registrado.</div>
<div class="card p"><b>Veludara · o Reino do Favor</b><i>Corrupção e suborno · língua: Meias-palavras</i>Salões de veludo, tudo suave e perfumado, e tudo <b>custa</b>. A <b>Baronesa Eulália</b> só sabe ser amada com presente. Dissidente: <b>Cassiano</b>, o tesoureiro arrependido. Cede à transparência, à rede forte e às provas guardadas.</div>
<div class="card p"><b>Ferrolho · o Reino da Ordem</b><i>Medo e coação · língua: Ordem</i>Muros baixos, portões de ferro e cadeados. Não há violência: há porta fechada. O <b>Chaveiro-Mor Ismael</b> viu uma cidade pegar fogo e acha que só trancando se protege. Dissidente: <b>Pedro</b>, o Rondante que deixa o portão entreaberto. A cura do medo é a Roda aberta, com testemunhas.</div>
<div class="card p"><b>Ecoalto · o Reino da Voz</b><i>Estigma e mídia · língua: Manchetês</i>Caixas de som, telões e um Mural das Manchetes que muda sozinho. <b>Cléo, a Voz</b>, crê que quem fala mais alto é quem existe. Dissidente: <b>Fábio</b>, repórter de rua. Cede quando percebe que contar a vila certo dá mais audiência.</div>
<div class="card p"><b>Névoa Muda · o Reino da Ausência</b><i>Invisibilidade · língua: Ausência</i>Neblina, corredores de arquivo sem fim, papéis em branco. É o reino do que não foi respondido nem contado. Sua guardiã é <b>Iolanda</b>, a última Entendente, que quis ser a ponte inteira e se perdeu. "Ponte é feita de muitas tábuas." Ela volta quando você chega acompanhado.</div>
<div class="card p"><b>Tostão Curto · o Reino do Edital</b><i>Escassez e financiamento · língua: Edital</i>Balcões de vidro, filas de prestação de contas e um Cofre Vazio. <b>Seu Vintém</b>, magro e apavorado, crê que o dinheiro nunca basta. Dissidente: <b>Nair</b>, a contadora. Cede a quem tem projeto registrado, rede diversificada e meios próprios.</div>
<div class="card p"><b>O Monólogo</b><i>A voz única da Torre</i>Fala por todos os reinos em uníssono. Só cai quando <b>todas as vozes falam e são entendidas</b>: você conduz a Roda das Línguas, e cada domínio fala na sua. Cada gota que falta é uma voz ausente.</div>
</div>

<h3>As forças do mundo</h3>
<p>Nem tudo é poder com nome. Há forças que atingem primeiro os mais frágeis: a <b>Maré Parda</b> (a chuva-lama das cheias), a <b>Febre das Águas Paradas</b> (surto que nasce da água parada e pede mutirão), a <b>Eleição da Cadeira</b> (o prometido pode ser desfeito), a <b>Compra</b> (de terrenos, poços, favores e silêncios), o <b>Boato</b> (notícia falsa que corre mais rápido que a verificação), o <b>Corte</b> (o fim da verba que sustentava uma obra) e o <b>Apagamento</b>, o risco maior: a comunidade deixa de ser vista e vira "terreno vazio" nos mapas.</p>` },

  { id: 'linguas', t: 'Línguas e ferramentas', h: `
<h3>As doze línguas de Veredália</h3>
<p>As línguas não são idiomas inventados: são <b>maneiras de falar, saber e mandar</b>. Ninguém fala todas. A graça do jogo é aprender a ponte entre elas.</p>
<table>
<tr><th>Línguas Vivas (do povo)</th><th>Como é</th></tr>
<tr><td><b>Relato</b></td><td>Conta o que viu: causos e exemplos. "Foi assim que eu vi."</td></tr>
<tr><td><b>Cuidado</b></td><td>Fala de corpo, de sintoma, de quem cuida de quem.</td></tr>
<tr><td><b>Terra</b></td><td>Fala de estação, semente, chuva e plantio.</td></tr>
<tr><td><b>Caminho</b></td><td>Fala de travessia, rota, quem passa e o que leva.</td></tr>
<tr><td><b>Dado</b></td><td>Fala de número, gráfico e evidência.</td></tr>
</table>
<table>
<tr><th>Línguas da Torre (dos reinos)</th><th>Como é</th></tr>
<tr><td><b>Oficialês</b> (Mandorra)</td><td>Ofício e protocolo: "estamos analisando", "encaminhe-se".</td></tr>
<tr><td><b>Projetês</b> (Concretália)</td><td>Cifrão e cronograma: "revitalização", "requalificação".</td></tr>
<tr><td><b>Manchetês</b> (Ecoalto)</td><td>Rótulo e escândalo, o que dá clique.</td></tr>
<tr><td><b>Meias-palavras</b> (Veludara)</td><td>Favor e convite: "a gente se entende".</td></tr>
<tr><td><b>Ordem</b> (Ferrolho)</td><td>Regra e portão: "não é permitido".</td></tr>
<tr><td><b>Edital</b> (Tostão Curto)</td><td>Prazo, critério, formulário e escassez.</td></tr>
<tr><td><b>Ausência</b> (Névoa Muda)</td><td>O que não foi respondido, registrado nem contado.</td></tr>
</table>

<h3>Traduzir de verdade</h3>
<p>Traduzir não é trocar uma palavra por outra. É achar o ponto em que duas línguas dizem a mesma coisa e dizer de um jeito que o outro entenda <b>sem que o primeiro perca o sentido</b>. Tradução boa reforça a inteligibilidade sem dissolver a identidade de quem fala. Tradução ruim empobrece: vira o relato em número e perde o sentido, vira o pedido em protocolo e perde a urgência. E a <b>tradução comprada</b>, de quem serve a quem paga, é a pior.</p>

<h3>O que você carrega</h3>
<div class="grid">
<div class="card"><b>O Cantil</b>A cabaça com as últimas gotas da Água-Fala. Cada tradução bem feita acende uma gota; no fim, chega a nove.</div>
<div class="card"><b>O Caderno de Traduções</b>O dicionário vivo do Entendente (tecla <b>C</b>): palavras, equivalências e provas.</div>
<div class="card"><b>As Lentes</b>Cada língua que você entende dá uma Lente para ler o mundo. Combinando três, aparece a Inteligência Comum: ver o que ninguém vê sozinho.</div>
<div class="card"><b>Ecos e Ruídos</b>No caminho, <b>Ecos-de-Boca</b> (ruídos) repetem frases de desencontro. Com <b>Q</b> você <b>verte</b> o Eco: só a língua certa o transforma, e escolher a errada custa Ânimo.</div>
</div>

<h3>As leis da Roda</h3>
<ol>
<li><b>A Água informa, a Roda decide.</b> Dados e relatos orientam; a decisão é do grupo.</li>
<li><b>Setenta e duas horas.</b> Um alerta crítico se responde em três dias; se ninguém responde, registra-se a falta de resposta.</li>
<li><b>Devolve-se ao território antes de publicar.</b> Ninguém conta a história de uma comunidade sem que ela a ouça primeiro.</li>
<li><b>Resolve-se no nível mais próximo.</b> Primeiro o que a vila pode; depois o que exige vizinhos; por último o que exige reinos.</li>
<li><b>Sempre há plano B.</b> Quem planeja sem alternativa planeja para cair.</li>
</ol>

<h3>Palavras do mundo</h3>
<p><b>Marco:</b> cada uma das nove etapas da campanha. <b>Lua:</b> o dia, a etapa de aprendizado; são nove. <b>Trecho:</b> uma fase lateral dentro de um lugar. <b>Roda:</b> a reunião de decisão do grupo. <b>Plano Popular:</b> o plano de ação construído pela comunidade. <b>Livro de Leis:</b> o registro das decisões, que pode ser revisto. <b>Memória do Território:</b> as marcas que ficam de um ciclo para o outro. <b>Apagamento:</b> quando uma comunidade deixa de ser vista. <b>Veredália:</b> a terra de todas as águas.</p>` }
];
