/* Entendência — protótipo v0.1 (Phaser 3). Mapa-Mundo (visto de cima) + Trecho 1 "A Vila Acorda" (lateral). */
(function () {
'use strict';
var W = 1280, H = 720, BARH = 62; // BARH: altura da barra de cima; os mapas (Mundo e Reinos) são desenhados abaixo dela, nunca por baixo
var FONT = '"Pixelify Sans", "Trebuchet MS", Verdana, sans-serif'; // fonte pixel (OFL) em assets/fonts; fallback do sistema
var PELE = [0xffd6ae, 0xd89048, 0xa8682c, 0x7a4a24];
var CABELO = [0x2a1f2d, 0x8a4a1e, 0xffc83a, 0xe0382e];
var ROUPA = [0x2ecf5a, 0x3a8cff, 0xff9a2e, 0xb04ee8];
var COR = { ZENI: '#ffd54f', DUDA: '#81c784', 'LÉO': '#64b5f6', ARBOVIA: '#ce93d8', ECO: '#b0b0b0', VOCÊ: '#ffffff', ROSINHA: '#f48fb1', FERNANDA: '#b0bec5', 'TOMÁS': '#90caf9', 'DRA. CINTHYA': '#a5d6a7', 'DONA COTA': '#ce93d8', WAGNER: '#b0bec5', ARISTIDES: '#ffb74d', NIVELINO: '#90a4ae', 'LÚCIA': '#80cbc4', ED: '#ff8a65', NEIDE: '#ffd54f', 'TIÃO': '#4db6ac', CACILDA: '#f48fb1', RAIZA: '#81c784', 'SEBASTIÃO': '#4fc3f7', 'CLÉO': '#ba68c8', 'FÁBIO': '#bcaaa4', CHIQUINHA: '#4dd0e1', VALDEMAR: '#d4a95a', ALBA: '#9ccc65', PRATA: '#9fa8da', TEREZA: '#80cbc4', ALCIDES: '#d4b070', LETÍCIA: '#ff8a65', IOLANDA: '#b0b0c0', TEODORO: '#aed581', RAQUEL: '#66bb6a', 'VINTÉM': '#b0bec5', NAIR: '#f8bbd0', NONATO: '#4fc3f7', LIA: '#ffab91', 'HONÓRIO': '#9fa8da', 'EULÁLIA': '#e1a0e8', CASSIANO: '#bcaaa4', ISMAEL: '#b0bec5', PEDRO: '#90caf9', REGENTE: '#c5cae9', 'CASSIANO': '#ffd54f', 'MONÓLOGO': '#cfd8dc', 'MESTRA ISABEL': '#ffcc80', 'RUÍDO': '#c9a0ff', CADERNO: '#ffe082', '': '#cfd8dc' };
var DIALOG_MS = 7000; function dialogMs() { return E.assist ? 25000 : DIALOG_MS; } // tempo sem resposta para a conversa fechar sozinha
var GRAV = 1800, SPD = 300, JUMP = -720;
var PORTRAIT = { ZENI: 'p_zeni', 'LÉO': 'p_leo', DUDA: 'p_marta', ROSINHA: 'p_rosa', FERNANDA: 'p_mari', 'TOMÁS': 'p_tomas', 'DRA. CINTHYA': 'p_irac', 'DONA COTA': 'p_cota', WAGNER: 'p_gilvan', ARISTIDES: 'p_aristides', NIVELINO: 'p_nivelino', 'LÚCIA': 'p_lucia', ED: 'p_davi', NEIDE: 'p_neide', 'TIÃO': 'p_tiao', CACILDA: 'p_cacilda', RAIZA: 'p_joana', 'SEBASTIÃO': 'p_sebastiao', 'CLÉO': 'p_cleo', 'FÁBIO': 'p_fabio', CHIQUINHA: 'p_chiquinha', VALDEMAR: 'p_valdemar', ALBA: 'p_dete', PRATA: 'p_prata', TEREZA: 'p_tereza', ALCIDES: 'p_alcides', LETÍCIA: 'p_valdete', IOLANDA: 'p_iolanda', TEODORO: 'p_teodoro', RAQUEL: 'p_bruna', 'VINTÉM': 'p_vintem', NAIR: 'p_nair', NONATO: 'p_nonato', LIA: 'p_lia', 'HONÓRIO': 'p_honorio', 'EULÁLIA': 'p_eulalia', CASSIANO: 'p_cassiano', ISMAEL: 'p_ismael', PEDRO: 'p_pedro', REGENTE: 'p_regente', 'CASSIANO': 'p_aurelio', 'MESTRA ISABEL': 'p_evaristo', ARBOVIA: 'p_arb', VOCÊ: 'p_hero' };

var E = window.E = {
  nome: '', token: null,
  avatar: { pele: 0, cabelo: 0, roupa: 0, criado: false },
  rec: { Saberes: 1, Meios: 1, Rede: 1, 'Ânimo': 5, Visibilidade: 0, Entendimento: 0 },
  lua: 1, gotas: 1, flags: {}, caderno: [], prob: {}, ui: null, _t: null
};
function snapshot() { return { _ts: Date.now(), avatar: E.avatar, rec: E.rec, lua: E.lua, gotas: E.gotas, flags: E.flags, caderno: E.caderno, modo: E.modo, assist: E.assist, linguas: E.linguas, termos: E.termos, atv: E.atv, roca: E.roca, diario: E.diario, mut: E.mut, desc: E.desc, finais: E.finais, legado: E.legado, prob: E.prob }; }
/* Salvamento automático: local na hora; servidor 1,2 s depois (agrupa mudanças), de novo ao fechar/ocultar a aba,
   a cada 20 s enquanto houver algo pendente e ao voltar a conexão. Nunca perde progresso por falha de rede. */
E._dirty = false;
E.sendSave = function (keep) {
  if (!E.token || !E._dirty) return;
  var s = null; try { s = localStorage.getItem('entendencia_' + E.nome); } catch (e) {}
  if (!s) s = JSON.stringify(snapshot());
  E._dirty = false;
  try {
    fetch('api/save' + (E.mundo ? '?slot=mundo' : ''), { method: 'PUT', headers: { Authorization: 'Bearer ' + E.token }, body: s, keepalive: !!keep })
      .then(function (r) { if (!r.ok) E._dirty = true; }).catch(function () { E._dirty = true; });
  } catch (e) { E._dirty = true; }
};
E.persist = function () {
  var s = JSON.stringify(snapshot());
  try { localStorage.setItem('entendencia_' + E.nome, s); } catch (e) {}
  if (!E.token) return;
  E._dirty = true;
  clearTimeout(E._t);
  E._t = setTimeout(function () { E.sendSave(false); }, 1200);
};
(function () {
  function flush() { if (E.token && E.nome) { try { var s = localStorage.getItem('entendencia_' + E.nome); if (s) { E._dirty = true; E.sendSave(true); } } catch (e) {} } }
  window.addEventListener('pagehide', flush);
  window.addEventListener('beforeunload', flush);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('online', function () { E._dirty = true; E.sendSave(false); });
  setInterval(function () { if (E.token && E.nome && window._entTick !== false) { if (E._dirty) E.sendSave(false); } }, 20000);
})();
function applySave(s) { if (!s) return; ['avatar', 'rec', 'lua', 'gotas', 'flags', 'caderno', 'modo', 'assist', 'linguas', 'termos', 'atv', 'roca', 'diario', 'mut', 'desc', 'finais', 'legado', 'prob'].forEach(function (k) { if (s[k] !== undefined) E[k] = s[k]; }); }
function note(k, p, o) { if (!E.caderno.some(function (x) { return x.k === k; })) E.caderno.push({ k: k, p: p, o: o }); E.persist(); }
function snd(n) { try { if (window.Snd) Snd.sfx(n); } catch (e) {} }
var MUS = { titulo: 'titulo', mapa: 'mapa', trecho: 'vila', sala2: 'salao', sala3: 'convites', sala4: 'roda', sala5: 'varanda', sala6: 'rota', sala7: 'fila', sala8: 'mapaleo', sala9: 'nascente', sala10: 'canteiro', sala11: 'mapa_pronto', sala12: 'vila', sala13: 'mapa', sala14: 'rio', sala15: 'igarape', sala16: 'mapa_pronto', sala17: 'sertao', sala18: 'salao', sala19: 'roda', sala20: 'mapa_pronto', sala21: 'pantanal', sala22: 'rota', sala23: 'roda', sala24: 'nascente', sala25: 'fila', sala26: 'mata', sala27: 'varanda', sala28: 'igarape', sala29: 'canteiro', sala30: 'costa', sala31: 'fila', sala32: 'salao', sala33: 'canteiro', sala34: 'mapa_pronto', sala35: 'nascente', sala36: 'mapa_pronto', sala37: 'mapa_pronto', sala38: 'titulo' };
function music(k) { try { if (window.Snd) Snd.play(MUS[k] || 'mapa'); } catch (e) {} }
function chg(k, v) {
  if (E.assist && k === 'Ânimo' && v < 0) v = 0;
  if (k === 'Saberes' && v > 0) snd('saber'); E.rec[k] = Math.max(k === 'Ânimo' ? 1 : 0, E.rec[k] + v); E.persist(); if (E.ui) E.ui.hud();
  // Apagamento: Visibilidade (do território) e Voz (Rede) zeradas depois de começar a jornada; sem game over, vira campanha legada
  if (v < 0 && (k === 'Visibilidade' || k === 'Rede') && E.rec.Visibilidade === 0 && E.rec.Rede === 0 && E.flags && E.flags.marco1 && !E.flags.apagamento && E.ui && E.ui.run) {
    E.flags.apagamento = true;
    setTimeout(function () { E.ui.run([{ s: 'ARBOVIA', t: 'Apagamento: ninguém mais vê, ninguém mais ouve.' }, { s: 'ARBOVIA', t: 'Mas o território guarda tudo. Eis a Memória do Território: sua campanha vira legado.' }, { fn: function () { E.rec.Rede = 1; E.rec.Visibilidade = 1; E.legado = true; E.ui.hud(); } }]); }, 600);
  }
}
/* Finais do Ciclo 1 (Reconhecimento, Autonomia, Coalizão, Sonho): contados na Devolutiva */
function finaisAlcancados() { var f = E.flags || {}; return { Reconhecimento: !!(f.marco3 && f.marco4), Autonomia: !!f.sonhosOk, 'Coalizão': !!(f.baixadaOk && f.marco8), Sonho: true }; }

/* ---------- pixel art: assets PNG + canvas procedural (personagens) ---------- */
var OC = '#2a1f2d';
var PNGS = ['solo', 'plat', 'grama', 'colinas1', 'colinas2', 'colinas3', 'ceu', 'ceu_int', 'nuvem1', 'nuvem2', 'nuvem3', 'tijolo', 'madeira', 'piso', 'rio', 'cipo', 'bandeira', 'luz',
  'arvore', 'buriti', 'arbusto', 'saber', 'casa', 'casa2', 'ubs', 'barraca', 'poste', 'porta', 'mesa', 'estante', 'relogio', 'janela', 'cadeira', 'coracao', 'coracao_vazio', 'gota', 'gota_vazia',
  'nuvem_ameaca', 'td_arvore', 'td_casa', 'praca', 'ponte', 'ponte_trilho'];
function hexs(c) { return '#' + ('000000' + c.toString(16)).slice(-6); }
function mixc(c, f) { var r = Math.min(255, ((c >> 16) & 255) * f), g = Math.min(255, ((c >> 8) & 255) * f), b = Math.min(255, (c & 255) * f); return (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b); }
function mkCv(w, h) { var cv = document.createElement('canvas'); cv.width = w; cv.height = h; return cv; }
function pxr(g, c, x, y, w, h) { g.fillStyle = typeof c === 'number' ? hexs(c) : c; g.fillRect(x, y, w, h); }
function pel(g, c, x0, y0, x1, y1, ring) {
  var cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, rx = (x1 - x0 + 1) / 2, ry = (y1 - y0 + 1) / 2; g.fillStyle = typeof c === 'number' ? hexs(c) : c;
  for (var y = Math.floor(y0); y <= y1; y++) for (var x = Math.floor(x0); x <= x1; x++) {
    var dx = (x + .5 - cx) / rx, dy = (y + .5 - cy) / ry, d2 = dx * dx + dy * dy; if (d2 > 1) continue;
    if (ring) { var ex = (x + .5 - cx) / (rx - 1), ey = (y + .5 - cy) / (ry - 1); if (ex * ex + ey * ey < 1) continue; }
    g.fillRect(x, y, 1, 1);
  }
}
function finishCv(cv, outline) { // luz no canto superior esquerdo + contorno escuro
  var W = cv.width, H = cv.height, g = cv.getContext('2d'), id = g.getImageData(0, 0, W, H), d = id.data, o = new Uint8ClampedArray(d);
  function A(x, y) { return (x < 0 || y < 0 || x >= W || y >= H) ? 0 : d[(y * W + x) * 4 + 3]; }
  function same(x, y, x2, y2) { if (A(x2, y2) === 0) return false; var i = (y * W + x) * 4, j = (y2 * W + x2) * 4; return d[i] === d[j] && d[i + 1] === d[j + 1] && d[i + 2] === d[j + 2]; }
  for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
    if (A(x, y) === 0) continue; var f = 1; if (!same(x, y, x - 1, y - 1)) f = 1.14; if (!same(x, y, x + 1, y + 1)) f = .78; var i = (y * W + x) * 4;
    o[i] = Math.min(255, d[i] * f); o[i + 1] = Math.min(255, d[i + 1] * f); o[i + 2] = Math.min(255, d[i + 2] * f);
  }
  if (outline) for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
    if (A(x, y) !== 0) continue; if (A(x + 1, y) || A(x - 1, y) || A(x, y + 1) || A(x, y - 1)) { var k = (y * W + x) * 4; o[k] = 0x2a; o[k + 1] = 0x1f; o[k + 2] = 0x2d; o[k + 3] = 255; }
  }
  id.data.set(o); g.putImageData(id, 0, 0); return cv;
}
function personCv(o) {
  var cv = mkCv(24, 28), g = cv.getContext('2d'), ox = 4, oy = 2;
  function R(x0, y0, x1, y1, c) { pxr(g, c, x0 + ox, y0 + oy, x1 - x0 + 1, y1 - y0 + 1); }
  function El(x0, y0, x1, y1, c, ring) { pel(g, c, x0 + ox, y0 + oy, x1 + ox, y1 + oy, ring); }
  var skin = o.skin, hair = o.hair, shirt = o.shirt, pants = o.pants, acc = o.acc, po = o.pose, wc = acc === 'wheelchair';
  if (!wc) {
    if (po === 'jump') { R(4, 16, 6, 19, pants); R(5, 20, 8, 21, mixc(pants, .45)); R(8, 15, 10, 18, mixc(pants, .82)); R(10, 17, 13, 18, mixc(pants, .4)); }
    else if (po === 'climb') { R(5, 16, 7, 20, pants); R(5, 21, 8, 22, mixc(pants, .45)); R(8, 14, 10, 18, mixc(pants, .82)); R(8, 18, 11, 19, mixc(pants, .4)); }
    else { var ab = { 0: [5, 8], 1: [3, 10], 2: [6, 7] }[o.frame || 0], a = ab[0], b = ab[1];
      R(a, 16, a + 2, 21, pants); R(b + 1, 16, b + 3, 21, mixc(pants, .82)); R(a, 22, a + 3, 23, mixc(pants, .45)); R(b + 1, 22, b + 4, 23, mixc(pants, .4)); }
  } else { R(4, 16, 11, 18, pants); R(10, 18, 12, 21, pants); R(11, 22, 13, 22, mixc(pants, .4)); }
  R(4, 9, 11, 16, shirt);
  if (o.fem && !wc) R(3, 16, 12, 19, pants);
  if (acc === 'apron') { R(5, 11, 10, 17, 0xf3efe2); R(5, 11, 10, 11, 0xd9534f); }
  if (acc === 'blazer') { R(4, 9, 11, 17, 0x6e7480); R(7, 9, 8, 14, 0xf1f1f1); }
  if (acc === 'coat') { R(4, 9, 11, 18, 0xf5f5f2); R(7, 10, 8, 13, shirt); R(9, 12, 10, 14, 0x2e8b57); }
  if (acc === 'backpack') R(2, 10, 4, 16, 0xa0591f);
  if (po === 'jump' || po === 'climb') { R(1, 5, 2, 10, mixc(shirt, .8)); R(1, 3, 2, 4, skin); R(13, 4, 14, 10, shirt); R(13, 2, 14, 3, skin); }
  else { R(3, 10, 4, 14, mixc(shirt, .8)); R(3, 15, 4, 15, skin); R(11, 10, 12, 14, shirt); R(11, 15, 12, 16, skin); }
  R(6, 8, 9, 9, mixc(skin, .85)); El(3, 0, 12, 9, skin);
  var hs = o.hairstyle || 'short';
  if (hs === 'short') { El(2, -1, 11, 4, hair); R(2, 2, 5, 7, hair); R(9, 1, 11, 2, hair); }
  else if (hs === 'bun') { El(2, -1, 12, 5, hair); R(2, 2, 5, 8, hair); El(1, -3, 5, 1, hair); }
  else if (hs === 'long') { El(2, -1, 12, 5, hair); R(2, 2, 5, 11, hair); }
  else if (hs === 'white') { El(2, -1, 12, 5, hair); R(2, 2, 4, 6, hair); El(1, -3, 5, 1, hair); }
  else if (hs === 'cap') { El(2, -1, 12, 4, hair); R(8, 3, 14, 4, hair); }
  else if (hs === 'afro') { El(1, -3, 13, 4, hair); R(2, 2, 4, 6, hair); }
  R(9, 4, 9, 5, 0x1c1420); R(10, 7, 10, 7, mixc(skin, .7));
  if (acc === 'glasses') { R(8, 5, 10, 6, 0x1c1420); R(9, 5, 9, 5, 0xd8f0ff); }
  if (acc === 'scarf') { El(2, -1, 12, 4, 0xd8556a); R(2, 2, 5, 8, 0xd8556a); R(3, 5, 5, 5, mixc(0xd8556a, .75)); }
  if (acc === 'hearing') { R(2, 5, 3, 7, 0xe8e0d0); R(2, 7, 2, 8, 0xb0a898); }
  if (wc) { El(1, 12, 10, 22, 0x3a3f4a, true); R(10, 17, 13, 18, 0x3a3f4a); El(10, 20, 13, 23, 0x3a3f4a, true); }
  return finishCv(cv, true);
}
function ecoCv(w, h, col) {
  var cv = mkCv(w + 8, h + 8), g = cv.getContext('2d'); pel(g, col, 4, 4, 4 + w - 1, 4 + h - 9);
  for (var i = 0; i < 10; i++) pxr(g, col, 8 - Math.floor(i * .2), 4 + h - 10 + i, Math.max(1, Math.round(7 - i * .7)), 1);
  var ey = 4 + Math.floor((h - 8) / 2) - 3;
  if (h > 20) { for (var k = 0; k < 3; k++) pxr(g, 0xffffff, 8 + k * 5, ey, 3, 3); for (var s = 0; s < 9; s++) pxr(g, 0xffffff, 9 + s, ey + 7 + (s > 1 && s < 7 ? 1 : 0), 1, 1); pel(g, mixc(col, 1.25), 6, 7, 11, 12); }
  else { pxr(g, 0xffffff, 9, 7, 2, 2); pxr(g, 0xffffff, 14, 7, 2, 2); }
  return finishCv(cv, true);
}
function orbCv() {
  // Arbovia em alto contraste: halo dourado, corpo azul-marinho (mesmo tom do balão de conversa) e núcleo branco
  var cv = mkCv(14, 14), g = cv.getContext('2d'); pel(g, 'rgba(255,210,58,0.6)', 0, 0, 14, 14); pel(g, 0x14213d, 2, 2, 10, 10); pel(g, 0xffffff, 4, 4, 6, 6);
  pxr(g, 0xffd23a, 0, 5, 3, 3); pxr(g, 0xffd23a, 11, 5, 3, 3); return cv;
}
function addCv(sc, key, cv) { if (sc.textures.exists(key)) sc.textures.remove(key); sc.textures.addCanvas(key, cv); }
function portraitOf(cv) { var p = mkCv(20, 18); p.getContext('2d').drawImage(cv, 2, 1, 20, 18, 0, 0, 20, 18); return p; }
/* ---------- acabamento pixel art: placas com cantos em degrau, discos, lajes, estradas orgânicas ---------- */
var ASSETV = '20261117e';
function cssRGBA(c) {
  if (typeof c === 'number') return [(c >> 16) & 255, (c >> 8) & 255, c & 255, 1];
  c = String(c);
  if (c.charAt(0) === '#') { var h = c.slice(1); if (h.length === 3) h = h.replace(/./g, function (x) { return x + x; }); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), h.length >= 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1]; }
  var m = c.match(/[\d.]+/g); return m ? [+m[0], +m[1], +m[2], m[3] !== undefined ? +m[3] : 1] : [0, 0, 0, 1];
}
function rgbaS(a, k, al) { k = k || 1; return 'rgba(' + Math.min(255, Math.round(a[0] * k)) + ',' + Math.min(255, Math.round(a[1] * k)) + ',' + Math.min(255, Math.round(a[2] * k)) + ',' + (al === undefined ? a[3] : al) + ')'; }
function stairPath(g, x, y, w, h, c) {
  c = c === undefined ? ((w >= 14 && h >= 14) ? 3 : 1) : c;
  if (w <= 2 * c || h <= 2 * c) { g.fillRect(x, y, w, h); return; }
  if (c >= 3) { g.fillRect(x + 3, y, w - 6, h); g.fillRect(x + 1, y + 1, w - 2, h - 2); g.fillRect(x, y + 3, w, h - 6); }
  else if (c === 2) { g.fillRect(x + 2, y, w - 4, h); g.fillRect(x + 1, y + 1, w - 2, h - 2); g.fillRect(x, y + 2, w, h - 4); }
  else { g.fillRect(x + 1, y, w - 2, h); g.fillRect(x, y + 1, w, h - 2); }
}
function plateDraw(g, w, h, fill, border, bw, edge, step) {
  w = Math.round(w); h = Math.round(h); var F = cssRGBA(fill), lum = .3 * F[0] + .59 * F[1] + .11 * F[2], e = edge ? (step ? 1 : 2) : 0;
  bw = bw === undefined ? 2 : bw; g.clearRect(0, 0, w, h);
  if (edge) { g.fillStyle = edge; stairPath(g, 0, 0, w, h, step); }
  var i0 = e;
  if (border) { g.fillStyle = border; stairPath(g, e, e, w - 2 * e, h - 2 * e, step); i0 = e + bw; }
  g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000'; stairPath(g, i0, i0, w - 2 * i0, h - 2 * i0, step); g.globalCompositeOperation = 'source-over';
  g.fillStyle = fill; stairPath(g, i0, i0, w - 2 * i0, h - 2 * i0, step);
  if (lum > 140 && F[3] > .8 && w - 2 * i0 > 10 && h - 2 * i0 > 10) {
    var s = step ? 1 : 2; g.fillStyle = 'rgba(255,255,255,0.5)'; g.fillRect(i0 + 3, i0, w - 2 * i0 - 6, s); g.fillRect(i0, i0 + 3, s, h - 2 * i0 - 6);
    g.fillStyle = 'rgba(0,0,0,0.13)'; g.fillRect(i0 + 3, h - i0 - s, w - 2 * i0 - 6, s); g.fillRect(w - i0 - s, i0 + 3, s, h - 2 * i0 - 6);
  }
}
function plateAuto(g, w, h, bg) { // placa de fundo de texto: borda derivada da cor
  var F = cssRGBA(bg), lum = .3 * F[0] + .59 * F[1] + .11 * F[2];
  var border = lum > 110 ? rgbaS(F, 0.58, 1) : 'rgba(255,255,255,0.3)';
  plateDraw(g, w, h, bg, border, 2, null);
}
function pxPanel(sc, x, y, w, h, fill, border, bw, edge) {
  w = Math.round(w); h = Math.round(h); var st = { border: border };
  function tex() {
    var key = 'pp_' + w + '_' + h + '_' + fill + '_' + st.border + '_' + bw + '_' + edge;
    if (!sc.textures.exists(key)) { var c = mkCv(w, h); plateDraw(c.getContext('2d'), w, h, fill, st.border, bw, edge); sc.textures.addCanvas(key, c); }
    return key;
  }
  var im = sc.add.image(x, y, tex()).setOrigin(0, 0);
  im.setStrokeStyle = function (wd, col) { st.border = sgnCol(col); im.setTexture(tex()); return im; };
  return im;
}
function sgnCol(c) { return typeof c === 'number' ? hexs(c) : c; }
function pxRect(sc, cx, cy, w, h, fill, stroke, alpha) { // retângulo "de cenário": pixels de 4 px, cantos chanfrados, contorno e luz
  var S = 4, lw = Math.max(2, Math.round(w / S)), lh = Math.max(2, Math.round(h / S)), st = { fill: fill, stroke: stroke };
  function tex() {
    var f = sgnCol(st.fill), sk = st.stroke !== undefined && st.stroke !== null ? sgnCol(st.stroke) : null, key = 'pr_' + lw + '_' + lh + '_' + f + '_' + sk;
    if (!sc.textures.exists(key)) {
      var c = mkCv(lw, lh), g = c.getContext('2d'), F = cssRGBA(f), bs = sk || rgbaS(F, 0.62, 1);
      if (lw >= 3 && lh >= 3) plateDraw(g, lw, lh, f, bs, 1, null, 1); else { g.fillStyle = f; g.fillRect(0, 0, lw, lh); }
      if (lw >= 5 && lh >= 5) { g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(2, 1, lw - 4, 1); }
      sc.textures.addCanvas(key, c);
    }
    return key;
  }
  var im = sc.add.image(cx, cy, tex()).setScale(S).setAlpha(alpha === undefined ? 1 : alpha);
  im.setFillStyle = function (f, a) { st.fill = f; im.setTexture(tex()); if (a !== undefined) im.setAlpha(a); return im; };
  im.setStrokeStyle = function (wd, col) { st.stroke = col; im.setTexture(tex()); return im; };
  im.setSize = function (ww, hh) { im.setDisplaySize(ww === null || ww === undefined ? im.displayWidth : ww, hh); return im; };
  return im;
}
function pxDisc(sc, x, y, r, fill, ring, alpha) {
  var S = 3, lr = Math.max(3, Math.round(r / S)), d = lr * 2 + 2, st = { fill: fill, ring: ring };
  function tex() {
    var f = sgnCol(st.fill), rg = st.ring !== undefined && st.ring !== null ? sgnCol(st.ring) : null, key = 'dk_' + lr + '_' + f + '_' + rg;
    if (!sc.textures.exists(key)) {
      var c = mkCv(d, d), g = c.getContext('2d'), has = !!rg;
      if (has) { pel(g, rg, 0, 0, d - 1, d - 1); pel(g, f, 1, 1, d - 2, d - 2); } else pel(g, f, 0, 0, d - 1, d - 1);
      if (d >= 8) { g.fillStyle = 'rgba(255,255,255,0.4)'; var o = has ? 2 : 1; g.fillRect(Math.round(d * 0.3), o + 1, Math.max(1, Math.round(d * 0.22)), 1); g.fillRect(o + 1, Math.round(d * 0.3), 1, Math.max(1, Math.round(d * 0.2))); }
      sc.textures.addCanvas(key, c);
    }
    return key;
  }
  var im = sc.add.image(x, y, tex()).setScale(S).setAlpha(alpha === undefined ? 1 : alpha);
  im.setFillStyle = function (f, a) { st.fill = f; im.setTexture(tex()); if (a !== undefined) im.setAlpha(a); return im; };
  im.setStrokeStyle = function (wd, col) { st.ring = col; im.setTexture(tex()); return im; };
  im.setRadius = function (rr) { im.setScale(Math.max(0.3, 2 * rr / d)); return im; };
  return im;
}
function pxRing(sc, x, y, r, col) {
  var S = 3, lr = Math.max(3, Math.round(r / S)), key = 'rg_' + lr + '_' + col;
  if (!sc.textures.exists(key)) { var d = lr * 2 + 2, c = mkCv(d, d), g = c.getContext('2d'); pel(g, col, 0, 0, d - 1, d - 1, true); sc.textures.addCanvas(key, c); }
  return sc.add.image(x, y, key).setScale(S);
}
function pxSlab(sc, x, y, w, vh, key) { // chão/plataforma em pixel art, com pontas e quinas em degrau (sem canto reto)
  var lw = Math.max(4, Math.round(w / 4) || 4), lh = Math.max(4, Math.round(vh / 4) || 4), tk = 'sl_' + key + '_' + lw + '_' + lh;
  if (!sc.textures.exists(tk)) {
    var src = sc.textures.get(key).getSourceImage(), c = mkCv(lw, lh), g = c.getContext('2d'), yy, xx;
    for (yy = 0; yy < lh; yy += src.height) for (xx = 0; xx < lw; xx += src.width) g.drawImage(src, xx, yy);
    var id = g.getImageData(0, 0, lw, lh), d = id.data;
    function clr(px, py) { if (px >= 0 && py >= 0 && px < lw && py < lh) d[(py * lw + px) * 4 + 3] = 0; }
    function drk(px, py, f) { if (px < 0 || py < 0 || px >= lw || py >= lh) return; var i = (py * lw + px) * 4; if (d[i + 3] === 0) return; d[i] *= f; d[i + 1] *= f; d[i + 2] *= f; }
    clr(0, lh - 1); clr(1, lh - 1); clr(0, lh - 2); clr(lw - 1, lh - 1); clr(lw - 2, lh - 1); clr(lw - 1, lh - 2); clr(0, 0); clr(lw - 1, 0);
    for (yy = 0; yy < lh; yy++) { drk(0, yy, 0.55); drk(lw - 1, yy, 0.55); }
    for (xx = 0; xx < lw; xx++) drk(xx, lh - 1, 0.55);
    g.putImageData(id, 0, 0); sc.textures.addCanvas(tk, c);
  }
  return sc.add.image(x, y, tk).setOrigin(0, 0).setScale(4);
}
function cancelaTex(sc, horiz) {
  var key = 'cancela_' + (horiz ? 'h' : 'v');
  if (!sc.textures.exists(key)) {
    var w = horiz ? 24 : 8, h = horiz ? 8 : 24, c = mkCv(w, h), g = c.getContext('2d'), n = horiz ? w : h, i;
    for (i = 0; i < n; i++) { var col = ((i >> 2) & 1) ? '#f4f0e6' : '#d1442e'; if (horiz) { g.fillStyle = col; g.fillRect(i, 3, 1, 3); g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(i, 3, 1, 1); } else { g.fillStyle = col; g.fillRect(3, i, 3, 1); g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(3, i, 1, 1); } }
    var pc = '#6e4a2b'; if (horiz) { pxr(g, pc, 0, 1, 2, 7); pxr(g, pc, w - 2, 1, 2, 7); } else { pxr(g, pc, 1, 0, 7, 2); pxr(g, pc, 1, h - 2, 7, 2); }
    finishCv(c, true); sc.textures.addCanvas(key, c);
  }
  return key;
}
var ROADN = 0;
function stampRoads(sc, groups, wf0) { // várias estradas = uma só malha em pixel art (sem sobreposição), com borda orgânica, rebordo claro, contorno e franja de mato
  groups = groups.filter(function (g) { return g.samples && g.samples.length; }); if (!groups.length) return null;
  var S = 4, rcB = 6.4 * (wf0 || 1), R = rcB + 3.6, Ri = Math.ceil(R), minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9, i, k;
  groups.forEach(function (g) { g.samples.forEach(function (p) { minx = Math.min(minx, p.x); miny = Math.min(miny, p.y); maxx = Math.max(maxx, p.x); maxy = Math.max(maxy, p.y); }); });
  var ox = Math.floor(minx / S) - Ri - 1, oy = Math.floor(miny / S) - Ri - 1, w = Math.ceil(maxx / S) + Ri + 2 - ox, h = Math.ceil(maxy / S) + Ri + 2 - oy;
  var dist = new Float32Array(w * h), own = new Uint8Array(w * h); for (i = 0; i < dist.length; i++) dist[i] = 99;
  groups.forEach(function (g, gi) {
    var pts = [], sm = g.samples, rcG = 6.4 * (g.wf || wf0 || 1);
    if (sm.length === 1) pts.push({ x: sm[0].x / S - ox, y: sm[0].y / S - oy });
    for (var q = 0; q < sm.length - 1; q++) { var a = sm[q], b = sm[q + 1], n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / S)); for (var t = 0; t <= n; t++) pts.push({ x: (a.x + (b.x - a.x) * t / n) / S - ox, y: (a.y + (b.y - a.y) * t / n) / S - oy }); }
    g.rc = rcG;
    pts.forEach(function (p) {
      var x0 = Math.max(0, Math.floor(p.x) - Ri), x1 = Math.min(w - 1, Math.floor(p.x) + Ri), y0 = Math.max(0, Math.floor(p.y) - Ri), y1 = Math.min(h - 1, Math.floor(p.y) + Ri);
      for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) { var d = Math.hypot(x + .5 - p.x, y + .5 - p.y) - (rcG - rcB); if (d < dist[y * w + x]) { dist[y * w + x] = d; own[y * w + x] = gi; } }
    });
  });
  var cv = mkCv(w, h), g2 = cv.getContext('2d'), id = g2.createImageData(w, h), D = id.data, BAY = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], rc = rcB;
  function nz(x, y, s) { var n = (x * 374761393 + y * 668265263 + s * 69069) | 0; n = (n ^ (n >>> 13)) * 1274126177 | 0; return (((n ^ (n >>> 16)) >>> 0) & 65535) / 65535; }
  function put(x, y, c, al) { var j = (y * w + x) * 4; D[j] = c[0]; D[j + 1] = c[1]; D[j + 2] = c[2]; D[j + 3] = Math.round(255 * al); }
  for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
    var d = dist[y * w + x]; if (d >= R) continue; var al = groups[own[y * w + x]].alpha; al = al === undefined ? 1 : al;
    var gx = x + ox, gy = y + oy, th = (BAY[gy & 3][gx & 3] + .5) / 16, n1 = nz(gx, gy, 3);
    if (d <= rc - 1.4) { var c = [224, 188, 120]; if (n1 > .9) c = [244, 218, 158]; else if (n1 < .08) c = [196, 154, 88]; else if (nz(gx, gy, 8) > .95) c = [176, 130, 70]; put(x, y, c, al); }
    else if (d <= rc) put(x, y, (rc - d) / 1.4 < th ? [224, 188, 120] : [200, 158, 92], al);
    else if (d <= rc + 1.1) put(x, y, [244, 224, 166], al);
    else if (d <= rc + 2.1) put(x, y, [138, 90, 42], al);
    else if (d < R && n1 > .55 && ((gx + gy) & 1) === 0) put(x, y, [58, 146, 58], al);
  }
  g2.putImageData(id, 0, 0);
  var key = 'road_' + (ROADN++); if (sc.textures.exists(key)) sc.textures.remove(key);
  sc.textures.addCanvas(key, cv);
  return sc.add.image(ox * S, oy * S, key).setOrigin(0, 0).setScale(S).setDepth(0.5);
}
function stampRoad(sc, samples, alpha, wf) { return stampRoads(sc, [{ samples: samples, alpha: alpha, wf: wf }]); }
/* fundo de texto (backgroundColor) vira placa em pixel art, sem quina reta */
(function () {
  var P = Phaser.GameObjects.Text.prototype, up = P.updateText, FR = CanvasRenderingContext2D.prototype.fillRect;
  P.updateText = function () {
    var bg = this.style && this.style.backgroundColor; if (!bg) return up.call(this);
    var ctx = this.context, cv = this.canvas, res = this.style.resolution || 1;
    var hook = function (x, y, w, h) { if (x === 0 && y === 0 && w >= cv.width && h >= cv.height) { delete ctx.fillRect; try { plateAuto(ctx, w, h, bg); } finally { ctx.fillRect = hook; } } else FR.call(ctx, x, y, w, h); };
    ctx.fillRect = hook;
    try { return up.call(this); } finally { delete ctx.fillRect; }
  };
})();
/* rectangle/circle de cenário viram pixel art; tintas de tela cheia, véus translúcidos e áreas de clique seguem nativos */
(function () {
  var GF = Phaser.GameObjects.GameObjectFactory.prototype, r0 = GF.rectangle, c0 = GF.circle;
  GF.rectangle = function (x, y, w, h, fill, alpha) {
    if (fill === undefined || w < 6 || h < 6 || (w >= 1000 && h >= 600) || (alpha !== undefined && alpha <= 0.4)) return r0.apply(this, arguments);
    return pxRect(this.scene, x, y, w, h, fill, null, alpha);
  };
  GF.circle = function (x, y, r, fill, alpha) {
    if (fill === undefined || r < 6 || (alpha !== undefined && alpha <= 0.4)) return c0.apply(this, arguments);
    return pxDisc(this.scene, x, y, r, fill, null, alpha);
  };
})();
function mkPortalMapa(sc, x, y, nome, aberta) { // portal do mapa-mundo: único acesso de cada Reino
  var im = sc.add.image(x, y, 'ct_portal0').setOrigin(0.5, 1).setScale(3.4).setDepth(y + 1); if (!aberta) im.setTint(0x777777); return im;
}
function mkPortal(sc, x, rot, y) { // portal em pixel art, com brilho animado; marca o começo e o fim de cada fase
  y = y === undefined ? GY + 4 : y; var im = sc.add.image(x, y, 'ct_portal0').setOrigin(0.5, 1).setScale(4).setDepth(1), f = 0;
  sc.time.addEvent({ delay: 420, loop: true, callback: function () { if (im.scene) { f = 1 - f; im.setTexture('ct_portal' + f); } } });
  sc.add.text(x, y - 168, rot, { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#fff', backgroundColor: '#00000099', padding: { x: 5, y: 1 } }).setOrigin(0.5).setDepth(2); return im;
}
var NPCS = {
  zeni: { skin: 0xa8682c, hair: 0xf0ece4, shirt: 0xffa826, pants: 0xb0643a, hairstyle: 'bun', acc: 'apron' },
  leo: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0x3a8cff, pants: 0x3a50b8, hairstyle: 'cap', acc: 'wheelchair' },
  marta: { skin: 0xffd6ae, hair: 0x5a3a22, shirt: 0x2ed0b0, pants: 0x3a6fe8, hairstyle: 'long', acc: 'coat' },
  rosa: { skin: 0xd89048, hair: 0xe4e4e4, shirt: 0xff4d5a, pants: 0x7a4a6a, hairstyle: 'white' },
  mari: { skin: 0xffd6ae, hair: 0x9a5a2a, shirt: 0x8fa0c8, pants: 0x4a5a8a, hairstyle: 'long', acc: 'blazer' },
  tomas: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0x3ad0ff, pants: 0x6a5ac8, hairstyle: 'afro', acc: 'backpack' },
  irac: { skin: 0xffd6ae, hair: 0xc8c8d0, shirt: 0x34c85a, pants: 0x4a5a6a, hairstyle: 'short', acc: 'glasses' },
  gilvan: { skin: 0xd89048, hair: 0x4a3a3a, shirt: 0xeaf0ff, pants: 0x5a5a88, hairstyle: 'short', acc: 'glasses' },
  cota: { skin: 0x8a5a2a, hair: 0xf4f4f4, shirt: 0xc060f0, pants: 0x8a4a9a, hairstyle: 'white' },
  aristides: { skin: 0xa8682c, hair: 0xe8e8e8, shirt: 0xe8a020, pants: 0x6a5a4a, hairstyle: 'cap' },
  nivelino: { skin: 0xd89048, hair: 0x3a2a22, shirt: 0xc8d0e0, pants: 0x3a4a6a, hairstyle: 'short', acc: 'blazer' },
  lucia: { skin: 0xffd6ae, hair: 0x2a1f2d, shirt: 0x2ed0b0, pants: 0x5a4a8a, hairstyle: 'long', acc: 'glasses' },
  davi: { skin: 0xd89048, hair: 0x2a1f2d, shirt: 0xff7043, pants: 0x3a50b8, hairstyle: 'cap' },
  neide: { skin: 0xa8682c, hair: 0x8a4a1e, shirt: 0xffd23a, pants: 0xc0392b, hairstyle: 'bun', acc: 'apron' },
  tiao: { skin: 0x8a5a2a, hair: 0x2a1f2d, shirt: 0x2ec0a0, pants: 0x5a7a3a, hairstyle: 'cap' },
  cacilda: { skin: 0x7a4a24, hair: 0x2a1f2d, shirt: 0xff6f91, pants: 0x3a6fe8, hairstyle: 'long' },
  joana: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0x34c85a, pants: 0x8a5a2a, hairstyle: 'long' },
  sebastiao: { skin: 0x8a5a2a, hair: 0xe0e0e0, shirt: 0x3ad0ff, pants: 0x4a5a6a, hairstyle: 'white' },
  cleo: { skin: 0xffd6ae, hair: 0x8a2a2a, shirt: 0xb04ee8, pants: 0x2a2a4a, hairstyle: 'long', acc: 'blazer' },
  fabio: { skin: 0xd89048, hair: 0x4a3a3a, shirt: 0xb8b8a8, pants: 0x6a6a4a, hairstyle: 'short', acc: 'backpack' },
  chiquinha: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0x3ad0ff, pants: 0x8a5a2a, hairstyle: 'bun', acc: 'apron' },
  valdemar: { skin: 0x8a5a2a, hair: 0xe0e0e0, shirt: 0xc8a050, pants: 0x6a5a4a, hairstyle: 'cap' },
  dete: { skin: 0x8a5a2a, hair: 0xf4f4f4, shirt: 0x6fbf55, pants: 0x8a4a9a, hairstyle: 'white', acc: 'apron' },
  prata: { skin: 0xffd6ae, hair: 0xc8c8d0, shirt: 0x3a3a5a, pants: 0x2a2a3a, hairstyle: 'short', acc: 'blazer' },
  tereza: { skin: 0x8a5a2a, hair: 0xe8e8e8, shirt: 0x34b8a0, pants: 0x6a8a4a, hairstyle: 'bun', acc: 'apron' },
  alcides: { skin: 0xa8682c, hair: 0x4a3a3a, shirt: 0xd8b060, pants: 0x5a4a3a, hairstyle: 'cap' },
  valdete: { skin: 0x7a4a24, hair: 0x2a1f2d, shirt: 0xff7a5a, pants: 0x3a50b8, hairstyle: 'long' },
  iolanda: { skin: 0xc8c8d4, hair: 0xb8b8c8, shirt: 0x9a9aa8, pants: 0x7a7a8a, hairstyle: 'long' },
  teodoro: { skin: 0xa8682c, hair: 0xe0e0e0, shirt: 0x7a9a4a, pants: 0x5a4a3a, hairstyle: 'cap' },
  bruna: { skin: 0xffd6ae, hair: 0x8a4a1e, shirt: 0x2e9a5a, pants: 0x3a6fe8, hairstyle: 'long' },
  vintem: { skin: 0xd89048, hair: 0x3a2a22, shirt: 0xc8c8d8, pants: 0x4a4a6a, hairstyle: 'short', acc: 'glasses' },
  nair: { skin: 0x8a5a2a, hair: 0x2a1f2d, shirt: 0xe8a0c0, pants: 0x5a4a8a, hairstyle: 'long', acc: 'glasses' },
  nonato: { skin: 0x8a5a2a, hair: 0xe0e0e0, shirt: 0x3ad0ff, pants: 0x4a7aa8, hairstyle: 'cap' },
  lia: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0xff9a5a, pants: 0x3a6fe8, hairstyle: 'bun', acc: 'apron' },
  honorio: { skin: 0xd89048, hair: 0xc8c8d0, shirt: 0x6a6a8a, pants: 0x3a3a5a, hairstyle: 'short', acc: 'blazer' },
  eulalia: { skin: 0xffd6ae, hair: 0xe0e0e0, shirt: 0xd870d8, pants: 0x8a4a9a, hairstyle: 'long', acc: 'blazer' },
  cassiano: { skin: 0xd89048, hair: 0x4a3a3a, shirt: 0x8a6a4a, pants: 0x4a3a2a, hairstyle: 'short', acc: 'glasses' },
  ismael: { skin: 0x7a4a24, hair: 0xb8b8b8, shirt: 0x6a6a7a, pants: 0x3a3a4a, hairstyle: 'white' },
  pedro: { skin: 0xa8682c, hair: 0x2a1f2d, shirt: 0x5a7aa8, pants: 0x3a4a6a, hairstyle: 'cap' },
  regente: { skin: 0xffd6ae, hair: 0x5a3a22, shirt: 0xc0c0e0, pants: 0x3a3a5a, hairstyle: 'short', acc: 'blazer' },
  aurelio: { skin: 0xffd6ae, hair: 0x8a6a2a, shirt: 0xe8c860, pants: 0x5a4a8a, hairstyle: 'short', acc: 'blazer' },
  iolanda2: { skin: 0xd8b888, hair: 0xe0e0e0, shirt: 0xf0e0a0, pants: 0x8a7a5a, hairstyle: 'long' },
  evaristo: { skin: 0x7a4a24, hair: 0xe0e0e0, shirt: 0xb8742a, pants: 0x4a3a2a, hairstyle: 'bun', acc: 'glasses' }
};
var PERS = { aurelio: { nome: 'Aurélio', hs: 'short', fem: false }, aurora: { nome: 'Aurora', hs: 'long', fem: true } }; // personagens jogáveis
function makeAvatar(sc) {
  var PR = PERS[E.avatar.pers] || PERS.aurelio;
  var base = { skin: PELE[E.avatar.pele], hair: CABELO[E.avatar.cabelo], shirt: ROUPA[E.avatar.roupa], pants: 0x3a6fe8, hairstyle: PR.hs, fem: PR.fem, acc: [undefined, 'glasses', 'scarf', 'hearing', 'wheelchair'][E.avatar.extra || 0] };
  function v(o, extra) { var r = {}; for (var k in o) r[k] = o[k]; for (k in extra) r[k] = extra[k]; return r; }
  var f0 = personCv(v(base, { frame: 0 }));
  addCv(sc, 'av0', f0); addCv(sc, 'av1', personCv(v(base, { frame: 1 }))); addCv(sc, 'av2', personCv(v(base, { frame: 2 })));
  addCv(sc, 'avj', personCv(v(base, { pose: 'jump' }))); addCv(sc, 'avc', personCv(v(base, { pose: 'climb' })));
  addCv(sc, 'p_hero', portraitOf(f0));
}
function makeTextures(sc) {
  if (window.ARTE) { var art = ARTE.build(); Object.keys(art).forEach(function (k) { addCv(sc, k, art[k]); }); }
  addCv(sc, 'px', (function () { var c = mkCv(2, 2); pxr(c.getContext('2d'), 0xffffff, 0, 0, 2, 2); return c; })());
  Object.keys(NPCS).forEach(function (k) { var c = personCv(NPCS[k]); addCv(sc, 'n_' + k, c); addCv(sc, 'p_' + k, portraitOf(c)); });
  addCv(sc, 'estrada', (function () { var c = mkCv(16, 16), g = c.getContext('2d'); pxr(g, 0xe0bc78, 0, 0, 16, 16);
    [[2, 3], [9, 1], [13, 6], [5, 9], [11, 12], [1, 14], [7, 5], [14, 14]].forEach(function (p) { pxr(g, 0xc9a05a, p[0], p[1], 2, 1); }); [[4, 6], [10, 9], [0, 11], [12, 3]].forEach(function (p) { pxr(g, 0xf0d598, p[0], p[1], 1, 1); }); return c; })());
  addCv(sc, 'eco_big', ecoCv(24, 52, 0xc77dff)); addCv(sc, 'eco_ok', ecoCv(20, 10, 0x6ff0a0)); addCv(sc, 'arb', orbCv()); addCv(sc, 'p_arb', (function () { var c = mkCv(20, 18); c.getContext('2d').drawImage(orbCv(), 3, 2, 14, 14); return c; })());
}

/* ---------- entrada unificada (teclado + gamepad) ---------- */
function Ctl(sc) {
  this.sc = sc; var k = sc.input.keyboard;
  this.k = k.addKeys('W,A,S,D,E,Q,SPACE,UP,DOWN,LEFT,RIGHT,ESC');
  this.pp = {}; this.s = {};
}
Ctl.prototype.poll = function () {
  var k = this.k, pad = this.sc.input.gamepad && this.sc.input.gamepad.pad1; if (pad && !pad.connected) pad = null;
  var ax = pad ? pad.axes[0].getValue() : 0, ay = pad ? pad.axes[1].getValue() : 0;
  var self = this;
  function edge(n, cur) { var r = cur && !self.pp[n]; self.pp[n] = cur; return r; }
  var JD = Phaser.Input.Keyboard.JustDown;
  this.s = {
    left: k.A.isDown || k.LEFT.isDown || ax < -0.4, right: k.D.isDown || k.RIGHT.isDown || ax > 0.4,
    up: k.W.isDown || k.UP.isDown || ay < -0.4, down: k.S.isDown || k.DOWN.isDown || ay > 0.4,
    jumpHeld: k.SPACE.isDown || k.W.isDown || k.UP.isDown || !!(pad && pad.buttons[0].pressed),
    jump: JD(k.SPACE) | JD(k.W) | JD(k.UP) | edge('pj', !!(pad && pad.buttons[0].pressed)),
    act: JD(k.E) | edge('pa', !!(pad && pad.buttons[2].pressed)),
    verter: JD(k.Q) | edge('pv', !!(pad && pad.buttons[1].pressed)),
    esc: JD(k.ESC) | edge('pe', !!(pad && pad.buttons[9] && pad.buttons[9].pressed))
  };
  return this.s;
};


/* ---------- Guia: história, mundo, como jogar, objetivo da fase ---------- */
var GUIA_TABS = ['A História', 'O Mundo', 'Como jogar', 'Esta fase', 'Glossário'];
var GUIA = {
  0: [
    "Veredália é um planalto de veredas onde cada vila fala do seu jeito: o sertanejo, o ribeirinho, o praiano, o pantaneiro, o quilombola, o indígena, o cidadão da capital... Durante muito tempo todos se entenderam, porque se escutavam.",
    "Aí começou a obra da Torre Inacabada. Ela promete \"uma só língua, uma só voz\". Quem manda nela se chama Monólogo. Quanto mais a Torre sobe, mais gente deixa de ser ouvida, e uma Nuvem do Apagamento cobre as vilas: o que ninguém registra, some.",
    "Você é um Entendente: alguém que escuta, traduz e junta as pessoas. Arbovia, uma luz-guia, e o Cantil que você carrega acompanham a viagem. Cada Lua que você conquista é uma etapa de aprendizado de como um território se organiza e decide junto.",
    "Seu objetivo: atravessar 9 Luas, juntar as 9 gotas e chegar à Olho-d'Água, a nascente onde a Roda Aberta pode, enfim, se reunir e entregar a Devolutiva: dizer a todos o que foi decidido e por quê."
  ],
  1: [
    "A Vila Mutirão é o ponto de partida. Aqui moram Zeni, Duda, Léo, Rosinha e Dona Cota, que já se desentendem há tempos sem perceber que falam línguas diferentes sobre as mesmas coisas.",
    "Ao sair da Vila, o Mapa-Mundo se abre. As estradas levam a oito Reinos, cada um com seu clima, sua música e seu Marco (uma missão central). Os Marcos se abrem em ordem: a porta seguinte só destranca quando o Marco anterior termina.",
    "Os Reinos, em ordem: Vila Mutirão (Marco 1, a Roda) · Varanda e Rota (Marco 2, Traduzir) · Território Usado (Marco 3, o Mapa) · Rio-Mundo e Boca do Igarapé (Marco 4, o Rumor) · Cacimba Grande (Marco 5, a Leitura) · Pouso das Garças (Marco 6, a Sala) · Jequitibá (Marco 7, o Plano) · Enseada do Siri e Mandorra (Marco 8, a Porta) · A Torre (Marco 9, a Devolutiva)."
  ]
};
var GUIA_COMO = [
  "MOVER: setas ou WASD (ou direcional do controle) · PULAR: Espaço (segure para mais alto) · SUBIR CIPÓ: W ou ↑.",
  "FALAR / INTERAGIR: E (ou Espaço nos diálogos) · VERTER um Eco: Q · CADERNO de Traduções: C · GUIA: G · SOM: botão ♪ Som (volume da música e dos efeitos) ou M (silencia tudo) · MODO LEVE: L · FPS: F3 · VOLTAR (salva): Esc · TROCAR MODO DE MAPA: K.",
  "ATIVIDADES: botão Atividades na barra de cima (ou tecla F) no mapa abre o menu de Atividades, Jogos e Saúde. Pontos azuis (✦) na Vila são atividades da história: Feira, Rádio, Oficina, Roda, Cartografia, Roça, Diário e Mutirão.",
  "BÔNUS: pontos roxos (★) no mapa do Reino são fases opcionais só de diversão; dão um presente de Meios uma vez por dia e nunca bloqueiam a história.",
  "MODO CAMINHO (padrão): ao entrar num Reino você vê o mapa dele, com cada fase num lugar diferente, ligado por uma estrada. A cancela do próximo lugar só abre quando você conclui o anterior. MODO CLÁSSICO (tecla K no mapa): a porta do Reino leva direto à próxima fase.",
  "As conversas fecham sozinhas depois de 7 segundos sem você apertar nada. Para reabrir, fale de novo com E.",
  "Nas escolhas: [E] = Escutar e traduzir · [P] = Pressa, impor uma decisão · [?] = Perguntar · [C] = Comprar ou ceder. Escutar e perguntar rendem Saberes, Rede e Entendimento; pressa e cessão custam Ânimo.",
  "Recursos no alto da tela: Saberes (o que você entendeu), Meios (o que você tem para agir), Rede (quem confia em você), Ânimo (corações), Entendimento (clareza do território) e as 9 gotas, uma por Lua conquistada.",
  "Cair não é o fim: você volta ao último ponto seguro. Um Eco que você não entende pode ser Vertido com Q, perto dele, escolhendo a tradução certa."
];
var GUIA_GLOS = [
  ["Eco", "Palavra ou frase difícil, em Oficialês, que paira como uma sombra. Traduzida, vira entendimento."],
  ["Verter", "Traduzir um Eco para a língua da gente (tecla Q)."],
  ["Oficialês", "A língua dos papéis, editais e comunicados: correta, mas que quase ninguém entende."],
  ["Roda", "Reunião em que todos falam e todos escutam. A base de toda decisão em Veredália."],
  ["Línguas", "Cada território tem a sua: Projetês, Manchetês, Edital, Meias-palavras, Ordem e a Ausência (o silêncio)."],
  ["Lentes / Leitor de Sinais", "Instrumentos para ler um território sem confundir cuidado com vigilância."],
  ["Pressão Coordenada", "Vários territórios pedindo juntos, de forma organizada, ao mesmo tempo."],
  ["Devolutiva", "Contar de volta o que foi decidido, com quem decidiu e por quê. Fecha o ciclo."],
  ["Olho-d'Água", "A nascente onde tudo recomeça. Fim do Ciclo 1 e começo do Novo Ciclo."],
  ["Ruído", "Qualquer fala que atrapalha a escuta: Eco-de-Boca, Carimbo, Letreiro, Redemoinho, Febre-Mosca, Seca-Rachada, Branco. Cada um fala uma Língua."],
  ["Eco-de-Boca", "Frase de desânimo repetida ('não adianta'). Verta em Relato: escute e conte o relato inteiro."],
  ["Carimbo", "Ruído de papel e protocolo. Verta em Oficialês traduzido: diga o que se pede, em poucas linhas."],
  ["Letreiro", "Ruído de manchete que grita. Verta em Fato verificado (Manchetês desfeito): o que houve e quem confirma."],
  ["Redemoinho", "Ruído de boato que gira. Verta em Caminho: mostre por onde o boato passou e onde para."],
  ["Fala", "A resposta que você escolhe ao Verter. Só a Língua do Ruído o transforma; as outras custam Ânimo."],
  ["Visibilidade", "O quanto o território é visto por quem decide. Sobe com registro, mapas e rádio."],
  ["Voz", "A confiança que a Roda tem em você (a Rede). Se Visibilidade e Voz zerarem, vem o Apagamento: sem game over, só a Memória do Território."],
  ["Apagamento", "Quando ninguém mais vê nem ouve. O jogo não acaba: sua campanha vira legado."],
  ["Cantil", "Guarda a água de cada Lua conquistada (as gotas)."],
  ["Mapa-Corpo-Território", "Desenhar no mapa onde há risco e onde há cuidado, ligando saúde, corpo e lugar."],
  ["Modo assistido", "Tecla V: as conversas esperam mais para fechar e erros de Fala não custam Ânimo. Tecla L: modo leve. O jogo é o mesmo para todos."],
  ["Finais", "Reconhecimento, Autonomia, Coalizão e Sonho: quatro jeitos de fechar o Ciclo 1, conforme o que você fez."]
];
/* Termos novos aparecem como aviso na primeira vez; ficam marcados como descobertos no Guia */
function novoTermo(t) { E.termos = E.termos || {}; if (E.termos[t]) return; E.termos[t] = true; var d = GUIA_GLOS.filter(function (g) { return g[0] === t; })[0]; if (d && E.ui) E.ui.toast('Novo termo no Guia: ' + t); }
var OBJ = {
  0: ["Mapa-Mundo", "Escolha um Reino e siga a estrada até a porta. As portas abrem em ordem de Marco.", "A porta fechada se abre quando o Marco anterior termina."],
  "-1": ["Mapa do Reino", "Siga a estrada de lugar em lugar. Cada porta é uma fase; a cancela do próximo lugar abre quando você conclui o atual.", "A porta com o círculo dourado é a próxima. Lugares com ✓ podem ser revisitados."],
  1: ["A Vila Acorda", "Conheça os moradores, converse com todos e chegue ao fim da rua.", "Fale com cada pessoa: cada um tem uma língua própria."],
  2: ["O Salão Fechado", "Descubra por que o salão da Vila está trancado e ache quem tem a chave.", "Use Q perto dos Ecos para traduzir o que está escrito nas portas."],
  3: ["Os Convites", "Entregue convites que cada pessoa entenda, na linguagem dela.", "Escutar vale mais do que insistir."],
  4: ["A Reunião que Não Acontece", "Monte a primeira Roda: chame, escute e registre.", "Todos precisam ser ouvidos antes de decidir."],
  5: ["A Varanda", "Comece o Caderno de Traduções e aprenda o básico de ética ao registrar.", "Aperte C para ver o que já traduziu."],
  6: ["A Rota do Léo", "Registre o que as pessoas dizem sem anotar dados pessoais.", "Perguntar o essencial, nada além."],
  7: ["A Fila do Funcionário", "Atravesse a burocracia: traduza o Formulário Gigante do Wagner.", "Palavras difíceis escondem o que realmente se pede."],
  8: ["O Mapa de Quem Não Passa", "Você é o Léo, sem pulo. Veja o território pelo olhar de quem tem obstáculos.", "Procure outros caminhos: nem tudo se resolve pulando."],
  9: ["A Nascente Antiga", "Colete relatos dos antigos moradores sobre a água e o território.", "Quem viveu ali conhece o que o mapa não mostra."],
  10: ["O Canteiro", "Converse com Aristides e monte um croqui do que existe de verdade.", "Registre o que vê, não o que supõe."],
  11: ["O Mapa que Já Vem Pronto", "Confronte o mapa pronto de Nivelino e Lúcia com o que a comunidade sabe.", "Um mapa que ninguém ajudou a fazer deixa gente de fora."],
  12: ["Rádio Pé-de-Vereda", "Ajude o Ed a corrigir uma informação errada, no ar.", "Corrigir com respeito vale mais que desmentir com raiva."],
  13: ["Feira do Pequi", "Monte com Neide a Banca Honesta: só o que se pode confirmar.", "Pergunte a fonte de cada notícia."],
  14: ["Rio-Mundo", "Atravesse o rio de balsa e fuja dos Redemoinhos de boato.", "Timing: espere o redemoinho passar."],
  15: ["Boca do Igarapé", "Com Raiza, proteja a Floresta em Pé contra a desinformação.", "Cada notícia precisa de fonte."],
  16: ["O Boato", "Ouça as 3 fontes do boato e descubra de onde ele veio.", "Ninguém é vilão: o boato nasceu do medo."],
  17: ["Cacimba Grande", "Cruze o sertão sob o calor e ache sombra. Valdemar guarda a leitura do lugar.", "Fique na sombra para não perder Ânimo."],
  18: ["Alto da Chapada", "Suba a chapada e olhe o território de cima.", "Os sinais do lugar dizem mais que números soltos."],
  19: ["Cuidado × Dado", "Use o Leitor de Sinais: separe cuidado de vigilância.", "Coletar dado só vale se serve a quem foi coletado."],
  20: ["O Gráfico que Mente", "Enfrente o Sr. Prata: mostre o que o gráfico esconde.", "Pergunte o que ficou fora do gráfico."],
  21: ["Pouso das Garças", "Cruze as tábuas que sobem e descem no ritmo da maré.", "Cada tábua tem seu tempo: observe antes de pular."],
  22: ["A Vila na Cheia", "Duas ações para ajudar a vila alagada.", "Escolha o que traz mais gente junto."],
  23: ["A Roda das Três Crises", "Mande a Roda decidir com o Livro de Leis, e lembre da voz ausente.", "Quem não está na roda também precisa ser ouvido."],
  24: ["A Descida à Névoa", "Desça com Iolanda e traduza os Ecos da névoa.", "O Branco some quando você o verte."],
  25: ["A Fila das 72 Horas", "Aguente o relógio da burocracia sem perder a calma.", "O tempo corre: priorize o essencial."],
  26: ["Fragmento do Jequitibá", "Plante mudas que viram pontes e use o segundo pulo.", "Cada muda precisa de espaço para crescer."],
  27: ["A Roda dos Sonhos", "Modo Obra: junte sonhos da comunidade num plano comum.", "Sonho sem prioridade vira promessa vazia."],
  28: ["Baixada do Lamaçal", "Crie pontes e atravesse a lama.", "Observe o chão antes de saltar."],
  29: ["O Orçamento que Acabou", "Com Vintém e Nair, faça o dinheiro acabado render.", "Um bom plano começa pelo que é urgente."],
  30: ["Enseada do Siri", "Cruze a maré e a cerca da enseada.", "Observe a maré: ela muda a passagem."],
  31: ["Corredores de Mandorra", "Convença o Regente Honório a abrir espaço.", "Procure o ponto em comum antes do conflito."],
  32: ["Salão de Veludara", "Resolva o dilema de Rosinha, Cassiano e Eulália.", "Nem toda saída é limpa: escolha o que cuida de todos."],
  33: ["Portão de Ferrolho", "Passe o Portão: respeite as regras e procure a brecha justa.", "Falar com o guarda custa menos que forçar."],
  34: ["A Porta Fechada", "Faça a Pressão Coordenada com 5 territórios.", "Junte todos os aliados que já conheceu."],
  35: ["A Névoa Muda de Volta", "Volte à Névoa com aliados e verta os Brancos.", "Os aliados iluminam: use Q perto de cada Branco."],
  36: ["A Subida da Torre", "Traduza as 7 palavras-chave de baixo para cima.", "Cada andar fala uma Língua diferente."],
  37: ["A Roda Aberta e o Monólogo", "Reúna as delegações e responda ao Monólogo sem calá-lo.", "Ele também tem medo: responda ao medo."],
  38: ["A Devolutiva e o Novo Ciclo", "Conte de volta à comunidade o que foi decidido.", "Fechar o ciclo é parte do trabalho."]
};

/* ---------- Ruídos e Falas: sistema genérico de Verter (bíblia: Línguas, Ruídos, Lentes) ---------- */
var FALA = { // Falas (Línguas) que o Entendente pode verter sobre um Ruído; só a Língua do Ruído o transforma
  'Ordem': 'Mando o Ruído calar a boca.',
  'Dado': 'Jogo um número na cara dele, sem escutar.',
  'Meias-palavras': 'Digo qualquer coisa vaga para ele sossegar.',
  'Relato': 'Escuto e conto o relato inteiro.'
};
var RUIDOS = {
  eco: { nome: 'Eco-de-Boca', lingua: 'Relato', ph: ['"não adianta..."', '"já fizemos isso..."', '"de novo?..."'], tr: ['"Não adianta" quer dizer: a gente perdeu e ninguém ouviu.', '"Já fizemos isso" quer dizer: a gente se cansou de começar sem terminar.', '"De novo?" quer dizer: eu tenho medo de me importar outra vez.'], ok: 'O Eco virou um degrau, arrumado no lugar.', err: ['Ordem', 'Dado'], dica: 'Escute o relato inteiro antes de responder.' },
  carimbo: { nome: 'Carimbo', lingua: 'Oficialês', cor: 0xd8b060, ph: ['"O assunto encontra-se em análise."', '"Falta o Anexo K, via original."', '"Protocolo suspenso: campo 14 em branco."'], tr: ['Traduzo o pedido: quem pede e o quê, em duas linhas.', 'Traduzo: ele só precisa de um papel; o resto é do sistema.', 'Traduzo: o campo 14 é o endereço; eu preencho e sigo.'], ok: 'O Carimbo abriu como uma porta. Cabe gente.', err: ['Relato', 'Meias-palavras'], dica: 'Traduza o pedido: diga o que é preciso, em poucas linhas.' },
  letreiro: { nome: 'Letreiro', lingua: 'Manchetês', cor: 0xff7a7a, ph: ['"ESCÂNDALO! A VILA VAI SUMIR!"', '"URGENTE: NÃO É O QUE PARECE!"', '"VOCÊ NÃO VAI ACREDITAR!"'], tr: ['Verto Fato verificado: o que houve, quando e quem confirma.', 'Verto Fato verificado: de onde veio a notícia e quem checou.', 'Verto Fato verificado: o que está provado e o que é boato.'], ok: 'O Letreiro apagou e mostrou a história inteira.', err: ['Ordem', 'Dado'], dica: 'Letreiro grita: devolva o fato verificado, sem gritar.' },
  redemoinho: { nome: 'Redemoinho', lingua: 'Caminho', ph: ['"dizem por aí... dizem..."', '"roda, roda, roda..."'], tr: ['Verto Caminho: mostro por onde o boato passou e onde ele para.', 'Verto Caminho: marco a saída da corrente, passo a passo.'], ok: 'O Redemoinho virou trilho de balsa.', err: ['Ordem', 'Meias-palavras'], dica: 'Redemoinho gira: ofereça um caminho, não um grito.' },
  febre: { nome: 'Febre-Mosca', lingua: 'Cuidado', ph: ['"febre... febre..."', '"água parada..."'], tr: ['"Febre" quer dizer: a gente precisa de cuidado antes de ter número.', '"Água parada" quer dizer: cada caixa-d\'água sem tampa é um criadouro.'], ok: 'A Febre-Mosca virou um vaga-lume que ilumina.', err: ['Dado', 'Ordem'], dica: 'Seque a água e cuide: Cuidado vem antes do número.' },
  seca: { nome: 'Seca-Rachada', lingua: 'Terra', ph: ['"não chove..."', '"a terra rachou..."'], tr: ['Verto Terra: planto uma semente na rachadura.', 'Verto Terra: guardo a água para a próxima travessia.'], ok: 'A rachadura virou um cipó que sobe.', err: ['Meias-palavras', 'Dado'], dica: 'A terra pede semente e espera, não discurso.' },
  branco: { nome: 'Branco', lingua: 'Ausência', ph: ['"sem resposta..."', '"ninguém veio..."'], tr: ['"Sem resposta" quer dizer: registre a ausência, ela também é dado.', '"Ninguém veio" quer dizer: a pergunta ainda pode ser feita.'], ok: 'O Branco virou chão firme.', err: ['Ordem', 'Meias-palavras'], dica: 'Registre o que falta: a ausência também é dado.' }
};
var KIND2R = { zeni: 'eco', free: 'eco', voz: 'eco', roda: 'eco', rumor: 'eco', rio: 'redemoinho', seca: 'seca', febre: 'febre', branco: 'branco', carimbo: 'carimbo', letreiro: 'letreiro' };
var RUIDOS_EXTRA = { 7: [['carimbo', [1100, 1900]]], 12: [['letreiro', [1300]]], 20: [['letreiro', [1100]]], 31: [['carimbo', [900, 1600]]], 33: [['carimbo', [1000]]] };
function ruidoOf(e) { return RUIDOS[KIND2R[e && e.kind] || 'eco']; }
function verterRuido(sc, e, ov, solved) {
  var lvl = sc.lvl || 0, R = ruidoOf(e), kindR = KIND2R[e.kind] || 'eco', et = ECO_TXT[lvl], i = e.i || 0, ph, tr, okm;
  if (ov) { ph = ov.ph; tr = ov.tr; okm = ov.ok; }
  else if (et && (kindR === 'branco' || kindR === 'febre')) { ph = et.ph[i % et.ph.length]; tr = et.tr[i % et.tr.length]; okm = et.ok; }
  else { ph = R.ph[i % R.ph.length]; tr = R.tr[i % R.tr.length]; okm = R.ok; }
  var opts = [{ k: R.lingua, t: 'Verter ' + R.lingua + ': ' + tr, fx: function () { chg('Entendimento', 1); E.linguas = E.linguas || {}; if (!E.linguas[R.lingua]) { E.linguas[R.lingua] = true; E.ui.toast('Língua aprendida: ' + R.lingua + ' (veja no Guia)'); } sc.dissolve(e); },
    then: [{ s: 'ARBOVIA', t: okm }, { fn: function () { if (solved) solved(); if (sc.checkEcos) sc.checkEcos(); } }] }];
  R.err.forEach(function (w) { opts.push({ k: w, t: 'Verter ' + w + ': ' + FALA[w], fx: function () { if (sc.amp) sc.amp = false; else chg('Ânimo', -1); snd('bad'); if (sc.grow) sc.grow(e); }, then: [{ s: 'ARBOVIA', t: 'O ' + R.nome + ' fala ' + R.lingua + '. ' + R.dica }] }); });
  var rot = (i + lvl) % opts.length; opts = opts.slice(rot).concat(opts.slice(0, rot));
  novoTermo(R.nome);
  E.ui.run([{ s: 'RUÍDO', t: R.nome + ': ' + ph }, { ask: opts }]);
}

/* Falas curtas: caixas longas viram 2 ou mais caixas de até ~110 caracteres, cortando em fim de frase */
function splitFalas(items) {
  var out = [];
  items.forEach(function (it) {
    if (!it || typeof it !== 'object' || it.fn || it.ask || typeof it.t !== 'string' || it.t.length <= 130) { out.push(it); return; }
    var parts = it.t.match(/[^.!?…]+[.!?…]+["')\]]*\s*|[^.!?…]+$/g) || [it.t], cur = '';
    parts.forEach(function (p) {
      if (cur && (cur + p).length > 110) { out.push(Object.assign({}, it, { t: cur.trim() })); cur = ''; }
      cur += p;
    });
    if (cur.trim()) out.push(Object.assign({}, it, { t: cur.trim() }));
  });
  return out;
}

/* ---------- UI: HUD + diálogo ---------- */
var UI = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function UIScene() { Phaser.Scene.call(this, { key: 'UI' }); },
  create: function () {
    var sc = this; E.ui = this; this.busy = false; this.lock = 0;
    this.bar = pxPanel(this, -6, -12, W + 12, 72, '#fff3c4', '#e8a45a', 4, '#2a1f2d');
    this.hudT = this.add.text(258, 17, '', { fontFamily: FONT, fontSize: '17px', fontStyle: 'bold', color: '#3b2a2a' }); this.hudI = this.add.container(0, 0);
    if (window.ENT_DEMO) this.demoT = this.add.text(8, BARH + 6, 'VERSÃO DE TESTE · DEMO', { fontFamily: FONT, fontSize: '15px', fontStyle: 'bold', color: '#fff8e1', backgroundColor: '#d1442e', padding: { x: 8, y: 3 } }).setDepth(45);
    this.toastT = this.add.text(W / 2, 72, '', { fontFamily: FONT, fontSize: '20px', color: '#ffffff', backgroundColor: '#14213d', padding: { x: 14, y: 7 } }).setOrigin(0.5, 0).setAlpha(0).setDepth(50);
    this.promptT = this.add.text(0, 0, '', { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#ffffff', backgroundColor: '#14213d', padding: { x: 9, y: 4 } }).setOrigin(0.5, 1).setVisible(false).setDepth(40);
    this.box = this.add.container(0, 0).setVisible(false).setDepth(30);
    this.boxBg = pxPanel(this, 40, 520, 1200, 180, '#14213d', '#e8a45a', 4, '#0a1020');
    this.pFrame = pxPanel(this, 60, 540, 140, 140, '#bfe8ff', '#8a96b0', 3, '#2a1f2d'); this.pImg = this.add.image(130, 612, 'p_arb').setScale(6);
    this.nameT = this.add.text(64, 530, '', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#3b2a2a', padding: { x: 8, y: 2 } });
    this.bodyT = this.add.text(64, 570, '', { fontFamily: FONT, fontSize: '23px', color: '#ffffff', wordWrap: { width: 1150 }, lineSpacing: 5 });
    this.hintT = this.add.text(1220, 680, (document.documentElement.classList.contains('touch') ? 'Toque para continuar' : '[E] continuar'), { fontFamily: FONT, fontSize: (document.documentElement.classList.contains('touch') ? '19px' : '15px'), color: '#ffd23a' }).setOrigin(1, 1);
    this.box.add([this.boxBg, this.pFrame, this.pImg, this.nameT, this.bodyT, this.hintT]);
    this.fpsT = this.add.text(W - 8, 64, '', { fontFamily: 'monospace', fontSize: '14px', color: '#9fe8a0', backgroundColor: '#000000aa' }).setOrigin(1, 0).setVisible(false).setDepth(60);
    this.cad = this.add.container(0, 0).setVisible(false).setDepth(70);
    this.guia = this.add.container(0, 0).setVisible(false).setDepth(80); this.gTab = 0;
    var TOUCH = document.documentElement.classList.contains('touch'); E.touch = TOUCH;
    function hudBtn(x, label, fn) { var b = sc.add.text(x, TOUCH ? 10 : 15, TOUCH ? label.replace(/ \[[A-Z]\]/, '') : label, { fontFamily: FONT, fontSize: TOUCH ? '20px' : '17px', fontStyle: 'bold', color: '#3b2a2a', backgroundColor: '#ffd23a', padding: TOUCH ? { x: 14, y: 9 } : { x: 8, y: 4 } }).setInteractive({ useHandCursor: true });
      b.on('pointerover', function () { b.setBackgroundColor('#ffe680'); }); b.on('pointerout', function () { b.setBackgroundColor('#ffd23a'); }); b.on('pointerdown', fn); b.setDepth(5); return b; }
    this.btnGuia = hudBtn(16, '? Guia [G]', function () { sc.toggleGuia(); });
    this.btnCad = hudBtn(130, 'Caderno [C]', function () { sc.toggleCaderno(); });
    this.som = this.add.container(0, 0).setVisible(false).setDepth(85); this.somSel = 0; this.somRef = {};
    this.btnSom = hudBtn(752, '♪ Som', function () { sc.toggleSom(); });
    this.abrirAtiv = function () {
      if (sc.busy || sc.mode) return; var a = sc.game.scene.getScenes(true).filter(function (x) { return x.scene.key === 'World' || x.scene.key === 'Regiao'; })[0];
      if (!a) { sc.toast('As Atividades abrem no mapa. Saia da fase com Esc.'); return; }
      a.leaving = true; a.scene.start('AtivMenu', { from: a.scene.key === 'Regiao' ? { scene: 'Regiao', data: { dom: a.dom } } : { scene: 'World' } });
    };
    this.btnAtiv = hudBtn(842, '★ Atividades [F]', function () { sc.abrirAtiv(); });
    this.ods = this.add.container(0, 0).setVisible(false).setDepth(70);
    this.btnOds = hudBtn(1004, 'ODS [O]', function () { sc.toggleODS(); });
    this.input.keyboard.on('keydown-O', function () { sc.toggleODS(); });
    if (TOUCH) { var gx = 16; [this.btnGuia, this.btnCad].forEach(function (b) { b.x = gx; gx += b.displayWidth + 10; }); this.hudT.setPosition(gx + 10, 20); var rx = 1090; [this.btnOds, this.btnAtiv, this.btnSom].forEach(function (b) { rx -= b.displayWidth; b.x = rx; rx -= 12; }); }
    if (E.mundo) { this.btnMural = hudBtn(W - 124, 'Mural [N]', function () { if (!sc.busy && !sc.mode) mundoMural(true); }); this.btnMural.setPosition(W - this.btnMural.displayWidth - 12, BARH + (TOUCH ? 12 : 8)); this.input.keyboard.on('keydown-N', function () { if (!sc.busy && !sc.mode) mundoMural(); }); }
    // zoom do mapa (Mapa-Mundo e mapas dos Reinos): botões +/−, roda do mouse e teclas + − 0
    this.zoomBox = this.add.container(0, 0).setDepth(60).setVisible(false);
    function zbtn(y, label, fn) { var b = sc.add.text(W - 50, y, label, { fontFamily: FONT, fontSize: '30px', fontStyle: 'bold', color: '#3b2a2a', backgroundColor: '#ffd23a', padding: { x: 13, y: 2 } }).setOrigin(0.5).setInteractive({ useHandCursor: true }); b.on('pointerover', function () { b.setBackgroundColor('#ffe680'); }); b.on('pointerout', function () { b.setBackgroundColor('#ffd23a'); }); b.on('pointerdown', fn); return b; }
    this.zoomT = this.add.text(W - 50, H - 118, '100%', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 4, y: 1 } }).setOrigin(0.5);
    this.zoomBox.add([zbtn(H - 160, '+', function () { sc.mapZoom(0.15); }), this.zoomT, zbtn(H - 76, '−', function () { sc.mapZoom(-0.15); })]);
    this.input.on('wheel', function (p, go, dx, dy) { if (!sc.busy && sc.zoomBox.visible) sc.mapZoom(dy > 0 ? -0.1 : 0.1); });
    this.input.keyboard.on('keydown', function (e) { if (sc.busy || !sc.zoomBox.visible) return; if (e.key === '+' || e.key === '=') sc.mapZoom(0.15); else if (e.key === '-' || e.key === '_') sc.mapZoom(-0.15); else if (e.key === '0') sc.mapZoom(0, true); });
    this.input.keyboard.on('keydown-G', function () { sc.toggleGuia(); });
    this.input.keyboard.on('keydown-K', function () {
      if (sc.busy) return; var m = sc.scene.manager; if (m.isActive('Trecho') || m.isActive('Sala') || m.isActive('Creator')) { sc.toast('Troque o modo no mapa (fora das fases).'); return; }
      E.modo = E.modo === 'classico' ? 'caminho' : 'classico'; E.persist();
      sc.toast(E.modo === 'classico' ? 'Modo Clássico: cada Reino entra direto na próxima fase (K)' : 'Modo Caminho: cada Reino tem um mapa com as fases em sequência (K)');
      if (E.modo === 'classico' && m.isActive('Regiao')) { m.stop('Regiao'); m.start('World'); }
    });
    this.input.keyboard.on('keydown-LEFT', function () { if (sc.mode === 'guia') sc.guiaTab(-1); else if (sc.mode === 'som') sc.somAdj(-0.1); });
    this.input.keyboard.on('keydown-RIGHT', function () { if (sc.mode === 'guia') sc.guiaTab(1); else if (sc.mode === 'som') sc.somAdj(0.1); });
    this.input.keyboard.on('keydown-UP', function () { if (sc.mode === 'som') { sc.somSel = 0; sc.somUpd(); } });
    this.input.keyboard.on('keydown-DOWN', function () { if (sc.mode === 'som') { sc.somSel = 1; sc.somUpd(); } });
    this.input.keyboard.on('keydown-V', function () { E.assist = !E.assist; E.persist(); sc.toast(E.assist ? 'Modo assistido ligado (V): conversas esperam mais e erros não custam Ânimo' : 'Modo assistido desligado (V)'); });
    this.input.keyboard.on('keydown-F', function () { sc.abrirAtiv(); });
    this.input.keyboard.on('keydown-L', function () { E.lite = !E.lite; sc.applyLite(); sc.toast(E.lite ? 'Modo leve ligado (L)' : 'Modo leve desligado (L)'); });
    var self0 = this; this.input.keyboard.on('keydown-C', function () { self0.toggleCaderno(); });
    this.input.keyboard.on('keydown-M', function () { if (window.Snd) { sc.toast(Snd.toggleMute() ? 'Som desligado (M)' : 'Som ligado (M)'); if (sc.mode === 'som') sc.somUpd(); } });
    this.input.keyboard.on('keydown-F3', function () { sc.fpsT.setVisible(!sc.fpsT.visible); });
    var k = this.input.keyboard.addKeys('E,SPACE,ENTER,UP,DOWN,W,S,ONE,TWO,THREE');
    this.keys = k; this.mode = null;
    this.hud();
    E.ev = new Phaser.Events.EventEmitter();
  },
  closeDialog: function () {
    this.mode = null; this.cb = null; this.busy = false; this.box.setVisible(false); this.lock = this.time.now + 150; E.persist();
    if (this.q && this.q.length) { var n = this.q.shift(); this.run(n[0], n[1]); }
  },
  hud: function () {
    if (!this.hudT) return;
    var r = E.rec, self = this;
    this.hudT.setText('Lua ' + E.lua + '/9   Saberes ' + r.Saberes + '  Meios ' + r.Meios + '  Rede ' + r.Rede + '  Entend. ' + r.Entendimento);
    this.hudI.removeAll(true);
    var n = Math.max(5, r['Ânimo']); for (var i = 0; i < n; i++) this.hudI.add(this.add.image(W - 40 - i * 30, 22, i < r['Ânimo'] ? 'coracao' : 'coracao_vazio').setScale(3));
    for (var j = 0; j < 9; j++) this.hudI.add(this.add.image(W - 30 - j * 20, 44, j < E.gotas ? 'gota' : 'gota_vazia').setScale(2));
  },
  mapZoom: function (d, reset) {
    var m = this.scene.manager, key = m.isActive('World') ? 'World' : m.isActive('Regiao') ? 'Regiao' : null; if (!key) return;
    var cam = m.getScene(key).cameras.main, b = cam.getBounds(), mn = Math.max(0.45, W / b.width, (H - BARH) / b.height);
    E.mapZoom = reset ? 1 : Phaser.Math.Clamp(Math.round(((E.mapZoom || 1) + d) * 100) / 100, mn, 1.6); cam.setZoom(E.mapZoom); this.zoomT.setText(Math.round(E.mapZoom * 100) + '%');
  },
  toggleSom: function () {
    if (this.mode === 'som') { this.closeSom(); return; }
    if (this.busy || this.cad.visible) return;
    this.busy = true; this.mode = 'som'; this.somSel = 0; this.promptT.setVisible(false); this.drawSom(); snd('ask');
  },
  closeSom: function () {
    this.som.setVisible(false); this.mode = null; this.busy = false; this.lock = this.time.now + 150;
    if (this.q && this.q.length) { var n = this.q.shift(); this.run(n[0], n[1]); }
  },
  somAdj: function (d) { var k = this.somSel ? 's' : 'm'; if (window.Snd) { Snd.setVol(k, Math.round((Snd.getVol(k) + d) * 10) / 10); snd('move'); } this.somUpd(); },
  somSet: function (k, v) { if (window.Snd) Snd.setVol(k, Math.round(v * 20) / 20); this.somUpd(); },
  somUpd: function () {
    var R = this.somRef, self = this; if (!R.m) return;
    ['m', 's'].forEach(function (k, i) {
      var v = window.Snd ? Snd.getVol(k) : 1, r = R[k];
      r.fill.setDisplaySize(Math.max(2, 440 * v), 14); r.knob.x = 380 + 440 * v; r.txt.setText(Math.round(v * 100) + '%'); r.lab.setText((self.somSel === i ? '▶ ' : '   ') + r.nome);
    });
    R.mute.setText(window.Snd && Snd.muted() ? '🔇 Som desligado: clique para ligar [M]' : '🔊 Som ligado: clique para silenciar tudo [M]');
  },
  drawSom: function () {
    var sc = this, g = this.som; g.removeAll(true); this.somRef = {};
    g.add([this.add.rectangle(0, 0, W, H, 0x000000, 0.45).setOrigin(0, 0).setInteractive(), pxPanel(this, 300, 170, 680, 380, '#fff3c4', '#e8a45a', 4, '#2a1f2d'),
      this.add.text(640, 190, 'Som do jogo', { fontFamily: FONT, fontSize: '30px', fontStyle: 'bold', color: '#c8561a' }).setOrigin(0.5, 0)]);
    [['m', 'Música (trilha sonora)', 290], ['s', 'Efeitos sonoros', 380]].forEach(function (r, i) {
      var k = r[0], y = r[2], lab = sc.add.text(380, y - 38, r[1], { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a' });
      var bg = pxPanel(sc, 376, y - 14, 448, 28, '#d9c9a0', '#8a6a45', 3, '#2a1f2d'), fill = sc.add.image(380, y, 'px').setOrigin(0, 0.5).setTint(0xc8561a).setDisplaySize(440, 14);
      var knob = pxDisc(sc, 820, y, 18, '#ffd23a', '#3b2a2a'), txt = sc.add.text(850, y, '100%', { fontFamily: FONT, fontSize: '20px', color: '#3b2a2a' }).setOrigin(0, 0.5);
      var hit = sc.add.rectangle(360, y - 22, 480, 44, 0xffffff, 0.001).setOrigin(0, 0).setInteractive({ useHandCursor: true });
      function setFromPointer(p) { sc.somSel = i; sc.somSet(k, (p.x - 380) / 440); }
      hit.on('pointerdown', function (p) { setFromPointer(p); }); hit.on('pointermove', function (p) { if (p.isDown) setFromPointer(p); });
      g.add([lab, bg, fill, knob, txt, hit]); sc.somRef[k] = { fill: fill, knob: knob, txt: txt, lab: lab, nome: r[1] };
    });
    var mute = this.add.text(640, 455, '', { fontFamily: FONT, fontSize: '19px', fontStyle: 'bold', color: '#3b2a2a', backgroundColor: '#ffd23a', padding: { x: 12, y: 6 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    mute.on('pointerdown', function () { if (window.Snd) Snd.toggleMute(); sc.somUpd(); }); this.somRef.mute = mute;
    var x = this.add.text(950, 178, ' X ', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c0392b' }).setOrigin(1, 0).setInteractive({ useHandCursor: true }); x.on('pointerdown', function () { sc.closeSom(); });
    g.add([mute, x, this.add.text(960, 530, '↑↓ escolher · ←→ ajustar · [M] silenciar · [E] fechar', { fontFamily: FONT, fontSize: '15px', color: '#8a6a45' }).setOrigin(1, 1)]);
    g.setVisible(true); this.somUpd();
  },
  toggleGuia: function () {
    if (this.mode === 'guia') { this.closeGuia(); return; }
    if (this.busy || this.cad.visible) return;
    this.busy = true; this.mode = 'guia'; this.promptT.setVisible(false);
    this.gTab = E.guiaVisto ? 3 : 0; if (!E.guiaVisto) E.guiaVisto = true;
    this.drawGuia(); snd('ask');
  },
  closeGuia: function () {
    this.guia.setVisible(false); this.mode = null; this.busy = false; this.lock = this.time.now + 150;
    if (this.q && this.q.length) { var n = this.q.shift(); this.run(n[0], n[1]); }
  },
  guiaTab: function (d) { this.gTab = (this.gTab + d + GUIA_TABS.length) % GUIA_TABS.length; this.drawGuia(); snd('move'); },
  drawGuia: function () {
    var sc = this, g = this.guia, lv = E.curLvl || 0, TX = { fontFamily: FONT, fontSize: '19px', color: '#3b2a2a', wordWrap: { width: 920 }, lineSpacing: 4 };
    g.removeAll(true);
    g.add([this.add.rectangle(0, 0, W, H, 0x000000, 0.45).setOrigin(0, 0).setInteractive(), pxPanel(this, 140, 70, 1000, 580, '#fff3c4', '#e8a45a', 4, '#2a1f2d')]);
    GUIA_TABS.forEach(function (t, i) {
      var b = sc.add.text(160 + i * 192, 82, t, { fontFamily: FONT, fontSize: '19px', fontStyle: 'bold', color: i === sc.gTab ? '#ffffff' : '#3b2a2a', backgroundColor: i === sc.gTab ? '#c8561a' : '#ffd23a', padding: { x: 12, y: 6 } }).setInteractive({ useHandCursor: true });
      b.on('pointerdown', function () { sc.gTab = i; sc.drawGuia(); snd('move'); }); g.add(b);
    });
    var y = 140, tab = this.gTab, sty = function (c, sz, b) { return { fontFamily: FONT, fontSize: sz + 'px', color: c, fontStyle: b ? 'bold' : 'normal', wordWrap: { width: 920 }, lineSpacing: 4 }; };
    function para(t, st) { var o = sc.add.text(180, y, t, st || TX); g.add(o); y += o.height + 12; }
    if (tab === 0) { para('A História de Veredália', sty('#c8561a', 26, 1)); GUIA[0].forEach(function (t) { para(t); }); }
    else if (tab === 1) { para('O Mundo', sty('#c8561a', 26, 1)); GUIA[1].forEach(function (t) { para(t); }); }
    else if (tab === 2) { para('Como jogar', sty('#c8561a', 26, 1)); GUIA_COMO.forEach(function (t) { para(t); }); }
    else if (tab === 3) { var o = OBJ[lv] || OBJ[0]; para('Esta fase: ' + o[0], sty('#c8561a', 26, 1)); para('Objetivo', sty('#1f9a3c', 20, 1)); para(o[1]); para('Dica', sty('#3a6fe8', 20, 1)); para(o[2]);
      if (lv > 0) para('Fase ' + lv + ' de 38 · Lua ' + E.lua + '/9 · gotas ' + E.gotas + '/9', sty('#8a6a45', 16)); }
    else { para('Glossário', sty('#c8561a', 26, 1)); GUIA_GLOS.forEach(function (d) { var a = sc.add.text(180, y, d[0] + ': ', sty('#c8561a', 18, 1)); var b = sc.add.text(180 + a.width, y, d[1], { fontFamily: FONT, fontSize: '18px', color: '#3b2a2a', wordWrap: { width: 920 - a.width } }); g.add([a, b]); y += Math.max(a.height, b.height) + 8; }); }
    var x = this.add.text(1120, 80, ' X ', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c0392b' }).setInteractive({ useHandCursor: true }); x.on('pointerdown', function () { sc.closeGuia(); });
    g.add([x, this.add.text(1120, 636, '← → trocar aba · [G] ou [E] fechar', { fontFamily: FONT, fontSize: '15px', color: '#8a6a45' }).setOrigin(1, 1)]);
    g.setVisible(true);
  },
  applyLite: function () {
    var scs = this.game.scene.getScenes(true), lite = !!E.lite;
    scs.forEach(function (s) {
      if (s.hillsL) s.hillsL.forEach(function (h) { h[0].setVisible(!lite); });
      if (s.children && s.children.list) s.children.list.forEach(function (c) { if (c.texture && /^nuvem/.test(c.texture.key)) c.setVisible(!lite); });
    });
  },
  toggleCaderno: function () {
    if (this.busy) return;
    if (this.cad.visible) { this.cad.setVisible(false); return; }
    this.cad.removeAll(true);
    var bg = pxPanel(this, 140, 90, 1000, 540, '#fff3c4', '#e8a45a', 4, '#2a1f2d');
    this.cad.add([bg, this.add.text(640, 108, 'Caderno de Traduções', { fontFamily: FONT, fontSize: '30px', fontStyle: 'bold', color: '#c8561a' }).setOrigin(0.5, 0),
      this.add.text(180, 160, 'O que a gente diz', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#1f9a3c' }), this.add.text(700, 160, 'Em Oficialês', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3a6fe8' })]);
    if (!E.caderno.length) this.cad.add(this.add.text(640, 340, 'Ainda vazio. As palavras que você traduzir aparecem aqui.', { fontFamily: FONT, fontSize: '20px', color: '#6a4a2a' }).setOrigin(0.5));
    var y = 200, self = this; E.caderno.forEach(function (w) {
      self.cad.add([self.add.text(180, y, w.k, { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#c8561a' }),
        self.add.text(180, y + 24, w.p, { fontFamily: FONT, fontSize: '18px', color: '#3b2a2a', wordWrap: { width: 480 } }),
        self.add.text(700, y + 24, w.o, { fontFamily: FONT, fontSize: '18px', color: '#2a4a9a', wordWrap: { width: 400 } })]); y += 68;
    });
    this.cad.add(this.add.text(1120, 612, '[C] fechar', { fontFamily: FONT, fontSize: '15px', color: '#8a6a45' }).setOrigin(1, 1));
    this.cad.setVisible(true);
  },
  toggleODS: function () {
    if (this.busy || !window.FAT) return;
    if (this.ods.visible) { this.ods.setVisible(false); return; }
    if (this.cad.visible) this.cad.setVisible(false);
    var self = this, R = odsResumo(), c = this.ods; c.removeAll(true);
    c.add([pxPanel(this, 140, 90, 1000, 540, '#fff3c4', '#e8a45a', 4, '#2a1f2d'),
      this.add.text(640, 104, 'Selos dos ODS · Agenda 2030', { fontFamily: FONT, fontSize: '28px', fontStyle: 'bold', color: '#c8561a' }).setOrigin(0.5, 0),
      this.add.text(640, 140, R.n + ' de ' + window.FAT.probs.length + ' problemas trabalhados · cada Selo se ganha concluindo uma fase desse tema', { fontFamily: FONT, fontSize: '16px', color: '#6a4a2a' }).setOrigin(0.5, 0)]);
    for (var o = 1; o <= 18; o++) {
      (function (o) {
        var col = (o - 1) % 6, row = Math.floor((o - 1) / 6), x = 168 + col * 160, y = 172 + row * 112, got = !!R.g[o], cor = got ? Phaser.Display.Color.HexStringToColor(ODS_COR[o]).color : 0xb9ad94;
        c.add(self.add.rectangle(x, y, 148, 102, cor).setOrigin(0).setStrokeStyle(3, 0x2a1f2d));
        c.add(self.add.text(x + 8, y + 4, String(o), { fontFamily: FONT, fontSize: '34px', fontStyle: 'bold', color: got ? '#ffffff' : '#7a6f5a' }));
        c.add(self.add.text(x + 74, y + 8, got ? '✓ Selo' : 'Sem selo', { fontFamily: FONT, fontSize: '14px', fontStyle: 'bold', color: got ? '#ffffff' : '#7a6f5a' }));
        c.add(self.add.text(x + 8, y + 48, ODS_NOME[o], { fontFamily: FONT, fontSize: '13px', color: got ? '#ffffff' : '#6a5f4a', wordWrap: { width: 134 } }));
        c.add(self.add.text(x + 140, y + 94, (R.g[o] || 0) + '/' + (R.tot[o] || 0), { fontFamily: FONT, fontSize: '13px', color: got ? '#ffffff' : '#6a5f4a' }).setOrigin(1, 1));
      })(o);
    }
    c.add(this.add.text(180, 512, 'Os 6 Eixos da Cartografia Social', { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#3b2a2a' }));
    window.FAT.eixos.forEach(function (ex, i) {
      var x = 168 + i * 160, e = R.eix[ex.n] || [0, 0];
      c.add(self.add.rectangle(x, 538, 148, 64,Phaser.Display.Color.HexStringToColor(ex.cor).color).setOrigin(0).setStrokeStyle(3, 0x2a1f2d));
      c.add(self.add.text(x + 6, 543, 'Eixo ' + ex.n + ' · ' + e[0] + '/' + e[1], { fontFamily: FONT, fontSize: '14px', fontStyle: 'bold', color: '#ffffff' }));
      c.add(self.add.text(x + 6, 561, ex.titulo, { fontFamily: FONT, fontSize: '11px', color: '#ffffff', wordWrap: { width: 138 } }));
    });
    c.add(this.add.text(1120, 612, '[O] fechar', { fontFamily: FONT, fontSize: '15px', color: '#8a6a45' }).setOrigin(1, 1));
    c.setVisible(true);
  },
  toast: function (t) {
    this.toastT.setText(t).setAlpha(1); this.tweens.killTweensOf(this.toastT);
    this.tweens.add({ targets: this.toastT, alpha: 0, delay: 2600, duration: 600 });
  },
  prompt: function (x, y, t) { if (!t) { this.promptT.setVisible(false); return; } this.promptT.setText(t).setPosition(x, y).setVisible(true); },
  run: function (items, done) {
    var self = this;
    // fila: se já há conversa em andamento (ex.: efeito que abre outra fala), espera a atual terminar
    if (this.busy) { (this.q = this.q || []).push([items, done]); return; }
    this.busy = true; this.lock = this.time.now + 250;
    this.promptT.setVisible(false);
    this._run(items, function () {
      self.busy = false; self.box.setVisible(false); self.mode = null; self.lock = self.time.now + 150; E.persist();
      try { if (done) done(); } catch (e) { console.error(e); }
      if (!self.busy && self.q && self.q.length) { var n = self.q.shift(); self.run(n[0], n[1]); }
    });
  },
  _run: function (items, done) {
    var self = this, i = 0;
    if (!Array.isArray(items)) items = items ? [items] : [];
    items = splitFalas(items);
    function next() {
      if (i >= items.length) { done(); return; }
      var it = items[i++];
      // um erro em um item não pode travar a conversa: registra e segue
      if (typeof it === 'function' || it.fn) { try { (it.fn || it)(); } catch (e) { console.error(e); } next(); }
      else if (it.ask) self.choose(it.ask, function (c) {
        var sub = [];
        try { if (c.fx) c.fx(); sub = typeof c.then === 'function' ? c.then() : (c.then || []); } catch (e) { console.error(e); }
        self._run(sub, next);
      });
      else self.line(it, next);
    }
    next();
  },
  line: function (it, cb) {
    var col = COR[it.s] || '#fff', pk = PORTRAIT[it.s];
    this.box.setVisible(true); this.boxBg.setStrokeStyle(4, Phaser.Display.Color.HexStringToColor(col).color);
    this.setPortrait(pk, col);
    this.nameT.setText(it.s || '').setBackgroundColor(it.s ? col : null); this.bodyT.setText(it.t); this.hintT.setText(E.touch ? 'Toque para continuar · fecha em 7 s' : '[E] continuar · fecha em 7 s');
    this.mode = 'line'; this.cb = cb; this.lock = this.time.now + 180; this.idleAt = this.time.now; snd('blip');
  },
  setPortrait: function (pk, col) {
    var x = pk ? 224 : 64; this.pFrame.setVisible(!!pk); this.pImg.setVisible(!!pk); if (pk) { this.pImg.setTexture(pk); this.pFrame.setStrokeStyle(4, Phaser.Display.Color.HexStringToColor(col).color); }
    this.nameT.x = x; this.bodyT.x = x; this.bodyT.setWordWrapWidth(pk ? 990 : 1150);
  },
  choose: function (opts, cb) {
    this.box.setVisible(true); this.boxBg.setStrokeStyle(4, 0xe8a45a); this.setPortrait(null);
    this.nameT.setText('Sua escolha').setBackgroundColor('#ffd23a'); this.opts = opts; this.sel = 0; this.cb = cb; this.mode = 'choice';
    this.hintT.setText(E.touch ? 'Toque na opção · toque de novo para confirmar' : '↑↓ escolher · [E] confirmar'); this.drawChoices(); this.lock = this.time.now + 180; this.idleAt = this.time.now; snd('ask');
  },
  drawChoices: function () {
    var s = '', self = this;
    this.opts.forEach(function (o, n) { s += (n === self.sel ? '▶ ' : '   ') + '[' + o.k + '] ' + o.t + '\n'; });
    this.bodyT.setText(s);
  },
  update: function (t) {
    if (this.fpsT.visible && (this._f = (this._f || 0) + 1) % 20 === 0) this.fpsT.setText(Math.round(this.game.loop.actualFps) + ' FPS');
    var k = this.keys, JD = Phaser.Input.Keyboard.JustDown;
    var ok = JD(k.E) | JD(k.SPACE) | JD(k.ENTER), up = JD(k.UP) | JD(k.W), dn = JD(k.DOWN) | JD(k.S);
    var n1 = JD(k.ONE), n2 = JD(k.TWO), n3 = JD(k.THREE);
    // padrão do jogo: sem apertar nada por 7 s, a conversa fecha; só reabre com a tecla E
    var mg = this.scene.manager, zv = !this.busy && (mg.isActive('World') || mg.isActive('Regiao')); if (zv !== this.zoomBox.visible) this.zoomBox.setVisible(zv); if (zv) this.zoomT.setText(Math.round((E.mapZoom || 1) * 100) + '%');
    if (this.mode === 'guia') { if (ok && t > this.lock) this.closeGuia(); return; }
    if (this.mode === 'som') { if (ok && t > this.lock) this.closeSom(); return; }
    // modo leve automático: FPS baixo por ~6 s seguidos
    if ((this._lf = (this._lf || 0) + 1) % 120 === 0 && !E.lite && !E.liteOff) { var fps = this.game.loop.actualFps; this._low = fps < 24 ? (this._low || 0) + 1 : 0; if (this._low >= 3) { E.lite = true; this.applyLite(); this.toast('FPS baixo: modo leve ligado (L desliga)'); } }
    if (E.lite && (this._lf % 60 === 0)) this.applyLite();
    if (this.busy && this.mode && this.time.now - (this.idleAt || 0) > dialogMs()) { this.closeDialog(); return; }
    if (this.busy && !this.mode && t > this.lock + 300) { this.busy = false; this.box.setVisible(false); } // salvaguarda contra conversa órfã
    if (!this.busy || t < this.lock) return;
    var pad = this.input.gamepad && this.input.gamepad.pad1;
    if (pad && pad.connected) { var b = pad.buttons[2].pressed || pad.buttons[0].pressed; ok = ok || (b && !this._pb); this._pb = b; }
    if (this.mode === 'line' && ok) { var cb = this.cb; this.mode = null; cb(); }
    else if (this.mode === 'choice') {
      if (up) { this.sel = (this.sel + this.opts.length - 1) % this.opts.length; this.drawChoices(); snd('move'); this.idleAt = this.time.now; }
      if (dn) { this.sel = (this.sel + 1) % this.opts.length; this.drawChoices(); snd('move'); this.idleAt = this.time.now; }
      if (n1 && this.opts[0]) { this.sel = 0; ok = 1; } if (n2 && this.opts[1]) { this.sel = 1; ok = 1; } if (n3 && this.opts[2]) { this.sel = 2; ok = 1; }
      if (ok) { var c = this.opts[this.sel], cb2 = this.cb; this.mode = null; snd(c.k === 'P' || c.k === 'C' ? 'bad' : 'good'); cb2(c); }
    }
  }
});

/* ---------- Boot ---------- */
var Boot = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Boot() { Phaser.Scene.call(this, { key: 'Boot' }); },
  preload: function () {
    var sc = this, t = this.add.text(W / 2, H / 2, 'Carregando...', { fontFamily: FONT, fontSize: '28px', color: '#f2c14e' }).setOrigin(0.5);
    this.load.setPath('assets/'); PNGS.forEach(function (k) { sc.load.image(k, k + '.png?v=' + ASSETV); });
  },
  create: function () {
    makeTextures(this); makeAvatar(this);
    this.scene.launch('UI');
    this.scene.start(E.avatar.criado && E.avatar.pers ? 'World' : 'Creator');
  }
});

/* ---------- Criação do avatar ---------- */
var Creator = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Creator() { Phaser.Scene.call(this, { key: 'Creator' }); },
  create: function () {
    this.stage = ''; var sc = this; music('titulo'); this.cameras.main.setBackgroundColor('#8fd0ff'); this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setDepth(-40); ['colinas1', 'colinas2', 'colinas3'].forEach(function (h, i) { sc.add.image(0, 0, h).setOrigin(0, 0).setScale(4).setDepth(-30 + i); }); pxSlab(this, 0, 440, W, 192, 'solo').setDepth(-1); this.add.rectangle(0, 632, W, 88, 0x8a5a2a, 0.4).setOrigin(0, 0).setFillStyle(0x8a5a2a, 1).setDepth(-2);
    if (!E.avatar.pers) { this.escolha(); return; }
    this.add.text(W / 2, 100, 'Quem é você, Entendente?', { fontFamily: FONT, fontSize: '42px', fontStyle: 'bold', color: '#ffffff', stroke: '#3b2a2a', strokeThickness: 6 }).setOrigin(0.5);
    this.add.text(W / 2, 150, (E.nick || E.nome) + ' — escolha sua aparência (clique ou use ← → ↑ ↓, Enter para começar)', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5);
    var rows = [['pele', PELE], ['cabelo', CABELO], ['roupa', ROUPA]], self = this; this.row = 0; this.sw = [];
    self.add.text(300, 250 + 3 * 80, 'extra', { fontFamily: FONT, fontSize: '26px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0, 0.5);
    ['Nenhum', 'Óculos', 'Lenço', 'Aparelho', 'Cadeira'].forEach(function (lb, ci) {
      var r = self.add.rectangle(480 + ci * 98, 250 + 3 * 80, 90, 40, 0xf2e8d0).setStrokeStyle(3, 0x444444).setInteractive({ useHandCursor: true });
      self.add.text(480 + ci * 98, 250 + 3 * 80, lb, { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5);
      r.on('pointerdown', function () { self.row = 3; self.pick(3, ci); }); self.sw.push({ r: r, ri: 3, ci: ci });
    });
    rows.forEach(function (rw, ri) {
      self.add.text(300, 250 + ri * 80, rw[0], { fontFamily: FONT, fontSize: '26px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0, 0.5);
      rw[1].forEach(function (c, ci) {
        var r = self.add.rectangle(480 + ci * 70, 250 + ri * 80, 54, 54, c).setStrokeStyle(3, 0x444444).setInteractive({ useHandCursor: true });
        r.on('pointerdown', function () { self.row = ri; self.pick(ri, ci); });
        self.sw.push({ r: r, ri: ri, ci: ci });
      });
    });
    this.prev = this.add.image(1000, 300, 'av0').setScale(10).setOrigin(0.5);
    var b = this.add.text(W / 2, 600, '▶ Começar', { fontFamily: FONT, fontSize: '32px', color: '#1a1a1a', backgroundColor: '#f2c14e', padding: { x: 24, y: 10 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    b.on('pointerdown', function () { self.go(); });
    this.cur = this.input.keyboard.addKeys('LEFT,RIGHT,UP,DOWN,ENTER');
    this.refresh();
  },
  escolha: function () {
    var sc = this, ks = ['aurelio', 'aurora']; this.stage = 'pers'; this.psel = 0; this.cards = [];
    this.add.text(W / 2, 90, 'Escolha seu personagem', { fontFamily: FONT, fontSize: '42px', fontStyle: 'bold', color: '#ffffff', stroke: '#3b2a2a', strokeThickness: 6 }).setOrigin(0.5);
    this.add.text(W / 2, 142, (E.nick || E.nome) + ' — clique em um deles (ou use ← → e Enter)', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5);
    ks.forEach(function (k, i) {
      var P = PERS[k], x = W / 2 + (i ? 230 : -230), pv = { skin: PELE[E.avatar.pele || 0], hair: CABELO[E.avatar.cabelo || 0], shirt: ROUPA[E.avatar.roupa || 0], pants: 0x3a6fe8, hairstyle: P.hs, fem: P.fem, frame: 0 };
      addCv(sc, 'pv_' + k, personCv(pv));
      var card = sc.add.rectangle(x, 380, 330, 400, 0xf6ecd0).setStrokeStyle(4, 0x3b2a2a).setInteractive({ useHandCursor: true });
      sc.add.image(x, 350, 'pv_' + k).setScale(10).setOrigin(0.5);
      sc.add.text(x, 520, P.nome, { fontFamily: FONT, fontSize: '36px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5);
      card.on('pointerover', function () { sc.psel = i; sc.prefresh(); }); card.on('pointerdown', function () { sc.psel = i; sc.pescolhe(); });
      sc.cards.push(card);
    });
    this.cur = this.input.keyboard.addKeys('LEFT,RIGHT,UP,DOWN,ENTER,SPACE,E');
    this.prefresh();
  },
  prefresh: function () { var sc = this; this.cards.forEach(function (c, i) { c.setStrokeStyle(i === sc.psel ? 8 : 4, i === sc.psel ? 0xe8a020 : 0x3b2a2a); }); },
  pescolhe: function () { E.avatar.pers = ['aurelio', 'aurora'][this.psel]; makeAvatar(this); E.persist(); this.scene.restart(); },
  pick: function (ri, ci) { var key = ['pele', 'cabelo', 'roupa', 'extra'][ri]; E.avatar[key] = ci; makeAvatar(this); this.refresh(); },
  refresh: function () {
    var keys = ['pele', 'cabelo', 'roupa', 'extra'], self = this;
    this.sw.forEach(function (s) { s.r.setStrokeStyle(s.ci === (E.avatar[keys[s.ri]] || 0) ? 5 : 3, s.ci === (E.avatar[keys[s.ri]] || 0) ? 0xffffff : 0x3b2a2a); });
    this.prev.setTexture('av0'); this.prev.setTint(0xffffff);
    this.prev.setPosition(1000, 300);
  },
  go: function () { E.avatar.criado = true; E.persist(); this.scene.start('World'); },
  update: function () {
    if (this.stage === 'pers') { var Jp = Phaser.Input.Keyboard.JustDown, cp = this.cur; if (Jp(cp.LEFT) || Jp(cp.UP)) { this.psel = 0; this.prefresh(); } if (Jp(cp.RIGHT) || Jp(cp.DOWN)) { this.psel = 1; this.prefresh(); } if (Jp(cp.ENTER) || Jp(cp.SPACE) || Jp(cp.E)) this.pescolhe(); return; }
    var J = Phaser.Input.Keyboard.JustDown, c = this.cur, keys = ['pele', 'cabelo', 'roupa', 'extra'], nn = this.row === 3 ? 5 : 4, cv = E.avatar[keys[this.row]] || 0;
    if (J(c.UP)) this.row = (this.row + 3) % 4; if (J(c.DOWN)) this.row = (this.row + 1) % 4;
    if (J(c.LEFT)) this.pick(this.row, (cv + nn - 1) % nn);
    if (J(c.RIGHT)) this.pick(this.row, (cv + 1) % nn);
    if (J(c.ENTER)) this.go();
  }
});

/* ---------- Mapa-Mundo (visto de cima) ---------- */

/* ---------- estradas curvas (usadas no Mapa-Mundo e nos mapas dos Reinos) ---------- */
function chaikin(pts, it) {
  for (var k = 0; k < it; k++) { var o = [pts[0]]; for (var i = 0; i < pts.length - 1; i++) { var p = pts[i], q = pts[i + 1]; o.push({ x: 0.75 * p.x + 0.25 * q.x, y: 0.75 * p.y + 0.25 * q.y }, { x: 0.25 * p.x + 0.75 * q.x, y: 0.25 * p.y + 0.75 * q.y }); } o.push(pts[pts.length - 1]); pts = o; }
  return pts;
}
function samplePath(pts, step) { // pontos igualmente espaçados ao longo da linha quebrada
  var out = [{ x: pts[0].x, y: pts[0].y }], acc = 0;
  for (var i = 1; i < pts.length; i++) {
    var a = pts[i - 1], b = pts[i], d = Math.hypot(b.x - a.x, b.y - a.y), t = step - acc;
    while (t <= d) { out.push({ x: a.x + (b.x - a.x) * t / d, y: a.y + (b.y - a.y) * t / d }); t += step; }
    acc = d - (t - step);
  }
  return out;
}
function WT(x, y) { return { x: Math.round(1440 + (x - 960) * 1.5), y: Math.round(960 + (y - 640) * 1.5) }; } // afasta os Reinos entre si
var MUNDO_AGUA = function () { return false; };
var CIDK = { 'Boca do Igarapé': 'cid_boca', 'Pouso das Garças': 'cid_pouso', 'Cacimba Grande': 'cid_cacimba', 'Jequitibá': 'cid_jeq', 'Coxilha da Fronteira': 'cid_coxilha', 'Enseada do Siri': 'cid_enseada', 'Planalto Frio': 'cid_planalto', 'Babaçual': 'cid_babacual' };
var LMK = { 'Boca do Igarapé': 'lm_boca', 'Pouso das Garças': 'lm_pouso', 'Cacimba Grande': 'lm_cacimba', 'Jequitibá': 'lm_jeq', 'Coxilha da Fronteira': 'lm_coxilha', 'Enseada do Siri': 'lm_enseada', 'Planalto Frio': 'lm_planalto', 'Babaçual': 'lm_babacual' };
var ICON_LVL = { 1: 'casa', 2: 'salao', 3: 'carta', 4: 'roda', 5: 'livro', 6: 'placa', 7: 'guiche', 8: 'mapa', 9: 'gota', 10: 'obra', 11: 'mapa', 12: 'antena', 13: 'barraca', 14: 'onda', 15: 'arvore', 16: 'balao', 17: 'sol', 18: 'montanha', 19: 'lupa', 20: 'grafico', 21: 'tabua', 22: 'onda', 23: 'livro', 24: 'nevoa', 25: 'relogio', 26: 'arvore', 27: 'estrela', 28: 'tabua', 29: 'moeda', 30: 'onda', 31: 'portao', 32: 'salao', 33: 'portao', 34: 'porta', 35: 'nevoa', 36: 'torre', 37: 'roda', 38: 'carta' };
var DOMINIOS = [
  { n: 'Boca do Igarapé', b: 'Amazônia', x: 330, y: 230, c: 0x1f7a3a },
  { n: 'Pouso das Garças', b: 'Pantanal', x: 760, y: 150, c: 0x3fa7a0 },
  { n: 'Cacimba Grande', b: 'Caatinga', x: 1680, y: 290, c: 0xc98a3b },
  { n: 'Jequitibá', b: 'Mata Atlântica', x: 190, y: 640, c: 0x2f6b2f },
  { n: 'Coxilha da Fronteira', b: 'Pampa', x: 1760, y: 780, c: 0x8bb356 },
  { n: 'Enseada do Siri', b: 'Sistema Costeiro-Marinho', x: 1100, y: 1160, c: 0x4aa3d8 },
  { n: 'Planalto Frio', b: 'Terra de Passagem', x: 330, y: 1090, c: 0x9aa7b5 },
  { n: 'Babaçual', b: 'Terra de Passagem', x: 1640, y: 1130, c: 0x6fa05a }
];
DOMINIOS.forEach(function (d) { var q = WT(d.x, d.y); d.x = q.x; d.y = q.y; });
function nextLevel(nome) {
  var FR = { 'Coxilha da Fronteira': [39, 40, 41], 'Babaçual': [42, 43, 44], 'Planalto Frio': [45, 46, 47] };
  if (FR[nome]) { for (var q = 0; q < 3; q++) if (!E.flags[GEN[FR[nome][q]].flag]) return FR[nome][q]; return 0; }
  var near = { nome: nome };
  var isEns = near.nome === 'Enseada do Siri', isJeq = near.nome === 'Jequitibá', isPou = near.nome === 'Pouso das Garças', isCac = near.nome === 'Cacimba Grande', isBoca = near.nome === 'Boca do Igarapé';
  return isEns ? (!E.flags.mareOk ? 30 : !E.flags.honOk ? 31 : !E.flags.veluOk ? 32 : !E.flags.ferrolhoOk ? 33 : !E.flags.marco8 ? 34 : 0) : isJeq ? (!E.flags.corredorOk ? 26 : !E.flags.sonhosOk ? 27 : !E.flags.baixadaOk ? 28 : !E.flags.marco7 ? 29 : 0) : isPou ? (!E.flags.cheiaOk ? 21 : !E.flags.vilaOk ? 22 : !E.flags.rodaCrises ? 23 : !E.flags.nevoaOk ? 24 : !E.flags.marco6 ? 25 : 0) : isCac ? (!E.flags.valdemarOk ? 17 : !E.flags.chapadaOk ? 18 : !E.flags.cuidadoDado ? 19 : !E.flags.marco5 ? 20 : 0) : isBoca ? (!(E.flags.tiaoOk && E.flags.redem0 && E.flags.redem1) ? 14 : !E.flags.igarapeOk ? 15 : !E.flags.marco4 ? 16 : 0) : !E.flags.encontro1 ? 1 : !E.flags.salao ? 2 : !(E.flags.conv_m && E.flags.conv_i) ? 3 : !E.flags.roda ? 4 : !E.flags.varanda ? 5 : !E.flags.rota ? 6 : !E.flags.formulario ? 7 : !E.flags.mapaLeo ? 8 : !E.flags.nascente ? 9 : !E.flags.croqui ? 10 : !E.flags.marco3 ? 11 : !E.flags.rumorOk ? 12 : !E.flags.feira ? 13 : !E.flags.marco8 ? 0 : !E.flags.voltaNevoa ? 35 : !E.flags.torreOk ? 36 : !E.flags.monologoOk ? 37 : !E.flags.marco9 ? 38 : 0;
}
window.nextLevel = nextLevel;

/* ---------- Modo Caminho: cada Reino vira um mapa com as fases em lugares diferentes, liberadas em sequência ---------- */
var DOMLVL = {
  'Vila Mutirão': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 35, 36, 37, 38],
  'Boca do Igarapé': [14, 15, 16], 'Cacimba Grande': [17, 18, 19, 20], 'Pouso das Garças': [21, 22, 23, 24, 25],
  'Jequitibá': [26, 27, 28, 29], 'Enseada do Siri': [30, 31, 32, 33, 34]
};
function domOf(l) { for (var k in DOMLVL) if (DOMLVL[k].indexOf(l) >= 0) return k; return 'Vila Mutirão'; }
var NODOS = { 'Vila Mutirão': [[1], [2, 3], [4], [5, 6], [7], [8, 9, 10], [11], [12, 13], [35, 36], [37], [38]] }; // lugares do mapa que encadeiam fases vizinhas
var CHAIN = { 2: 3, 5: 6, 8: 9, 9: 10, 12: 13, 35: 36 }; // ao concluir a fase, o portal de saída leva direto à próxima do mesmo lugar
function nodesOf(name) { return NODOS[name] || (DOMLVL[name] || []).map(function (l) { return [l]; }); }
function nodeName(g) { return g.map(levelName).join(' + '); }
function domState(name) {
  var N = nodesOf(name), D = N.map(function (g) { return g[0]; }), cur = nextLevel(name), n = N.length, trava = false, i;
  if (cur) { n = 0; for (i = 0; i < N.length; i++) if (N[i].indexOf(cur) >= 0) n = i; }
  if (!cur && name === 'Vila Mutirão' && !E.flags.marco8) { for (i = 0; i < N.length; i++) if (N[i].indexOf(35) >= 0) n = i; trava = true; } // Torre só depois do Marco 8
  return { D: D, N: N, done: n, trava: trava, cur: (n < N.length && !trava) ? cur : 0 };
}
function levelName(l) { return (OBJ[l] && OBJ[l][0]) || ('Fase ' + l); }

/* ---------- Mestra Isabel: a Ciência acompanhando o Entendente em todos os Reinos ---------- */
var MES = 'MESTRA ISABEL';
var HABITO = { 'Boca do Igarapé': 'checar a fonte antes de acreditar', 'Cacimba Grande': 'ler o dado e o relato juntos', 'Pouso das Garças': 'registrar a decisão para poder conferir depois', 'Jequitibá': 'transformar sonho em plano que se pode testar', 'Enseada do Siri': 'levar evidência a quem decide' };
var REINO_IMP = {
  'Vila Mutirão': ['A Vila é o começo e o fim do caminho. Aqui você aprende a base de toda ciência: escutar antes de concluir e registrar com cuidado e ética.', 'Sem isso nada se sustenta. E é pra cá que você volta, no fim, para entregar a Devolutiva: contar a todos o que foi decidido e por quê.'],
  'Boca do Igarapé': ['No Boca do Igarapé o assunto é rumor e fonte. Ciência é checar: de onde veio a notícia, quem disse, como a gente sabe.', 'Quem aprende a desmontar um boato protege a Floresta em Pé e a Rede de Notícias, e a Nuvem do Apagamento não ganha terreno.'],
  'Cacimba Grande': ['Na Cacimba Grande você aprende a ler o dado e o relato juntos. O número mostra o que se repete; a vivência mostra o que o número não pega.', 'Ciência boa mede sem desprezar quem sente, e diz o quanto ainda não sabe.'],
  'Pouso das Garças': ['No Pouso das Garças a ciência vira decisão em grupo. Cheias e crises pedem dados, mas pedem Roda também.', 'Registrar quem falou, o que ficou acordado e quem faltou: decisão sem registro ninguém consegue conferir depois.'],
  'Jequitibá': ['No Jequitibá o saber vira plano. Plano é hipótese: se fizermos isto, esperamos aquilo.', 'Com orçamento de verdade a gente testa, ajusta e prioriza o urgente. Sonho sem prioridade vira promessa vazia.'],
  'Enseada do Siri': ['Na Enseada do Siri você leva evidência até onde o poder decide. Cinco territórios pedindo juntos, com dado e relato, pesam mais que um grito isolado.', 'É a ciência a serviço da voz coletiva.']
};
var FASE_IMP = {
  1: 'Toda investigação começa olhando e ouvindo. Aqui você conhece as pessoas e o jeito de falar de cada uma; sem isso a gente confunde discordância com mal-entendido.',
  2: 'Problema só se resolve quando se acha a causa. Salão trancado há sete anos: por quê? Perguntar e traduzir o oficialês é o primeiro método.',
  3: 'Quem não é chamado não participa. Adaptar o convite à língua de cada um é ampliar o número de vozes que a gente escuta.',
  4: 'A Roda é o laboratório da decisão coletiva: todo mundo fala, alguém registra, e o resultado pode ser conferido depois.',
  5: 'O Caderno de Traduções é o seu diário de campo. Anotar com cuidado e ética é o que separa memória de evidência.',
  6: 'Registrar sem coletar dado pessoal: boa ciência colhe só o necessário e protege quem responde.',
  7: 'Procedimento confuso esconde falhas. Traduzir o formulário gigante mostra onde o sistema trava e quem fica de fora.',
  8: 'Mudar o ponto de vista muda o que se enxerga. Pelo olhar do Léo, o mapa mostra barreiras que ninguém via; ciência inclui outros pontos de observação.',
  9: 'Relato de quem viveu o lugar é fonte. A história da água é um dado que não está em tabela nenhuma.',
  10: 'Croqui é registro de campo: desenhar o que existe de verdade, não o que a gente supõe.',
  11: 'Todo mapa é escolha de quem desenhou. Comparar o mapa pronto com o que a comunidade sabe mostra o que ficou de fora.',
  12: 'Corrigir informação errada sem humilhar é método e respeito: mostra a fonte e abre espaço para rever.',
  13: 'Banca honesta só vende o que se confirma. É o princípio de citar a fonte.',
  14: 'Rumor corre como correnteza. Saber esperar e escolher a hora certa evita ser levado por qualquer notícia.',
  15: 'Proteger a floresta em pé exige informação confiável. Aqui você aprende a checar antes de repassar.',
  16: 'Todo boato tem origem. Ouvir as três fontes mostra que ele nasce do medo, não da maldade, e que dá para desfazer sem culpar ninguém.',
  17: 'Observar o ambiente é coletar dado. Seu Valdemar lê o céu há décadas: saber popular também é método acumulado.',
  18: 'De cima se vê o padrão, mas não se ouve quem está embaixo. Série de dados pede conversa com o território.',
  19: 'O Leitor de Sinais separa cuidado de vigilância: só se justifica coletar dado quando ele serve a quem foi observado.',
  20: 'Gráfico pode enganar sem mentir: pela escala, pelo corte, pelo que ficou de fora. Perguntar o que não está no gráfico é ciência.',
  21: 'Observar o ritmo da maré antes de agir é experimentar com cuidado: cada tábua tem seu tempo.',
  22: 'Em crise é preciso escolher ações pelo efeito esperado: quais juntam mais gente e causam menos dano.',
  23: 'Decidir com o Livro de Leis e lembrar de quem não está na sala: o registro e a ausência também são dado.',
  24: 'A Névoa esconde o que ninguém registrou. Traduzir seus Ecos é trazer o invisível para a luz.',
  25: 'Prazo mostra prioridade. Com o relógio correndo, ciência é separar o urgente do importante.',
  26: 'Plano nasce como muda: precisa de espaço e de tempo. Cada ponte é uma hipótese que você testa pisando.',
  27: 'Juntar os sonhos e priorizar é transformar desejo em plano que dá para conferir depois.',
  28: 'Terreno incerto pede passo a passo: observar o chão antes de cada salto.',
  29: 'Dinheiro curto exige escolher com critério: começar pelo urgente e prestar contas.',
  30: 'Maré muda o que está firme. Reconhecer ciclos, maré alta e maré baixa, é método.',
  31: 'Para convencer quem decide, procure primeiro o ponto em comum: bom argumento parte do que o outro já aceita.',
  32: 'Nem toda saída é limpa. Pesar ganhos e perdas para todos os lados e decidir com transparência é o método num dilema real.',
  33: 'Regra é o campo onde a gente atua; conhecê-la abre brechas legítimas.',
  34: 'Uma voz isolada pesa pouco; cinco territórios com evidência pesam muito. É a pressão coordenada.',
  35: 'Voltar ao que já foi visto, com mais gente, revela o que escapou. Repetir e conferir é parte da ciência.',
  36: 'Cada andar fala uma língua. Traduzir as sete palavras-chave é provar que linguagem difícil pode ser explicada.',
  37: 'Responder ao medo sem calar quem fala: ciência convive com a divergência.',
  38: 'Devolver à comunidade o que foi decidido, e por quê. Ciência que não volta pra quem ajudou a produzir fica pela metade.'
};
function mestreBoasVindas(dom) {
  if (dom === 'Vila Mutirão') return [{ s: MES, t: 'Bom dia, Entendente! Sou a Mestra Isabel. Trabalho com ciência: o jeito de duvidar com método e de aprender com o que a gente vê e escuta.' }, { s: MES, t: 'Vou te acompanhar por todos os Reinos. Quer uma dica, ou entender por que uma fase importa? Me procure perto da saída de cada mapa.' }];
  return [{ s: MES, t: 'Chegamos em ' + dom + '. Aqui o hábito a aprender é ' + (HABITO[dom] || 'olhar com método') + '. Se precisar de uma dica, é só me chamar.' }];
}
function mestreRegiao(sc) {
  var st = sc.st, dom = sc.dom, cur = st.cur, ref = cur || st.D[Math.max(0, Math.min(st.done, st.D.length) - 1)];
  function menu() {
    return [{ ask: [
      { k: '?', t: cur ? 'Como passo da fase atual?' : 'Como estou neste Reino?', then: function () {
        if (!cur) return [{ s: MES, t: st.trava && dom === 'Vila Mutirão' ? 'A Torre ainda está fechada: ela só abre depois do Marco 8, na Enseada do Siri. Siga as outras estradas do Mapa-Mundo.' : 'Você concluiu tudo por aqui. Pode revisitar os lugares com ✓ quando quiser.' }].concat(menu());
        var o = OBJ[cur] || ['', '', '']; return [{ s: MES, t: levelName(cur) + ': ' + o[1] }, { s: MES, t: 'Minha dica: ' + o[2] }].concat(menu());
      } },
      { k: '?', t: 'Por que esta fase importa?', then: function () { return [{ s: MES, t: levelName(ref) + '. ' + (FASE_IMP[ref] || '') }].concat(menu()); } },
      { k: '?', t: 'Por que este Reino importa?', then: function () {
        var txt = (REINO_IMP[dom] || ['']).map(function (t) { return { s: MES, t: t }; });
        if (dom === 'Vila Mutirão' && st.done >= 8) txt.push({ s: MES, t: 'A Torre é o último degrau: comunicar de volta, com clareza, o que foi decidido. Ciência que não volta pra quem ajudou a produzir fica pela metade.' });
        return txt.concat(menu());
      } },
      { k: '?', t: 'Até logo, Mestra', then: [{ s: MES, t: 'Vá com calma, Entendente. Duvide com método e escute com respeito.' }] }
    ] }];
  }
  E.ui.run([{ s: MES, t: 'Pois não, Entendente? Posso ajudar com a fase de agora, com o porquê dela ou com o porquê deste Reino.' }].concat(menu()));
}
function proxDom() { // Reino da próxima fase a jogar (null se tudo concluído)
  var ordem = [['Vila Mutirão', true], ['Boca do Igarapé', !!E.flags.feira], ['Cacimba Grande', !!E.flags.marco4], ['Pouso das Garças', !!E.flags.marco5], ['Jequitibá', !!E.flags.marco6], ['Enseada do Siri', !!E.flags.marco7]];
  for (var i = 0; i < ordem.length; i++) { if (ordem[i][1] && domState(ordem[i][0]).cur) return ordem[i][0]; }
  return null;
}
function mestreMundo() {
  var ordem = [['Vila Mutirão', true], ['Boca do Igarapé', !!E.flags.feira], ['Cacimba Grande', !!E.flags.marco4], ['Pouso das Garças', !!E.flags.marco5], ['Jequitibá', !!E.flags.marco6], ['Enseada do Siri', !!E.flags.marco7]];
  function proximo() {
    for (var i = 0; i < ordem.length; i++) { if (!ordem[i][1]) continue; var st = domState(ordem[i][0]); if (st.cur) return 'Seu próximo passo é ' + ordem[i][0] + ', fase ' + (st.done + 1) + ': ' + levelName(st.cur) + '. Entre pela porta dele no mapa.'; }
    return E.flags.marco9 ? 'Você concluiu o Ciclo 1! Pode revisitar os lugares, os bônus e os bichos. Outras veredas ainda pedem Roda.' : 'Por ora o caminho está parado: conclua o Marco 8 na Enseada do Siri para a Torre da Vila se abrir.';
  }
  function menu() {
    return [{ ask: [
      { k: '?', t: 'Quem é você, Mestra?', then: function () { return [{ s: MES, t: 'Sou Isabel, mestra andarilha. Ciência, pra mim, é um jeito de perguntar: o que a gente sabe, como sabe e o que ainda não sabe.' }, { s: MES, t: 'Não vim dar ordem. Vim te ajudar a olhar: observar, anotar, comparar, duvidar do que parece certo demais e voltar pra contar o que achou.' }, { s: MES, t: 'Em Veredália a ciência anda de mãos dadas com o saber da gente. Um sem o outro enxerga pela metade.' }].concat(menu()); } },
      { k: '?', t: 'Para onde vou agora?', then: function () { return [{ s: MES, t: proximo() }].concat(menu()); } },
      { k: '?', t: 'Por que cada Reino importa?', then: function () { return [{ s: MES, t: 'Cada Reino ensina um hábito: na Vila, escutar e registrar; no Boca do Igarapé, checar a fonte; na Cacimba, ler dado e relato juntos.' }, { s: MES, t: 'No Pouso, registrar a decisão; no Jequitibá, transformar sonho em plano; na Enseada, levar evidência a quem decide. No fim, a Devolutiva fecha o ciclo.' }].concat(menu()); } },
      { k: '?', t: 'Até logo, Mestra', then: [{ s: MES, t: 'Estou por aqui, em cada Reino. É só chamar.' }] }
    ] }];
  }
  E.ui.run([{ s: MES, t: 'Olá, Entendente! O que você quer saber?' }].concat(menu()));
}
var REG_PTS = {
  'Vila Mutirão': [[220, 260], [560, 210], [900, 320], [1250, 230], [1620, 360], [1480, 640], [1130, 560], [780, 650], [420, 610], [560, 960], [1000, 1000]],
  'Boca do Igarapé': [[260, 430], [640, 250], [1000, 470]],
  'Cacimba Grande': [[200, 300], [520, 520], [850, 330], [1100, 540]],
  'Pouso das Garças': [[180, 480], [430, 260], [700, 480], [930, 260], [1130, 480]],
  'Jequitibá': [[220, 520], [480, 280], [780, 500], [1040, 300]],
  'Enseada do Siri': [[160, 300], [420, 520], [660, 270], [900, 500], [1120, 300]]
};

/* ---------- Problemas dos Eixos (Cartografia Social), ODS e Selos ----------
   Dados em js/fatores.js (gerado por tools/gerar_fatores.js a partir do guia dos 6 eixos do Vigiante).
   Cada fase tem um Problema (agrupa fatores parecidos). Ao entrar: ficha + classificação (Ameaça,
   Vulnerabilidade, Resiliência, Incerteza) + importância. Ao concluir: estratégia (quem puxa, prazo) e Selos de ODS. */
var ODS_COR = ['', '#E5243B', '#DDA63A', '#4C9F38', '#C5192D', '#FF3A21', '#26BDE2', '#FCC30B', '#A21942', '#FD6925', '#DD1367', '#FD9D24', '#BF8B2E', '#3F7E44', '#0A97D9', '#56C02B', '#00689D', '#19486A', '#8B5A2B'];
var ODS_NOME = ['', 'Erradicação da Pobreza', 'Fome Zero e Agricultura Sustentável', 'Saúde e Bem-Estar', 'Educação de Qualidade', 'Igualdade de Gênero', 'Água Potável e Saneamento', 'Energia Limpa e Acessível', 'Trabalho Decente e Crescimento Econômico', 'Indústria, Inovação e Infraestrutura', 'Redução das Desigualdades', 'Cidades e Comunidades Sustentáveis', 'Consumo e Produção Responsáveis', 'Ação Contra a Mudança do Clima', 'Vida na Água', 'Vida Terrestre', 'Paz, Justiça e Instituições Eficazes', 'Parcerias e Meios de Implementação', 'Igualdade Racial'];
var CLS = [
  { id: 'ameaca', k: 'A', t: 'Ameaça: já machuca a comunidade', eco: 'Ameaça anotada: isso já machuca a comunidade. Vale agir logo.' },
  { id: 'vuln', k: 'V', t: 'Vulnerabilidade: a comunidade está exposta', eco: 'Vulnerabilidade anotada: ainda não machucou, mas a comunidade está exposta.' },
  { id: 'resil', k: 'R', t: 'Resiliência: já existe força para crescer', eco: 'Resiliência anotada: já existe força aqui para a gente construir em cima.' },
  { id: 'incerta', k: 'I', t: 'Incerteza: falta informação para saber', eco: 'Incerteza anotada: falta informação. Ouvir mais gente já é parte da solução.' }
];
var _probIdx = null;
function probDe(l) {
  var F = window.FAT; if (!F) return null;
  if (!_probIdx) { _probIdx = {}; F.probs.forEach(function (p) { _probIdx[p.id] = p; }); }
  var id = F.fase[l] || F.reprise[l]; return id ? _probIdx[id] : null;
}
function fichaItens(lvl) { // conversa de entrada da fase (só na primeira vez)
  var p = probDe(lvl); if (!p || (E.prob && E.prob[lvl])) return null;
  E.prob = E.prob || {};
  var F = window.FAT, ex = F.eixos[p.eixo - 1], rep = !F.fase[lvl];
  var ods = p.ods.map(function (o) { return 'ODS ' + o; }).join(', ');
  var nomes = p.fatores.slice(0, 4).map(function (f) { return f.n.replace(/\s+-\s+.*$/, '').replace(/\s*\(.*$/, ''); }).join('; ');
  var it = [{ s: MES, t: 'PROBLEMA DESTA FASE: ' + p.nome + '. Eixo ' + p.eixo + ' · ' + ex.titulo + ' (' + ods + ').' },
    { s: MES, t: p.def + ' Na Cartografia Social, isso aparece como: ' + nomes + '.' }];
  if (rep) { it.push({ s: MES, t: 'Este problema volta aqui para fechar o ciclo: agora com tudo que você ouviu pelos Reinos.' }); it.push({ fn: function () { E.prob[lvl] = { rep: 1 }; E.persist(); } }); return it; }
  it.push({ s: MES, t: 'Como você classifica isso no território?' });
  it.push({ ask: CLS.map(function (c) { return { k: c.k, t: c.t, fx: function () { E.prob[lvl] = E.prob[lvl] || {}; E.prob[lvl].cls = c.id; chg('Saberes', 1); }, then: [{ s: MES, t: c.eco }] }; }) });
  it.push({ s: MES, t: 'E qual a importância disso para a comunidade?' });
  it.push({ ask: [[1, 3, 'Pouco urgente'], [2, 6, 'Importante'], [3, 9, 'Muito urgente']].map(function (o) { return { k: String(o[0]), t: o[2], fx: function () { E.prob[lvl] = E.prob[lvl] || {}; E.prob[lvl].imp = o[1]; }, then: [] }; }) });
  it.push({ s: MES, t: 'Anotado. Quando a fase acabar, a gente pensa a estratégia.' }); it.push({ fn: function () { E.persist(); } });
  return it;
}
function odsGanhos() { var g = {}; for (var l in (E.prob || {})) { var r = E.prob[l]; if (r && r.done) { var p = probDe(+l); if (p) p.ods.forEach(function (o) { g[o] = (g[o] || 0) + 1; }); } } return g; }
function estrategiaFase(lvl) { // fase concluída: dá os Selos e pergunta a estratégia (uma vez)
  var r = E.prob && E.prob[lvl], p = probDe(lvl); if (!p || !r || r.done) return;
  var antes = odsGanhos(); r.done = true; var depois = odsGanhos(), novos = Object.keys(depois).filter(function (o) { return !antes[o]; });
  E.persist();
  var it = [];
  if (novos.length) it.push({ fn: function () { snd('lua'); if (E.ui) E.ui.toast('Selo de ODS: ' + novos.map(function (o) { return 'ODS ' + o; }).join(', ') + ' [O]'); } });
  if (!r.rep && !r.pz) {
    it.push({ s: MES, t: 'Fase concluída: ' + p.nome + '. Agora a estratégia do Plano Popular. Quem deve puxar essa ação?' });
    it.push({ ask: [['1', 'A própria comunidade (mutirão, associação)', 'comunidade'], ['2', 'O poder público (prefeitura, estado)', 'poder público'], ['3', 'Uma parceria entre os dois', 'parceria']].map(function (o) { return { k: o[0], t: o[1], fx: function () { r.ag = o[2]; }, then: [] }; }) });
    it.push({ s: MES, t: 'E em que prazo isso precisa sair do papel?' });
    it.push({ ask: [['1', 'Curto (3 a 6 meses)', 'curto'], ['2', 'Médio (6 a 12 meses)', 'médio'], ['3', 'Longo (mais de 12 meses)', 'longo']].map(function (o) { return { k: o[0], t: o[1], fx: function () { r.pz = o[2]; E.persist(); if (E.mundo) grupoDecidiu(lvl, r); }, then: [] }; }) });
    it.push({ s: MES, t: 'Estratégia registrada no Plano Popular: ' + p.nome + '. Veja seus Selos em [O].' });
  }
  if (it.length && E.ui) E.ui.run(it);
}
function reconciliarProb(name, st) { // fases já concluídas neste Reino viram "feitas" (cobre fases que saem sem passar pelo exit)
  try { for (var i = 0; i < st.done; i++) st.N[i].forEach(function (l) { if (E.prob && E.prob[l] && !E.prob[l].done) estrategiaFase(l); }); } catch (e) { console.error(e); }
}
function odsResumo() { // para o painel dos Selos
  var F = window.FAT, g = odsGanhos(), tot = {}, feitos = {}, eix = {};
  F.probs.forEach(function (p) { p.ods.forEach(function (o) { tot[o] = (tot[o] || 0) + 1; }); eix[p.eixo] = eix[p.eixo] || [0, 0]; eix[p.eixo][1]++; });
  for (var l in E.prob) { var r = E.prob[l], p = probDe(+l); if (r && r.done && p && F.fase[l]) { feitos[p.id] = 1; } }
  F.probs.forEach(function (p) { if (feitos[p.id]) eix[p.eixo][0]++; });
  return { g: g, tot: tot, eix: eix, n: Object.keys(feitos).length };
}

/* ---------- Cidades dos Reinos: tamanhos de mapa, estilos por bioma e povoamento ---------- */
var REINO_SZ = { 'Vila Mutirão': [4200, 2925, 2.19, 2.18] };
['Boca do Igarapé', 'Cacimba Grande', 'Pouso das Garças', 'Jequitibá', 'Enseada do Siri', 'Coxilha da Fronteira', 'Babaçual', 'Planalto Frio'].forEach(function (n) { REINO_SZ[n] = [3600, 2175, 2.82, 3.0]; });
var ESC = { td_casa: 2.2, td_arvore: 3.4, barraca: 2, casa: 1.7, casa2: 1.7, ubs: 1.6 };
var TREEK = { ct_jequi: 1, ct_palmeira: 1, ct_coqueiro: 1, ct_ipe: 1, ct_pinheiro: 1, ct_mandacaru: 1, ct_pequizeiro: 1, ct_buriti: 1, td_arvore: 1, ct_arbustoF: 1, ct_pedra: 1, ct_cerca: 1 };
var ESTILO = {
  'Vila Mutirão': { b: ['ct_sobrado', 'ct_taipa', 'ct_igreja', 'ct_galpao', 'ct_sobrado', 'ct_taipa', 'ct_chale'], t: ['ct_pequizeiro', 'ct_buriti', 'ct_pequizeiro', 'ct_buriti', 'ct_ipe', 'td_arvore', 'ct_arbustoF'], d: ['ct_poco', 'ct_caixa', 'ct_cerca'], dn: 1, tom: 0xe0a040 },
  'Boca do Igarapé': { b: ['ct_palafita', 'ct_palafita', 'ct_oca', 'ct_taipa'], t: ['ct_jequi', 'ct_palmeira', 'ct_coqueiro', 'ct_arbustoF'], d: ['ct_canoa', 'ct_poco', 'ct_cerca'], dn: 1.2, pc: 0x4aa3d8, pn: 4, tom: 0x1f7a3a },
  'Pouso das Garças': { b: ['ct_palafita', 'ct_palafita', 'ct_taipa', 'ct_galpao'], t: ['ct_palmeira', 'ct_arbustoF', 'td_arvore'], d: ['ct_canoa', 'ct_caixa', 'ct_cerca'], dn: 0.9, pc: 0x3fa7a0, pn: 6, tom: 0x3fa7a0 },
  'Cacimba Grande': { b: ['ct_taipa', 'ct_taipa', 'ct_galpao', 'ct_igreja'], t: ['ct_mandacaru', 'ct_mandacaru', 'ct_pedra', 'ct_arbustoF'], d: ['ct_poco', 'ct_caixa', 'ct_cerca'], dn: 0.55, pc: 0xe0c47a, pn: 5, pa: 0.55, tom: 0xc98a3b },
  'Jequitibá': { b: ['ct_sobrado', 'ct_sobrado', 'ct_igreja', 'ct_chale'], t: ['ct_jequi', 'ct_ipe', 'td_arvore', 'ct_arbustoF'], d: ['ct_poco', 'ct_cerca'], dn: 1.3, tom: 0x2f6b2f },
  'Enseada do Siri': { b: ['ct_palafita', 'ct_taipa', 'ct_sobrado', 'ct_farol'], t: ['ct_coqueiro', 'ct_arbustoF', 'ct_pedra'], d: ['ct_canoa', 'ct_canoa', 'ct_caixa'], dn: 0.7, pc: 0x4aa3d8, pn: 3, tom: 0x4aa3d8 },
  'Coxilha da Fronteira': { b: ['ct_galpao', 'ct_galpao', 'ct_taipa', 'ct_sobrado'], t: ['ct_ipe', 'td_arvore', 'ct_arbustoF', 'ct_pedra'], d: ['ct_cerca', 'ct_cerca', 'ct_poco'], dn: 0.6, pc: 0xc8d878, pn: 5, pa: 0.5, tom: 0x8bb356 },
  'Babaçual': { b: ['ct_oca', 'ct_oca', 'ct_palafita', 'ct_taipa'], t: ['ct_palmeira', 'ct_palmeira', 'ct_arbustoF', 'ct_jequi'], d: ['ct_fogueira', 'ct_cerca', 'ct_poco'], dn: 1.2, pc: 0x4f9a3a, pn: 4, pa: 0.5, tom: 0x6fa05a },
  'Planalto Frio': { b: ['ct_chale', 'ct_chale', 'ct_igreja', 'ct_galpao'], t: ['ct_pinheiro', 'ct_pinheiro', 'ct_arbustoF', 'ct_pedra'], d: ['ct_fogueira', 'ct_cerca', 'ct_poco'], dn: 1, pc: 0xd0dce8, pn: 5, pa: 0.55, tom: 0x9aa7b5 }
};
/* casas típicas do bioma nas fases (substituem os PNGs genéricos 'casa', 'casa2', 'ubs') */
function casaImg(sc, x, y, key) {
  var dom = domOf(E.curLvl > 0 ? E.curLvl : 1), E1 = ESTILO[dom] || ESTILO['Vila Mutirão'];
  var casas = E1.b.filter(function (k) { return k.indexOf('ct_') === 0 && k !== 'ct_igreja' && k !== 'ct_farol'; }), esp = E1.b.filter(function (k) { return k === 'ct_igreja' || k === 'ct_farol'; });
  var h = Math.abs(Math.round(x / 97)), k;
  if (key === 'ubs') k = esp.length ? esp[0] : casas[casas.length - 1]; else k = casas[(h + (key === 'casa2' ? 1 : 0)) % casas.length];
  return sc.add.image(x, y, k).setOrigin(0.5, 1).setScale(key === 'ubs' ? 4.6 : 4);
}
/* construção típica do bioma para cada lugar (fase, bônus, atividade) nos mapas dos Reinos */
function lugarImg(sc, name, i, x, y, tipo) {
  var E1 = ESTILO[name] || ESTILO['Vila Mutirão'], casas = E1.b.filter(function (k) { return k.indexOf('ct_') === 0 && k !== 'ct_igreja' && k !== 'ct_farol'; }), esp = E1.b.filter(function (k) { return k === 'ct_igreja' || k === 'ct_farol'; });
  var k = tipo === 'bonus' ? (casas.indexOf('ct_galpao') >= 0 ? 'ct_galpao' : casas[0]) : tipo === 'ativ' ? casas.concat(esp)[i % (casas.length + esp.length)] : casas[i % casas.length];
  return sc.add.image(x, y, k).setOrigin(0.5, 1).setScale(3.6);
}
/* cursos d'água, lagos, mar e leito seco típicos de cada bioma, dentro dos Reinos */
var REINO_AGUA = null;
var AGUA_PAL = {
  azul: { b: [58, 142, 214], m: [68, 156, 224], s: [110, 190, 236], e: [30, 78, 140], k1: [236, 214, 150], k2: [222, 190, 120] },
  amazonia: { b: [74, 124, 104], m: [86, 138, 116], s: [120, 170, 140], e: [34, 70, 56], k1: [150, 112, 70], k2: [126, 92, 56] },
  pantanal: { b: [64, 150, 150], m: [76, 164, 160], s: [130, 200, 186], e: [28, 88, 90], k1: [180, 170, 110], k2: [150, 140, 86] },
  barrenta: { b: [112, 140, 142], m: [124, 152, 150], s: [160, 180, 160], e: [60, 78, 66], k1: [206, 176, 114], k2: [184, 152, 96] },
  frio: { b: [150, 206, 240], m: [176, 222, 248], s: [220, 240, 252], e: [70, 120, 170], k1: [244, 248, 252], k2: [214, 226, 238] }
};
var AGUA_ESP = {
  'Vila Mutirão': { cor: 'azul', r: [[[0, .82], [.18, .72], [.34, .86], [.52, .74], [.7, .9], [1, .78]], 36], l: [[.88, .16, 210, 130]] },
  'Boca do Igarapé': { cor: 'amazonia', rs: [[[[0, .3], [.22, .4], [.4, .28], [.62, .44], [1, .36]], 22], [[[.34, 1], [.4, .82], [.3, .64], [.5, .5]], 18], [[[0, .93], [.3, .86], [.6, .95], [1, .88]], 58]] },
  'Pouso das Garças': { cor: 'pantanal', r: [[[1, .2], [.78, .32], [.6, .18], [.4, .36], [.22, .26], [0, .4]], 40], l: [[.3, .8, 300, 170], [.76, .74, 240, 150], [.55, .52, 150, 90]] },
  'Cacimba Grande': { cor: 'barrenta', seco: [[[0, .45], [.25, .56], [.5, .42], [.75, .58], [1, .5]], 42], l: [[.2, .86, 120, 76]] },
  'Jequitibá': { cor: 'azul', rs: [[[[.15, 0], [.26, .3], [.12, .56], [.3, .8], [.2, 1]], 28], [[[.56, 0], [.62, .36], [.5, .6], [.7, .86], [.8, 1]], 26]], l: [[.86, .5, 180, 115]] },
  'Enseada do Siri': { cor: 'azul', mar: 0.86, r: [[[.18, .5], [.3, .68], [.24, .86]], 22] },
  'Coxilha da Fronteira': { cor: 'azul', r: [[[0, .55], [.3, .5], [.55, .62], [.8, .48], [1, .52]], 46], l: [[.2, .2, 240, 124]] },
  'Babaçual': { cor: 'pantanal', r: [[[0, .2], [.3, .32], [.5, .2], [.75, .4], [1, .3]], 46], l: [[.3, .82, 210, 120], [.72, .78, 270, 140]] },
  'Planalto Frio': { cor: 'frio', rs: [[[[.1, 0], [.3, .3], [.15, .6], [.4, .82], [.3, 1]], 24], [[[.6, .1], [.75, .4], [.62, .7], [.9, .92]], 22]], l: [[.82, .24, 195, 120]] }
};
function aguaReino(sc, name, WW, WH, avoid, roadPts) {
  var esp = AGUA_ESP[name]; if (!esp) return null;
  var pal = AGUA_PAL[esp.cor], CW = Math.ceil(WW / 4), CH = Math.ceil(WH / 4), MK = new Uint8Array(CW * CH), lagos = [];
  function livreDe(x, y, r) { for (var i = 0; i < avoid.length; i++) if (Math.hypot(x - avoid[i].x, y - (avoid[i].y + 30)) < r) return false; return true; }
  function roadFree(x, y, rr) { for (var i = 0; i < roadPts.length; i += 2) if (Math.hypot(x - roadPts[i].x, y - roadPts[i].y) < rr) return false; return true; }
  function away(p) { for (var it = 0; it < 3; it++) avoid.forEach(function (a) { var dx = p.x - a.x, dy = p.y - (a.y + 30), d = Math.hypot(dx, dy) || 1; if (d < 190) { p.x = a.x + dx / d * 190; p.y = a.y + 30 + dy / d * 190; } }); return p; }
  function rio(def, kind) {
    var raw = def[0].map(function (f) { return { x: f[0] * WW, y: f[1] * WH }; }), sm = samplePath(raw, 20).map(away), pts = samplePath(chaikin(sm, 2), 10);
    pts.forEach(function (q, k) { var rw = def[1] * (1 + 0.12 * Math.sin(k * 0.21)), r4 = Math.ceil(rw / 4) + 1, qx = Math.floor(q.x / 4), qy = Math.floor(q.y / 4); for (var yy = qy - r4; yy <= qy + r4; yy++) for (var xx = qx - r4; xx <= qx + r4; xx++) { if (xx < 0 || yy < 0 || xx >= CW || yy >= CH) continue; if (Math.hypot(xx + .5 - q.x / 4, yy + .5 - q.y / 4) <= rw / 4 && MK[yy * CW + xx] === 0) MK[yy * CW + xx] = kind; } });
  }
  if (esp.r) rio(esp.r, 1); if (esp.rs) esp.rs.forEach(function (d) { rio(d, 1); }); if (esp.seco) rio(esp.seco, 4);
  (esp.l || []).forEach(function (L, li) {
    var cx = L[0] * WW, cy = L[1] * WH, ok = false, k, ang, rad;
    for (k = 0; k < 40 && !ok; k++) { ang = k * 2.4; rad = k * 26; var tx = Phaser.Math.Clamp(cx + Math.cos(ang) * rad, 160, WW - 160), ty = Phaser.Math.Clamp(cy + Math.sin(ang) * rad, 300, WH - 160); if (livreDe(tx, ty, Math.max(L[2], L[3]) + 150) && roadFree(tx, ty, Math.min(L[2], L[3]) * 1.25 + 60)) { cx = tx; cy = ty; ok = true; } }
    if (!ok) return; lagos.push([cx, cy]);
    for (var yy = Math.floor((cy - L[3] * 1.3) / 4); yy <= Math.ceil((cy + L[3] * 1.3) / 4); yy++) for (var xx = Math.floor((cx - L[2] * 1.3) / 4); xx <= Math.ceil((cx + L[2] * 1.3) / 4); xx++) {
      if (xx < 0 || yy < 0 || xx >= CW || yy >= CH) continue; var dx = (xx * 4 + 2 - cx) / L[2], dy = (yy * 4 + 2 - cy) / L[3], th = Math.atan2(dy, dx), rr = 1 + 0.13 * Math.sin(3 * th + li) + 0.08 * Math.sin(5 * th + 2 * li + 1);
      if (Math.hypot(dx, dy) < rr && MK[yy * CW + xx] === 0) MK[yy * CW + xx] = 2;
    }
  });
  if (esp.mar) for (var cx0 = 0; cx0 < CW; cx0++) { var wx = cx0 * 4 + 2, cs = WH * esp.mar + 34 * Math.sin(wx / 140) + 16 * Math.sin(wx / 53); avoid.forEach(function (a) { if (Math.abs(wx - a.x) < 260) cs = Math.max(cs, a.y + 30 + 200); }); roadPts.forEach(function (q) { if (Math.abs(wx - q.x) < 150) cs = Math.max(cs, q.y + 110); }); for (var cy0 = Math.max(0, Math.floor(cs / 4)); cy0 < CH; cy0++) MK[cy0 * CW + cx0] = 3; }
  function nz(x, y, s) { var n = (x * 374761393 + y * 668265263 + s * 69069) | 0; n = (n ^ (n >>> 13)) * 1274126177 | 0; return (((n ^ (n >>> 16)) >>> 0) & 65535) / 65535; }
  var cv = mkCv(CW, CH), g2 = cv.getContext('2d'), id = g2.createImageData(CW, CH), D = id.data;
  function px(x, y, c) { var j = (y * CW + x) * 4; D[j] = c[0]; D[j + 1] = c[1]; D[j + 2] = c[2]; D[j + 3] = 255; }
  function near(x, y, r, want) { for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) { var xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= CW || yy >= CH) continue; var k = MK[yy * CW + xx]; if ((k > 0 && k !== 4) === want) return true; } return false; }
  for (var y = 0; y < CH; y++) for (var x = 0; x < CW; x++) {
    var k = MK[y * CW + x], r = nz(x, y, 5);
    if (k === 4) { var c = [222, 190, 122]; if (r > 0.93) c = [240, 214, 150]; else if (nz(x >> 1, y >> 1, 9) > 0.82) c = [186, 148, 86]; else if (((x * 3 + y * 5) % 11 === 0) && r > 0.5) c = [170, 132, 76]; px(x, y, c); }
    else if (k) {
      var edge = near(x, y, 1, false), shore = !edge && near(x, y, 2, false), mid = !edge && !shore && near(x, y, 4, false), base = pal.b;
      if (edge) px(x, y, pal.e); else if (shore) px(x, y, pal.s); else { if (mid) base = pal.m; if (r > 0.985) base = [224, 244, 255]; else if (((x + (y >> 1)) % 9 === 0) && r > 0.55) base = [Math.min(255, base[0] + 30), Math.min(255, base[1] + 30), Math.min(255, base[2] + 20)]; px(x, y, base); }
    } else if (near(x, y, 2, true)) px(x, y, near(x, y, 1, true) ? pal.k1 : pal.k2);
  }
  g2.putImageData(id, 0, 0); var key = 'agua_' + (ROADN++); if (sc.textures.exists(key)) sc.textures.remove(key); sc.textures.addCanvas(key, cv);
  sc.add.image(0, 0, key).setOrigin(0, 0).setScale(4).setDepth(0.4);
  function em(x, y, m) { m = m || 0; function a(px2, py2) { var cx = Math.floor(px2 / 4), cy = Math.floor(py2 / 4); if (cx < 0 || cy < 0 || cx >= CW || cy >= CH) return false; var v = MK[cy * CW + cx]; return v > 0 && v !== 4; } return a(x, y) || (m > 0 && (a(x + m, y) || a(x - m, y) || a(x, y + m) || a(x, y - m))); }
  function paredes(grupo) { // blocos de 32 px; onde uma estrada cruza a água há vau (sem parede)
    var rb = {}; roadPts.forEach(function (q) { for (var dx = -2; dx <= 2; dx++) for (var dy = -2; dy <= 2; dy++) rb[(Math.floor(q.x / 32) + dx) + ',' + (Math.floor(q.y / 32) + dy)] = 1; });
    for (var by = 0; by < WH; by += 32) { var run = -1, bx; for (bx = 0; bx <= WW; bx += 32) { var blk = bx < WW && em(bx + 16, by + 16) && !rb[(bx / 32) + ',' + (by / 32)]; if (blk && run < 0) run = bx; if (!blk && run >= 0) { grupo.create(run + (bx - run) / 2, by + 16, 'px').setVisible(false).setDisplaySize(bx - run, 32).refreshBody(); run = -1; } } }
  }
  function pontes(sc2, segs2) { // onde uma estrada cruza água, uma ponte de madeira
    var h = sc2.textures.get('ponte_trilho').getSourceImage().height * 4;
    segs2.forEach(function (sg) {
      var sm = sg.samples, i = 0;
      while (i < sm.length) {
        if (!em(sm[i].x, sm[i].y, 0)) { i++; continue; }
        var j = i; while (j + 1 < sm.length && em(sm[j + 1].x, sm[j + 1].y, 0)) j++;
        var a = sm[Math.max(0, i - 1)], b = sm[Math.min(sm.length - 1, j + 1)], ang = Math.atan2(b.y - a.y, b.x - a.x), len = Math.hypot(sm[j].x - sm[i].x, sm[j].y - sm[i].y) + 150, mx = (sm[i].x + sm[j].x) / 2, my = (sm[i].y + sm[j].y) / 2, nx = -Math.sin(ang), ny = Math.cos(ang);
        sc2.add.tileSprite(mx, my, len, 130, 'ponte').setTileScale(4, 4).setRotation(ang).setDepth(1);
        sc2.add.tileSprite(mx - nx * 62, my - ny * 62, len, h, 'ponte_trilho').setTileScale(4, 4).setRotation(ang).setOrigin(0.5, 1).setDepth(2);
        sc2.add.tileSprite(mx + nx * 62, my + ny * 62, len, h, 'ponte_trilho').setTileScale(4, 4).setRotation(ang).setOrigin(0.5, 0).setDepth(2);
        i = j + 1;
      }
    });
  }
  return { em: em, paredes: paredes, lagos: lagos, pontes: pontes };
}
function povoar(sc, name, WW, WH, avoid, roadPts) { // vilas organizadas (rua + casas alinhadas), bosques e espaço livre entre os lugares
  var E1 = ESTILO[name] || ESTILO['Vila Mutirão'], seed = 31 + name.length * 13; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
  sc.walls = sc.physics.add.staticGroup(); var occ = [];
  function livre(x, y, rn, rr) {
    if (x < 90 || x > WW - 90 || y < 240 || y > WH - 70) return false; if (REINO_AGUA && REINO_AGUA(x, y, 55)) return false;
    var i, q; for (i = 0; i < avoid.length; i++) { q = avoid[i]; if (Math.hypot(x - q.x, y - (q.y + 30)) < rn) return false; }
    for (i = 0; i < roadPts.length; i += 2) { q = roadPts[i]; if (Math.hypot(x - q.x, y - q.y - 20) < rr) return false; }
    for (i = 0; i < occ.length; i++) { q = occ[i]; if (Math.hypot(x - q[0], y - q[1]) < q[2]) return false; }
    return true;
  }
  function put(key, x, y, wall) {
    var im = sc.add.image(x, y, key).setOrigin(0.5, 1).setScale(ESC[key] || (TREEK[key] ? 3.2 : 2.6)).setDepth(y); occ.push([x, y - 20, im.displayWidth * 0.6]);
    if (wall) { var w = im.displayWidth * 0.62, h = 30; sc.walls.create(x, y - h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody(); } return im;
  }
  var k, tr, i;
  if (E1.pc && ['Boca do Igarapé', 'Pouso das Garças', 'Enseada do Siri'].indexOf(name) < 0) for (k = 0; k < Math.round(E1.pn * 1.6); k++) { for (tr = 0; tr < 30; tr++) { var px = 300 + rnd() * (WW - 600), py = 400 + rnd() * (WH - 700), pr = 130 + rnd() * 190; if (livre(px, py, pr + 200, pr + 90)) { pxDisc(sc, px, py, pr, hexs(E1.pc), null, E1.pa || 0.9).setDepth(0.2); occ.push([px, py, pr + 50]); break; } } }
  var cs = [], nT = name === 'Vila Mutirão' ? 5 : 3, t;
  for (t = 0; t < 2500 && cs.length < nT; t++) {
    var cx = 500 + rnd() * (WW - 1000), cy = 460 + rnd() * (WH - 860), ok = livre(cx, cy, 380, 150) && livre(cx - 380, cy, 220, 100) && livre(cx + 380, cy, 220, 100);
    if (ok) cs.forEach(function (c) { if (Math.hypot(cx - c[0], cy - c[1]) < 800) ok = false; }); if (ok) cs.push([cx, cy, rnd() < 0.35]);
  }
  cs.forEach(function (c, ci) {
    var cx = c[0], cy = c[1], vert = c[2], i, sd;
    pxRect(sc, cx, cy, vert ? 46 : 860, vert ? 860 : 46, '#d8c8a0', '#b8a070', 0.95).setDepth(0.25); pxDisc(sc, cx, cy, 96, '#e0d0a8', '#b8a070', 0.95).setDepth(0.26);
    for (i = -4; i <= 4; i++) occ.push([cx + (vert ? 0 : i * 100), cy + (vert ? i * 100 : 0), 60]);
    put(E1.d[ci % E1.d.length], cx, cy + 16, false);
    [-3, -2, -1, 1, 2, 3].forEach(function (n) { [-1, 1].forEach(function (sd) {
      var bx = vert ? cx + sd * 120 : cx + n * 140, by = vert ? cy + n * 140 + 34 : (sd < 0 ? cy - 36 : cy + 150);
      var key = E1.b[Math.floor(rnd() * E1.b.length)]; if ((key === 'ct_farol' || key === 'ct_igreja') && rnd() < 0.85) key = E1.b[0]; if (Math.abs(n) === 3 && sd < 0 && E1.b.indexOf('ct_igreja') >= 0) key = 'ct_igreja';
      if (!livre(bx, by - 30, 150, 60)) return; var im = put(key, bx, by, true); if (rnd() < 0.5) im.setFlipX(true);
    }); });
    for (i = 0; i < 4; i++) { var tx = cx + (rnd() - 0.5) * 900, ty = cy + (vert ? (rnd() - 0.5) * 900 : (rnd() < 0.5 ? -1 : 1) * (260 + rnd() * 80)); if (livre(tx, ty, 200, 90)) put(E1.t[Math.floor(rnd() * E1.t.length)], tx, ty, false); }
  });
  var nG = name === 'Vila Mutirão' ? 9 : 7;
  for (t = 0; t < 600 && nG > 0; t++) {
    var gx = 300 + rnd() * (WW - 600), gy = 420 + rnd() * (WH - 700); if (!livre(gx, gy, 300, 140)) continue; nG--;
    var nt = 7 + Math.floor(rnd() * 5); for (i = 0; i < nt; i++) { var a2 = rnd() * 6.28, rr2 = rnd() * 260, x = gx + Math.cos(a2) * rr2, y = gy + Math.sin(a2) * rr2 * 0.75; if (livre(x, y, 130, 85)) put(E1.t[Math.floor(rnd() * E1.t.length)], x, y, false); }
  }
  var N = Math.round(WW * WH / 120000 * E1.dn), i2; for (i2 = 0; i2 < N; i2++) { var x1 = 120 + rnd() * (WW - 240), y1 = 260 + rnd() * (WH - 340); if (livre(x1, y1, 170, 90)) put(E1.t[Math.floor(rnd() * E1.t.length)], x1, y1, false); }
  for (i2 = 0; i2 < N * 0.5; i2++) { var x3 = 120 + rnd() * (WW - 240), y3 = 260 + rnd() * (WH - 340); if (livre(x3, y3, 140, 70)) put(rnd() < 0.5 ? 'ct_arbustoF' : 'ct_pedra', x3, y3, false); }
}
/* Mapa-Mundo: cidade e vegetação do bioma ao redor do portal de cada Reino */
function povoarMundo(sc, cx, cy, name, wall, roadPts, sn) {
  var E1 = ESTILO[name]; if (!E1) return; var seed = 77 + sn * 19, vila = name === 'Vila Mutirão'; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
  function ok(x, y, rr) { if (x < 60 || x > 2820 || y < 100 || y > 1850 || MUNDO_AGUA(x, y, 50)) return false; for (var ic = 0; ic < roadPts.length; ic++) { var qc = roadPts[ic]; if (Math.abs(x - qc.x) < 80 && qc.y > y - 150 && qc.y < y + 40) return false; } for (var i = 0; i < roadPts.length; i += 2) { var q = roadPts[i]; if (Math.hypot(x - q.x, y - q.y - 20) < rr) return false; } return true; }
  var offs = vila ? [[-560, -90], [560, -90], [-470, 220], [470, 220], [-700, 90], [700, 90], [-300, 400], [300, 400]] : [];
  offs.forEach(function (o, i) { var x = cx + o[0], y = cy + o[1] + (vila ? 0 : 70); if (!ok(x, y, 100)) return; var key = E1.b[(i + sn) % E1.b.length], im = sc.add.image(x, y, key).setOrigin(0.5, 1).setScale(ESC[key] || 2.4).setDepth(y); if (i % 2) im.setFlipX(true); wall(x - im.displayWidth * 0.31, y - 30, im.displayWidth * 0.62, 30); });
  if (E1.pc && !vila) { var lx = cx + (sn % 2 ? -1 : 1) * 520, ly = cy + 150; if (ok(lx, ly, 190)) pxDisc(sc, lx, ly, 130, hexs(E1.pc), null, E1.pa || 0.9).setDepth(0.25); }
  var n = vila ? 16 : 12; for (var j = 0; j < n; j++) { var a = rnd() * 6.28, rr = (vila ? 720 : 440) + rnd() * 220, x2 = cx + Math.cos(a) * rr, y2 = cy + 70 + Math.sin(a) * rr * 0.8; if (!ok(x2, y2, 90)) continue; var k2 = E1.t[Math.floor(rnd() * E1.t.length)]; sc.add.image(x2, y2, k2).setOrigin(0.5, 1).setScale(ESC[k2] || 3.2).setDepth(y2); wall(x2 - 7, y2 - 12, 14, 12); }
  // cinturão de vegetação típica do bioma ao redor da cidade (as estradas e a água abrem as clareiras)
  (function () {
    var RX = vila ? 700 : 330, RY = vila ? 520 : 250, N = Math.round((vila ? 46 : 78) * (E1.dn || 1)), under = E1.t.filter(function (k) { return k === 'ct_arbustoF' || k === 'ct_pedra'; }), altas = E1.t.filter(function (k) { return k !== 'ct_arbustoF' && k !== 'ct_pedra'; });
    var cnt = 0; for (var q = 0; q < N * 3; q++) {
      var a = rnd() * 6.2832, r = 1.0 + rnd() * (vila ? 0.35 : 0.55), x = cx + Math.cos(a) * RX * r, y = cy + (vila ? 0 : -70) + Math.sin(a) * RY * r;
      if (!ok(x, y, 90) || x < 90 || y < 130) continue; var arb = under.length && rnd() < 0.3, lst = arb ? under : altas; if (!lst.length) lst = E1.t; var kk = lst[Math.floor(rnd() * lst.length)];
      sc.add.image(x, y, kk).setOrigin(0.5, 1).setScale(ESC[kk] || (kk === 'ct_arbustoF' || kk === 'ct_pedra' ? 3 : 3.4)).setDepth(y); if (!arb) wall(x - 8, y - 12, 16, 12);
      if (++cnt >= N) break;
    }
  })();
}
var Regiao = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Regiao() { Phaser.Scene.call(this, { key: 'Regiao' }); },
  init: function (d) { this.dom = (d && d.dom) || 'Vila Mutirão'; },
  create: function () {
    var sc = this, name = this.dom, st = domState(name), D = st.D, n = D.length; E.curLvl = -1; music('mapa'); this.ctl = new Ctl(this); this.fichaOn = false; reconciliarProb(name, st);
    var info = name === 'Vila Mutirão' ? { b: 'Planalto das Veredas', c: 0xe0a040 } : DOMINIOS.filter(function (d) { return d.n === name; })[0];
    var big = name === 'Vila Mutirão', SZ = REINO_SZ[name] || [W, H, 1, 1], WW = SZ[0], WH = SZ[1], fx = SZ[2], fy = SZ[3];
    var pos = (REG_PTS[name] || []).map(function (q) { return { x: q[0] * fx, y: (q[1] + (big ? 90 : 0)) * fy }; });
    this.cameras.main.setBounds(0, 0, WW, WH); this.cameras.main.setViewport(0, BARH, W, H - BARH); this.physics.world.setBounds(0, 70, WW, WH - 70);
    this.add.tileSprite(0, 0, WW, WH, 'grama').setOrigin(0, 0).setTileScale(4, 4);
    this.add.rectangle(0, 0, WW, WH, (ESTILO[name] || {}).tom || info.c, 0.3).setOrigin(0, 0).setDepth(0.1);
    // estrada curva entre lugares consecutivos (alterna o lado da curva); a cancela fica no primeiro trecho fechado
    var roadPts = [], segs = [];
    for (var i = 1; i < n; i++) {
      var a = { x: pos[i - 1].x, y: pos[i - 1].y + 16 }, b = { x: pos[i].x, y: pos[i].y + 16 }, dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1, sg = i % 2 ? 1 : -1;
      var cx = (a.x + b.x) / 2 - dy / L * L * 0.22 * sg, cy = (a.y + b.y) / 2 + dx / L * L * 0.22 * sg, curve = [];
      for (var t = 0; t <= 1.0001; t += 1 / Math.max(6, Math.ceil(L / 22))) curve.push({ x: (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * cx + t * t * b.x, y: (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * cy + t * t * b.y });
      var al = (i <= st.done && !(st.trava && i === st.done)) ? 1 : 0.85; segs.push({ samples: curve, alpha: al }); roadPts = roadPts.concat(curve);
      var mi = Math.floor(curve.length * 0.32), mj = Math.floor(curve.length * 0.62), ang = Math.atan2(curve[mi + 1].y - curve[mi].y, curve[mi + 1].x - curve[mi].x);
      this.add.text(curve[mi].x, curve[mi].y, '▶', { fontFamily: FONT, fontSize: '26px', color: al === 1 ? '#ffffff' : '#cccccc', stroke: '#6b4220', strokeThickness: 4 }).setOrigin(0.5).setRotation(ang).setDepth(3).setAlpha(al === 1 ? 1 : 0.6);
      if (i === (st.trava ? st.done : st.done + 1)) {
        var g = curve[mj], ang2 = Math.atan2(curve[mj + 1].y - curve[mj].y, curve[mj + 1].x - curve[mj].x) + Math.PI / 2;
        var hz = Math.abs(Math.sin(ang2)) > 0.7071; this.add.image(g.x, g.y, cancelaTex(this, hz)).setScale(4).setDepth(3);
        this.add.text(g.x, g.y + 52, 'fechado', { fontFamily: FONT, fontSize: '13px', color: '#fff', backgroundColor: '#00000099', padding: { x: 4, y: 1 } }).setOrigin(0.5).setDepth(4);
      }
    }
    var bonusRoad = null;
    // árvores de enfeite (determinístico), longe das estradas e dos lugares
    var seed = 11; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    // lugares (um por fase), com o número da sequência bem visível
    this.items = []; var portaisR = [], pfr = 0; this.time.addEvent({ delay: 420, loop: true, callback: function () { pfr = 1 - pfr; portaisR.forEach(function (q) { if (q.scene) q.setTexture('ct_portal' + pfr); }); } });
    D.forEach(function (lv0, i) {
      var lv = lv0, p = pos[i], state = i < st.done ? 'ok' : (i === st.done && !st.trava) ? 'cur' : 'lock';
      if (state === 'cur' && st.cur) lv = st.cur; var nm = nodeName(st.N[i]);
      var col = state === 'ok' ? 0x1f9a3c : state === 'cur' ? 0xc8561a : 0x555555;
      pxDisc(sc, p.x, p.y + 30, 66, state === 'lock' ? '#555555' : hexs(info.c), null, state === 'lock' ? 0.3 : 0.4).setDepth(0.3);
      if (state === 'cur') { var ring = pxRing(sc, p.x, p.y + 30, 76, '#ffd23a').setDepth(2); sc.tweens.add({ targets: ring, scale: { from: 2.7, to: 3.45 }, alpha: { from: 1, to: 0.3 }, yoyo: true, repeat: -1, duration: 700 }); }
      var ico = lugarImg(sc, name, i, p.x, p.y + 34, 'fase').setDepth(p.y); if (state === 'lock') ico.setTint(0x777777);
      pxDisc(sc, p.x, p.y - 108, 24, hexs(col), '#ffffff').setDepth(900);
      sc.add.text(p.x, p.y - 108, String(i + 1), { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff' }).setOrigin(0.5).setDepth(901);
      sc.add.text(p.x, p.y + 44, nm, { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 4, y: 2 }, align: 'center', wordWrap: { width: 176 } }).setOrigin(0.5, 0).setDepth(900);
      if (state === 'ok') sc.add.text(p.x + 52, p.y - 60, '✓', { fontFamily: FONT, fontSize: '28px', fontStyle: 'bold', color: '#7CFC8A', stroke: '#000', strokeThickness: 4 }).setOrigin(0.5).setDepth(900);
      if (state === 'lock') sc.add.text(p.x, p.y - 10, '🔒', { fontSize: '24px' }).setOrigin(0.5).setDepth(900);
      sc.items.push({ x: p.x, y: p.y, i: i, lvl: lv, state: state, nome: nm });
    });
    // ponto de bônus (piloto: Vila, depois da fase 3)
    if (name === 'Vila Mutirão' && st.done >= 2) {
      var bp = { x: 700 * fx, y: 440 * fy }, bs = samplePath([{ x: pos[1].x, y: pos[1].y + 34 }, { x: bp.x, y: bp.y + 30 }], 18);
      bonusRoad = bs;
      pxDisc(sc, bp.x, bp.y + 30, 66, '#6a3ab8', null, 0.35).setDepth(0.3);
      lugarImg(sc, name, 0, bp.x, bp.y + 34, 'bonus').setDepth(bp.y);
      pxDisc(sc, bp.x, bp.y - 108, 24, '#6a3ab8', '#ffffff').setDepth(900); sc.add.text(bp.x, bp.y - 108, '★', { fontFamily: FONT, fontSize: '22px', color: '#fff' }).setOrigin(0.5).setDepth(901);
      sc.add.text(bp.x, bp.y + 60, 'Bônus: Mutirão de Colheita', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#6a3ab8cc', padding: { x: 4, y: 2 }, align: 'center', wordWrap: { width: 176 } }).setOrigin(0.5, 0).setDepth(900);
      sc.items.push({ x: bp.x, y: bp.y, bonus: true, state: 'cur', nome: 'Mutirão de Colheita' });
    }
    diarioMarca(name);
    var avoid = pos.slice(); if (name === 'Vila Mutirão') { PINS.forEach(function (pn) { avoid.push({ x: pn.x * fx, y: pn.y * fy }); }); avoid.push({ x: 700 * fx, y: 440 * fy }); } avoid.push({ x: 110, y: 200 }, { x: 260, y: 230 }); if (bonusRoad) roadPts = roadPts.concat(bonusRoad);
    if (name === 'Vila Mutirão') {
      PINS.forEach(function (pn0) {
        var pn = { id: pn0.id, ic: pn0.ic, x: pn0.x * fx, y: pn0.y * fy };
        var lk = !!ativTrava(pn.id), A = ATIV[pn.id];
        pxDisc(sc, pn.x, pn.y + 30, 66, lk ? '#555555' : '#2a7ab8', null, 0.35).setDepth(0.3);
        var ic = lugarImg(sc, name, (pn.id.charCodeAt(0) + pn.id.length), pn.x, pn.y + 34, 'ativ').setDepth(pn.y); if (lk) ic.setTint(0x777777);
        pxDisc(sc, pn.x, pn.y - 108, 24, lk ? '#555555' : '#2a7ab8', '#ffffff').setDepth(900); sc.add.text(pn.x, pn.y - 108, lk ? '🔒' : '✦', { fontFamily: FONT, fontSize: '22px', color: '#fff' }).setOrigin(0.5).setDepth(901);
        sc.add.text(pn.x, pn.y + 60, A.nome, { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#2a7ab8cc', padding: { x: 4, y: 2 }, align: 'center', wordWrap: { width: 176 } }).setOrigin(0.5, 0).setDepth(900);
        sc.items.push({ x: pn.x, y: pn.y, ativ: pn.id, state: lk ? 'lock' : 'cur', nome: A.nome });
      });
      var col = (E.roca && E.roca.colhidas) || 0; [[1, 1050 * fx, 640 * fy], [3, 1560 * fx, 200 * fy], [5, 780 * fx, 1150 * fy], [8, 1380 * fx, 840 * fy]].forEach(function (c) { if (col >= c[0]) { sc.add.image(c[1], c[2], 'td_arvore').setOrigin(0.5, 1).setScale(4).setDepth(c[2]); sc.add.image(c[1] + 70, c[2] + 6, 'bn_fruta').setOrigin(0.5, 1).setScale(3).setDepth(c[2] + 1); } });
    }
    if (bonusRoad) segs.push({ samples: bonusRoad, alpha: 0.85, wf: 0.7 });
    // ramais: entrada do Reino -> 1ª fase; atividades -> fase mais próxima (todas as estradas ligam todos os lugares)
    function ramal(a, b, sg, wf) {
      var dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1, cx2 = (a.x + b.x) / 2 - dy * 0.12 * sg, cy2 = (a.y + b.y) / 2 + dx * 0.12 * sg, cu = [], nn = Math.max(6, Math.ceil(L / 22));
      for (var t = 0; t <= nn; t++) { var u = t / nn; cu.push({ x: (1 - u) * (1 - u) * a.x + 2 * (1 - u) * u * cx2 + u * u * b.x, y: (1 - u) * (1 - u) * a.y + 2 * (1 - u) * u * cy2 + u * u * b.y }); }
      segs.push({ samples: cu, alpha: 0.85, wf: wf || 0.8 }); roadPts = roadPts.concat(cu);
    }
    if (pos.length) ramal({ x: 110, y: 200 }, { x: pos[0].x, y: pos[0].y + 16 }, 1, 1);
    if (name === 'Vila Mutirão') PINS.forEach(function (pn0, ii) { var q = { x: pn0.x * fx, y: pn0.y * fy + 16 }, bi = 0, bd = 1e12; pos.forEach(function (p, k) { var d = Math.hypot(p.x - q.x, p.y + 16 - q.y); if (d < bd) { bd = d; bi = k; } }); ramal({ x: pos[bi].x, y: pos[bi].y + 16 }, q, ii % 2 ? 1 : -1, 0.75); });
    REINO_AGUA = null; var AG = aguaReino(this, name, WW, WH, avoid, roadPts); if (AG) REINO_AGUA = AG.em;
    povoar(this, name, WW, WH, avoid, roadPts);
    if (AG) AG.paredes(this.walls);
    this.agua = AG;
    stampRoads(this, segs);
    if (AG) AG.pontes(this, segs);
    // saída para o Mapa-Mundo
    var ex = { x: 110, y: 170 }; this.add.image(ex.x, ex.y + 70, 'ct_portao').setOrigin(0.5, 1).setScale(3.2).setDepth(ex.y + 71);
    this.add.text(ex.x, ex.y + 82, 'Mapa-Mundo', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 4, y: 2 } }).setOrigin(0.5, 0).setDepth(900);
    this.items.push({ x: ex.x, y: ex.y, exit: true, nome: 'Mapa-Mundo' });
    // Mestra Isabel (a Ciência) perto da saída, em todos os Reinos
    var mx = ex.x + 150, mf = ex.y + 60;
    var ms = this.add.image(mx, mf, 'n_evaristo').setOrigin(0.5, 1).setScale(4).setDepth(mf); this.tweens.add({ targets: ms, y: mf - 4, yoyo: true, repeat: -1, duration: 900, ease: 'Sine.easeInOut' });
    this.add.text(mx, mf - 124, MES, { fontFamily: FONT, fontSize: '15px', color: '#ffcc80', backgroundColor: '#00000099', padding: { x: 4, y: 1 } }).setOrigin(0.5).setDepth(900);
    this.items.push({ x: mx, y: mf - 40, mestre: true, nome: MES });
    // título (fixo na tela)
    this.add.text(W / 2, 84, name + ' · ' + info.b, { fontFamily: FONT, fontSize: '26px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 5 }).setOrigin(0.5).setDepth(950).setScrollFactor(0);
    this.add.text(W / 2, 114, 'Siga os números 1 → ' + n + '   ·   Concluídas: ' + Math.min(st.done, n) + '/' + n + '   ·   [Esc] Mapa-Mundo   ·   [K] trocar modo', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 6, y: 2 } }).setOrigin(0.5).setDepth(950).setScrollFactor(0);
    // bichos do bioma
    var fbd = { x0: 40, y0: 150, x1: WW - 40, y1: WH - 30 }, blkA = this.agua ? function (x, y) { return this.agua.em(x, y, 22); }.bind(this) : null; spawnFauna(this, FAUNA[name], WW / 2, WH / 2 + 40, Math.max(WW, WH) * 0.42, big ? 30 : 22, 4, fbd, blkA); if (this.agua) this.agua.lagos.forEach(function (lg) { spawnFauna(sc, AQUA[name] || FAUNA[name], lg[0], lg[1], 300, 5, 4, fbd, blkA); });
    // jogador
    var idx = -1; st.N.forEach(function (g, gi) { if (g.indexOf(E.regLvl) >= 0) idx = gi; }); if (idx < 0) idx = Math.min(st.done, n - 1); var sp = pos[idx];
    this.p = this.physics.add.sprite(sp.x, Math.min(sp.y + 100, WH - 20), 'av0').setScale(4).setDepth(500); this.p.setCollideWorldBounds(true); this.p.body.setSize(10, 6).setOffset(7, 20); this.physics.add.collider(this.p, this.walls);
    this.arb = this.add.image(this.p.x + 60, this.p.y - 70, 'arb').setScale(3).setDepth(2000);
    this.tweens.add({ targets: this.arb, scale: { from: 2.7, to: 3.6 }, yoyo: true, repeat: -1, duration: 700 });
    this.cameras.main.startFollow(this.p, true, 0.12, 0.12); this.cameras.main.setZoom(Math.max(E.mapZoom || 1, Math.max(W / WW, (H - BARH) / WH)));
    this.st = st; this.leaving = false;
    var fm = 'mestre_' + name; if (!E.flags[fm]) { E.flags[fm] = true; this.time.delayedCall(450, function () { E.ui.run(mestreBoasVindas(name)); }); }
    var flag = 'regIntro_' + name;
    if (!E.flags[flag]) { E.flags[flag] = true; this.time.delayedCall(400, function () { E.ui.run([{ s: 'ARBOVIA', t: 'Este é o mapa de ' + name + '. Cada porta numerada é um lugar diferente, e a estrada liga um ao outro em ordem: 1, 2, 3...' }, { s: 'ARBOVIA', t: 'Siga as setas ▶ até a porta com o círculo dourado e aperte [E]. Terminou um lugar, a cancela do próximo se abre. Os já concluídos (✓) podem ser revisitados.' }]); }); }
  },
  update: function (time) {
    var s = this.ctl.poll(), p = this.p, ui = E.ui; if (!ui || !ui.hudT || this.leaving) return;
    this.arb.x += (p.x + 62 - this.arb.x) * 0.08; this.arb.y += (p.y - 80 + Math.sin(time / 300) * 5 - this.arb.y) * 0.08;
    if (ui.busy) { p.setVelocity(0, 0); p.setTexture('av0'); return; }
    var vx = (s.right ? 1 : 0) - (s.left ? 1 : 0), vy = (s.down ? 1 : 0) - (s.up ? 1 : 0), len = Math.sqrt(vx * vx + vy * vy) || 1;
    p.setVelocity(vx / len * 340, vy / len * 340);
    if (vx || vy) { p.setTexture(Math.floor(time / 140) % 2 ? 'av1' : 'av2'); if (vx) p.setFlipX(vx < 0); } else p.setTexture('av0');
    p.setDepth(p.y);
    var near = null, nd = 115, cam = this.cameras.main;
    this.items.forEach(function (d) { var dd = Phaser.Math.Distance.Between(p.x, p.y, d.x, d.y + 40); if (dd < nd) { nd = dd; near = d; } });
    var wv = cam.worldView; if (near) ui.prompt((near.x - wv.x) * cam.zoom, BARH + (near.y - 140 - wv.y) * cam.zoom, near.mestre ? '[E] Falar com a Mestra Isabel' : near.ativ ? (near.state === 'lock' ? 'Fechado: ' + near.nome + ' (' + ativTrava(near.ativ) + ')' : '[E] Atividade: ' + near.nome) : near.bonus ? '[E] Bônus opcional: ' + near.nome : near.exit ? '[E] Voltar ao Mapa-Mundo' : near.state === 'lock' ? 'Fechado: ' + (near.i + 1) + '. ' + near.nome : '[E] ' + (near.state === 'ok' ? 'Rever' : 'Entrar') + ' ' + (near.i + 1) + '. ' + near.nome); else ui.prompt();
    if (s.act && near && ui.time.now > ui.lock) {
      if (near.exit) { this.toWorld(); return; }
      if (near.mestre) { ui.prompt(); mestreRegiao(this); return; }
      if (near.ativ) { if (near.state === 'lock') { ui.run([{ s: 'ARBOVIA', t: 'Esta atividade abre depois de uma fase da Vila: ' + ativTrava(near.ativ) + '.' }]); return; } this.leaving = true; ui.prompt(); snd('door'); this.scene.start('Ativ', { id: near.ativ, from: { scene: 'Regiao', data: { dom: this.dom } } }); return; }
      if (near.bonus) { this.leaving = true; E.ui.prompt(); E.bonusDom = this.dom; E.persist(); snd('door'); this.scene.start('Bonus'); return; }
      if (near.state === 'lock') {
        var prev = this.st.D[near.i - 1];
        ui.run([{ s: 'ARBOVIA', t: (this.st.trava && this.dom === 'Vila Mutirão') ? 'A Torre Inacabada só se abre depois do Marco 8, na Enseada do Siri. Siga as outras estradas do Mapa-Mundo.' : 'Este lugar (nº ' + (near.i + 1) + ') ainda está fechado. Conclua primeiro o nº ' + near.i + ', "' + levelName(prev) + '", para abrir a cancela.' }]);
      } else this.enter(near.lvl);
    }
    if (s.esc) this.toWorld();
  },
  enter: function (lvl) {
    var self = this;
    function go() { self.leaving = true; E.ui.prompt(); E.regLvl = lvl; E.persist(); snd('door'); if (lvl === 1) self.scene.start('Trecho'); else self.scene.start('Sala', { lvl: lvl }); }
    if (this.leaving || (this.fichaOn && E.ui.busy)) return; this.fichaOn = false; // se a conversa fechou sozinha (7 s), o próximo E reabre a ficha
    var it = null; try { it = fichaItens(lvl); } catch (e) { console.error(e); }
    if (!it) { go(); return; }
    this.fichaOn = true; E.ui.prompt(); E.ui.run(it, function () { self.fichaOn = false; go(); });
  },
  toWorld: function () { this.leaving = true; E.ui.prompt(); E.persist(); E.ui.toast('Progresso salvo.'); this.scene.start('World'); }
});

/* ---------- fauna: bichos de cada bioma, andando/voando pelo mapa e fugindo de quem chega perto ---------- */
var FAUNA = {
  'Vila Mutirão': ['galinha', 'viralata', 'veado'], 'Boca do Igarapé': ['arara', 'macaco', 'preguica', 'tucano'], 'Pouso das Garças': ['capivara', 'jacare', 'garca'],
  'Cacimba Grande': ['bode', 'tatu', 'calango'], 'Jequitibá': ['mico', 'tucano', 'preguica'], 'Enseada do Siri': ['siri', 'gaivota', 'garca'],
  'Coxilha da Fronteira': ['ema', 'ovelha', 'veado'], 'Planalto Frio': ['lobo', 'gralha', 'veado'], 'Babaçual': ['cutia', 'araraazul', 'macaco', 'garca']
};
var AQUA = { 'Pouso das Garças': ['capivara', 'jacare', 'garca', 'jacare'], 'Babaçual': ['garca', 'cutia', 'araraazul'], 'Enseada do Siri': ['siri', 'siri', 'gaivota'], 'Boca do Igarapé': ['macaco', 'arara', 'garca'], 'Coxilha da Fronteira': ['ovelha', 'ema'], 'Jequitibá': ['mico', 'tucano'], 'Planalto Frio': ['gralha', 'lobo'], 'Cacimba Grande': ['bode', 'tatu'], 'Vila Mutirão': ['galinha', 'viralata'] };
var VOA = { arara: 1, tucano: 1, gaivota: 1, gralha: 1, araraazul: 1, garca: 1 };
function spawnFauna(sc, list, hx, hy, R, n, scale, bnd, blk) {
  if (!list || !sc.textures.exists('an_' + list[0] + '_0')) return;
  var cr = [];
  for (var i = 0; i < n; i++) {
    var nm = list[i % list.length], a, rr, x, y, tries = 0; do { a = Math.random() * Math.PI * 2; rr = 70 + Math.random() * (R - 70); x = Phaser.Math.Clamp(hx + Math.cos(a) * rr, bnd.x0, bnd.x1); y = Phaser.Math.Clamp(hy + Math.sin(a) * rr * 0.7, bnd.y0, bnd.y1); } while (blk && !VOA[nm] && blk(x, y) && ++tries < 40);
    cr.push({ s: sc.add.image(x, y, 'an_' + nm + '_0').setOrigin(0.5, 1).setScale(scale).setDepth(VOA[nm] ? 1990 : y), nm: nm, fly: !!VOA[nm], by: y, ph: Math.random() * 6, dir: Math.random() < 0.5 ? 1 : -1, vx: 0, vy: 0, t: 0, pause: 0, fa: 0, fl: 0, flee: 0 });
  }
  var fn = function (time, delta) {
    var dt = delta / 1000, p = sc.p;
    cr.forEach(function (c) {
      var s = c.s, moving;
      if (c.fly) {
        s.x += c.dir * 70 * dt; if (Math.abs(s.x - hx) > R || s.x < bnd.x0 || s.x > bnd.x1) c.dir = -c.dir; s.y = c.by - 40 + Math.sin(time / 450 + c.ph) * 18; s.setFlipX(c.dir < 0); moving = true;
      } else {
        if (p && c.flee <= 0) { var d = Phaser.Math.Distance.Between(p.x, p.y, s.x, s.y); if (d < 130) { var k = d || 1; c.vx = (s.x - p.x) / k * 120; c.vy = (s.y - p.y) / k * 70; c.flee = 800; c.pause = 0; c.t = 800; } }
        if (c.flee > 0) c.flee -= delta;
        if (c.pause > 0) { c.pause -= delta; c.vx = c.vy = 0; }
        else if ((c.t -= delta) <= 0) {
          if (Math.random() < 0.4) c.pause = 800 + Math.random() * 2200;
          else { var an = Math.random() * Math.PI * 2, sp = 22 + Math.random() * 20; c.vx = Math.cos(an) * sp; c.vy = Math.sin(an) * sp * 0.6; c.t = 1200 + Math.random() * 2500; }
          if (Phaser.Math.Distance.Between(s.x, s.y, hx, hy) > R) { var dx = hx - s.x, dy = hy - s.y, l = Math.hypot(dx, dy) || 1; c.vx = dx / l * 30; c.vy = dy / l * 20; }
        }
        var nx2 = Phaser.Math.Clamp(s.x + c.vx * dt, bnd.x0, bnd.x1), ny2 = Phaser.Math.Clamp(s.y + c.vy * dt, bnd.y0, bnd.y1); if (blk && blk(nx2, ny2)) { c.vx = -c.vx; c.vy = -c.vy; c.t = 0; nx2 = s.x; ny2 = s.y; } s.x = nx2; s.y = ny2; moving = Math.abs(c.vx) + Math.abs(c.vy) > 1;
        if (Math.abs(c.vx) > 1) s.setFlipX(c.vx < 0); s.setDepth(s.y);
      }
      c.fa += delta; if (c.fa > (c.fly ? 160 : 220)) { c.fa = 0; c.fl = moving ? 1 - c.fl : 0; s.setTexture('an_' + c.nm + '_' + c.fl); }
    });
  };
  sc.events.on('update', fn); sc.events.once('shutdown', function () { sc.events.off('update', fn); });
}

function spawnFaunaLado(sc, dom, L, ext) { // bichos típicos do Reino em TODAS as fases laterais: bichos de chão no piso e, ao ar livre, aves no céu
  var list = FAUNA[dom]; if (!list || !sc.textures.exists('an_' + list[0] + '_0')) return;
  var solids = sc.solids ? sc.solids.getChildren() : [], cr = [], gy = GY, best = 0;
  solids.forEach(function (o) { var b = o.body; if (b && b.top > 300 && b.top < 720 && b.width > best) { best = b.width; gy = b.top; } }); // piso principal = o sólido mais largo
  var segs = solids.map(function (o) { return o.body; }).filter(function (b) { return b && Math.abs(b.top - gy) <= 8 && b.width > 160; });
  function groundAt(x) { for (var i = 0; i < segs.length; i++) { var b = segs[i]; if (x >= b.left + 40 && x <= b.right - 40) return { l: b.left + 40, r: b.right - 40 }; } return null; }
  var xs = [];
  list.forEach(function (nm) {
    if (VOA[nm]) {
      if (!ext) return; // dentro de prédios não há céu
      for (var i = 0; i < 2; i++) { var y = 110 + Math.random() * 170; cr.push({ s: sc.add.image(Math.random() * L, y, 'an_' + nm + '_0').setScale(3).setDepth(-10), nm: nm, fly: true, by: y, ph: Math.random() * 6, dir: Math.random() < 0.5 ? 1 : -1, fa: 0, fl: 0 }); }
    } else {
      var want = ext ? 5 : 3;
      for (var t = 0; t < 40 && want > 0; t++) {
        var x = 220 + Math.random() * (L - 440), g = groundAt(x); if (!g) continue;
        if (xs.some(function (q) { return Math.abs(q - x) < 180; })) continue;
        xs.push(x); want--;
        cr.push({ s: sc.add.image(x, gy + 2, 'an_' + nm + '_0').setOrigin(0.5, 1).setScale(3).setDepth(3), nm: nm, fly: false, g: g, vx: 0, t: 0, pause: 0, fa: 0, fl: 0, flee: 0 });
      }
    }
  });
  var fn = function (time, delta) {
    var dt = delta / 1000, p = sc.p;
    cr.forEach(function (c) {
      var s = c.s, moving;
      if (c.fly) { s.x += c.dir * 60 * dt; if (s.x < 0 || s.x > L) c.dir = -c.dir; s.y = c.by + Math.sin(time / 450 + c.ph) * 16; s.setFlipX(c.dir < 0); moving = true; }
      else {
        if (p && c.flee <= 0 && Math.abs(p.x - s.x) < 150 && Math.abs(p.y - s.y) < 200) { c.vx = (s.x < p.x ? -1 : 1) * 130; c.flee = 700; c.pause = 0; c.t = 700; }
        if (c.flee > 0) c.flee -= delta;
        if (c.pause > 0) { c.pause -= delta; c.vx = 0; }
        else if ((c.t -= delta) <= 0) { if (Math.random() < 0.4) c.pause = 800 + Math.random() * 2200; else { c.vx = (Math.random() < 0.5 ? -1 : 1) * (22 + Math.random() * 20); c.t = 1200 + Math.random() * 2500; } }
        s.x = Phaser.Math.Clamp(s.x + c.vx * dt, c.g.l, c.g.r); if (s.x <= c.g.l || s.x >= c.g.r) c.vx = -c.vx;
        moving = Math.abs(c.vx) > 1; if (moving) s.setFlipX(c.vx < 0);
      }
      c.fa += delta; if (c.fa > (c.fly ? 160 : 220)) { c.fa = 0; c.fl = moving ? 1 - c.fl : 0; s.setTexture('an_' + c.nm + '_' + c.fl); }
    });
  };
  sc.events.on('update', fn); sc.events.once('shutdown', function () { sc.events.off('update', fn); });
}
var World = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function World() { Phaser.Scene.call(this, { key: 'World' }); },
  create: function () {
    var sc = this, WW = 3200, WH = 2400; E.curLvl = 0; music('mapa'); this.ctl = new Ctl(this);
    this.cameras.main.setBounds(0, 0, WW, WH); this.cameras.main.setViewport(0, BARH, W, H - BARH); this.physics.world.setBounds(0, 0, WW, WH);
    this.add.tileSprite(0, 0, WW, WH, 'grama').setOrigin(0, 0).setTileScale(4, 4);
    this.add.image(1440, 960, 'praca').setScale(4).setDepth(1);
    var walls = this.physics.add.staticGroup();
    function wall(x, y, w, h) { walls.create(x + w / 2, y + h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody(); }
    // água do mundo: lago (nascente do rio), rio sinuoso com ponte, mar ao sul com baía na Enseada
    var CW = WW / 4, CH = WH / 4, MK = new Uint8Array(CW * CH);
    var RIOP = samplePath(chaikin([{ x: 2040, y: 300 }, { x: 2100, y: 520 }, { x: 1960, y: 680 }, { x: 1985, y: 860 }, { x: 2085, y: 1000 }, { x: 2040, y: 1120 }, { x: 2040, y: 1215 }, { x: 2040, y: 1310 }, { x: 1990, y: 1430 }, { x: 1930, y: 1570 }, { x: 2000, y: 1730 }, { x: 2095, y: 1870 }, { x: 2040, y: 2080 }], 3), 10);
    function lagoR(x, y) { var dx = (x - 2040) / 290, dy = (y - 230) / 125, th = Math.atan2(dy, dx), r = 1 + 0.12 * Math.sin(3 * th + 1) + 0.08 * Math.sin(5 * th + 2); return Math.hypot(dx, dy) < r; }
    function costa(x) { return 2040 - 135 * Math.exp(-Math.pow((x - 1650) / 340, 2)) + 26 * Math.sin(x / 150) + 14 * Math.sin(x / 61); }
    RIOP.forEach(function (q, k) { var rw = 44 + 5 * Math.sin(k * 0.23), r4 = Math.ceil(rw / 4) + 1, qx = Math.floor(q.x / 4), qy = Math.floor(q.y / 4); for (var yy = qy - r4; yy <= qy + r4; yy++) for (var xx = qx - r4; xx <= qx + r4; xx++) { if (xx < 0 || yy < 0 || xx >= CW || yy >= CH) continue; if (Math.hypot(xx + .5 - q.x / 4, yy + .5 - q.y / 4) <= rw / 4) MK[yy * CW + xx] = 1; } });
    for (var cy0 = 0; cy0 < CH; cy0++) for (var cx0 = 0; cx0 < CW; cx0++) { var wx = cx0 * 4 + 2, wy = cy0 * 4 + 2; if (wy > costa(wx)) MK[cy0 * CW + cx0] = 3; else if (lagoR(wx, wy)) MK[cy0 * CW + cx0] = 2; }
    var FLOR = [[3010, 900, 170, 640], [800, 250, 120, 95], [1580, 430, 125, 250], [250, 1290, 170, 110], [1150, 1780, 210, 105]];
    function emFlor(x, y, m) { for (var f = 0; f < FLOR.length; f++) { var F = FLOR[f]; if (Math.pow((x - F[0]) / (F[2] + m), 2) + Math.pow((y - F[1]) / (F[3] + m), 2) < 1) return true; } return false; }
    function aguaEm(x, y) { var cx = Math.floor(x / 4), cy = Math.floor(y / 4); return cx >= 0 && cy >= 0 && cx < CW && cy < CH && MK[cy * CW + cx] > 0; }
    MUNDO_AGUA = function (x, y, m) { m = m || 0; return aguaEm(x, y) || (m > 0 && (aguaEm(x + m, y) || aguaEm(x - m, y) || aguaEm(x, y + m) || aguaEm(x, y - m))) || emFlor(x, y, m); };
    (function () { // textura única da água (pixel art, 1 célula = 4 px)
      var cv = mkCv(CW, CH), g2 = cv.getContext('2d'), id = g2.createImageData(CW, CH), D = id.data;
      function nz(x, y, s) { var n = (x * 374761393 + y * 668265263 + s * 69069) | 0; n = (n ^ (n >>> 13)) * 1274126177 | 0; return (((n ^ (n >>> 16)) >>> 0) & 65535) / 65535; }
      function px(x, y, c) { var j = (y * CW + x) * 4; D[j] = c[0]; D[j + 1] = c[1]; D[j + 2] = c[2]; D[j + 3] = 255; }
      function near(x, y, r, wantWater) { for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) { var xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= CW || yy >= CH) continue; if ((MK[yy * CW + xx] > 0) === wantWater) return true; } return false; }
      for (var y = 0; y < CH; y++) for (var x = 0; x < CW; x++) {
        var k = MK[y * CW + x];
        if (k) {
          var edge = near(x, y, 1, false), shore = !edge && near(x, y, 2, false), mid = !edge && !shore && near(x, y, 4, false), r = nz(x, y, 5);
          if (edge) px(x, y, [30, 78, 140]); else if (shore) px(x, y, [110, 190, 236]);
          else { var base = k === 3 ? [40, 108, 182] : [58, 142, 214]; if (mid) base = [base[0] + 10, base[1] + 14, base[2] + 10]; if (r > 0.985) base = [214, 240, 255]; else if (((x + (y >> 1)) % 9 === 0) && r > 0.55) base = [base[0] + 34, base[1] + 34, base[2] + 22]; px(x, y, base); }
        } else if (near(x, y, 2, true)) px(x, y, near(x, y, 1, true) ? [236, 214, 150] : [222, 190, 120]);
      }
      g2.putImageData(id, 0, 0); if (sc.textures.exists('agua_mundo')) sc.textures.remove('agua_mundo'); sc.textures.addCanvas('agua_mundo', cv);
      sc.add.image(0, 0, 'agua_mundo').setOrigin(0, 0).setScale(4).setDepth(0.4);
    })();
    // paredes invisíveis na água (blocos de 32 px agrupados em faixas); a ponte deixa passagem
    for (var by = 0; by < WH; by += 32) { var run = -1; for (var bx = 0; bx <= WW; bx += 32) { var blk = bx < WW && aguaEm(bx + 16, by + 16) && !(bx >= 1984 && bx <= 2080 && Math.abs(by + 16 - 1215) < 80); if (blk && run < 0) run = bx; if (!blk && run >= 0) { wall(run, by, bx - run, 32); run = -1; } } }
    this.add.tileSprite(2040, 1215, 128, 140, 'ponte').setTileScale(4, 4).setDepth(1); this.add.image(2040, 1147, 'ponte_trilho').setScale(4).setOrigin(0.5, 1).setDepth(3); this.add.image(2040, 1283, 'ponte_trilho').setScale(4).setOrigin(0.5, 0).setDepth(3);
    // estradas ligando a Vila e todos os Reinos (retângulos x, y, largura, altura; faixa de 64 px)
    var PATHS = [
      [[960, 610], [930, 480], [850, 340], [790, 240], [760, 202]],                     // Pouso das Garças
      [[920, 650], [760, 700], [600, 650], [430, 690], [290, 640], [190, 692]],         // Jequitibá
      [[600, 650], [540, 520], [430, 380], [340, 300], [330, 282]],                     // Boca do Igarapé
      [[980, 690], [1010, 850], [1060, 990], [1090, 1100], [1100, 1212]],               // Enseada do Siri
      [[1010, 850], [800, 950], [580, 1010], [420, 1090], [330, 1142]],                 // Planalto Frio
      [[1000, 640], [1160, 730], [1360, 810], [1500, 800], [1600, 790], [1760, 832]],   // leste, pela ponte: Coxilha
      [[1500, 800], [1540, 620], [1600, 440], [1660, 350], [1680, 342]],                // Cacimba Grande
      [[1500, 800], [1480, 950], [1550, 1060], [1620, 1130], [1640, 1182]]              // Babaçual
    ];
    this.roadPts = [];
    var DOMX = { 0: 'Pouso das Garças', 1: 'Jequitibá', 2: 'Boca do Igarapé', 3: 'Enseada do Siri', 4: 'Planalto Frio', 5: 'Coxilha da Fronteira', 6: 'Cacimba Grande', 7: 'Babaçual' };
    var PW = PATHS.map(function (pa, ix) { // pontos em coordenadas do mundo; a última ponta entra na porta do Reino e a primeira da rota 0 sai da porta da Vila
      var pts = pa.map(function (q) { return WT(q[0], q[1]); }), dd = DOMINIOS.filter(function (d) { return d.n === DOMX[ix]; })[0];
      if (dd) pts[pts.length - 1] = { x: dd.x, y: dd.y + 66 };
      if (ix === 0) pts[0] = { x: 1440, y: 930 };
      return pts;
    });
    var groups = PW.map(function (pw) { var sm = samplePath(chaikin(pw, 3), 20); sc.roadPts = sc.roadPts.concat(sm); return { samples: sm, alpha: 1 }; });
    stampRoads(sc, groups);
    // sinalização: só a estrada do Reino da próxima fase fica marcada (setas, placa e seta no destino)
    var tgt = proxDom(), rotas = { 'Pouso das Garças': [PW[0]], 'Jequitibá': [PW[1]], 'Boca do Igarapé': [PW[1].slice(0, 3), PW[2]], 'Enseada do Siri': [PW[3]], 'Cacimba Grande': [PW[5].slice(0, 4), PW[6]] };
    if (tgt && rotas[tgt]) {
      var rp = []; rotas[tgt].forEach(function (pa) { rp = rp.concat(samplePath(chaikin(pa, 3), 20)); });
      for (var k = 6; k < rp.length - 6; k += 5) {
        var an = Math.atan2(rp[k + 1].y - rp[k].y, rp[k + 1].x - rp[k].x);
        var ch = this.add.text(rp[k].x, rp[k].y, '▶', { fontFamily: FONT, fontSize: '34px', color: '#ffe066', stroke: '#6b4220', strokeThickness: 5 }).setOrigin(0.5).setRotation(an).setDepth(3);
        this.tweens.add({ targets: ch, alpha: { from: 0.2, to: 1 }, scale: { from: 0.8, to: 1.15 }, yoyo: true, repeat: -1, duration: 550, delay: (k / 5) * 110 });
      }
      var sp0 = rp[Math.min(18, rp.length - 1)];
      this.add.image(sp0.x + 70, sp0.y - 10, 'ic_placa').setOrigin(0.5, 1).setScale(5).setDepth(sp0.y);
      this.add.text(sp0.x + 70, sp0.y - 96, 'Próxima fase:\n' + tgt, { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#c8561aee', padding: { x: 5, y: 2 }, align: 'center' }).setOrigin(0.5, 1).setDepth(900);
    }
    if (tgt) {
      var dd = tgt === 'Vila Mutirão' ? { x: 1440, y: 660 } : DOMINIOS.filter(function (d) { return d.n === tgt; })[0], ay = tgt === 'Vila Mutirão' ? 650 : dd.y - 205;
      var ar = this.add.text(dd.x, ay, '▼', { fontFamily: FONT, fontSize: '46px', color: '#ffe066', stroke: '#6b4220', strokeThickness: 6 }).setOrigin(0.5).setDepth(950);
      this.tweens.add({ targets: ar, y: ay + 16, yoyo: true, repeat: -1, duration: 500 });
    }
    // florestas fechadas: copas densas e intransponíveis (cada árvore tem um bloco sólido)
    FLOR.forEach(function (F, fi) {
      var fs = 400 + fi * 37; function fr() { fs = (fs * 9301 + 49297) % 233280; return fs / 233280; }
      for (var fy = F[1] - F[3]; fy <= F[1] + F[3]; fy += 40) for (var fx2 = F[0] - F[2]; fx2 <= F[0] + F[2]; fx2 += 54) {
        var ox2 = fx2 + ((Math.round(fy / 40) % 2) ? 27 : 0) + (fr() - 0.5) * 18, oy2 = fy + (fr() - 0.5) * 14, nn = 0.95 + 0.1 * Math.sin(oy2 / 53 + fi);
        if (Math.pow((ox2 - F[0]) / (F[2] * nn), 2) + Math.pow((oy2 - F[1]) / (F[3] * nn), 2) > 1) continue;
        if (aguaEm(ox2, oy2)) continue; var bad2 = false; sc.roadPts.forEach(function (r) { if (!bad2 && Math.abs(ox2 - r.x) < 90 && r.y > oy2 - 150 && r.y < oy2 + 40) bad2 = true; }); if (bad2) continue;
        var kk = fr() < 0.3 ? 'ct_jequi' : (fr() < 0.2 ? 'ct_pinheiro' : 'td_arvore'); sc.add.image(ox2, oy2, kk).setOrigin(0.5, 1).setScale(kk === 'td_arvore' ? 3.8 : 3.2).setDepth(oy2); wall(ox2 - 30, oy2 - 36, 60, 40);
      }
    });
    // árvores (determinístico), fora das estradas; só o tronco bloqueia
    var seed = 7; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    for (var i = 0; i < 160; i++) {
      var tx = 40 + rnd() * (WW - 80), ty = 70 + rnd() * (WH - 110);
      var bad = Math.abs(tx - 1440) < 760 && Math.abs(ty - 960) < 560; 
      DOMINIOS.forEach(function (d) { if (Math.abs(tx - d.x) < 560 && Math.abs(ty - d.y) < 460) bad = true; }); if (MUNDO_AGUA(tx, ty, 70)) bad = true;
      sc.roadPts.forEach(function (r) { if (!bad && Math.abs(tx - r.x) < 90 && r.y > ty - 150 && r.y < ty + 40) bad = true; });
      if (bad) continue; this.add.image(tx, ty, 'td_arvore').setOrigin(0.5, 1).setScale(4).setDepth(ty); wall(tx - 7, ty - 12, 14, 12);
    }
    // casas decorativas da vila
    [[800, 560], [1100, 560], [820, 760], [1090, 770]].map(function (p) { return [p[0] + 480, p[1] + 320]; }).forEach(function (p) { sc.add.image(p[0], p[1] + 40, ['ct_taipa','ct_sobrado','ct_chale','ct_galpao'][Math.abs(Math.round(p[0]/70))%4]).setOrigin(0.5, 1).setScale(2.4).setDepth(p[1] + 40); wall(p[0] - 40, p[1] + 14, 80, 26); });
    povoarMundo(sc, 1440, 960, 'Vila Mutirão', wall, sc.roadPts, 0); DOMINIOS.forEach(function (d, i) { povoarMundo(sc, d.x, d.y, d.n, wall, sc.roadPts, i + 1); });
    this.add.text(1440, 700, 'Vila Mutirão', { fontFamily: FONT, fontSize: '36px', fontStyle: 'bold', color: '#fff6c8', stroke: '#2a1a10', strokeThickness: 6, backgroundColor: '#000000aa', padding: { x: 12, y: 4 } }).setOrigin(0.5).setDepth(5000);
    // portas
    this.doors = [];
    this.doors.push({ x: 1440, y: 880, nome: 'Vila Mutirão', aberta: true, r: 90 });
    this.add.image(1440, 872, 'lm_vila').setOrigin(0.5, 1).setScale(4).setDepth(840);
    this.add.image(1440, 962, 'ct_portao').setOrigin(0.5, 1).setScale(3.4).setDepth(963);
    DOMINIOS.forEach(function (d) {
      pxDisc(sc, d.x, d.y + 20, 230, hexs(d.c), null, 0.35).setDepth(0.3);
      var lmimg = sc.add.image(d.x, d.y + 70, CIDK[d.n]).setOrigin(0.5, 1).setScale(3).setDepth(d.y + 40); wall(d.x - 170, d.y - 20, 340, 90);
      sc.add.text(d.x, d.y - 278, d.n, { fontFamily: FONT, fontSize: '36px', fontStyle: 'bold', color: '#fff6c8', stroke: '#2a1a10', strokeThickness: 6, backgroundColor: '#000000aa', padding: { x: 12, y: 4 } }).setOrigin(0.5).setDepth(5000);
      var aberta = (d.n === 'Boca do Igarapé' && !!E.flags.feira) || (d.n === 'Cacimba Grande' && !!E.flags.marco4) || (d.n === 'Pouso das Garças' && !!E.flags.marco5) || (d.n === 'Jequitibá' && !!E.flags.marco6) || (d.n === 'Enseada do Siri' && !!E.flags.marco7) || (['Coxilha da Fronteira', 'Babaçual', 'Planalto Frio'].indexOf(d.n) >= 0 && !!E.flags.marco4);
      if (!aberta) lmimg.setTint(0x8a8a8a);
      if (!aberta) sc.add.text(d.x, d.y - 110, '🔒', { fontSize: '40px' }).setOrigin(0.5).setDepth(5000);
      sc.doors.push({ x: d.x, y: d.y + 36, nome: d.n, bioma: d.b, aberta: aberta, r: 85 });
    });
    // Mestra Isabel na praça da Vila
    var mw = this.add.image(1440, 1060, 'n_evaristo').setOrigin(0.5, 1).setScale(4).setDepth(1060); this.tweens.add({ targets: mw, y: 1056, yoyo: true, repeat: -1, duration: 900, ease: 'Sine.easeInOut' });
    this.add.text(1440, 936, MES, { fontFamily: FONT, fontSize: '15px', color: '#ffcc80', backgroundColor: '#00000099', padding: { x: 4, y: 1 } }).setOrigin(0.5).setDepth(900);
    this.doors.push({ x: 1440, y: 1040, nome: MES, npc: true, aberta: true });
    // bichos de cada bioma
    var fb = { x0: 40, y0: 90, x1: 2800, y1: 1850 };
    DOMINIOS.forEach(function (d) { spawnFauna(sc, FAUNA[d.n], d.x, d.y + 150, 300, 4, 3, fb); });
    spawnFauna(sc, FAUNA['Vila Mutirão'], 1440, 960, 430, 5, 3, fb);
    // nuvem de ameaça
    this.cloud = this.add.image(1440, 90, 'nuvem_ameaca').setScale(4).setDepth(1000).setAlpha(0.95);
    this.cloudLabel = this.add.text(0, 0, 'Nuvem do Apagamento', { fontFamily: FONT, fontSize: '14px', color: '#ddd' }).setOrigin(0.5).setDepth(1001);
    this.placeCloud(false);
    // jogador
    var sp = E.flags.mapPos || { x: 1440, y: 900 };
    this.p = this.physics.add.sprite(sp.x, sp.y, 'av0').setScale(4).setDepth(500); this.p.setCollideWorldBounds(true);
    this.p.body.setSize(10, 6).setOffset(7, 20);
    this.physics.add.collider(this.p, walls);
    this.arb = this.add.image(this.p.x + 60, this.p.y - 70, 'arb').setScale(3).setDepth(2000);
    this.tweens.add({ targets: this.arb, scale: { from: 2.7, to: 3.6 }, yoyo: true, repeat: -1, duration: 700 });
    this.cameras.main.startFollow(this.p, true, 0.12, 0.12); this.cameras.main.setZoom(E.mapZoom || 1);
    this.anim = 0;
    if (E.mundo) vilaIniciar(this);
    if (!E.flags.prologo) {
      E.flags.prologo = true;
      this.time.delayedCall(400, function () { E.ui.run(PROLOGO); });
    }
  },
  placeCloud: function (anim) {
    var t = Math.min(1, (E.lua - 1) / 8), x = 1440, y = 90 + (800 - 90) * t * 0.82; // vem do norte, longe da Boca do Igarapé
    if (anim) this.tweens.add({ targets: this.cloud, x: x, y: y, duration: 1800 }); else this.cloud.setPosition(x, y);
  },
  update: function (time) {
    var s = this.ctl.poll(), p = this.p, ui = E.ui; if (!ui || !ui.hudT) return;
    this.cloudLabel.setPosition(this.cloud.x, this.cloud.y + 90);
    this.arb.x += (p.x + 62 - this.arb.x) * 0.08; this.arb.y += (p.y - 80 + Math.sin(time / 300) * 5 - this.arb.y) * 0.08;
    if (ui.busy) { p.setVelocity(0, 0); p.setTexture('av0'); return; }
    var vx = (s.right ? 1 : 0) - (s.left ? 1 : 0), vy = (s.down ? 1 : 0) - (s.up ? 1 : 0);
    var len = Math.sqrt(vx * vx + vy * vy) || 1; p.setVelocity(vx / len * 260, vy / len * 260);
    if (vx || vy) { p.setTexture(Math.floor(time / 140) % 2 ? 'av1' : 'av2'); if (vx) p.setFlipX(vx < 0); } else p.setTexture('av0');
    p.setDepth(p.y);
    var near = null, nd = 150;
    this.doors.forEach(function (d) { var dd = Phaser.Math.Distance.Between(p.x, p.y + 30, d.x, d.y + 20); if (dd < Math.min(nd, d.r || 150)) { nd = dd; near = d; } });
    var wc = this.cameras.main, wv = wc.worldView; if (near) ui.prompt((near.x - wv.x) * wc.zoom, BARH + (near.y - 180 - wv.y) * wc.zoom, near.npc ? '[E] Falar com a Mestra Isabel' : '[E] ' + (near.aberta ? 'Entrar' : near.nome)); else ui.prompt();
    if (s.act && near && ui.time.now > ui.lock) {
      if (near.npc) { ui.prompt(); mestreMundo(); return; }
      if (near.aberta && E.modo !== 'classico' && DOMLVL[near.nome]) {
        E.flags.mapPos = { x: near.x, y: Math.min(near.y + 110, 1880) }; ui.prompt(); snd('door'); this.scene.start('Regiao', { dom: near.nome }); return;
      }
      if (near.aberta) {
        var nx = nextLevel(near.nome); var isEns = near.nome === 'Enseada do Siri', isJeq = near.nome === 'Jequitibá', isPou = near.nome === 'Pouso das Garças', isCac = near.nome === 'Cacimba Grande', isBoca = near.nome === 'Boca do Igarapé';
        if (!nx) ui.run([{ s: 'ARBOVIA', t: isEns ? 'Marco 8 concluído! A Porta se abriu pela pressão de cinco territórios. Falta só o Marco 9, a Devolutiva, para fechar a jornada.' : isJeq ? 'Marco 7 concluído! O Plano Popular tem obras e dinheiro de verdade. As outras portas ainda não se abrem: o Marco 8 vem em breve.' : isPou ? 'Marco 6 concluído! A Roda agora decide e registra. As outras portas ainda não se abrem: o Marco 7 vem em breve.' : isCac ? 'Marco 5 concluído! Você aprendeu a ler o que o dado e o relato dizem juntos. As outras portas ainda não se abrem: o Marco 6 vem em breve.' : isBoca ? 'Marco 4 concluído! A Rede de Notícias está de pé. As outras portas ainda não se abrem: o Marco 5 vem em breve.' : E.flags.marco9 ? 'Jornada concluída! O Ciclo 1 de Entendência terminou. Revisite os lugares quando quiser: outras veredas pedem Roda.' : E.flags.feira ? 'A Rádio e a Feira já ficaram para trás. Siga para a Boca do Igarapé: a porta no canto noroeste do mapa agora está aberta.' : 'Marco 3 concluído!' }]);
        else { E.flags.mapPos = { x: 1440, y: 900 }; ui.prompt(); if (nx === 1) this.scene.start('Trecho'); else this.scene.start('Sala', { lvl: nx }); }
      }
      else ui.run([{ s: 'ARBOVIA', t: near.nome + ' (' + near.bioma + '): a porta está lacrada. A Vila Mutirão precisa de você primeiro.' }]);
    }
    if (s.esc) { E.persist(); ui.toast('Progresso salvo.'); }
  }
});
var PROLOGO = [
  { s: '', t: 'Veredália é uma terra de muitas paisagens. No coração dela, o Planalto das Veredas: fios verdes no chão dourado, onde nascem as águas.' },
  { s: '', t: 'Aqui falam muitas línguas. Cada uma sabe uma parte da verdade. Quase ninguém entende o vizinho.' },
  { s: 'ARBOVIA', t: 'Oi! Eu sou Arbovia. Vou com você. Entender não é concordar: é conseguir ouvir de verdade.' },
  { s: 'ARBOVIA', t: 'Setas ou WASD para andar. [E] para falar e entrar. Entre pela porta da Vila Mutirão, ao norte.' },
  { s: 'ARBOVIA', t: 'Ali perto, uma nuvem escura vem se aproximando a cada Lua. Vamos?' }
];

/* ---------- Trecho 1: A Vila Acorda ---------- */
var GY = 620, LW = 3840;
var Trecho = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Trecho() { Phaser.Scene.call(this, { key: 'Trecho' }); },
  create: function () {
    var sc = this; E.curLvl = 1; music('trecho'); this.ctl = new Ctl(this); this.falls = 0; this.cp = { x: 60, y: 540 }; this.hillsL = [];
    this.physics.world.gravity.y = GRAV;
    this.cameras.main.setBounds(0, 0, LW, H); this.physics.world.setBounds(0, -400, LW, H + 800);
    var cam = this.cameras.main; this.bgExterior();
    // cenário (fundo)
    [[120, 'arvore'], [760, 'arvore'], [1420, 'arvore'], [1980, 'arvore'], [2660, 'arvore'], [3040, 'arvore'], [2260, 'buriti'], [2780, 'buriti'], [3700, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
    [[250, 'casa'], [920, 'casa2'], [1250, 'casa'], [2100, 'casa2'], [3150, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(0); });
    this.add.image(560, GY + 4, 'barraca').setOrigin(0.5, 1).setScale(4).setDepth(1);
    casaImg(this, 3440, GY + 4, 'ubs').setDepth(1);
    [330, 720, 1060, 1340, 1900, 2230, 2420, 2700, 3250, 3620].forEach(function (x) { sc.add.image(x, GY + 6, 'arbusto').setOrigin(0.5, 1).setScale(3).setDepth(4); });
    // chão e plataformas
    this.solids = this.physics.add.staticGroup();
    this.mkSolid(0, GY, 1500, 100, 'solo'); this.mkSolid(1650, GY, LW - 1650, 100, 'solo');
    this.mkSolid(1760, 540, 180, 20, 'plat', 64); this.mkSolid(1990, 460, 180, 20, 'plat', 64); this.mkSolid(2220, 540, 160, 20, 'plat', 64);
    this.mkSolid(2780, 330, 100, 20, 'plat', 64); this.mkSolid(2940, 330, 220, 20, 'plat', 64);
    this.add.tileSprite(2905, 330, 32, 290, 'cipo').setOrigin(0.5, 0).setTileScale(4, 4).setDepth(2);
    this.vineX = 2905;
    mkPortal(this, 3750, 'Saída'); mkPortal(this, 40, 'Entrada');
    // pontos de Roda
    this.lamps = [60, 1380, 2300].map(function (x) { return sc.mkLamp(x); });
    // Ecos
    this.ecos = this.physics.add.staticGroup();
    this.eco1 = this.mkEco(660, 'zeni'); this.eco2 = this.mkEco(2500, 'free');
    // sabers
    this.sabers = this.physics.add.staticGroup();
    [[2080, 400, 's1'], [2990, 270, 's2'], [3250, 560, 's3']].forEach(function (s) {
      if (E.flags[s[2]]) return; var o = sc.sabers.create(s[0], s[1], 'saber').setScale(3).refreshBody(); o.key = s[2]; sc.tweens.add({ targets: o, y: s[1] - 10, yoyo: true, repeat: -1, duration: 700 });
    });
    // NPCs
    this.npcs = {
      zeni: this.add.image(500, GY + 8, 'n_zeni').setOrigin(0.5, 1).setScale(4).setDepth(3),
      leo: this.add.image(1740, GY + 8, 'n_leo').setOrigin(0.5, 1).setScale(4).setFlipX(true).setDepth(3),
      marta: this.add.image(3380, GY + 8, 'n_marta').setOrigin(0.5, 1).setScale(4).setFlipX(true).setDepth(3)
    };
    ['ZENI', 'LÉO', 'DUDA'].forEach(function (n, i) { var k = ['zeni', 'leo', 'marta'][i], o = sc.npcs[k]; sc.add.text(o.x, o.y - 124, n, { fontFamily: FONT, fontSize: '16px', color: COR[n], backgroundColor: '#00000099', padding: { x: 4, y: 1 } }).setOrigin(0.5).setDepth(4); });
    // jogador
    var st = E.flags.cpx ? { x: E.flags.cpx, y: 540 } : this.cp; this.cp = st; this.mkHero(st.x, st.y);
    cam.startFollow(this.p, true, 0.1, 0.1); cam.setDeadzone(120, 80); spawnFaunaLado(this, 'Vila Mutirão', LW, true);
    this.coyote = 0; this.buf = 0; this.climbing = false; this.lastVert = 0; this.done = !!E.flags.encontro1;
    if (E.flags.eco1) this.dissolve(this.eco1, true); if (E.flags.eco2) this.dissolve(this.eco2, true);
    if (!E.flags.t1intro) { E.flags.t1intro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'Vila Mutirão, ao amanhecer. A feira desperta, mas o ar está pesado de comentários.' },
      { s: 'ARBOVIA', t: 'Setas/A D andam, Espaço pula (segure para pular mais alto), [E] fala, [Q] Verte um Eco-de-Boca, Esc volta ao mapa.' }]); }); }
  },
  mkHero: function (x, y) {
    this.p = this.physics.add.sprite(x, y, 'av0').setScale(4).setDepth(5); this.p.body.setSize(10, 23).setOffset(7, 3); this.p.setCollideWorldBounds(false);
    this.physics.add.collider(this.p, this.solids); this.physics.add.collider(this.p, this.ecos);
    this.physics.add.overlap(this.p, this.sabers, function (pl, o) { E.flags[o.key] = true; o.destroy(); chg('Saberes', 1); E.ui.toast('+1 Saber'); });
    this.arb = this.add.image(x, y - 80, 'arb').setScale(3).setDepth(6);
    this.p.setAlpha(0); this.tweens.add({ targets: this.p, alpha: 1, duration: 500, delay: 150 }); this.exiting = false;
  },
  mkSolid: function (x, y, w, h, key, vh) {
    this.solids.create(x + w / 2, y + h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody();
    return pxSlab(this, x, y, w, vh || h, key).setDepth(2);
  },
  mkLamp: function (x) {
    var l = this.add.image(x, GY + 4, 'poste').setOrigin(0.5, 1).setScale(2.5).setDepth(1).setAlpha(0.8); l.cx = x;
    l.glow = this.add.image(x, GY - 100, 'luz').setScale(3).setDepth(1).setAlpha(0); return l;
  },
  bgExterior: function () {
    var sc = this; this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setScrollFactor(0).setDepth(-40);
    [['nuvem1', 80, 90, 0.04, 70000], ['nuvem2', 640, 190, 0.06, 90000], ['nuvem3', 1000, 50, 0.05, 80000]].forEach(function (c) {
      var im = sc.add.image(c[1], c[2], c[0]).setScale(4).setScrollFactor(c[3]).setDepth(-39); sc.tweens.add({ targets: im, x: c[1] + 220, yoyo: true, repeat: -1, duration: c[4] / 6, ease: 'Sine.easeInOut' });
    });
    [['colinas1', 0.1], ['colinas2', 0.2], ['colinas3', 0.35]].forEach(function (h, i) {
      var t = sc.add.tileSprite(0, 320, W, 400, h[0]).setOrigin(0, 0).setScrollFactor(0).setTileScale(4, 4).setDepth(-30 + i); t.tilePositionY = 80; sc.hillsL.push([t, h[1]]);
    });
  },
  bgInterior: function (L) {
    var sc = this; this.add.image(0, 0, 'ceu_int').setOrigin(0, 0).setScale(4).setScrollFactor(0).setDepth(-40);
    this.add.tileSprite(0, 0, L, GY, 'tijolo').setOrigin(0, 0).setTileScale(4, 4).setDepth(-20);
    this.add.tileSprite(0, 0, L, 70, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(-19);
    this.add.tileSprite(0, 130, L, 24, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(-19);
    for (var x = 240; x < L; x += 560) { this.add.tileSprite(x, 0, 36, GY, 'madeira').setOrigin(0.5, 0).setTileScale(4, 4).setDepth(-18); }
    this.add.tileSprite(0, 150, L, 56, 'bandeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(-17);
    for (x = 520; x < L - 200; x += 560) {
      this.add.image(x, 330, 'janela').setScale(4).setDepth(-16);
      this.add.rectangle(x + 280, 200, 4, 80, 0x2a1f2d).setDepth(-15); this.add.rectangle(x + 280, 250, 24, 18, 0xd9a441).setStrokeStyle(2, 0x2a1f2d).setDepth(-15);
      this.add.image(x + 280, 262, 'luz').setScale(4).setAlpha(0.75).setDepth(-14);
    }
  },
  mkEco: function (x, kind) {
    var e = this.ecos.create(x, GY - 120, 'eco_big'); e.setScale(4).refreshBody(); e.kind = kind; e.state = 'big';
    var R = RUIDOS[KIND2R[kind] || 'eco']; if (R.cor) e.setTint(R.cor);
    e.lab = this.add.text(x, GY - 262, R.nome, { fontFamily: FONT, fontSize: '15px', fontStyle: 'bold', color: '#fff', backgroundColor: '#4a2a7acc', padding: { x: 5, y: 1 } }).setOrigin(0.5).setDepth(4);
    this.tweens.add({ targets: e, alpha: { from: 0.85, to: 1 }, yoyo: true, repeat: -1, duration: 600 });
    return e;
  },
  dissolve: function (e, quiet) { snd('verter'); snd('poof');
    e.state = 'step'; if (e.lab) e.lab.setVisible(false); e.setTexture('eco_ok'); e.setScale(4); e.setPosition(e.x, GY - 36); e.refreshBody(); e.clearTint(); e.setAlpha(1);
  },
  grow: function (e) { e.setScale(5); e.setPosition(e.x, GY - 150); e.refreshBody(); },
  respawn: function (fell) {
    this.p.setPosition(this.cp.x, 540); this.p.setVelocity(0, 0); this.climbing = false;
    if (fell) {
      snd('fall'); chg('Ânimo', -1); this.falls++; E.ui.toast('Você caiu. Ânimo −1 — levanta e segue.');
      if (this.falls >= 3 && !this.bridge && this.cp.x < 1500) {
        this.bridge = true;
        this.solids.create(1575, GY + 8, 'px').setVisible(false).setDisplaySize(150, 16).refreshBody();
        this.add.tileSprite(1500, GY, 150, 64, 'plat').setOrigin(0, 0).setTileScale(4, 4).setDepth(2);
        E.ui.run([{ s: 'ARBOVIA', t: 'Opa! Deixa que eu estendo uma tábua aqui. Pedir ajuda também é saber.' }]);
      }
    }
  },
  ecoList: function () { return [this.eco1, this.eco2]; },
  verter: function () {
    var best = null, bd = 230, p = this.p;
    this.ecoList().forEach(function (e) { if (e.state === 'big') { var d = Phaser.Math.Distance.Between(p.x, p.y, e.x, e.y); if (d < bd) { bd = d; best = e; } } });
    if (!best) { E.ui.toast('Nada para Verter por perto.'); return; }
    var e = best, self = this, first = e === this.eco1;
    verterRuido(this, e, { ph: first ? '"derrubar... a vila inteira..."' : '"dizem que vão... tomar tudo... ouvi dizer..."', tr: first ? 'Alguém ouviu que haverá uma obra. Ninguém leu o plano ainda.' : 'Ninguém sabe quem disse; vamos perguntar de onde veio.', ok: 'O Eco virou um degrau. Dá para seguir.' }, function () { if (first) E.flags.eco1 = true; else E.flags.eco2 = true; });
  },
  talkZeni: function () {
    var self = this, sc = this;
    function ask() {
      return { ask: [
        { k: 'E', t: 'Zeni, conta de quem você ouviu e quando.', fx: function () { chg('Rede', 1); E.flags.zeniOk = true; },
          then: function () { var it = [{ s: 'ZENI', t: 'Foi... o Ed no rádio, uai. E a vizinha da frente. E o menino da padaria.' }];
            if (self.eco1.state === 'big') it.push({ fn: function () { self.dissolve(self.eco1); E.flags.eco1 = true; } }, { s: 'ARBOVIA', t: 'Viu? Quando você pergunta de onde veio, o Eco encolhe e vira degrau.' }); return it; } },
        { k: 'P', t: 'Ninguém vai derrubar nada, Zeni.', fx: function () { chg('Ânimo', -1); },
          then: function () { return [{ s: 'ZENI', t: 'Ai, e ocê sabe? Eu não sei, sô, eu *ouvi*.' }, { s: 'ARBOVIA', t: 'Hm. Negar sem saber só faz o Eco crescer. Tenta de novo.' }, ask()]; } },
        { k: '?', t: 'Zeni, quem mais comentou isso?', fx: function () { chg('Saberes', 1); E.flags.zeniOk = true; },
          then: function () { return [{ s: 'ZENI', t: 'A Duda, na UBS! Ela leu o plano. Vai lá, meu bem!' }]; } }
      ] };
    }
    var intro = E.flags.zeniOk ? [{ s: 'ZENI', t: 'Vai lá falar com a Duda, meu bem. Ela está na UBS, ao fim da rua.' }] :
      [{ s: 'ZENI', t: 'Uai, olha só quem apareceu! Tá sabendo, meu bem? Tão falando que vão derrubar a vila inteira. A do Seu Tião, a da Dona Cota, a minha barraca. Tudo!' },
       { s: 'ARBOVIA', t: 'Ele repete tudo. Sempre mais alto. (Dica: [Q] Verte o Eco-de-Boca; mas perguntar também ajuda.)' }, ask()];
    E.ui.run(intro);
  },
  talkLeo: function () {
    E.ui.run([
      { s: 'LÉO', t: 'Se a vila cair, adeus rampa nova. Eu mesmo desenhei a curva. Tá vendo? Sem degrau. Isso aí é trabalho de arte, trem bonito.' },
      { s: 'LÉO', t: 'Dica: pra subir ali, segura o pulo mais um tiquinho. A rampa dá o impulso, o resto é fé.' },
      { s: 'LÉO', t: 'Cai e levanta. É assim que se desenha uma rampa.' }]);
  },
  talkMarta: function () {
    var self = this;
    if (E.flags.encontro1) { E.ui.run([{ s: 'DUDA', t: 'O plano está no site, é só abrir. E obrigada por ouvir a Zeni.' }]); return; }
    if (!E.flags.zeniOk) { E.ui.run([{ s: 'DUDA', t: 'Isso é o terceiro aviso. O plano do Mirante está no site da prefeitura desde terça. Eu li.' }, { s: 'ARBOVIA', t: 'Fale primeiro com a Zeni, no começo da rua. O Encontro precisa das duas.' }]); return; }
    E.ui.run([
      { s: 'DUDA', t: 'Isso é o terceiro aviso. O plano do Mirante está no site da prefeitura desde terça. Eu li.' },
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'Zeni (Relato) e Duda (Cuidado) chegam juntas à UBS.' },
      { s: 'ZENI', t: 'Dizem que vão derrubar a vila!' },
      { s: 'DUDA', t: 'O plano está publicado. São 312 casas na área do projeto. A UBS está dentro.' },
      { s: 'ZENI', t: 'Dentro? Nossa Senhora, e eu aqui com boato de padaria!' },
      { s: 'DUDA', t: 'Boato de padaria que, por acaso, está certo.' },
      { ask: [
        { k: 'E', t: 'Zeni ouviu o que vai acontecer. Duda leu o plano. As duas dizem a mesma coisa, de jeitos diferentes.',
          fx: function () { chg('Entendimento', 2); chg('Rede', 2); E.gotas = Math.max(E.gotas, 2); E.flags.encontro1 = true; },
          then: [{ s: 'ZENI', t: '...É verdade.' }, { s: 'DUDA', t: '...É verdade.' }, { s: 'ARBOVIA', t: 'O Cantil ganhou uma segunda gota de luz!' }, { fn: function () { self.finish(); } }] },
        { k: 'P', t: 'A Duda é quem sabe, Zeni.', fx: function () { chg('Rede', -1); },
          then: [{ s: 'ZENI', t: 'Ah, tá. Meu saber não conta.' }, { s: 'ARBOVIA', t: 'Opa. Isso empobreceu a conversa. Fale com a Duda de novo e tente outra carta.' }] },
        { k: '?', t: 'Duda, onde está o plano? Zeni, quem mais ouviu?',
          fx: function () { chg('Saberes', 1); E.flags.encontro1 = true; },
          then: [{ s: 'DUDA', t: 'No site, é só abrir.' }, { s: 'ZENI', t: 'Eu levo a notícia pra feira!' }, { fn: function () { self.finish(); } }] }
      ] }
    ]);
  },
  finish: function () {
    var self = this; this.done = true;
    E.ui.run([
      { s: 'DUDA', t: 'Eu entendo a Zeni. Ela entende o que eu escrevo? Ninguém nunca explicou nada pra ninguém por aqui.' },
      { s: 'ARBOVIA', t: 'Dá pra explicar! O Centro Comunitário, no fim da rua, está fechado. A porta ao leste leva de volta ao mapa.' }]);
  },
  update: function (time, delta) {
    var s = this.ctl.poll(), p = this.p, b = p.body, ui = E.ui, sc = this; if (!ui || !ui.hudT) return;
    var scx = this.cameras.main.scrollX; (this.hillsL || []).forEach(function (h) { h[0].tilePositionX = scx * h[1] / 4; });
    this.arb.x += (p.x + 62 - this.arb.x) * 0.08; this.arb.y += (p.y - 80 + Math.sin(time / 300) * 5 - this.arb.y) * 0.08;
    if (p.y > H + 120) { this.respawn(true); return; }
    if (this.exiting) { b.setVelocity(0, 0); b.allowGravity = false; return; }
    if (ui.busy) { b.setVelocityX(0); if (this.climbing) b.setVelocityY(0); else if (b.blocked.down) p.setTexture('av0'); return; }
    // checkpoints
    this.lamps.forEach(function (l) { if (Math.abs(p.x - l.cx) < 70 && sc.cp.x !== l.cx) { sc.cp = { x: l.cx, y: 540 }; E.flags.cpx = l.cx; l.setAlpha(1); l.glow.setAlpha(0.85); snd('check'); ui.toast('Ponto de Roda guardado.'); } });
    var SPEED = this.noJump ? 230 : SPD, onGround = b.blocked.down || b.touching.down;
    // escalada
    var nearVine = this.vineX && Math.abs(p.x - this.vineX) < 36 && p.y > 300 && p.y < GY + 10;
    if (!this.climbing && nearVine && time > (this.noClimb || 0) && (s.up || (s.down && !onGround))) { this.climbing = true; }
    if (this.climbing) {
      b.allowGravity = false; p.x += (this.vineX - p.x) * 0.3;
      b.setVelocityY(s.up ? -190 : s.down ? 190 : 0); b.setVelocityX(0);
      if (s.jump && !s.up) { this.climbing = false; b.allowGravity = true; b.setVelocityY(-620); b.setVelocityX((s.right ? 1 : s.left ? -1 : 0) * 260); }
      else if (b.bottom < 330 + 4) { this.climbing = false; this.noClimb = time + 900; this.drift = time + 450; b.allowGravity = true; b.setVelocityY(-440); b.setVelocityX(280); }
      else if (b.blocked.down && s.down) { this.climbing = false; b.allowGravity = true; }
      p.setTexture('avc'); p.setFlipX(Math.floor(time / 180) % 2 === 0); p.setDepth(5);
    } else {
      b.allowGravity = true;
      b.setVelocityX((s.right ? 1 : 0) * SPEED - (s.left ? 1 : 0) * SPEED);
      if (time < (this.drift || 0)) b.setVelocityX(280);
      if (s.left) p.setFlipX(true); else if (s.right) p.setFlipX(false);
      if (onGround) this.coyote = 110; else this.coyote -= delta;
      if (s.jump) this.buf = 110; else this.buf -= delta;
      if (this.buf > 0 && this.coyote > 0 && !this.noJump) { b.setVelocityY(JUMP); this.buf = 0; this.coyote = 0; snd('jump'); }
      else if (E.flags.corredor && !this.noJump && this.buf > 0 && !onGround && !this.dbl && this.coyote <= 0) { b.setVelocityY(JUMP * 0.92); this.buf = 0; this.dbl = true; snd('jump'); }
      if (onGround) this.dbl = false;
      if (!s.jumpHeld && b.velocity.y < -260) b.setVelocityY(b.velocity.y * 0.55);
      if (!onGround) p.setTexture('avj'); else p.setTexture((s.left || s.right) ? (Math.floor(time / 120) % 2 ? 'av1' : 'av2') : 'av0');
    }
    if (this.lvl === 17 && this.shade) { var sh = this.shade.some(function (z) { return p.x > z[0] && p.x < z[1]; }); if (!sh) { this.heatT += delta; if (this.heatT > 14000) { this.heatT = 0; chg('Ânimo', -1); ui.toast('O calor drena o Ânimo. Procure a sombra.'); } } else this.heatT = Math.max(0, this.heatT - delta * 2); }
    if ((this.lvl === 21 || this.lvl === 30) && this.cyc) {
      this.cycTime += delta; var rem = Math.max(0, 6000 - this.cycTime);
      if (rem < 1500) this.cyc.forEach(function (c) { if (c.b.body.enable) c.v.setAlpha(Math.floor(sc.cycTime / 120) % 2 ? 0.35 : 1); });
      if (this.cycTime >= 6000) { this.cycTime = 0; this.cycN++; this.setCyc(); snd('door'); }
      this.cycT.setText(this.lvl === 30 ? 'Maré ' + (this.cycN % 2 ? 'alta' : 'baixa') + ': raízes firmes por ' + Math.ceil(rem / 1000) + ' s' : 'Tábuas ' + (this.cycN % 2 ? 'do meio' : 'das pontas') + ' firmes por ' + Math.ceil(rem / 1000) + ' s');
    }
    if (this.lvl === 25 && this.relogio) {
      this.relT += delta; if (this.relT > 1000) { this.relT -= 1000; this.horas--; if (this.horas <= 0) { this.horas = 72; chg('Ânimo', -1); ui.toast('O relógio fechou e recomeçou. Ânimo −1.'); } } this.relogio.setText('RELÓGIO: ' + this.horas + ' h');
    }
    if (this.leoMode) p.setTexture('n_leo');
    // interações
    var near = null, nd = 160, items = this.items();
    items.forEach(function (i) { var d = Math.abs(p.x - i.x); if (d < nd) { nd = d; near = i; } });
    var cam = this.cameras.main;
    if (near) ui.prompt(p.x - cam.scrollX, p.y - cam.scrollY - 110, '[E] ' + near.lbl); else ui.prompt();
    var ex = items[items.length - 1];
    if (ex && /\+1 Lua/.test(ex.lbl) && !this.leaving && !this.exiting && Math.abs(p.x - ex.x) < 36 && onGround && !ui.busy) {
      this.exiting = true; ui.prompt(); snd('door'); b.setVelocity(0, 0); p.setTexture('av0');
      this.tweens.add({ targets: p, alpha: 0, scaleX: 2, scaleY: 3, duration: 450, onComplete: function () { ex.fn(); } }); return;
    }
    if (s.act && near && ui.time.now > ui.lock) near.fn();
    if (s.verter) this.verter();
    if (s.esc) this.exit(false);
  },
  items: function () {
    var sc = this;
    return [
      { x: this.npcs.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.talkZeni(); } },
      { x: this.npcs.leo.x, lbl: 'Falar com Léo', fn: function () { sc.talkLeo(); } },
      { x: this.npcs.marta.x, lbl: 'Falar com Duda', fn: function () { sc.talkMarta(); } },
      { x: 3750, lbl: this.done ? 'Voltar ao mapa (+1 Lua)' : 'Voltar ao mapa', fn: function () { sc.exit(sc.done); } }
    ];
  },
  exit: function (advance) {
    if (this.leaving) return; this.leaving = true; E.ui.prompt();
    if (advance) { try { estrategiaFase(this.lvl || 1); } catch (e) { console.error(e); } }
    var ak = 't' + (this.lvl || 1) + 'avancou';
    if (advance && !E.flags[ak]) { E.flags[ak] = true; var antes = E.lua; E.lua = Math.min(9, 1 + [1, 2, 3, 4, 5, 6, 7, 8, 9].filter(function (i) { return E.flags['marco' + i]; }).length); E.ui.hud(); this.luaUp = E.lua > antes; if (E.lua > antes) { if (window.Snd) Snd.sfx('lua'); } else snd('door'); } else snd('door');
    E.persist(); this.physics.world.gravity.y = 0; if (advance) rocaTick();
    var msg = advance ? (this.luaUp ? 'Uma Lua passou. A nuvem se aproximou.' : 'Trecho concluído.') : 'Voltando ao mapa.';
    var nxl = advance ? CHAIN[this.lvl || 1] : 0; if (nxl && E.modo !== 'classico') { E.ui.toast(msg + ' Seguindo para a próxima fase deste lugar.'); E.regLvl = nxl; this.scene.start('Sala', { lvl: nxl }); return; }
    E.ui.toast(msg); E.regLvl = this.lvl || 1; if (E.modo === 'classico') this.scene.start('World'); else this.scene.start('Regiao', { dom: domOf(this.lvl || 1) });
  }
});


/* ---------- Sala: Trechos 2, 3 e a Roda (Marco 1) ---------- */

var ECO_TXT = {
  35: { ph: ['"sem resposta..."', '"ninguém perguntou..."'], tr: ['"Sem resposta" quer dizer: registre a ausência, ela também é dado.', '"Ninguém perguntou" quer dizer: a pergunta ainda pode ser feita.'], ok: 'O Branco se iluminou: um trecho de chão firme sob a lanterna do aliado.' },
  22: { ph: ['"febre... febre..."', '"água parada..."'], tr: ['"Febre" quer dizer: a gente precisa de cuidado antes de ter número.', '"Água parada" quer dizer: cada caixa-d\'água sem tampa é um criadouro.'], ok: 'A Febre-Mosca virou um balde emborcado. A água foi embora.' },
  24: { ph: ['"sem resposta..."', '"ninguém veio..."'], tr: ['"Sem resposta" quer dizer: registre a ausência, ela também é dado.', '"Ninguém veio" quer dizer: anote a hora em que você chamou.'], ok: 'O Ruído Branco virou uma página do Caderno, firme como chão.' },
  17: { ph: ['"não chove, não chove..."', '"a cisterna secou..."'], tr: ['"Não chove" quer dizer: eu tô cansado de esperar sozinho, oxente.', '"Secou" quer dizer: a gente precisa dividir antes que acabe.'], ok: 'A Seca-Rachada virou uma cisterna cheia, visse?' },
  12: { ph: ['"o posto vai fechar..."', '"fechou, fechou, fechou..."', '"eu ouvi, uai..."'], tr: ['"O posto vai fechar" quer dizer: eu tenho medo de perder o cuidado que eu tenho.', '"Fechou" quer dizer: alguém me disse sem conferir, e eu passei adiante.', '"Eu ouvi" quer dizer: eu confiei em quem falou, e ninguém perguntou a fonte.'], ok: 'O Eco virou chuva fina e molhou a poeira da rua.' },
  13: { ph: ['"dizem que..."', '"fulano contou..."'], tr: ['"Dizem que" quer dizer: ninguém sabe quem falou primeiro.', '"Fulano contou" quer dizer: a notícia perdeu o dono pelo caminho.'], ok: 'O Eco virou uma caixa de frutas, arrumada na banca.' },
  14: { ph: ['"gira, gira, não passa..."', '"o rio não deixa..."'], tr: ['O redemoinho diz: tem caminho, só precisa de quem escute o rio.', 'O redemoinho diz: eu giro porque ninguém me perguntou aonde eu vou.'], ok: 'O Redemoinho virou um trilho de balsa. O rio mostrou o caminho.' }
};
var LEN = { 2: 2600, 3: 2900, 4: 2000, 5: 1800, 6: 3400, 7: 2800, 8: 2600, 9: 2800, 10: 2200, 11: 3000, 12: 2400, 13: 2600, 14: 3200, 15: 2800, 16: 2200, 17: 3000, 18: 2400, 19: 2200, 20: 2600, 21: 3000, 22: 2800, 23: 2200, 24: 2600, 25: 3400, 26: 3000, 27: 2200, 28: 2800, 29: 2200, 30: 3000, 31: 2600, 32: 2600, 33: 2600, 34: 2600, 35: 2600, 36: 3800, 37: 2400, 38: 2400 };

/* ---------- Domínios livres (Pampa, Cocais, Araucárias) e Companheiros ---------- */
var GEN = {
  39: { dom: 'Coxilha da Fronteira', nome: 'A Cerca da Divisa', obj: 'Atravesse a divisa: Verta os dois Carimbos e fale com o Seu Tarcísio.', dica: 'Carimbo pede tradução: diga o que se precisa, em poucas linhas.', imp: 'Fronteira é regra escrita por quem não mora nela. Traduzir o papel mostra o que a cerca realmente pede.', L: 2400, flag: 'g39', tint: 0xc8d890,
    deco: [[300, 'arvore', 4], [1150, 'arbusto', 3], [1950, 'arbusto', 3]], plats: [[650, 500, 150], [1450, 480, 150]], saberes: [[725, 450, 'g391'], [1525, 430, 'g392']], ruidos: [['carimbo', 900], ['carimbo', 1700]],
    npcs: [['fim', 'n_teodoro', 2200, 'SEU TARCÍSIO', '#c5e1a5']],
    intro: [{ s: '', t: 'A Coxilha da Fronteira: campo aberto, vento minuano e uma cerca de arame cortando a estrada.' }, { s: 'ARBOVIA', t: 'Dois Carimbos seguram a passagem. Chegue perto e use [Q].' }],
    fim: [{ s: 'SEU TARCÍSIO', t: 'Bah, tchê! Passou sem protocolo nenhum.' }, { s: 'SEU TARCÍSIO', t: 'Faz tempo que ninguém atravessa a divisa de cabeça erguida.' }] },
  40: { dom: 'Coxilha da Fronteira', nome: 'O Rádio do Galpão', obj: 'Apague os Letreiros do rádio e fale com Dona Ledir.', dica: 'Letreiro grita: devolva o fato verificado, sem gritar.', imp: 'Boato de galpão corre mais que o vento. Checar a fonte antes de repassar protege a vizinhança.', L: 2400, flag: 'g40', tint: 0xd8c890,
    deco: [[400, 'barraca', 4], [1300, 'arbusto', 3], [2000, 'arvore', 4]], plats: [[800, 500, 150], [1600, 470, 150]], saberes: [[875, 450, 'g401'], [1675, 420, 'g402']], ruidos: [['letreiro', 1000], ['letreiro', 1800]],
    npcs: [['fim', 'n_lia', 2250, 'DONA LEDIR', '#ffab91']],
    intro: [{ s: 'DONA LEDIR', t: 'Guri, o rádio diz que vão vender o campo todo!' }, { s: 'ARBOVIA', t: 'Dois Letreiros gritam no galpão. Verta cada um com [Q].' }],
    fim: [{ s: 'DONA LEDIR', t: 'Ah, então era só boato! Vou botar o mate no fogo.' }, { s: 'DONA LEDIR', t: 'Agora eu confiro antes de passar adiante.' }] },
  41: { dom: 'Coxilha da Fronteira', nome: 'Mate na Roda', obj: 'Verta os Ecos de desânimo e sente na roda de chimarrão.', dica: 'Escute o relato inteiro antes de responder.', imp: 'Roda de mate é Roda de decisão: todo mundo tem a vez da cuia e a vez da fala.', L: 2400, flag: 'g41', tint: 0xb8d8a0,
    deco: [[350, 'arvore', 4], [1200, 'arvore', 4], [1950, 'arbusto', 3]], plats: [[700, 500, 150], [1500, 480, 150]], saberes: [[775, 450, 'g411'], [1575, 430, 'g412']], ruidos: [['eco', 950], ['eco', 1750]],
    npcs: [['fim', 'n_aristides', 2200, 'NELSON, O GURI', '#ffb74d']],
    intro: [{ s: 'ARBOVIA', t: 'Uma roda de chimarrão sem ninguém falando. Dois Ecos repetem: "não adianta".' }],
    fim: [{ s: 'NELSON', t: 'Eu achava que não adiantava. Mas agora alguém escutou.' }, { s: 'NELSON', t: 'Bah, a cuia chegou em mim. Posso falar?' }] },
  42: { dom: 'Babaçual', nome: 'As Quebradeiras de Coco', obj: 'Verta os Ecos do babaçual e fale com Dona Raimunda.', dica: 'Escute o relato inteiro antes de responder.', imp: 'Quem quebra coco conhece a mata melhor que o mapa. O relato dela é dado de campo.', L: 2400, flag: 'g42', tint: 0xa8d890,
    deco: [[300, 'buriti', 3], [1100, 'buriti', 3], [1900, 'buriti', 3]], plats: [[700, 500, 150], [1500, 480, 150]], saberes: [[775, 450, 'g421'], [1575, 430, 'g422']], ruidos: [['eco', 950], ['eco', 1750]],
    npcs: [['fim', 'n_cota', 2200, 'DONA RAIMUNDA', '#ce93d8']],
    intro: [{ s: 'DONA RAIMUNDA', t: 'Égua, menina! Coco não paga mais, dizem por aí.' }, { s: 'ARBOVIA', t: 'Dois Ecos pesam no ar. Verta cada um com [Q].' }],
    fim: [{ s: 'DONA RAIMUNDA', t: 'Pois é, meu fi. O coco paga quando a gente se junta.' }, { s: 'DONA RAIMUNDA', t: 'Sente aí, que o mingau já tá no ponto.' }] },
  43: { dom: 'Babaçual', nome: 'O Babaçu Livre', obj: 'Verta o Carimbo e o Letreiro da cerca e fale com Seu Zequiel.', dica: 'Carimbo pede tradução; Letreiro grita: devolva o fato verificado.', imp: 'Acesso livre à mata é direito escrito e vivido. Conhecer a regra abre a cerca com legitimidade.', L: 2400, flag: 'g43', tint: 0xb8d890,
    deco: [[400, 'buriti', 3], [1200, 'arbusto', 3], [1950, 'buriti', 3]], plats: [[750, 500, 150], [1550, 470, 150]], saberes: [[825, 450, 'g431'], [1625, 420, 'g432']], ruidos: [['carimbo', 1000], ['letreiro', 1800]],
    npcs: [['fim', 'n_valdete', 2250, 'SEU ZEQUIEL', '#ff8a65']],
    intro: [{ s: 'SEU ZEQUIEL', t: 'Fecharam o babaçu, meu fi. Diz que é terra de dono.' }, { s: 'ARBOVIA', t: 'Um Carimbo e um Letreiro. Cada um fala uma Língua diferente.' }],
    fim: [{ s: 'SEU ZEQUIEL', t: 'Abriu a porteira! O babaçu volta a ser de todo mundo.' }, { s: 'SEU ZEQUIEL', t: 'Égua, isso merece um café.' }] },
  44: { dom: 'Babaçual', nome: 'A Roda das Quebradeiras', obj: 'Verta o Eco e o Carimbo e feche a roda com Dona Raimunda.', dica: 'Cada Ruído fala uma Língua: leia o nome dele.', imp: 'Associação de quebradeiras é Roda: quem quebra, quem vende e quem cuida decidem juntos.', L: 2600, flag: 'g44', tint: 0xa0d890,
    deco: [[350, 'buriti', 3], [1250, 'buriti', 3], [2100, 'arbusto', 3]], plats: [[800, 500, 150], [1700, 470, 150]], saberes: [[875, 450, 'g441'], [1775, 420, 'g442']], ruidos: [['eco', 1000], ['carimbo', 1900]],
    npcs: [['fim', 'n_cota', 2400, 'DONA RAIMUNDA', '#ce93d8']],
    intro: [{ s: 'ARBOVIA', t: 'A Roda das Quebradeiras vai decidir o preço justo do coco.' }],
    fim: [{ s: 'DONA RAIMUNDA', t: 'Preço justo decidido na roda, com ata e tudo.' }, { s: 'DONA RAIMUNDA', t: 'Égua, que orgulho!' }] },
  45: { dom: 'Planalto Frio', nome: 'Pinhal e Geada', obj: 'Verta os Brancos do silêncio e fale com a Dona Gertrudes.', dica: 'Registre o que falta: a ausência também é dado.', imp: 'Quem não aparece no registro não aparece no mapa. Anotar a ausência é cuidar.', L: 2400, flag: 'g45', tint: 0xbfd0e8,
    deco: [[300, 'arvore', 5], [1100, 'arvore', 5], [1900, 'arvore', 5]], plats: [[700, 500, 150], [1500, 480, 150]], saberes: [[775, 450, 'g451'], [1575, 430, 'g452']], ruidos: [['branco', 950], ['branco', 1750]],
    npcs: [['fim', 'n_nair', 2200, 'DONA GERTRUDES', '#f8bbd0']],
    intro: [{ s: 'DONA GERTRUDES', t: 'Ô guria, aqui a geada leva até o assunto.' }, { s: 'ARBOVIA', t: 'Dois Brancos engolem as vozes. Verta cada um com [Q].' }],
    fim: [{ s: 'DONA GERTRUDES', t: 'Capaz! Anotaram até quem não veio.' }, { s: 'DONA GERTRUDES', t: 'Entra, que tem pinhão assado.' }] },
  46: { dom: 'Planalto Frio', nome: 'A Tropa no Pinhão', obj: 'Verta o Letreiro e o Eco e converse com o Seu Anselmo.', dica: 'Letreiro grita: devolva o fato verificado, sem gritar.', imp: 'Tropeiro leva notícia e leva boato. Quem confere a fonte decide o que a tropa carrega.', L: 2400, flag: 'g46', tint: 0xc8d8e8,
    deco: [[400, 'arvore', 5], [1250, 'barraca', 4], [2000, 'arvore', 5]], plats: [[800, 500, 150], [1600, 470, 150]], saberes: [[875, 450, 'g461'], [1675, 420, 'g462']], ruidos: [['letreiro', 1000], ['eco', 1800]],
    npcs: [['fim', 'n_vintem', 2250, 'SEU ANSELMO', '#b0bec5']],
    intro: [{ s: 'SEU ANSELMO', t: 'Piá, a tropa parou: diz que a estrada vai fechar.' }, { s: 'ARBOVIA', t: 'Um Letreiro e um Eco seguram a tropa.' }],
    fim: [{ s: 'SEU ANSELMO', t: 'Estrada aberta, tropa em marcha!' }, { s: 'SEU ANSELMO', t: 'Capaz que a gente chegava no fim do mês sem saber.' }] },
  47: { dom: 'Planalto Frio', nome: 'Fogo de Chão', obj: 'Verta os Ecos ao redor do fogo e feche a roda com Dona Gertrudes.', dica: 'Escute o relato inteiro antes de responder.', imp: 'Fogo de chão junta gente. A decisão tomada em volta dele é a que a comunidade cumpre.', L: 2600, flag: 'g47', tint: 0xb8c8e8,
    deco: [[350, 'arvore', 5], [1250, 'arvore', 5], [2100, 'arvore', 5]], plats: [[800, 500, 150], [1700, 470, 150]], saberes: [[875, 450, 'g471'], [1775, 420, 'g472']], ruidos: [['eco', 1000], ['eco', 1900]],
    npcs: [['fim', 'n_nair', 2400, 'DONA GERTRUDES', '#f8bbd0']],
    intro: [{ s: 'ARBOVIA', t: 'Noite no pinhal. Um fogo de chão e dois Ecos de cansaço.' }],
    fim: [{ s: 'DONA GERTRUDES', t: 'Fogo aceso, roda feita. Obrigada, guria.' }, { s: 'DONA GERTRUDES', t: 'Capaz que o planalto se aquece.' }] }
};
(function () {
  var dm = { 'Coxilha da Fronteira': [39, 40, 41], 'Babaçual': [42, 43, 44], 'Planalto Frio': [45, 46, 47] };
  var pts = { 'Coxilha da Fronteira': [[260, 430], [640, 250], [1000, 470]], 'Babaçual': [[260, 330], [640, 520], [1000, 300]], 'Planalto Frio': [[240, 480], [620, 260], [1000, 480]] };
  var ic = { 39: 'portao', 40: 'antena', 41: 'roda', 42: 'arvore', 43: 'portao', 44: 'roda', 45: 'nevoa', 46: 'barraca', 47: 'estrela' };
  var ms = { 39: 'mapa_pronto', 40: 'vila', 41: 'varanda', 42: 'sertao', 43: 'igarape', 44: 'roda', 45: 'nascente', 46: 'rota', 47: 'varanda' };
  Object.keys(dm).forEach(function (d) { DOMLVL[d] = dm[d]; REG_PTS[d] = pts[d]; });
  Object.keys(GEN).forEach(function (k) { var g = GEN[k]; OBJ[k] = [g.nome, g.obj, g.dica]; LEN[k] = g.L; ICON_LVL[k] = ic[k]; MUS['sala' + k] = ms[k]; FASE_IMP[k] = g.imp; });
  HABITO['Coxilha da Fronteira'] = 'traduzir o papel antes de obedecer a cerca'; HABITO['Babaçual'] = 'ouvir quem conhece a mata'; HABITO['Planalto Frio'] = 'anotar também quem não aparece';
  REINO_IMP['Coxilha da Fronteira'] = ['Na Coxilha a fronteira é um papel. Ciência é ler o que ele diz e o que ele esconde.', 'Quem traduz o Carimbo e confere o Letreiro atravessa a cerca com a cabeça erguida.'];
  REINO_IMP['Babaçual'] = ['No Babaçual o saber da quebradeira vale tanto quanto o dado. Relato é fonte.', 'Decisão em Roda, com ata e com preço justo, protege a mata e quem vive dela.'];
  REINO_IMP['Planalto Frio'] = ['No Planalto o frio apaga os rastros. Registrar também a ausência é método.', 'A tropa leva notícia: quem confere a fonte decide o que ela carrega.'];
})();
var COMP = { 7: 'zeni', 12: 'davi', 16: 'davi', 19: 'marta', 20: 'zeni', 22: 'marta', 33: 'leo', 34: 'leo', 41: 'zeni', 44: 'marta', 46: 'leo', 47: 'davi' };
var COMPS = {
  zeni: { nome: 'ZENI', tex: 'n_zeni', cor: '#ffb74d', ini: 'Deixa que eu converso, meu bem.', fim: 'Já conversei o que dava, uai.' },
  marta: { nome: 'DUDA', tex: 'n_marta', cor: '#80cbc4', ini: 'Bebe água e respira, Entendente.', fim: 'Já cuidei de você, agora vai.' },
  leo: { nome: 'LÉO', tex: 'n_leo', cor: '#90caf9', ini: 'Deixa que eu desenho a rampa, uai.', fim: 'A rampa tá lá. É só usar.' },
  davi: { nome: 'ED', tex: 'n_davi', cor: '#ff8a65', ini: 'Liga o microfone! Eu amplifico a sua voz.', fim: 'Microfone já tá ligado.' }
};

var Sala = new Phaser.Class({
  Extends: Trecho,
  initialize: function Sala() { Phaser.Scene.call(this, { key: 'Sala' }); },
  init: function (d) { this.lvl = (d && d.lvl) || 2; },
  create: function () {
    var sc = this, lvl = this.lvl, L = LEN[lvl], cam = this.cameras.main; E.curLvl = lvl; music('sala' + lvl);
    this.ctl = new Ctl(this); this.falls = 0; this.vineX = null; this.hillsL = []; this.leaving = false; this.fakes = null; this.cyc = null; this.shade = null; this.relogio = null; this.portao = null; this.torre = null; this.compUsed = false;
    this.physics.world.gravity.y = GRAV; cam.setBounds(0, 0, L, H); this.physics.world.setBounds(0, -400, L, H + 800);
    var ext = lvl === 3 || (lvl >= 5 && lvl !== 9 && !(lvl >= 18 && lvl <= 20) && lvl !== 23 && lvl !== 29 && lvl !== 31 && lvl !== 32 && lvl !== 34 && lvl !== 36); this.leoMode = this.noJump = lvl === 8; if (ext) this.bgExterior(); else this.bgInterior(L);
    this.solids = this.physics.add.staticGroup();
    var floor = ext ? 'solo' : 'madeira', pk = ext ? 'plat' : 'madeira', pvh = ext ? 64 : 28;
    function solid(x, y, w, h, key, vh) { return sc.mkSolid(x, y, w, h, key, vh); }
    this.lamps = []; this.sabers = this.physics.add.staticGroup(); this.ecos = this.physics.add.staticGroup(); this.ecoArr = []; this.npcs = {}; this.cp = { x: 60, y: 540 };
    function lamp(x) { sc.lamps.push(sc.mkLamp(x)); }
    function saber(x, y, k) { if (E.flags[k]) return; var o = sc.sabers.create(x, y, 'saber').setScale(3).refreshBody(); o.key = k; sc.tweens.add({ targets: o, y: y - 10, yoyo: true, repeat: -1, duration: 700 }); }
    function npc(k, tex, x, nome, cor, y) { y = y || GY; var o = sc.add.image(x, y + 8, tex).setOrigin(0.5, 1).setScale(4).setDepth(3); o.nome = nome; o.lbl = sc.add.text(x, y + 8 - 124, nome, { fontFamily: FONT, fontSize: '16px', color: cor, backgroundColor: '#14213d', padding: { x: 5, y: 2 } }).setOrigin(0.5).setDepth(4); sc.npcs[k] = o; return o; }
    function deco(key, x, sc4, y) { return sc.add.image(x, (y || GY) + 4, key).setOrigin(0.5, 1).setScale(sc4 || 4).setDepth(1); }
    lamp(60);
    if (lvl === 3) { solid(0, GY, 1300, 100, floor); solid(1450, GY, L - 1450, 100, floor); lamp(1180); } else if (lvl === 26) { [[0, 600], [880, 500], [1680, 520], [2500, L - 2500]].forEach(function (p) { solid(p[0], GY, p[1], 100, floor); }); } else if (lvl === 28) { [[0, 500], [780, 520], [1580, 520], [2380, L - 2380]].forEach(function (p) { solid(p[0], GY, p[1], 100, 'madeira', 28); }); this.add.rectangle(L / 2, GY + 130, L, 200, 0x2f9fe0, 0.85).setDepth(1); this.add.rectangle(L / 2, GY + 30, L, 6, 0xbfe8ff, 0.9).setDepth(1); } else if (lvl === 21 || lvl === 30) { [[0, 500], [800, 500], [1600, 500], [2400, L - 2400]].forEach(function (p) { solid(p[0], GY, p[1], 100, floor); }); this.add.rectangle(L / 2, GY + 130, L, 200, 0x2f9fe0, 0.85).setDepth(1); this.add.rectangle(L / 2, GY + 30, L, 6, 0xbfe8ff, 0.9).setDepth(1); } else if (lvl === 14) { [[0, 560], [700, 400], [1240, 400], [1780, 400], [2320, L - 2320]].forEach(function (p) { solid(p[0], GY, p[1], 100, 'madeira', 28); }); this.add.rectangle(L / 2, GY + 130, L, 200, 0x2f9fe0, 0.85).setDepth(1); this.add.rectangle(L / 2, GY + 30, L, 6, 0xbfe8ff, 0.9).setDepth(1); } else if (lvl !== 6) solid(0, GY, L, 100, floor);
    if (GEN[lvl]) {
      var G = GEN[lvl]; this.add.rectangle(W / 2, H / 2, W, H, G.tint, 0.1).setScrollFactor(0).setDepth(100);
      G.deco.forEach(function (d) { sc.add.image(d[0], GY + 6, d[1]).setOrigin(0.5, 1).setScale(d[2]).setDepth(-1); });
      G.plats.forEach(function (p) { solid(p[0], p[1], p[2], 20, pk, pvh); });
      G.saberes.forEach(function (q) { saber(q[0], q[1], q[2]); });
      G.ruidos.forEach(function (r, i) { var e = sc.mkEco(r[1], r[0]); e.i = i; sc.ecoArr.push(e); if (E.flags[G.flag]) sc.dissolve(e, true); });
      G.npcs.forEach(function (n) { npc(n[0], n[1], n[2], n[3], n[4]).setFlipX(true); });
      lamp(700); lamp(1500); this.exitX = G.L - 200;
    } else if (lvl === 2) {
      solid(1130, 540, 160, 20, pk, pvh); solid(1640, 530, 160, 20, pk, pvh); saber(1210, 490, 's21'); saber(1720, 480, 's22'); lamp(1000);
      deco('estante', 400, 4); deco('relogio', 620, 4); deco('cadeira', 1180, 4, 540); deco('cadeira', 1240, 4, 540); deco('mesa', 2330, 4).setAlpha(0.8);
      [900, 1400, 1900].forEach(function (x, i) { var e = sc.mkEco(x, 'voz'); e.i = i; sc.ecoArr.push(e); });
      npc('zeni', 'n_zeni', 250, 'ZENI', COR.ZENI); npc('leo', 'n_leo', 400, 'LÉO', COR['LÉO']); sc.npcs.leo.setFlipX(false);
      npc('rosa', 'n_rosa', 2330, 'ROSINHA', '#f48fb1').setVisible(false).lbl.setVisible(false);
      this.exitX = 2540;
    } else if (lvl === 3) {
      solid(1900, 540, 160, 20, pk, pvh); solid(500, 540, 140, 20, pk, pvh); saber(570, 490, 's31'); saber(1980, 490, 's32');
      [[350, 'arvore'], [1050, 'arvore'], [1700, 'buriti'], [2450, 'arvore']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      [[1000, 'casa'], [2400, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(0); });
      casaImg(this, 760, GY + 4, 'ubs').setDepth(1);
      [200, 1400, 2150, 2650].forEach(function (x) { sc.add.image(x, GY + 6, 'arbusto').setOrigin(0.5, 1).setScale(3).setDepth(4); });
      npc('mari', 'n_mari', 900, 'FERNANDA', '#b0bec5'); npc('tomas', 'n_tomas', 2000, 'TOMÁS', '#90caf9').setFlipX(true);
      this.exitX = 2820;
    } else if (lvl === 4) {
      solid(300, 540, 150, 20, pk, pvh); solid(790, 520, 150, 20, pk, pvh); solid(1290, 540, 150, 20, pk, pvh);
      deco('mesa', 1750, 4); deco('estante', 120, 4); deco('relogio', 1900, 4);
      npc('rosa', 'n_rosa', 375, 'ROSINHA', '#f48fb1', 540); npc('mari', 'n_mari', 865, 'FERNANDA', '#b0bec5', 520); npc('irac', 'n_irac', 1365, 'DRA. CINTHYA', '#a5d6a7', 540);
      var ec = [[560, 0xffa4a4], [1060, 0xffc78a], [1560, 0x8ac7ff]];
      ec.forEach(function (c, i) { var e = sc.mkEco(c[0], 'roda'); e.setTint(c[1]); e.i = i; sc.ecoArr.push(e); });
      this.stage = E.flags.stage4 || 0; this.ecoArr.forEach(function (e) { if (e.i < sc.stage) sc.dissolve(e); });
      this.exitX = 1930;
    } else if (lvl === 5) {
      [[300, 'arvore'], [1300, 'buriti'], [1560, 'arvore']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      casaImg(this, 640, GY + 4, 'casa2').setScale(5.2).setDepth(0);
      [180, 980, 1180, 1450].forEach(function (x) { sc.add.image(x, GY + 6, 'arbusto').setOrigin(0.5, 1).setScale(3).setDepth(4); });
      npc('cota', 'n_cota', 960, 'DONA COTA', '#ce93d8').setFlipX(true); lamp(1300);
      this.exitX = 1700;
    } else if (lvl === 6) {
      solid(0, GY, 800, 100, floor); solid(960, GY, 1040, 100, floor); solid(2160, GY, L - 2160, 100, floor); lamp(760); lamp(1950);
      solid(1100, 540, 170, 20, pk, pvh); solid(1340, 460, 170, 20, pk, pvh); solid(1580, 540, 170, 20, pk, pvh); saber(1420, 410, 's61'); saber(1180, 490, 's62');
      [[250, 'casa'], [700, 'casa2'], [1100, 'casa'], [1800, 'casa2'], [2300, 'casa'], [2800, 'casa2'], [3150, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [450, 1650, 2550].forEach(function (x) { sc.add.image(x, GY + 6, 'arvore').setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      npc('leo', 'n_leo', 330, 'LÉO', COR['LÉO']);
      this.regs = [600, 1420, 2550].map(function (x, i) {
        var y = i === 1 ? 460 : GY; sc.add.rectangle(x, y - 45, 8, 90, 0x6e4a2b).setDepth(2).setStrokeStyle(2, 0x2a1f2d);
        var sg = sc.add.rectangle(x, y - 100, 110, 44, E.flags['reg' + i] ? 0x6fbf55 : 0xf2c14e).setDepth(2).setStrokeStyle(3, 0x2a1f2d);
        sc.add.text(x, y - 100, 'ANOTAR', { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#2a1f2d' }).setOrigin(0.5).setDepth(3); return { x: x, i: i, sg: sg }; });
      this.exitX = 3300;
    } else if (lvl === 7) {
      solid(900, 540, 170, 20, pk, pvh); solid(1200, 470, 170, 20, pk, pvh); saber(980, 490, 's71'); saber(1280, 420, 's72');
      [[300, 'casa'], [800, 'casa2'], [1500, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [550, 1100, 2650].forEach(function (x) { sc.add.image(x, GY + 6, 'arvore').setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      this.add.image(2300, GY + 4, 'barraca').setOrigin(0.5, 1).setScale(4).setDepth(1);
      [[1640, 'n_leo'], [1780, 'n_tomas'], [1920, 'n_marta']].forEach(function (f) { sc.add.image(f[0], GY + 8, f[1]).setOrigin(0.5, 1).setScale(4).setDepth(3); });
      npc('zeni', 'n_zeni', 2060, 'ZENI', COR.ZENI); npc('gilvan', 'n_gilvan', 2260, 'WAGNER', COR.WAGNER).setFlipX(true); lamp(800);
      this.exitX = 2700;
    } else if (lvl === 8) {
      [[300, 'casa'], [1100, 'ubs'], [1700, 'casa2'], [2300, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [[560, 'arvore'], [1300, 'buriti'], [2100, 'arvore']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      this.add.rectangle(L / 2, GY - 2, L, 8, 0xffd23a, 0.9).setDepth(1);
      this.mbar = [{ x: 800, w: 70, h: 70, n: 'DEGRAU NA PORTA DA UBS', e: 'Marco aqui: degrau de vinte centímetros, sem rampa.', q: 'Quantos usam essa porta por dia?', a: '(um morador responde) A vila toda, uai. Mais de cem, fácil.' },
        { x: 1450, w: 90, h: 70, n: 'LAMA SEM CALÇADA', e: 'Marco aqui: lama e buraco, sem calçada pro campinho.', q: 'Desde quando tá assim?', a: '(um morador responde) Desde a chuva de novembro, sô. Ninguém veio arrumar.' },
        { x: 2000, w: 50, h: 90, n: 'POSTE NA CALÇADA', e: 'Marco aqui: poste no meio da calçada, sem passagem.', q: 'E do outro lado da rua?', a: '(um morador responde) Lá nem tem calçada. É só barranco, meu bem.' }].map(function (d, i) {
        var r = sc.mkBarrier(d.x, d.w, d.h, d.n); r.d = d; r.i = i; if (E.flags['mp' + i]) sc.barrierDone(r); return r; });
      npc('zeni', 'n_zeni', 2400, 'ZENI', COR.ZENI); lamp(1200);
      this.exitX = 2540;
    } else if (lvl === 9) {
      solid(600, 540, 150, 20, pk, pvh); solid(1200, 520, 150, 20, pk, pvh); solid(1800, 540, 150, 20, pk, pvh); saber(675, 490, 's91'); saber(1275, 470, 's92');
      this.relatos = [{ x: 675, y: 540, s: 'DONA COTA', t: 'Aqui era mina d\'água, sô. De manhãzinha o povo vinha de balde, e a conversa rendia mais que a água.' },
        { x: 1275, y: 520, s: 'ZENI', t: 'Minha mãe falava que secou no ano que cercaram o brejo. Pergunta pra nós ninguém fez, uai.' },
        { x: 1875, y: 540, s: 'MENINO DE ANTIGAMENTE', t: 'Eu pulava naquela pedra ali, trem bão demais. Aí a água foi embora e a turma também.' }].map(function (r, i) {
        r.i = i; r.img = sc.add.image(r.x, r.y - 70, 'eco_big').setScale(3).setDepth(3).setAlpha(E.flags['rel' + i] ? 0.25 : 0.9); sc.tweens.add({ targets: r.img, y: r.y - 82, yoyo: true, repeat: -1, duration: 900 }); return r; });
      this.pedra = this.add.rectangle(2350, GY - 14, 70, 28, 0x9a8a6a).setDepth(2).setStrokeStyle(3, 0x6a5a3a); this.add.text(2350, GY - 34, 'X', { fontFamily: FONT, fontSize: '26px', fontStyle: 'bold', color: '#c8561a' }).setOrigin(0.5, 1).setDepth(3);
      lamp(900); this.exitX = 2650;
    } else if (lvl === 10) {
      [[300, 'casa'], [1500, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [[600, 'arvore'], [1800, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      solid(700, 540, 150, 20, pk, pvh); solid(1300, 520, 150, 20, pk, pvh); saber(775, 490, 's101'); saber(1375, 470, 's102');
      this.add.image(1100, GY + 4, 'barraca').setOrigin(0.5, 1).setScale(4).setDepth(1);
      npc('aristides', 'n_aristides', 1000, 'ARISTIDES', '#ffb74d'); lamp(500); this.exitX = 2000;
    } else if (lvl === 11) {
      [[300, 'casa'], [800, 'casa2'], [2500, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      this.lona = this.add.rectangle(1100, GY - 150, 260, 120, 0xeeeeee).setDepth(2).setStrokeStyle(4, 0x3b2a2a); this.add.rectangle(1100, GY - 40, 10, 80, 0x6e4a2b).setDepth(1);
      this.lonaT = this.add.text(1100, GY - 150, E.flags.mapaPronto ? 'TERRITÓRIO\nUSADO' : 'ÁREA\nVAZIA', { fontFamily: FONT, fontSize: '30px', fontStyle: 'bold', color: E.flags.mapaPronto ? '#1f9a3c' : '#c82020', align: 'center' }).setOrigin(0.5).setDepth(3);
      npc('nivelino', 'n_nivelino', 1300, 'NIVELINO PRUMO', '#90a4ae').setFlipX(true);
      npc('lucia', 'n_lucia', 2300, 'LÚCIA PRADO', '#80cbc4').setFlipX(true);
      if (!E.flags.mapaPronto) { this.tapumeB = this.solids.create(1720 + 35, GY - 250, 'px').setVisible(false).setDisplaySize(70, 500).refreshBody();
        this.tapume = this.add.tileSprite(1720, GY - 500, 70, 500, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(2); this.tapumeT = this.add.text(1755, GY - 300, 'TAPUME', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c82020' }).setOrigin(0.5).setDepth(4); }
      lamp(900); this.exitX = 2800;
    } else if (lvl === 12) {
      [[300, 'casa'], [900, 'casa2'], [1250, 'casa'], [2100, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [[600, 'arvore'], [1700, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      casaImg(this, 1950, GY + 4, 'casa2').setScale(5.2).setDepth(0); this.add.text(1950, GY - 230, 'RÁDIO PÉ-DE-VEREDA', { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c82020', padding: { x: 5, y: 2 } }).setOrigin(0.5).setDepth(4);
      this.add.rectangle(1600, GY - 200, 10, 400, 0x6e4a2b).setDepth(1); this.add.rectangle(1600, GY - 390, 54, 30, 0xeeeeee).setDepth(2).setStrokeStyle(3, 0x3b2a2a);
      solid(1380, 540, 150, 20, pk, pvh); solid(1650, 470, 150, 20, pk, pvh); saber(1455, 490, 's121'); saber(1725, 420, 's122');
      [650, 1000, 1500].forEach(function (x, i) { var e = sc.mkEco(x, 'rumor'); e.i = i; sc.ecoArr.push(e); if (E.flags.rumorOk) sc.dissolve(e, true); });
      npc('zeni', 'n_zeni', 300, 'ZENI', COR.ZENI); npc('davi', 'n_davi', 1250, 'ED', '#ff8a65'); npc('marta', 'n_marta', 1340, 'DUDA', COR.DUDA).setFlipX(true); lamp(800);
      this.exitX = 2250;
    } else if (lvl === 13) {
      solid(400, 540, 160, 20, 'madeira', 28); solid(700, 460, 160, 20, 'madeira', 28); solid(1000, 380, 160, 20, 'madeira', 28); solid(1300, 460, 160, 20, 'madeira', 28); solid(1600, 540, 160, 20, 'madeira', 28);
      saber(480, 490, 's131'); saber(1080, 330, 's132'); saber(1680, 490, 's133');
      [[300, 'barraca'], [900, 'barraca'], [1450, 'barraca'], [2100, 'barraca']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [550, 1200, 1800].forEach(function (x) { sc.add.image(x, GY + 6, 'arbusto').setOrigin(0.5, 1).setScale(3).setDepth(4); });
      this.add.text(2100, GY - 200, 'COMPRO NOTÍCIA.\nVENDO NOTÍCIA.\nTROCO BOATO.', { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#3b2a2a', backgroundColor: '#ffd23a', align: 'center', padding: { x: 5, y: 3 } }).setOrigin(0.5).setDepth(4);
      [800, 1550].forEach(function (x, i) { var e = sc.mkEco(x, 'rumor'); e.i = i; sc.ecoArr.push(e); if (E.flags.feira) sc.dissolve(e, true); });
      npc('neide', 'n_neide', 2100, 'DONA NEIDE', '#ffd54f').setFlipX(true); lamp(1000); this.exitX = 2400;
    } else if (lvl === 14) {
      saber(900, 560, 's141'); saber(1950, 560, 's142'); lamp(760); lamp(1850);
      [900, 1980].forEach(function (x, i) { var e = sc.mkEco(x, 'rio'); e.i = i; e.setTint(0x9fe0ff); sc.ecoArr.push(e); if (E.flags['redem' + i]) sc.dissolve(e, true); });
      npc('tiao', 'n_tiao', 200, 'TIÃO BALSEIRO', '#4db6ac'); npc('cacilda', 'n_cacilda', 340, 'CACILDA', '#f48fb1'); npc('sebastiao', 'n_sebastiao', 2900, 'MESTRE SEBASTIÃO', '#4fc3f7');
      this.exitX = 3100;
    } else if (lvl === 15) {
      solid(500, 540, 170, 20, 'madeira', 28); solid(850, 470, 170, 20, 'madeira', 28); solid(1200, 540, 170, 20, 'madeira', 28); solid(1550, 470, 170, 20, 'madeira', 28); saber(585, 490, 's151'); saber(935, 420, 's152'); saber(1635, 420, 's153');
      [[300, 'casa'], [1000, 'casa2'], [1850, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [[700, 'arvore'], [1400, 'buriti'], [2050, 'arvore'], [2250, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(4).setDepth(-1); });
      npc('sebastiao', 'n_sebastiao', 400, 'MESTRE SEBASTIÃO', '#4fc3f7'); npc('joana', 'n_joana', 2050, 'RAIZA CASTANHEIRA', '#81c784').setFlipX(true);
      this.telao = this.add.rectangle(2600, GY - 330, 220, 130, 0x2a1f2d).setDepth(2).setStrokeStyle(5, 0xb04ee8).setVisible(!!E.flags.igarapeOk); this.telaoT = this.add.text(2600, GY - 330, 'JORNAL\nDAS ALTURAS', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#e1bee7', align: 'center' }).setOrigin(0.5).setDepth(3).setVisible(!!E.flags.igarapeOk);
      this.add.rectangle(2600, GY - 130, 14, 260, 0x6e4a2b).setDepth(1); lamp(1100); this.exitX = 2700;
    } else if (lvl === 16) {
      [[250, 'casa'], [1700, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      solid(350, 540, 150, 20, pk, pvh); solid(700, 470, 150, 20, pk, pvh); solid(1050, 540, 150, 20, pk, pvh); saber(425, 490, 's161'); saber(775, 420, 's162');
      this.telao = this.add.rectangle(1500, 240, 380, 200, 0x2a1f2d).setDepth(2).setStrokeStyle(6, 0xb04ee8); this.add.text(1500, 160, 'JORNAL DAS ALTURAS', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#e1bee7' }).setOrigin(0.5).setDepth(3);
      this.balao = this.add.circle(1500, 250, E.flags.marco4 ? 5 : 60, 0xff7a7a, 0.9).setDepth(3); this.balaoT = this.add.text(1500, 250, E.flags.marco4 ? '' : 'FOCO DE\nPROBLEMAS', { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#fff', align: 'center' }).setOrigin(0.5).setDepth(4);
      this.luzes = [0, 1, 2].map(function (i) { return sc.add.circle(1400 + i * 100, 340, 14, E.flags['luz' + i] ? 0xffe14a : 0x555555).setDepth(3).setStrokeStyle(3, 0xffffff); });
      npc('marta', 'n_marta', 425, 'DUDA', COR.DUDA, 540); npc('joana', 'n_joana', 775, 'RAIZA', '#81c784', 470); npc('cacilda', 'n_cacilda', 1125, 'CACILDA', '#f48fb1', 540); npc('davi', 'n_davi', 1000, 'ED', '#ff8a65');
      npc('fabio', 'n_fabio', 1800, 'FÁBIO PEREIRA', '#bcaaa4'); if (!E.flags.marco4) { sc.npcs.fabio.setVisible(false); sc.npcs.fabio.lbl.setVisible(false); }
      lamp(600); this.exitX = 2050;
    } else if (lvl === 17) {
      [[300, 'casa'], [1200, 'casa2'], [2000, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      this.shade = [[500, 760], [1500, 1760], [2400, 2700]];
      this.shade.forEach(function (z) { sc.add.image((z[0] + z[1]) / 2, GY + 6, 'arvore').setOrigin(0.5, 1).setScale(4).setDepth(4).setTint(0xc8d070); sc.add.rectangle((z[0] + z[1]) / 2, GY - 2, z[1] - z[0], 14, 0x000000, 0.12).setDepth(1); });
      [900, 1100, 1950].forEach(function (x) { sc.add.image(x, GY + 6, 'arbusto').setOrigin(0.5, 1).setScale(3).setDepth(4).setTint(0xb8d060); });
      solid(900, 540, 150, 20, pk, pvh); solid(1300, 520, 150, 20, pk, pvh); solid(1900, 540, 150, 20, pk, pvh); saber(975, 490, 's171'); saber(1375, 470, 's172'); saber(1975, 490, 's173');
      this.add.rectangle(W / 2, H / 2, W, H, 0xffa826, 0.16).setScrollFactor(0).setDepth(100); this.heatT = 0; this.hillsL.forEach(function (h) { h[0].setTint(0xe8c070); });
      [1050, 2100].forEach(function (x, i) { var e = sc.mkEco(x, 'seca'); e.i = i; e.setTint(0xffb060); sc.ecoArr.push(e); if (E.flags.valdemarOk) sc.dissolve(e, true); });
      npc('chiquinha', 'n_chiquinha', 400, 'CHIQUINHA', '#4dd0e1'); npc('valdemar', 'n_valdemar', 1650, 'SEU VALDEMAR', '#d4a95a'); lamp(1000); lamp(2000); this.exitX = 2850;
    } else if (lvl === 18) {
      solid(300, 540, 140, 20, 'madeira', 28); solid(560, 470, 140, 20, 'madeira', 28); solid(820, 540, 140, 20, 'madeira', 28); solid(1080, 470, 140, 20, 'madeira', 28); solid(1340, 400, 140, 20, 'madeira', 28); solid(1600, 470, 140, 20, 'madeira', 28);
      saber(370, 490, 's181'); saber(1410, 350, 's182'); saber(1670, 420, 's183');
      deco('estante', 200, 4); deco('estante', 700, 4); deco('estante', 1000, 4); deco('estante', 1800, 4); deco('relogio', 1950, 4);
      npc('tomas', 'n_tomas', 180, 'TOMÁS', '#90caf9'); npc('irac', 'n_irac', 2050, 'DRA. CINTHYA', '#a5d6a7').setFlipX(true); npc('dete', 'n_dete', 2200, 'ALBA DAS ERVAS', '#9ccc65').setFlipX(true); lamp(900); this.exitX = 2350;
    } else if (lvl === 19) {
      deco('estante', 300, 4); deco('relogio', 1900, 4);
      this.add.rectangle(1100, 250, 360, 200, 0xf5f0e0).setDepth(-5).setStrokeStyle(5, 0x3b2a2a); this.add.text(1100, 250, 'FEBRE · MORRO DAS MANGABAS\n14 casos no trimestre', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a', align: 'center' }).setOrigin(0.5).setDepth(-4);
      npc('irac', 'n_irac', 700, 'DRA. CINTHYA', '#a5d6a7'); npc('dete', 'n_dete', 1500, 'ALBA DAS ERVAS', '#9ccc65').setFlipX(true); npc('tomas', 'n_tomas', 1100, 'TOMÁS', '#90caf9'); this.exitX = 2000;
    } else if (lvl === 20) {
      this.telao = this.add.rectangle(2000, 230, 420, 220, 0x2a1f2d).setDepth(-5).setStrokeStyle(6, 0x9fa8da); this.telaoT = this.add.text(2000, 230, E.flags.marco5 ? '' : 'O MIRANTE REDUZ A FEBRE\nEM 62% EM 5 ANOS', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#e8eaf6', align: 'center' }).setOrigin(0.5).setDepth(-4);
      this.curva = [[500, 520], [750, 440], [1000, 360], [1250, 440], [1500, 520]].map(function (p) { return { b: solid(p[0], p[1], 170, 20, 'madeira', 28), y: p[1] }; });
      saber(580, 470, 's201'); saber(1080, 310, 's202');
      npc('prata', 'n_prata', 2150, 'SR. PRATA', '#9fa8da').setFlipX(true); npc('irac', 'n_irac', 1800, 'DRA. CINTHYA', '#a5d6a7'); npc('tomas', 'n_tomas', 1700, 'TOMÁS', '#90caf9'); lamp(400); this.exitX = 2450;
    } else if (lvl === 21) {
      this.cyc = [[500, 300, 0], [1300, 300, 1], [2100, 300, 0]].map(function (p) {
        var b = sc.solids.create(p[0] + p[1] / 2, GY + 50, 'px').setVisible(false).setDisplaySize(p[1], 100).refreshBody(); var v = sc.add.tileSprite(p[0], GY, p[1], 28, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(2);
        return { b: b, v: v, ph: p[2] }; });
      this.cycN = 0; this.setCyc = function () { sc.cyc.forEach(function (c) { var on = (c.ph === sc.cycN % 2); c.b.body.enable = on; c.v.setVisible(on).setAlpha(1); }); };
      this.setCyc(); this.cycT = this.add.text(1500, 150, '', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', backgroundColor: '#1565c0', padding: { x: 8, y: 3 } }).setOrigin(0.5).setDepth(50).setScrollFactor(0).setPosition(W / 2, 118); this.cycTime = 0;
      [[300, 'casa'], [1100, 'casa2'], [1900, 'casa'], [2700, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [[700, 'buriti'], [1500, 'buriti'], [2300, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      saber(1000, 560, 's211'); saber(1800, 560, 's212'); lamp(1000); lamp(1800); lamp(2500);
      npc('tereza', 'n_tereza', 250, 'MESTRA TEREZA', '#80cbc4'); npc('alcides', 'n_alcides', 1000, 'SEU ALCIDES', '#d4b070'); this.exitX = 2900;
    } else if (lvl === 22) {
      this.add.rectangle(W / 2, H / 2, W, H, 0x6a7a9a, 0.22).setScrollFactor(0).setDepth(100);
      [[300, 'casa'], [900, 'casa2'], [1500, 'casa'], [2100, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      solid(500, 540, 150, 20, pk, pvh); solid(1200, 520, 150, 20, pk, pvh); saber(575, 490, 's221'); saber(1275, 470, 's222');
      [800, 1700].forEach(function (x, i) { var e = sc.mkEco(x, 'febre'); e.i = i; e.setTint(0xb8d870); sc.ecoArr.push(e); if (E.flags.vilaOk) sc.dissolve(e, true); });
      npc('zeni', 'n_zeni', 350, 'ZENI', COR.ZENI); npc('marta', 'n_marta', 1000, 'DUDA', COR.DUDA); npc('leo', 'n_leo', 1900, 'LÉO', COR['LÉO']); lamp(700); lamp(1400); this.exitX = 2500;
    } else if (lvl === 23) {
      deco('estante', 150, 4); deco('relogio', 2050, 4); deco('mesa', 1100, 5);
      this.add.rectangle(1100, 220, 330, 130, 0xf5f0e0).setDepth(-5).setStrokeStyle(5, 0x3b2a2a); this.add.text(1100, 220, 'RELÓGIO DE LUAS\n72 HORAS', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#c82020', align: 'center' }).setOrigin(0.5).setDepth(-4);
      npc('rosa', 'n_rosa', 500, 'ROSINHA', '#f48fb1'); npc('marta', 'n_marta', 700, 'DUDA', COR.DUDA); npc('valdete', 'n_valdete', 900, 'MESTRA LETÍCIA', '#ff8a65'); npc('mari', 'n_mari', 1300, 'FERNANDA', '#b0bec5').setFlipX(true); npc('zeni', 'n_zeni', 1500, 'ZENI', COR.ZENI).setFlipX(true); npc('irac', 'n_irac', 1700, 'DRA. CINTHYA (RÁDIO)', '#a5d6a7').setFlipX(true);
      this.exitX = 2000;
    } else if (lvl === 24) {
      this.add.rectangle(W / 2, H / 2, W, H, 0x9a9aaa, 0.4).setScrollFactor(0).setDepth(100);
      [[300, 'estante'], [900, 'estante'], [1600, 'estante']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1).setTint(0xaaaabb); });
      solid(500, 540, 150, 20, pk, pvh); solid(1200, 520, 150, 20, pk, pvh); saber(575, 490, 's241'); saber(1275, 470, 's242');
      [800, 1400].forEach(function (x, i) { var e = sc.mkEco(x, 'branco'); e.i = i; e.setTint(0xe8e8f0); sc.ecoArr.push(e); if (E.flags.nevoaOk) sc.dissolve(e, true); });
      npc('iolanda', 'n_iolanda', 2200, 'IOLANDA', '#b0b0c0'); lamp(700); lamp(1700); this.exitX = 2450;
    } else if (lvl === 25) {
      [[300, 'casa'], [1200, 'casa2'], [2100, 'casa'], [3000, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [450, 600, 750, 1500, 1650, 1800, 2400, 2550, 2700].forEach(function (x, i) { sc.add.image(x, GY + 8, ['n_tomas', 'n_zeni', 'n_irac', 'n_leo', 'n_mari'][i % 5]).setOrigin(0.5, 1).setScale(4).setDepth(3).setTint(0xdddddd); });
      this.fila = [{ x: 1000, w: 60, h: 100, n: 'FILA' }, { x: 2000, w: 60, h: 100, n: 'FILA' }].map(function (d, i) { var r = sc.mkBarrier(d.x, d.w, d.h, d.n); r.i = i; if (E.flags['fila' + i]) sc.barrierDone(r); return r; });
      this.relogio = this.add.text(W / 2, 118, '', { fontFamily: FONT, fontSize: '24px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c82020', padding: { x: 8, y: 3 } }).setOrigin(0.5).setScrollFactor(0).setDepth(50); this.horas = 72; this.relT = 0;
      npc('zeni', 'n_zeni', 880, 'ZENI', COR.ZENI); npc('davi', 'n_davi', 1880, 'ED', '#ff8a65'); npc('mari', 'n_mari', 3050, 'FERNANDA', '#b0bec5').setFlipX(true); lamp(900); lamp(1900); lamp(2800); this.exitX = 3300;
    } else if (lvl === 26) {
      [[300, 'arvore'], [1100, 'arvore'], [1900, 'arvore'], [2700, 'arvore']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(5).setDepth(-1); });
      [[700, 'buriti'], [1500, 'buriti'], [2300, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-2).setAlpha(0.7); });
      this.add.rectangle(W / 2, H / 2, W, H, 0xdfe8ee, 0.18).setScrollFactor(0).setDepth(100);
      this.mkGaps([{ x0: 600, x1: 880, f: 'muda0', lbl: 'Plantar muda' }, { x0: 1380, x1: 1680, f: 'muda1', lbl: 'Plantar muda' }, { x0: 2200, x1: 2500, f: 'muda2', lbl: 'Plantar muda' }]);
      saber(1100, 560, 's261'); saber(1900, 560, 's262'); lamp(900); lamp(1700); lamp(2520);
      npc('teodoro', 'n_teodoro', 250, 'SEU TEODORO', '#aed581'); npc('bruna', 'n_bruna', 2800, 'RAQUEL DA RESERVA', '#66bb6a').setFlipX(true); this.exitX = 2930;
    } else if (lvl === 27) {
      this.add.rectangle(W / 2, H / 2, W, H, 0x3a4a8a, 0.14).setScrollFactor(0).setDepth(100);
      [250, 650, 1050, 1450, 1850].forEach(function (x) { lamp(x); });
      this.add.image(1100, GY + 4, 'praca').setOrigin(0.5, 1).setScale(2).setDepth(-3).setAlpha(0.9);
      [['cota', 'DONA COTA', '#ce93d8', 'n_cota'], ['zeni', 'ZENI', COR.ZENI, 'n_zeni'], ['marta', 'DUDA', COR.DUDA, 'n_marta'], ['rosa', 'ROSINHA', '#f48fb1', 'n_rosa'], ['davi', 'ED', '#ff8a65', 'n_davi'], ['aristides', 'ARISTIDES', '#ffb74d', 'n_aristides'], ['leo', 'LÉO', COR['LÉO'], 'n_leo'], ['valdete', 'LETÍCIA', '#ff8a65', 'n_valdete']].forEach(function (c, i) { npc(c[0], c[3], 400 + i * 190, c[1], c[2]).setFlipX(i > 3); });
      this.exitX = 2100;
    } else if (lvl === 28) {
      [[350, 'casa'], [1000, 'casa2'], [1850, 'casa'], [2650, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      this.add.rectangle(W / 2, H / 2, W, H, 0x8aa0b8, 0.14).setScrollFactor(0).setDepth(100);
      this.mkGaps([{ x0: 500, x1: 780, f: 'ponte0', lbl: 'Construir ponte', rel: 'Aqui moro eu, bem na beira. A água já entrou na minha cozinha três vezes.' }, { x0: 1300, x1: 1580, f: 'ponte1', lbl: 'Construir ponte', rel: 'Aqui mora a minha vizinha. Ela cuida de seis crianças. Agora elas vão pra escola a pé seco.' }, { x0: 2100, x1: 2380, f: 'ponte2', lbl: 'Construir ponte', rel: 'Aqui a gente faz o mutirão. Todo sábado, com café.' }]);
      saber(1000, 560, 's281'); saber(1850, 560, 's282'); lamp(780); lamp(1580); lamp(2380);
      npc('valdete', 'n_valdete', 250, 'MESTRA LETÍCIA', '#ff8a65'); this.exitX = 2650;
    } else if (lvl === 29) {
      deco('estante', 200, 4); deco('relogio', 2000, 4);
      this.add.rectangle(1100, 230, 340, 150, 0xf5f0e0).setDepth(-5).setStrokeStyle(5, 0x3b2a2a); this.add.text(1100, 230, 'EDITAL\n18 páginas · Anexos A a K\nContrapartida 20%', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a', align: 'center' }).setOrigin(0.5).setDepth(-4);
      npc('vintem', 'n_vintem', 800, 'SEU VINTÉM', '#b0bec5'); npc('nair', 'n_nair', 1000, 'NAIR BALDUÍNO', '#f8bbd0'); npc('rosa', 'n_rosa', 1400, 'ROSINHA', '#f48fb1').setFlipX(true); npc('valdete', 'n_valdete', 1600, 'LETÍCIA', '#ff8a65').setFlipX(true); this.exitX = 1950;
    } else if (lvl === 30) {
      this.cyc = [[500, 300, 0], [1300, 300, 1], [2100, 300, 0]].map(function (p) {
        var b = sc.solids.create(p[0] + p[1] / 2, GY + 50, 'px').setVisible(false).setDisplaySize(p[1], 100).refreshBody(); var v = sc.add.tileSprite(p[0], GY, p[1], 28, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(2).setTint(0xc89868);
        return { b: b, v: v, ph: p[2] }; });
      this.cycN = 0; this.setCyc = function () { sc.cyc.forEach(function (c) { var on = (c.ph === sc.cycN % 2); c.b.body.enable = on; c.v.setVisible(on).setAlpha(1); }); };
      this.setCyc(); this.cycT = this.add.text(W / 2, 118, '', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', backgroundColor: '#00838f', padding: { x: 8, y: 3 } }).setOrigin(0.5).setDepth(50).setScrollFactor(0); this.cycTime = 0;
      [[700, 'buriti'], [1500, 'buriti'], [2300, 'buriti']].forEach(function (p) { sc.add.image(p[0], GY + 6, p[1]).setOrigin(0.5, 1).setScale(3).setDepth(-1); });
      [[1000, 'barraca'], [1800, 'barraca']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1).setTint(0xc8b090); });
      this.cerca = this.mkBarrier(2650, 70, 150, 'CERCA · ÁREA PRIVATIVA'); if (E.flags.mareOk) this.barrierDone(this.cerca);
      saber(1000, 560, 's301'); saber(1800, 560, 's302'); lamp(1000); lamp(1800);
      npc('nonato', 'n_nonato', 250, 'MESTRE NONATO', '#4fc3f7'); npc('lia', 'n_lia', 1050, 'DONA LIA', '#ffab91'); this.exitX = 2900;
    } else if (lvl === 31) {
      deco('estante', 150, 4); deco('relogio', 2300, 4);
      this.add.rectangle(1300, 200, 240, 70, 0xf5f0e0).setDepth(-5).setStrokeStyle(4, 0x3b2a2a); this.add.text(1300, 200, 'SENHA 0042 · AGUARDE', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(-4);
      solid(600, 560, 150, 20, pk, pvh); solid(850, 500, 150, 20, pk, pvh); solid(1100, 440, 150, 20, pk, pvh); solid(1350, 380, 150, 20, pk, pvh); solid(1600, 320, 150, 20, pk, pvh); solid(1900, 300, 300, 20, pk, pvh);
      saber(675, 510, 's311'); saber(1425, 330, 's312'); lamp(900);
      npc('mari', 'n_mari', 250, 'FERNANDA', '#b0bec5'); npc('gilvan', 'n_gilvan', 450, 'WAGNER', COR.WAGNER); npc('honorio', 'n_honorio', 2000, 'REGENTE HONÓRIO', '#9fa8da', 300).setFlipX(true); this.exitX = 2450;
    } else if (lvl === 32) {
      this.add.rectangle(W / 2, H / 2, W, H, 0xe8a0e8, 0.08).setScrollFactor(0).setDepth(100);
      deco('estante', 200, 4); deco('mesa', 1700, 4);
      solid(500, 540, 150, 20, pk, pvh); solid(1000, 520, 150, 20, pk, pvh); saber(575, 490, 's321'); saber(1075, 470, 's322');
      this.fakes = this.physics.add.staticGroup();
      [[800, 500], [1300, 480], [1550, 460]].forEach(function (p) { var f = sc.fakes.create(p[0] + 75, p[1] + 10, 'px').setDisplaySize(150, 20).setTint(0xd870d8).refreshBody(); f.setDepth(2); if (p[0] === 800) saber(875, 450, 's323'); });
      npc('rosa', 'n_rosa', 1850, 'ROSINHA', '#f48fb1').setFlipX(true); npc('eulalia', 'n_eulalia', 2000, 'BARONESA EULÁLIA', '#e1a0e8').setFlipX(true); npc('cassiano', 'n_cassiano', 2350, 'CASSIANO', '#bcaaa4').setFlipX(true); lamp(800); this.exitX = 2500;
    } else if (lvl === 33) {
      [[300, 'casa'], [1000, 'casa2'], [1700, 'casa'], [2400, 'casa2']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1).setTint(0xb8b8c8); });
      this.add.rectangle(W / 2, H / 2, W, H, 0x4a4a6a, 0.12).setScrollFactor(0).setDepth(100);
      this.portao = [1300, 2200].map(function (x, i) { var r = sc.mkBarrier(x, 60, 160, 'PORTÃO DE FERRO'); r.i = i; if (E.flags['portao' + i]) sc.barrierDone(r); return r; });
      npc('ismael', 'n_ismael', 900, 'CHAVEIRO ISMAEL', '#b0bec5'); npc('pedro', 'n_pedro', 1900, 'PEDRO OLIVEIRA', '#90caf9'); saber(700, 560, 's331'); saber(1700, 560, 's332'); lamp(1000); lamp(2000); this.exitX = 2450;
    } else if (lvl === 34) {
      deco('estante', 150, 4);
      this.porta = this.add.rectangle(2250, GY - 180, 220, 360, 0x5a4a3a).setDepth(-3).setStrokeStyle(6, 0x2a1f2d); this.add.circle(2250, GY - 60, 40, 0xc82020).setDepth(-2); this.add.text(2250, GY - 60, 'EM\nANÁLISE', { fontFamily: FONT, fontSize: '14px', fontStyle: 'bold', color: '#fff', align: 'center' }).setOrigin(0.5).setDepth(-1);
      this.luzes = [0, 1, 2, 3, 4].map(function (i) { return sc.add.circle(2000 + i * 55, 140, 16, E.flags['luzp' + i] ? 0xffe14a : 0x555555).setDepth(3).setStrokeStyle(3, 0xffffff); });
      npc('mari', 'n_mari', 250, 'FERNANDA', '#b0bec5'); npc('rosa', 'n_rosa', 550, 'ROSINHA (VILA MUTIRÃO)', '#f48fb1'); npc('nonato', 'n_nonato', 850, 'NONATO (ENSEADA)', '#4fc3f7'); npc('chiquinha', 'n_chiquinha', 1150, 'CHIQUINHA (CACIMBA)', '#4dd0e1'); npc('joana', 'n_joana', 1450, 'RAIZA (BOCA)', '#81c784'); npc('tereza', 'n_tereza', 1750, 'TEREZA (POUSO)', '#80cbc4');
      npc('regente', 'n_regente', 2250, 'REGENTE NOVO', '#c5cae9').setFlipX(true); if (!E.flags.marco8) { sc.npcs.regente.setVisible(false); sc.npcs.regente.lbl.setVisible(false); } else sc.porta.setFillStyle(0x8a7a6a, 0.3);
      this.exitX = 2500;
    } else if (lvl === 35) {
      this.add.rectangle(W / 2, H / 2, W, H, 0xaab0c0, 0.28).setScrollFactor(0).setDepth(100);
      [[400, 'estante'], [1000, 'estante'], [1700, 'estante'], [2300, 'estante']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1).setTint(0xb0b8c8); });
      solid(500, 540, 150, 20, pk, pvh); solid(1100, 520, 150, 20, pk, pvh); saber(575, 490, 's351'); saber(1175, 470, 's352');
      [800, 1500].forEach(function (x, i) { var e = sc.mkEco(x, 'branco'); e.i = i; e.setTint(0xe8e8f0); sc.ecoArr.push(e); if (E.flags.voltaNevoa) sc.dissolve(e, true); });
      npc('zeni', 'n_zeni', 200, 'ZENI', COR.ZENI); npc('leo', 'n_leo', 330, 'LÉO', COR['LÉO']);
      npc('iolanda', E.flags.voltaNevoa ? 'n_iolanda2' : 'n_iolanda', 2200, 'IOLANDA', '#b0b0c0'); lamp(700); lamp(1700); this.exitX = 2450;
    } else if (lvl === 36) {
      this.torre = [['REQUALIFICAÇÃO', 'tirar gente de casa', 'melhorar com a vila', 'Projetês'], ['EM ANÁLISE', 'não sei decidir', 'estou avaliando com o grupo', 'Oficialês'], ['FOCO DE PROBLEMAS', 'rótulo', 'vila com demandas', 'Manchetês'],
        ['A GENTE SE ENTENDE', 'favor escondido', 'acordo aberto', 'Meias-palavras'], ['É PARA SUA SEGURANÇA', 'trancar', 'proteger sem trancar', 'Ordem'], ['FORA DO PRAZO', 'recusa', 'adiamento negociado', 'Edital'], ['(silêncio)', 'sem resposta', 'não foi perguntado', 'Ausência']].map(function (d, i) {
        var x = 350 + i * 460; sc.add.rectangle(x, 250, 300, 70, 0xd8d8d8).setDepth(-5).setStrokeStyle(4, 0x3b2a2a); sc.add.text(x, 240, d[0], { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(-4); sc.add.text(x, 268, 'ANDAR ' + i + ' · ' + d[3], { fontFamily: FONT, fontSize: '13px', color: '#555' }).setOrigin(0.5).setDepth(-4);
        if (i < 6) { solid(x + 120, 540 - i * 20, 120, 20, pk, pvh); } return { x: x, i: i, k: d[0], a: d[1], b: d[2], l: d[3] }; });
      saber(500, 480, 's361'); saber(1800, 450, 's362'); lamp(1500); lamp(2900);
      npc('aurelio', 'n_aurelio', 3500, 'REI CASSIANO', '#ffd54f').setFlipX(true); npc('iolanda', 'n_iolanda2', 120, 'IOLANDA', '#b0b0c0'); npc('aristides', 'n_aristides', 3300, 'ARISTIDES', '#ffb74d').setVisible(false).lbl.setVisible(false); this.exitX = 3700;
    } else if (lvl === 37) {
      this.monolo = this.add.rectangle(1200, GY - 200, 240, 400, 0x9aa0aa, 0.9).setDepth(2).setStrokeStyle(5, 0x3b2a2a); this.monoT = this.add.text(1200, GY - 330, E.flags.monologoOk ? '' : 'UMA SÓ LÍNGUA.\nUMA SÓ VOZ.', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff', align: 'center' }).setOrigin(0.5).setDepth(3);
      if (E.flags.monologoOk) { this.monolo.setFillStyle(0x4fc3f7, 0.5); this.add.rectangle(L / 2, GY + 10, L, 30, 0x4fc3f7, 0.6).setDepth(1); }
      [['n_zeni', 'ZENI', COR.ZENI], ['n_rosa', 'ROSINHA', '#f48fb1'], ['n_nonato', 'NONATO', '#4fc3f7'], ['n_chiquinha', 'CHIQUINHA', '#4dd0e1'], ['n_joana', 'RAIZA', '#81c784'], ['n_tereza', 'TEREZA', '#80cbc4'], ['n_marta', 'DUDA', COR.DUDA], ['n_leo', 'LÉO', COR['LÉO']]].forEach(function (c, i) { sc.add.image(250 + i * 110 + (i > 3 ? 900 : 0), GY + 8, c[0]).setOrigin(0.5, 1).setScale(4).setDepth(3).setFlipX(i > 3); });
      npc('cota', 'n_cota', 1000, 'DONA COTA', '#ce93d8'); npc('iolanda', 'n_iolanda2', 1400, 'IOLANDA', '#b0b0c0'); lamp(700); lamp(1700); this.exitX = 2250;
    } else if (lvl === 38) {
      this.add.rectangle(W / 2, H / 2, W, H, 0xffc878, 0.14).setScrollFactor(0).setDepth(100);
      [[400, 'casa'], [1200, 'casa2'], [2000, 'casa']].forEach(function (p) { casaImg(sc, p[0], GY + 4, p[1]).setDepth(-1); });
      [['rosa', 'ROSINHA', '#f48fb1'], ['cota', 'DONA COTA', '#ce93d8'], ['marta', 'DUDA', COR.DUDA], ['leo', 'LÉO', COR['LÉO']], ['valdete', 'LETÍCIA', '#ff8a65'], ['davi', 'ED', '#ff8a65'], ['iolanda2', 'IOLANDA', '#b0b0c0']].forEach(function (c, i) { npc(c[0], 'n_' + c[0], 300 + i * 220, c[1], c[2]).setFlipX(i > 3); });
      this.exitX = 2250;
    }
    mkPortal(this, this.exitX, 'Saída'); mkPortal(this, 40, 'Entrada');
    (RUIDOS_EXTRA[lvl] || []).forEach(function (g) { g[1].forEach(function (x, ix) {
      var ok = sc.solids.getChildren().some(function (b) { var bd = b.body; return bd && bd.left <= x - 90 && bd.right >= x + 90 && Math.abs(bd.top - GY) < 30; });
      if (!ok || x > sc.exitX - 300) return; var e = sc.mkEco(x, g[0]); e.i = ix; sc.ecoArr.push(e); if (E.flags['rx' + lvl + '_' + x]) sc.dissolve(e, true); e.xkey = 'rx' + lvl + '_' + x; });
    });
    if (COMP[lvl]) { var CC = COMPS[COMP[lvl]]; npc('comp', CC.tex, 230, CC.nome, CC.cor); }
    this.mkHero(60, 540);
    if (this.fakes) var fcol = this.physics.add.collider(this.p, this.fakes, function (pl, f) { if (f.falling || !pl.body.touching.down) return; f.falling = true; sc.time.delayedCall(450, function () { if (!f.body) return; f.body.enable = false; f.setAlpha(0.2); sc.time.delayedCall(3000, function () { if (f.body) { f.body.enable = true; f.setAlpha(1); f.falling = false; } }); }); });
    if (this.fakes) this.events.once('shutdown', function () { try { fcol.destroy(); } catch (e) {} });
    cam.startFollow(this.p, true, 0.1, 0.1); cam.setDeadzone(120, 80); spawnFaunaLado(this, domOf(lvl), L, ext);
    this.coyote = 0; this.buf = 0; this.climbing = false;
    if (GEN[lvl] && !E.flags['gi' + lvl]) { E.flags['gi' + lvl] = true; this.time.delayedCall(300, function () { E.ui.run(GEN[lvl].intro); }); }
    if (lvl === 5 && !E.flags.varIntro) { E.flags.varIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'A varanda de Dona Cota, à tarde. A luz dourada entra pelo capim, e o cheiro de café passado enche o ar.' },
      { s: 'ARBOVIA', t: 'Vá até a Dona Cota. Aperte [C] a qualquer hora para abrir o Caderno de Traduções.' }]); }); }
    if (lvl === 6 && !E.flags.rotaIntro) { E.flags.rotaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'LÉO', t: 'Primeira regra do mapa: anda devagar, uai. Quem corre não vê.' },
      { s: 'LÉO', t: 'Segunda: anota o que ninguém anota. Calçada quebrada, bueiro, esquina escura. É nisso que a ambulância demora.' },
      { s: 'ARBOVIA', t: 'Nos postes ANOTAR, aperte [E] para registrar. Acompanhe o Léo pelas ruas e telhados.' }]); }); }
    if (lvl === 7 && !E.flags.filaIntro) { E.flags.filaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'A praça. Uma mesa dobrável, uma tenda e uma fila de moradores que não anda.' },
      { s: 'ARBOVIA', t: 'É o balcão improvisado de Mandorra. Vamos ver o que o Wagner está pedindo.' }]); }); }
    if (lvl === 8 && !E.flags.mapaIntro) { E.flags.mapaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 3 · TERRITÓRIO USADO', t: 'O Mapa de Quem Não Passa. Hoje você anda nas rodas do Léo: sem pulo, só passa onde tem rampa.' },
      { s: 'LÉO', t: 'Cada degrau é uma porta fechada, uai. Chega perto de cada barreira vermelha e marca no mapa.' },
      { s: 'ARBOVIA', t: 'Barreira vermelha: onde falta rampa. Linha amarela: o caminho possível. Aperte [E] perto de cada barreira.' }]); }); }
    if (lvl === 9 && !E.flags.nascIntro) { E.flags.nascIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'A Nascente Antiga, atrás da horta. Aqui a água não vem do chão: vem da memória. Chegue perto das vozes e escute.' },
      { s: 'CADERNO', t: 'Lente do Relato: só anote com licença de quem contou.' }]); }); }
    if (lvl === 10 && !E.flags.cantIntro) { E.flags.cantIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'O Canteiro da obra parada. Um homem de capacete amarelo desenha na terra com um graveto.' },
      { s: 'ARBOVIA', t: 'É o Seu Aristides. Ele sabe coisa que o mapa novo não sabe.' }]); }); }
    if (lvl === 11 && !E.flags.mapaPIntro) { E.flags.mapaPIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'O Mapa que Já Vem Pronto.' },
      { s: 'ARBOVIA', t: 'Um tapume gigante fecha o caminho. Atrás dele, a moça que fez o mapa. Fale com o Nivelino e mostre as camadas que a gente reuniu.' }]); }); }
    if (lvl === 12 && !E.flags.radioIntro) { E.flags.radioIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 4 · O RUMOR', t: 'No Ar. Do alto-falante da Rádio Pé-de-Vereda saem vozes que se espalham pela vila.' },
      { s: 'ARBOVIA', t: 'Ecos-de-Boca! Cada um repete a mesma notícia, e cada repetição cresce. Chegue perto e use [Q] para Verter.' }]); }); }
    if (lvl === 13 && !E.flags.feiraIntro) { E.flags.feiraIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'A Feira do Pequi. Barracas em andares, gritaria, cheiro de fruta e de fofoca.' },
      { s: 'ARBOVIA', t: 'Suba pelas barracas. Lá no fim mora a Dona Neide, a Cambista de Notícias.' }]); }); }
    if (lvl === 14 && !E.flags.rioIntro) { E.flags.rioIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'O Rio-Mundo. Uma balsa de tábuas, chuva fina, copas altíssimas nas margens.' },
      { s: 'ARBOVIA', t: 'Pule entre as tábuas e Verta os Redemoinhos que travam o caminho. Cuidado: quem cai na água volta ao último poste.' }]); }); }
    if (lvl === 15 && !E.flags.igaIntro) { E.flags.igaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'SEBASTIÃO', t: '(no microfone) Bom dia, Boca do Igarapé! Aqui é a Rádio-Barco, a notícia que flutua. Hoje: chuva à tarde, peixe na feira e um papel que não cheira bem.' },
      { s: 'ARBOVIA', t: 'A Raiza está na ponte, lá adiante, com um rolo de papéis.' }]); }); }
    if (lvl === 16 && !E.flags.boatoIntro) { E.flags.boatoIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'O Boato.' },
      { s: 'CLÉO', t: '(no telão) Boa noite, Veredália! No Jornal das Alturas: EXCLUSIVO! Vilas dos Baixios fecham posto, ocupam terra e ameaçam o progresso. Fontes confiáveis dizem que a desordem é generalizada.' },
      { s: 'ARBOVIA', t: 'Ela está inventando! Para estourar o balão, confirme a notícia em três fontes: Duda, Raiza e Cacilda.' }]); }); }
    if (lvl === 17 && !E.flags.sertaoIntro) { E.flags.sertaoIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 5 · A LEITURA', t: 'Cacimba Grande. Sol forte, cisternas azuis, mandacaru e serra ao fundo.' },
      { s: 'CHIQUINHA', t: 'Bom dia, visse! A água é pouca, mas quem divide, não falta. Cada telha, uma cisterna. Cada cisterna, uma família.' },
      { s: 'ARBOVIA', t: 'O calor drena o Ânimo. Procure a sombra das árvores, onde o chão escurece.' }]); }); }
    if (lvl === 18 && !E.flags.chapIntro) { E.flags.chapIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'TOMÁS', t: 'Que bom que vocês vieram! A Dra. Cinthya tá de mau humor. Quando os números não batem, ela fica assim.' },
      { s: 'TOMÁS', t: 'Sobe pelas estantes seguindo o padrão: sobe três, desce dois, sobe três. Se acompanhar o movimento, o resto é pulo.' }]); }); }
    if (lvl === 20 && !E.flags.pratIntro) { E.flags.pratIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'O Gráfico que Mente.' },
      { s: 'ARBOVIA', t: 'O Sr. Prata, de Concretália, trouxe um telão. Suba pela curva e use o Leitor de Sinais para fazer as perguntas certas.' }]); }); }
    if (lvl === 21 && !E.flags.pantIntro) { E.flags.pantIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 6 · A SALA', t: 'Pouso das Garças. A planície em cheia: casas em aterros, canoas, garças em bando. A água sobe e desce.' },
      { s: 'TEREZA', t: 'A água sobe, a água desce, cumpadre. A gente aprendeu a subir e a descer com ela.' },
      { s: 'ARBOVIA', t: 'As tábuas aparecem quando a água desce, e somem quando ela sobe. Leia o ritmo no relógio azul, no alto.' }]); }); }
    if (lvl === 22 && !E.flags.cheiaIntro) { E.flags.cheiaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'DUDA', t: 'Cota tá com febre alta! É a febre das águas paradas!' }, { s: 'LÉO', t: 'A Baixada alagou, uai! Tem gente em cima do telhado!' },
      { s: 'ZENI', t: 'As caixas-d\'água viraram criadouro, e eu só queria uma feira em paz!' },
      { s: 'ARBOVIA', t: 'Você não dá conta de tudo sozinho: só duas ações. O resto, só a Roda resolve.' }]); }); }
    if (lvl === 23 && !E.flags.crisesIntro) { E.flags.crisesIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ROSINHA', t: 'Três crises. Recurso pra uma e meia. Hoje a gente decide. Pauta!' },
      { s: 'DUDA', t: 'Demanda 1: a Febre. Seis casos novos, nenhum sério. Risco de dobrar em dois dias.' }, { s: 'LETÍCIA', t: 'Demanda 2: a Baixada. Quarenta pessoas desabrigadas. Falta abrigo e comida.' },
      { s: 'FERNANDA', t: 'Demanda 3: a Eleição da Cadeira, em Mandorra, em três dias. O Regente prometeu a Rampa e o Posto. Se mudar, pode ser desfeito.' },
      { s: 'ARBOVIA', t: 'Traduza a urgência de cada uma: fale com Duda, Letícia e Fernanda. Depois, registre na mesa.' }]); }); }
    if (lvl === 24 && !E.flags.nevoaIntro) { E.flags.nevoaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'VOZ', t: '(sussurro, sem corpo) Não passe sozinho.' }, { s: 'ARBOVIA', t: 'A Névoa. Os Ruídos Brancos fecham o caminho: Verta cada um e a página em branco vira chão.' }]); }); }
    if (lvl === 25 && !E.flags.filaIntro2) { E.flags.filaIntro2 = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'A Fila das 72 Horas.' }, { s: 'ARBOVIA', t: 'Chegue ao último balcão antes que o relógio feche. Cada aliado abre uma porta na fila.' }]); }); }
    if (lvl === 26 && !E.flags.mataIntro) { E.flags.mataIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 7 · O PLANO', t: 'Fragmento do Jequitibá. A mata em pedaços, entre muros e avenidas. Neblina, copas gigantes.' },
      { s: 'TEODORO', t: 'Isto é uma pata-de-vaca, meu. Em dez anos dá sombra. Em quarenta, dá casa pra passarinho.' },
      { s: 'RAQUEL', t: 'O problema é que a mata tá em ilhas, cara. Dois pedaços sozinhos morrem. Ligados, se curam. A gente chama de corredor.' },
      { s: 'ARBOVIA', t: 'Nos vãos grandes, chegue na beirada e aperte [E] para plantar uma muda: ela cresce até virar ponte.' }]); }); }
    if (lvl === 27 && !E.flags.sonhoIntro) { E.flags.sonhoIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'A praça de Vila Mutirão, de noite, com lanternas. A Roda faz o círculo. Cada pessoa conta o seu sonho. Escute todas e depois monte a obra na mesa.' }]); }); }
    if (lvl === 28 && !E.flags.baixIntro) { E.flags.baixIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'A Baixada do Lamaçal: palafitas sobre terra alagada, pontes frágeis, chuva fraca. Fale com a Mestra Letícia antes de construir.' }]); }); }
    if (lvl === 29 && !E.flags.edIntro) { E.flags.edIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'O Orçamento que Acabou.' }, { s: 'VINTÉM', t: 'Temos um edital. Recurso, sim. Mas o prazo é de cinco dias, com formulário de dezoito páginas, anexos A a K, certidões negativas e contrapartida de vinte por cento.' },
      { s: 'NAIR', t: '(baixo) Dezoito páginas. Eu mesma estou perdida.' }, { s: 'ROSINHA', t: 'Vinte por cento de quê? Se a gente tivesse dinheiro, não precisava de edital.' }, { s: 'VINTÉM', t: 'São as regras.' }]); }); }
    if (lvl === 30 && !E.flags.costaIntro) { E.flags.costaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 8 · A PORTA', t: 'Enseada do Siri. Uma praia cercada, mangue ao lado, barcos de pescador encalhados.' },
      { s: 'NONATO', t: 'A praia sempre foi de todos, meu rei. Agora tem cerca. Dizem que é do resort.' },
      { s: 'LIA', t: 'Do outro lado, o mangue tá sendo aterrado. Sem mangue, sem siri. Sem siri, sem prato.' },
      { s: 'ARBOVIA', t: 'A maré sobe e desce: as raízes de mangue firmes mudam a cada ciclo. Leia o aviso azul, no alto.' }]); }); }
    if (lvl === 31 && !E.flags.mandIntro) { E.flags.mandIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'FERNANDA', t: 'Cheguei. Ninguém me viu. Mas me viram.' }, { s: 'WAGNER', t: '(em segredo) O de vocês tá no terceiro andar. Eu mandei mais rápido.' },
      { s: 'ARBOVIA', t: 'Suba pela escada de balcões até a Cadeira Giratória, no topo.' }]); }); }
    if (lvl === 32 && !E.flags.veluIntro) { E.flags.veluIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'EULÁLIA', t: 'Meus queridos! Quanta honra! Uma vila inteira à minha porta. Entrem, entrem. Ninguém sai da minha casa de mãos vazias.' },
      { s: 'ARBOVIA', t: 'Cuidado com as Cortinas-Fofas: as plataformas cor de rosa cedem sob o peso.' }]); }); }
    if (lvl === 33 && !E.flags.ferrIntro) { E.flags.ferrIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: '', t: 'O Portão de Ferrolho. Ruas estreitas, portões de ferro, vigias e toque de recolher.' }, { s: 'ARBOVIA', t: 'Nada de força: os cadeados só se abrem com ajuda de quem tem a chave.' }]); }); }
    if (lvl === 34 && !E.flags.portaIntro) { E.flags.portaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'A Porta Fechada.' }, { s: 'VOZ DA PORTA', t: '(o Carimbo, grave) O assunto encontra-se em análise.' },
      { s: 'ARBOVIA', t: 'A Porta só abre quando cinco territórios fizerem a mesma exigência ao mesmo tempo. Chame cada aliado.' }]); }); }
    if (lvl === 35 && !E.flags.voltaIntro) { E.flags.voltaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'MARCO 9 · A DEVOLUTIVA', t: 'A Névoa Muda, de volta. Desta vez você chega acompanhado.' }, { s: 'ZENI', t: 'Aqui é frio, uai.' }, { s: 'LÉO', t: '(olhando as prateleiras) Mapa sem nome. Gavetas sem fim. Alguém precisa ler isso.' }, { s: 'ARBOVIA', t: 'Estou aqui. Os Brancos se iluminam com as lanternas de vocês: use [Q] para Verter cada um.' }]); }); }
    if (lvl === 36 && !E.flags.torreIntro) { E.flags.torreIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'A Torre Inacabada. Cada andar fala uma Língua e traz uma palavra-chave escrita na parede. Traduza as sete, de baixo para cima.' }]); }); }
    if (lvl === 37 && !E.flags.monoIntro) { E.flags.monoIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'A Praça das Águas, abrindo-se por dentro como uma flor de concreto. Delegações de todos os Domínios em círculo.' },
      { s: 'MONÓLOGO', t: 'UMA SÓ LÍNGUA. UMA SÓ VOZ. UMA SÓ DECISÃO. SEM CONFUSÃO. SEM MEDO.' }, { s: 'ARBOVIA', t: 'Ele está com medo.' }, { s: 'IOLANDA', t: 'É medo que a gente não se entenda.' }]); }); }
    if (lvl === 2 && !E.flags.salaoIntro) { E.flags.salaoIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ZENI', t: '(passando pano) Fechado há sete anos, uai. Desde a Cerca. Ninguém teve coragem de abrir.' },
      { s: 'LÉO', t: 'Eu tive coragem, mas a chave tinha coragem maior.' },
      { s: 'ARBOVIA', t: 'Olha! Vozes antigas presas no salão. Chegue perto de um Eco e use [Q] para Verter.' }]); }); }
    if (lvl === 3 && !E.flags.convIntro) { E.flags.convIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ARBOVIA', t: 'Rosinha pediu três lados: gente nossa, gente da prefeitura e gente que entende de número. Faltam Fernanda e a Dra. Cinthya.' }]); }); }
    if (lvl === 4 && !E.flags.rodaIntro) { E.flags.rodaIntro = true; this.time.delayedCall(300, function () { E.ui.run([
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'A Reunião que Não Acontece. Ninguém senta.' },
      { s: 'ROSINHA', t: 'Eu só falo se houver ata em papel e assinatura de todo mundo.' },
      { s: 'FERNANDA', t: 'Eu só fico se não for gravado e se eu puder sair a qualquer momento.' },
      { s: 'DRA. CINTHYA', t: 'Eu só fico se trouxerem dado. Relato não é evidência.' },
      { s: 'ARBOVIA', t: 'Eles estão falando a mesma coisa. Só que cada um fala de um lado. Traduza as falas, uma a uma, da esquerda para a direita.' }]); }); }
  },
  respawn: function (fell) {
    this.p.setPosition(this.cp.x, 540); this.p.setVelocity(0, 0); this.climbing = false;
    if (!fell) return;
    chg('Ânimo', -1); this.falls++; E.ui.toast('Você caiu. Ânimo −1 — levanta e segue.');
    if (this.lvl === 3 && this.falls >= 3 && !this.bridge) {
      this.bridge = true; this.solids.create(1375, GY + 8, 'px').setVisible(false).setDisplaySize(150, 16).refreshBody();
      this.add.tileSprite(1300, GY, 150, 64, 'plat').setOrigin(0, 0).setTileScale(4, 4).setDepth(2);
      E.ui.run([{ s: 'ARBOVIA', t: 'Deixa que eu estendo uma tábua. Pedir ajuda também é saber.' }]);
    }
  },
  ecoList: function () { return this.ecoArr; },
  verter: function () {
    var sc = this, p = this.p;
    if (this.lvl === 4) { E.ui.toast('Aqui não basta Verter: fale com cada pessoa e traduza.'); return; }
    var best = null, bd = 230;
    this.ecoArr.forEach(function (e) { if (e.state === 'big') { var d = Phaser.Math.Distance.Between(p.x, p.y, e.x, e.y); if (d < bd) { bd = d; best = e; } } });
    if (!best) { E.ui.toast('Nada para Verter por perto.'); return; }
    var e = best;
    verterRuido(this, e, null, function () { if (sc.lvl === 14) E.flags['redem' + e.i] = true; });
  },
  talkGen: function () {
    var sc = this, G = GEN[this.lvl], pend = this.ecoArr.some(function (e) { return e.state === 'big'; });
    if (pend) { sc.say([{ s: G.npcs[0][3].split(',')[0], t: 'Ainda tem Ruído no caminho. Verta com [Q] e eu converso.' }]); return; }
    if (E.flags[G.flag]) { sc.say(G.fim.slice(0, 1)); return; }
    sc.say(G.fim.concat([{ fn: function () { E.flags[G.flag] = true; chg('Saberes', 1); chg('Entendimento', 1); chg('Visibilidade', 1); chg('Rede', 1); note('DOMÍNIO LIVRE', G.nome + ': concluído.', G.dom); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } }, { s: 'ARBOVIA', t: 'Fase livre concluída. Visibilidade e Voz cresceram.' }]));
  },
  talkComp: function () {
    var sc = this, k = COMP[this.lvl], C = COMPS[k];
    if (this.compUsed) { sc.say([{ s: C.nome, t: C.fim }]); return; }
    if (k === 'zeni') {
      var p = this.p, best = null, bd = 1e9; this.ecoArr.forEach(function (e) { if (e.state === 'big') { var d = Math.abs(p.x - e.x); if (d < bd) { bd = d; best = e; } } });
      if (!best) { sc.say([{ s: C.nome, t: 'Não vejo Ruído por aqui, meu bem.' }]); return; }
      this.compUsed = true; var R = ruidoOf(best); sc.say([{ s: C.nome, t: C.ini }, { s: C.nome, t: 'Aquele ali é ' + R.nome + ' e fala ' + R.lingua + '. Verta nessa Língua.' }]);
    } else if (k === 'marta') { this.compUsed = true; sc.say([{ s: C.nome, t: C.ini }, { fn: function () { chg('Ânimo', 2); E.ui.toast('Duda cuidou de você: +2 Ânimo'); } }]);
    } else if (k === 'leo') { this.compUsed = true; var px = this.p.x; sc.say([{ s: C.nome, t: C.ini }, { fn: function () { sc.mkSolid(px + 220, GY - 130, 220, 20, 'plat', 64); E.ui.toast('Léo desenhou uma rampa no ar!'); } }]);
    } else { this.compUsed = true; this.amp = true; sc.say([{ s: C.nome, t: C.ini }, { fn: function () { E.ui.toast('Ed amplificou: o próximo erro de Fala não custa Ânimo.'); } }]); }
  },
  checkEcos: function () {
    var all = this.ecoArr.every(function (e) { return e.state !== 'big'; });
    if (all && (this.lvl === 12 || this.lvl === 13)) { E.ui.run([{ s: 'ARBOVIA', t: this.lvl === 12 ? 'A vila ficou quieta. Fale com o Ed.' : 'A banca está livre. Vá até a Dona Neide.' }]); }
    if (all && GEN[this.lvl] && !E.flags[GEN[this.lvl].flag]) { E.ui.run([{ s: 'ARBOVIA', t: 'Caminho livre. Fale com ' + GEN[this.lvl].npcs[0][3].split(',')[0].toLowerCase().replace(/(^|\s)\S/g, function (c) { return c.toUpperCase(); }) + '.' }]); }
    if (all && this.lvl === 2 && !this.rosaIn) {
      this.rosaIn = true; var r = this.npcs.rosa; r.setVisible(true); r.lbl.setVisible(true);
      E.ui.run([{ s: 'ARBOVIA', t: 'Uma porta se abriu no fundo do salão. É a Roda! E alguém está entrando...' }]);
    }
  },
  say: function (arr) { E.ui.run(arr); },
  /* ---- Marco 3 ---- */
  mkBarrier: function (x, w, h, nome) {
    var b = this.solids.create(x + w / 2, GY - h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody();
    var v = this.add.rectangle(x + w / 2, GY - h / 2, w, h, 0xff4d3d, 0.95).setDepth(2).setStrokeStyle(3, 0x7a1a12);
    var t = this.add.text(x + w / 2, GY - h - 26, nome, { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c82020', padding: { x: 4, y: 2 } }).setOrigin(0.5).setDepth(4);
    return { x: x + w / 2, b: b, v: v, t: t, done: false };
  },
  barrierDone: function (r) { r.done = true; r.b.destroy(); r.v.setFillStyle(0xffd23a, 0.9).setStrokeStyle(3, 0xb88a00); r.v.setDisplaySize(r.v.displayWidth, 12); r.v.y = GY - 6; r.t.setText('RAMPA MARCADA').setBackgroundColor('#b88a00'); },
  talkBarrier: function (r) {
    var sc = this, d = r.d;
    if (r.done) { this.say([{ s: 'ARBOVIA', t: 'Esse ponto já está no mapa.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: d.q, fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: '', t: d.a }, ask(true)]; } });
      o.push({ k: 'E', t: d.e, fx: function () { chg('Entendimento', 1); E.flags['mp' + r.i] = true; },
        then: [{ fn: function () { sc.barrierDone(r); snd('stamp'); } }, { s: 'ARBOVIA', t: 'Marcado. Onde falta rampa agora está no mapa, para todo mundo ver.' }, { fn: function () { sc.checkMapa(); } }] });
      o.push({ k: 'P', t: 'Dá pra contornar por outro lado.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'LÉO', t: 'Contornar por onde, uai? Na minha cadeira não tem "outro lado".' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'ARBOVIA', t: d.n + '.' }, ask(false)]);
  },
  checkMapa: function () {
    if (this.mbar.every(function (r) { return r.done; }) && !E.flags.mapaOk) { E.flags.mapaOk = true; E.ui.run([{ s: 'ARBOVIA', t: 'Três barreiras no mapa. Leve isso até a Zeni, no fim da rua.' }]); }
  },
  talkZeniMapa: function () {
    if (E.flags.mapaLeo) { this.say([{ s: 'ZENI', t: 'Vai no Mural, meu bem. Esse mapa é do povo.' }]); return; }
    if (!E.flags.mapaOk) { this.say([{ s: 'ZENI', t: 'Marca todos os degraus, uai. Cada um é uma porta fechada.' }]); return; }
    this.say([{ s: 'ZENI', t: 'Fez o mapa, né, meu bem? E pra que serve ele?' }, { ask: [
      { k: 'E', t: 'O mapa mostra onde falta rampa e onde falta cuidado.', fx: function () { chg('Saberes', 1); chg('Rede', 1); E.flags.mapaLeo = true; note('MAPA DE QUEM NÃO PASSA', 'Onde falta rampa e onde falta cuidado, marcado por quem passa.', 'Levantamento de acessibilidade (camada do território usado)'); },
        then: [{ s: 'ZENI', t: 'E onde sobra cidade, uai. Isso a gente põe no Mural.' }, { s: 'ARBOVIA', t: 'Camada nova no mapa: rotas acessíveis em amarelo.' }] },
      { k: 'P', t: 'Coitado de quem não passa.', fx: function () { chg('Rede', -1); },
        then: [{ s: 'ZENI', t: 'Coitado, não, sô. Cansado de esperar é diferente.' }] }] }]);
  },
  talkRelato: function (r) {
    var sc = this;
    if (E.flags['rel' + r.i]) { this.say([{ s: 'ARBOVIA', t: 'Essa voz já foi ouvida e anotada, com licença.' }]); return; }
    this.say([{ s: r.s, t: r.t }, { ask: [
      { k: 'E', t: 'Obrigado por contar. Posso anotar o que você disse?', fx: function () { chg('Saberes', 1); chg('Rede', 1); E.flags['rel' + r.i] = true; r.img.setAlpha(0.25); },
        then: [{ s: r.s, t: 'Pode, sim. Que fique escrito.' }, { s: 'ARBOVIA', t: 'A Lente do Relato anotou, com licença de quem contou.' }] },
      { k: 'P', t: 'Já entendi.', fx: function () { chg('Ânimo', -1); },
        then: [{ s: 'ARBOVIA', t: 'A voz se calou. Chegue de novo e escute até o fim.' }] }] }]);
  },
  talkPedra: function () {
    if (E.flags.nascente) { this.say([{ s: 'ARBOVIA', t: 'A pedra marcada. Seca, mas lembrada.' }]); return; }
    var n = [0, 1, 2].filter(function (i) { return E.flags['rel' + i]; }).length;
    if (n < 3) { this.say([{ s: 'ARBOVIA', t: 'A pedra tem um X talhado, mas ainda falta ouvir ' + (3 - n) + ' voz(es) da caverna.' }]); return; }
    this.say([{ s: '', t: 'No fundo da caverna, uma pedra com um X talhado. O chão em volta está seco, mas guarda o desenho de um olho d\'água.' },
      { s: 'ARBOVIA', t: 'A nascente secou, mas três pessoas lembram onde ela ficava. Isso também é mapa.' },
      { fn: function () { E.flags.nascente = true; chg('Entendimento', 2); note('NASCENTE ANTIGA', 'Onde a água brotava, segundo quem lembra.', 'Registro de memória hídrica (relato)'); } },
      { s: 'CADERNO', t: 'Camada nova: Relato da nascente.' }]);
  },
  talkAristides: function () {
    var sc = this;
    if (E.flags.croqui) { this.say([{ s: 'ARISTIDES', t: 'Já te passei o desenho. Usa onde eu deixei, sô.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'O senhor trabalhou na Torre dos Mapas?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'ARISTIDES', t: 'Onze anos. Desenhei metade desses mapas. Depois mandaram embora o povo do campo.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'Só conto o que o senhor autorizar. O que o senhor quer que vá pro mapa?', fx: function () { chg('Rede', 2); chg('Entendimento', 1); E.flags.croqui = true; },
        then: [{ s: 'ARISTIDES', t: '(risca na terra com o graveto) A água de baixo da horta corre pra cá, ó. Pode levar isso. O resto fica comigo.' },
          { fn: function () { note('CROQUI DO ARISTIDES', 'O caminho da água por baixo da vila, desenhado por quem conhece.', 'Croqui autorizado (uso só onde ele permitir)'); } },
          { s: 'ARBOVIA', t: 'Ele escolheu o que contar. Isso é confiança.' }] });
      o.push({ k: 'P', t: 'O senhor devia contar tudo, é por uma boa causa.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'ARISTIDES', t: 'Boa causa é a que eu escolho, sô.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'ARISTIDES', t: 'Ô de casa. Tá olhando meu desenho? Ninguém olha mais.' }, ask(false)]);
  },
  talkNivelino: function () {
    var sc = this;
    if (E.flags.mapaPronto) { this.say([{ s: 'NIVELINO', t: '(sem graça) O mapa vai ser revisto. A Lúcia cuida.' }]); return; }
    var got = E.flags.camadas || (E.flags.camadas = {});
    function n() { return ['mapa', 'rel', 'cro'].filter(function (k) { return got[k]; }).length; }
    function done() { return [{ fn: function () { E.flags.mapaPronto = true; sc.lonaT.setText('TERRITÓRIO\nUSADO').setColor('#1f9a3c'); sc.tapumeB.destroy(); sc.tapume.destroy(); sc.tapumeT.destroy(); snd('stamp'); chg('Entendimento', 3); chg('Rede', 2); } },
      { s: 'NIVELINO', t: '(olhando a lona) ...Aqui tem gente. Tem nascente. Tem caminho. Não era "área vazia".' }, { s: 'ARBOVIA', t: 'O tapume caiu! Fale com a Lúcia Prado, do outro lado.' }]; }
    function ask() { var o = [];
      if (!got.mapa) o.push({ k: 'E', t: 'Camada 1: o Mapa de Quem Não Passa (rampas que faltam).', fx: function () { got.mapa = true; chg('Entendimento', 1); }, then: function () { return n() >= 3 ? done() : [{ s: 'NIVELINO', t: 'Hum. Isso o satélite não mostra.' }, ask()]; } });
      if (!got.rel) o.push({ k: 'E', t: 'Camada 2: o relato da nascente antiga.', fx: function () { got.rel = true; chg('Entendimento', 1); }, then: function () { return n() >= 3 ? done() : [{ s: 'NIVELINO', t: 'Relato não entra na base oficial... mas tá aqui, assinado.' }, ask()]; } });
      if (!got.cro) o.push({ k: 'E', t: 'Camada 3: o croqui do Aristides (autorizado por ele).', fx: function () { got.cro = true; chg('Entendimento', 1); }, then: function () { return n() >= 3 ? done() : [{ s: 'NIVELINO', t: 'Esse desenho é da Torre... o autor sabe do uso?' }, { s: 'VOCÊ', t: 'Sabe, e autorizou.' }, ask()]; } });
      o.push({ k: '?', t: 'De onde vieram os dados desse mapa?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'NIVELINO', t: 'Imagem de satélite de 2014 e um sobrevoo. Ninguém pisou aqui.' }, ask()]; } });
      o.push({ k: 'P', t: 'Esse mapa aí tá certo, doutor. A gente que errou.', fx: function () { chg('Rede', -1); chg('Ânimo', -1); }, then: function () { return [{ s: 'NIVELINO', t: 'Pois é.' }, { s: 'ARBOVIA', t: 'O Tapume resistiu. Mostre as camadas.' }, ask()]; } });
      return { ask: o }; }
    this.say([{ s: 'NIVELINO', t: 'Mapa oficial de ordenamento: pronto, aprovado, impresso. Essa área aqui é vazia, sem ocupação.' },
      { s: 'ARBOVIA', t: 'A lona diz ÁREA VAZIA. Mas a gente sabe que não é. Mostre o que reunimos.' }, ask()]);
  },
  talkLucia: function () {
    var sc = this;
    if (!E.flags.mapaPronto) { this.say([{ s: 'LÚCIA', t: '(do outro lado do tapume) Eu estou ouvindo. Só não consigo passar.' }]); return; }
    if (E.flags.marco3) { this.say([{ s: 'LÚCIA', t: 'Meu cartão tá com você. Pode ligar.' }]); return; }
    this.say([{ s: 'LÚCIA', t: 'Fui eu que desenhei esse mapa, sabe? Cumpri o prazo. Ninguém mandou eu ir lá ver.' },
      { s: 'LÚCIA', t: '(entrega um cartão) Se eu levar isso pra frente, posso me complicar na repartição. Mas esse mapa tá errado, e eu sei.' },
      { fn: function () { note('CARTÃO DA LÚCIA', 'Lúcia Prado, técnica do Mapa. Aliada por dentro.', 'Contato institucional (dissidente)'); } },
      { s: 'ARBOVIA', t: 'Uma aliada dentro da Torre. Cuide bem dela.' },
      { s: '', t: 'A Rodinha de fechamento: todo mundo chega perto da lona, agora com o nome de quem vive ali.' },
      { s: 'DONA COTA', t: 'A gente voltou a ter nome no mapa.' }, { s: 'LÉO', t: 'E rampas.' },
      { s: 'ARISTIDES', t: 'Sei onde está a água. Quando precisarem.' }, { s: 'ARBOVIA', t: 'Ele disse!' },
      { fn: function () { E.flags.marco3 = true; E.gotas = Math.max(E.gotas, 5); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
      { s: 'ARBOVIA', t: 'O Cantil ganhou uma quinta luz! A porta ao leste leva ao mapa.' }]);
  },
  talkRosaSalao: function () {
    var sc = this;
    if (E.flags.salao) { this.say([{ s: 'ROSINHA', t: 'Três lados. Estou esperando.' }]); return; }
    this.say([
      { s: 'ROSINHA', t: 'Quem abriu essa porta?' }, { s: 'ZENI', t: 'Foi quem Dona Cota mandou, Rosa.' },
      { s: 'ROSINHA', t: 'Dona Cota manda em muita coisa, uai. Eu sou presidente da Associação. Sou eu que respondo se der errado.' },
      { s: 'ROSINHA', t: 'Sete anos de Roda que acabou em derrota. Você acha que vai ser diferente?' },
      { ask: [
        { k: '?', t: 'O que aconteceu há sete anos?', fx: function () { chg('Saberes', 1); chg('Rede', 1); },
          then: [{ s: 'ROSINHA', t: 'A Cerca. Cercaram o poço sem avisar. Fizemos reunião, abaixo-assinado, tudo. Ninguém apareceu. Desde então eu só acredito em papel assinado.' }] },
        { k: 'E', t: 'Sete anos de silêncio doem. Mas agora há um papel de verdade na mesa: o Projeto Mirante.', fx: function () { chg('Rede', 1); },
          then: [{ s: 'ROSINHA', t: '...Isso eu entendo.' }] },
        { k: 'P', t: 'Dessa vez vai dar certo.', fx: function () { chg('Rede', -1); }, then: [{ s: 'ROSINHA', t: 'Todo mundo diz.' }] }
      ] },
      { s: 'ROSINHA', t: 'Se você quer Roda, traga os três lados. Gente nossa, gente da prefeitura e gente que entende de número. Se um deles não vier, eu saio.' },
      { s: 'ARBOVIA', t: 'Três lados. Anotei! A porta ao leste leva ao mapa.' }, { fn: function () { E.flags.salao = true; } }]);
  },
  talkMari: function () {
    var sc = this;
    if (E.flags.conv_m) { this.say([{ s: 'FERNANDA', t: 'Eu vou. Só lembre: nada sai sem eu aprovar.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'O que você precisa para vir?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'FERNANDA', t: 'Que não seja gravado, que não conte como "manifestação oficial" e que eu possa sair quando quiser.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'A gente registra uma ata que você vai poder rever antes de assinar. Nada sai sem você aprovar.', fx: function () { chg('Rede', 1); chg('Entendimento', 1); E.flags.conv_m = true; },
        then: [{ s: 'FERNANDA', t: '...Isso eu consigo defender na Coordenação.' }] });
      o.push({ k: 'C', t: 'Se você vier, a gente apoia o seu pedido de promoção.', fx: function () { chg('Entendimento', -1); E.flags.conv_m = true; E.flags.marilenePoor = true; },
        then: [{ s: 'FERNANDA', t: 'Pedido de promoção? Eu trabalho nisso. Não me compre. ...Mas eu vou, por ora.' }, { s: 'ARBOVIA', t: 'Ela virá, mas a confiança ficou baixa.' }] });
      return { ask: o }; }
    this.say([{ s: 'FERNANDA', t: 'Bom dia. Eu sou da Coordenação... técnica. Estou aqui só para observar.' },
      { s: 'FERNANDA', t: '(baixo) Entenda: se alguém souber que eu falei com a comunidade fora do protocolo, perco o cargo.' }, ask(false)]);
  },
  talkTomas: function () {
    if (E.flags.conv_i) { this.say([{ s: 'TOMÁS', t: 'Eu levo o recado. Ela vai de balsa.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: 'Diga a ela que a gente leva dado e relato. Os dois, lado a lado.', fx: function () { chg('Entendimento', 1); E.flags.conv_i = true; },
        then: [{ s: 'TOMÁS', t: 'Lado a lado? Ela nunca fez isso. (sorri) Eu levo o recado.' }] },
      { k: 'P', t: 'Diga que ela venha ouvir a vila.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'TOMÁS', t: 'Ela não vai querer. É "ouvir"... Ela quer medir.' }, { s: 'ARBOVIA', t: 'Tente falar a língua dela.' }, ask()]; } }] }; }
    this.say([{ s: 'TOMÁS', t: 'A Dra. Cinthya mandou um recado: "Só participo de reunião se houver dado sistematizado. Relato anedótico não substitui evidência."' },
      { s: 'TOMÁS', t: '(baixo) Ela fala assim. Mas eu sei que ela leu o Mirante três vezes. Está preocupada, só não sabe dizer.' }, ask()]);
  },
  stageTalk: function (who) {
    var sc = this, st = this.stage || 0, idx = { rosa: 0, mari: 1, irac: 2 }[who];
    if (idx !== st) { this.say([{ s: 'ARBOVIA', t: idx < st ? 'Essa fala já foi traduzida.' : 'Comece pela esquerda: traduza uma fala por vez.' }]); return; }
    var data = [
      { to: 'ROSINHA', e: 'Fernanda não quer esconder, quer se proteger. A ata dela precisa ser revisada por ela antes de assinada. Pode ser em papel, com assinatura.', ok: '...Em papel, revisada, assinada. Isso eu aceito.', p: 'Ela só tem medo.', bad: 'Medo todo mundo tem.' },
      { to: 'FERNANDA', e: 'A Rosinha quer papel porque, há sete anos, a vila perdeu sem ter nada assinado. Seu pedido de revisar a ata protege você, e o papel protege a vila.', ok: 'Nunca pensei que fossem a mesma coisa.', p: 'A Rosinha é teimosa.', bad: 'Teimosa ou não, ela tem razão de desconfiar.' },
      { to: 'DRA. CINTHYA', e: 'O dado é o que a vila não tem, e o relato é o que o dado não pega. Você traz um, e a vila traz o outro. Juntos fecham o quadro.', ok: 'Dado mais relato... Preciso ver. Mas eu aceito ficar.', p: 'Relato também é evidência, doutora.', bad: 'Não vim para discutir o que é evidência.' }][st];
    this.say([{ ask: [
      { k: 'E', t: '(para ' + data.to + ') ' + data.e, fx: function () { chg('Entendimento', 1); chg('Rede', 1); },
        then: [{ s: data.to, t: data.ok }, { fn: function () { sc.ecoArr.forEach(function (e) { if (e.i === st) sc.dissolve(e); }); sc.stage = st + 1; E.flags.stage4 = sc.stage; } },
          { s: 'ARBOVIA', t: st < 2 ? 'O Ruído se abriu. Siga em frente!' : 'Os três aceitaram ficar. A mesa os espera, à direita.' }] },
      { k: 'P', t: '(para ' + data.to + ') ' + data.p, fx: function () { chg('Rede', -1); }, then: [{ s: data.to, t: data.bad }, { s: 'ARBOVIA', t: 'O Ruído cresceu. Fale de novo, dos dois lados.' }] }
    ] }]);
  },
  talkMesa: function () {
    var sc = this;
    if (E.flags.roda) { this.say([{ s: 'ARBOVIA', t: 'A Roda está redonda de novo. A porta leva ao mapa.' }]); return; }
    if ((this.stage || 0) < 3) { this.say([{ s: 'ARBOVIA', t: 'A mesa só se completa quando os três lados aceitarem sentar.' }]); return; }
    function fim(ok) { return [{ s: '', t: 'Dona Cota entra devagar e toca o sino do Centro, que não tocava há sete anos. Em volta, a vila inteira para e olha.' },
      { s: 'DONA COTA', t: 'Escutaram.' },
      { fn: function () { E.gotas = Math.max(E.gotas, 3); E.flags.roda = true; E.flags.marco1 = true; if (window.Snd) Snd.jingle('roda'); chg('Entendimento', ok ? 3 : 1); if (E.flags.marilenePoor) chg('Rede', -1); E.ui.hud(); } },
      { s: 'ARBOVIA', t: 'O Cantil ganhou uma terceira luz! Um fio de água apareceu ao lado do Salão. Línguas aprendidas: Relato, Cuidado.' },
      { s: 'ROSINHA', t: '(baixo, depois que todos saíram) Sete anos. Obrigada por não prometer.' },
      { s: '', t: 'Fim do Marco 1: o Território-Lar acordou. A porta leva ao mapa.' }]; }
    this.say([
      { s: 'ROSINHA', t: 'O Mirante primeiro. Se perdemos isso, não sobra nada pra decidir.' },
      { s: 'DRA. CINTHYA', t: 'Mas as águas paradas matam mais cedo. Há quatro casos no posto.' },
      { s: 'DUDA', t: '(da porta) Seis. Eu só não entreguei a lista.' },
      { s: 'FERNANDA', t: 'Ao menos, registrem as duas. Eu levo o primeiro à Coordenação, e o segundo eu consigo acelerar.' },
      { ask: [
        { k: 'E', t: 'Duas pautas, duas pessoas responsáveis: Mirante com Rosinha e Fernanda; águas paradas com Cinthya e Duda.', then: function () { return fim(true); } },
        { k: '?', t: 'Duda, quem mais tem casos? Cinthya, o que falta para fechar o número?', fx: function () { chg('Saberes', 1); }, then: function () { return fim(true); } },
        { k: 'P', t: 'Só o Mirante. As águas esperam.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'CINTHYA', t: 'Seis casos esperando. Registre isso na ata.' }].concat(fim(false)); } }
      ] }]);
  },
  talkCota: function () {
    var sc = this;
    if (E.flags.varanda) { this.say([{ s: 'DONA COTA', t: 'Já tem Caderno e já sabe pedir licença. Agora vai, filho(a). O primeiro funcionário não espera.' }]); return; }
    var PAL = [
      { k: 'TERRITÓRIO USADO', i: 'Palavra bonita, né? Os livros dizem que "território usado" é o chão com tudo que a gente faz nele. Eu digo mais simples, uai.', p: 'O lugar onde a gente vive de verdade.', o: 'Unidade territorial.', e: 'Isso. Com 312 casas, uma horta e um campinho de futebol, ainda é só "unidade". Aí a gente vê por que a Torre não entende ninguém.' },
      { k: 'SENTIPENSAR', i: 'Agora esta: "sentipensar".', p: 'Pensar com o coração e com a cabeça juntos.', o: 'Abordagem integrada.', e: 'Quem só pensa esquece a gente. Quem só sente se perde. Os dois juntos, sô, caminham.' },
      { k: 'RODA', i: 'Mais uma: "Roda".', p: 'O lugar onde a decisão é de todos.', o: 'Fórum deliberativo.', e: 'A mesa redonda do Centro. Ninguém na cabeceira.' },
      { k: 'MATRIZ', i: 'Esta é de conta: "Matriz".', p: 'Ver o que é urgente, o que pesa e o que a gente dá conta de fazer.', o: 'Matriz de priorização.', e: 'Três perguntas e uma ordem. Sem briga de quem grita mais.' },
      { k: 'PLANO POPULAR', i: 'A última: "Plano Popular".', p: 'O plano que a gente escreve junto.', o: 'Instrumento de planejamento participativo.', e: 'Quando o povo escreve, o plano tem endereço e tem nome.' }];
    function palavra(i) {
      if (i >= PAL.length) return etica();
      var w = PAL[i];
      return { ask: [
        { k: 'E', t: '(escreve as duas versões) "' + w.k.charAt(0) + w.k.slice(1).toLowerCase() + '" é: ' + w.p.toLowerCase().replace(/\.$/, '') + '.', fx: function () { chg('Entendimento', 1); note(w.k, w.p, w.o); },
          then: function () { return [{ s: 'DONA COTA', t: 'E em Oficialês?' }, { s: 'ARBOVIA', t: '"' + w.o.replace(/\.$/, '') + '", acho.' }, { s: 'DONA COTA', t: w.e }, { s: 'CADERNO', t: 'Palavra gravada: ' + w.k + '.' }, { fn: function () { E.flags.palavras = i + 1; } }, palavra(i + 1)]; } },
        { k: 'P', t: '(escreve só a versão oficial) "' + w.k.charAt(0) + w.k.slice(1).toLowerCase() + ' é ' + w.o.toLowerCase().replace(/\.$/, '') + '".', fx: function () { chg('Ânimo', -1); },
          then: function () { return [{ s: 'DONA COTA', t: 'Perdeu a metade. Escreva de novo.' }, { s: 'CADERNO', t: 'O Caderno recusou: falta a versão da pessoa.' }, palavra(i)]; } }
      ] };
    }
    function etica() {
      return { ask: [
        { k: 'E', t: 'Se a informação pode machucar quem contou, só guardo o necessário.', fx: function () { chg('Entendimento', 1); E.flags.varanda = true; E.flags.cadernoCampo = true; },
          then: [{ s: 'DONA COTA', t: 'Isso. Lembre disso na porta do primeiro funcionário que aparecer.' }, { s: 'CADERNO', t: 'Desbloqueado: o Caderno de Campo.' }, { s: 'ARBOVIA', t: 'A porta ao leste leva ao mapa.' }] },
        { k: 'P', t: 'Anoto tudo, depois eu vejo o que serve.', fx: function () { chg('Rede', -1); },
          then: function () { return [{ s: 'DONA COTA', t: 'Não, não. Pergunte antes: "isso machuca quem contou?" Tenta de novo.' }, etica()]; } }
      ] };
    }
    var start = E.flags.palavras || 0;
    var intro = start === 0 ? [
      { s: 'DONA COTA', t: '(entregando uma caderneta de capa de papelão) Escreve aqui. Só o que você ouvir. Primeiro uma coluna, aí a outra.' },
      { s: 'ARBOVIA', t: 'Duas colunas?' },
      { s: 'DONA COTA', t: 'A da pessoa e a da outra. O que um diz e o que o outro entende. Entre as duas, a ponte.' }] : [{ s: 'DONA COTA', t: 'Vamos continuar de onde parou.' }];
    var tail = []; if (start < PAL.length) tail.push({ s: 'DONA COTA', t: PAL[start].i }); 
    if (start >= PAL.length) { tail = [{ s: 'DONA COTA', t: 'Mais uma coisa, que vale mais que todas: a Ética.' }, { s: 'DONA COTA', t: 'Quem conta a história dos outros precisa pedir licença. Não pergunte o que não precisa. Não anote nome, doença ou endereço de ninguém sem razão. Pergunte: "isso machuca quem contou?"' }]; }
    this.say(intro.concat(tail, [palavra(start)]));
  },
  talkReg: function (r) {
    var sc = this;
    if (E.flags['reg' + r.i]) { this.say([{ s: 'LÉO', t: 'Esse ponto já tá no mapa.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: '(registra o lugar) Só o lugar, a hora, o que vi. Sem nome de ninguém.', fx: function () { chg('Saberes', 1); E.flags['reg' + r.i] = true; r.sg.setFillStyle(0x6fbf55); note('REGISTRO ' + (r.i + 1), ['Calçada quebrada em frente à casa 14, às 8h', 'Bueiro aberto na esquina, às 8h40', 'Esquina escura sem poste, às 9h10'][r.i], 'Ocorrência georreferenciada (sem dados pessoais)'); },
        then: [{ s: 'LÉO', t: 'Assim.' }, { fn: function () { sc.checkRegs(); } }] },
      { k: 'P', t: '(tenta anotar o morador) Registro: Dona Maria, hipertensa, casa 14.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'LÉO', t: 'Ei. Isso é prontuário, não mapa. Dona Maria nem sabe que você anotou.' }, { s: 'CADERNO', t: 'O Caderno sublinhou em vermelho: dado pessoal.' }, { s: 'LÉO', t: 'Eu sei o que dá em quem vai por aí anotando vida alheia. Vamos de novo.' }, ask()]; } }] }; }
    this.say([ask()]);
  },
  checkRegs: function () {
    if (E.flags.reg0 && E.flags.reg1 && E.flags.reg2 && !E.flags.rota) {
      E.flags.rota = true; chg('Entendimento', 1);
      this.say([{ s: 'LÉO', t: 'Três pontos. Ficou um mapa de verdade, trem bonito. Agora a ambulância sabe por onde ir.' }, { s: 'ARBOVIA', t: 'Língua aprendida: Cuidado, em parte. A porta ao leste leva ao mapa.' }]);
    }
  },
  showForm: function () {
    if (this.formC) return; var sc = this, cx = W / 2, c = this.add.container(0, 0).setScrollFactor(0).setDepth(40); this.formC = c; this.formRows = {};
    c.add(this.add.rectangle(cx, 300, 660, 400, 0xf6efdc).setStrokeStyle(5, 0x2a1f2d));
    c.add(this.add.text(cx, 118, 'CADASTRO — PROJETO MIRANTE', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#2a1f2d' }).setOrigin(0.5));
    var F = ['NOME COMPLETO', 'CPF', 'ENDEREÇO', 'Nº DE MORADORES', 'DOENÇAS PREEXISTENTES', 'RENDA', 'PARENTES', 'FOTO'];
    F.forEach(function (n, i) { var y = 160 + i * 42; var r = sc.add.rectangle(cx, y + 14, 580, 34, 0xffffff).setStrokeStyle(2, 0x7a7a7a); var t = sc.add.text(cx - 270, y + 14, n, { fontFamily: FONT, fontSize: '20px', color: '#2a1f2d' }).setOrigin(0, 0.5); c.add([r, t]); sc.formRows[n] = { r: r, t: t, x: cx, y: y + 14 }; });
  },
  riscar: function (names) {
    var sc = this; names.forEach(function (n) { var f = sc.formRows[n]; if (!f) return; f.r.setFillStyle(0xcfcfcf); f.t.setColor('#8a8a8a'); var ln = sc.add.rectangle(f.x, f.y, 560, 4, 0xd9534f).setScrollFactor(0).setDepth(41); sc.formC.add(ln); });
  },
  hideForm: function () { if (this.formC) { this.formC.destroy(); this.formC = null; } },
  talkGilvan: function () {
    var sc = this;
    if (E.flags.formulario) { this.say([{ s: 'WAGNER', t: '(baixo) Ofício assinado. Não conta pra ninguém.' }]); return; }
    function fase2() { return { ask: [
      { k: 'E', t: 'Podemos escrever um ofício dizendo que o formulário reduzido atende ao objetivo. Você assina, e a vila assina. Os dois protegidos.', fx: function () { chg('Entendimento', 3); chg('Rede', 2); },
        then: [{ s: 'WAGNER', t: '...Um ofício. Isso eu sei fazer.' }, { fn: function () { sc.riscar(['NOME COMPLETO', 'CPF', 'FOTO']); } },
          { s: 'ARBOVIA', t: 'Os campos que sobraram se alinharam, e viraram uma escada de saída.' },
          { s: '', t: 'A sala fica em silêncio. Wagner carimba o ofício, hesita, e entrega uma cópia a você.' },
          { s: 'WAGNER', t: 'Estou ouvindo coisa que não gosto, e fazendo o que é certo. Não conta pra ninguém.' },
          { s: 'ZENI', t: 'Gente, ele sorriu!' }, { s: '', t: 'Wagner fecha a cara de novo, cabisbaixo.' },
          { fn: function () { E.flags.formulario = true; E.flags.marco2 = true; E.gotas = Math.max(E.gotas, 4); note('OFÍCIO', 'Pedido reduzido: só o endereço e o número de moradores.', 'Ofício de adequação de formulário'); sc.hideForm(); E.ui.hud(); } },
          { s: 'CADERNO', t: 'Língua aprendida: Oficialês (parcial). Wagner Teixeira agora é contato em Mandorra.' }, { s: 'ARBOVIA', t: 'O Cantil ganhou uma quarta luz! A porta ao leste leva ao mapa.' }] },
      { k: 'P', t: 'Então faz o que o sistema mandar.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'WAGNER', t: 'É o que eu faço todo dia.' }, { s: 'ARBOVIA', t: 'Ele está com medo de perder o cargo. Fale da proteção dos dois lados.' }, fase2()]; } }] }; }
    function fase1(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Qual é o objetivo do cadastro?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'WAGNER', t: 'Saber quantas casas e quantas pessoas estão na área do projeto.' }, fase1(true)]; } });
      o.push({ k: 'E', t: 'Se o objetivo é contar casas e pessoas, só precisa do endereço e do número de moradores. O resto é perigo e não ajuda.', fx: function () { chg('Entendimento', 1); },
        then: [{ s: 'WAGNER', t: '(coçando a cabeça) Hmm... Doença preexistente? Isso a gente nem usa pra nada.' }, { fn: function () { sc.riscar(['DOENÇAS PREEXISTENTES', 'RENDA', 'PARENTES']); } },
          { s: 'WAGNER', t: '(depois, baixo) Escuta... Eu também não gosto. Preencher isso tudo dá enxaqueca. Mas se eu não preencher, perco o cargo.' }, fase2()] });
      o.push({ k: 'P', t: 'É só cortar o que incomoda.', fx: function () { chg('Ânimo', -1); },
        then: function () { return [{ s: 'WAGNER', t: 'Cortar o quê? Eu não decido. O sistema decide.' }, { s: 'ARBOVIA', t: 'O formulário cresceu e bloqueou o caminho. Tente outra carta.' }, fase1(skipQ)]; } });
      o.push({ k: 'C', t: 'Eu te trago um café e a gente deixa o formulário como está.', fx: function () { chg('Entendimento', -1); E.flags.gilvanRessentido = true; },
        then: function () { return [{ s: 'WAGNER', t: 'Não aceito. Mas... nem precisa.' }, { s: 'ARBOVIA', t: 'Ele ficou ressentido. Comprar não é traduzir.' }, fase1(skipQ)]; } });
      return { ask: o }; }
    this.say([
      { s: 'WAGNER', t: '(mecânico) Próximo. Nome completo, CPF, endereço, número de moradores, doenças preexistentes. É para o cadastro do Projeto Mirante.' },
      { s: 'ZENI', t: 'Tudo isso? Pra quê?' }, { s: 'WAGNER', t: 'É o protocolo.' },
      { s: 'ENCONTRO DE ENTENDIMENTO', t: 'O Formulário Gigante.' }, { fn: function () { sc.showForm(); } },
      { s: 'WAGNER', t: 'Não é possível. O sistema só aceita se todos os campos estiverem preenchidos.' }, fase1(false)]);
  },
  /* ---- Marco 4: O Rumor ---- */
  talkDavi: function () {
    var sc = this;
    if (E.flags.rumorOk) { this.say([{ s: 'ED', t: 'No ar, com fonte e hora, uai. Aprendi.' }]); return; }
    var left = this.ecoArr.filter(function (e) { return e.state === 'big'; }).length;
    if (left) { this.say([{ s: 'ED', t: '(abafado) Tem eco demais na vila, sô. Dá um jeito neles primeiro.' }]); return; }
    function card() { return { ask: [
      { k: 'E', t: '"Gente, errei. O posto não fecha. O horário vai de oito às cinco para oito às três. Quem tiver dúvida passa aqui e eu mostro o ofício."', fx: function () { chg('Entendimento', 2); chg('Rede', 1); E.flags.rumorOk = true; },
        then: [{ s: 'ED', t: '(no ar, a voz trêmula) Foi isso. Errei. Fica no ar a correção.' }, { s: 'ARBOVIA', t: 'Os Ecos-de-Boca viraram chuva fina. Ed agora é aliado.' },
          { s: 'ZENI', t: 'Aprendeu, rapaz. Todo mundo erra. A gente erra e conserta.' }, { fn: function () { note('CORREÇÃO NO AR', 'Quando errar, corrija no mesmo lugar, com fonte e hora.', 'Errata pública (Manchetês)'); } }] },
      { k: 'P', t: '"Foi só um engano, gente. Ninguém vai se lembrar."', fx: function () { chg('Rede', -1); chg('Ânimo', -1); },
        then: function () { return [{ s: 'ED', t: 'Vão lembrar sim, sô.' }, card()]; } }] }; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'De onde veio essa informação?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'ED', t: '...De uma vizinha. Que ouviu de um menino. Que ouviu... eu nunca perguntei.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'Podemos ir ao ar de novo e corrigir, contando exatamente o que mudou e de onde veio.', fx: function () { chg('Saberes', 1); },
        then: [{ s: 'ED', t: 'Corrigir no ar? O povo vai rir de mim, uai.' }, { s: 'DUDA', t: 'Vão rir menos do que se acreditarem que o posto fechou.' }, { s: 'ARBOVIA', t: 'Escolha o texto da correção.' }, card()] });
      o.push({ k: 'P', t: 'Foi só um engano. Ninguém vai lembrar.', fx: function () { chg('Rede', -1); chg('Ânimo', -1); },
        then: function () { return [{ s: 'ED', t: 'Vão lembrar.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'ED', t: '(no microfone, ligado) Atenção, Vila Mutirão! Informação em primeira mão: o posto de saúde vai fechar na semana que vem! Fica no ar!' },
      { s: 'DUDA', t: 'Ed! Quem disse isso? O posto não fecha. Muda de horário, de oito às cinco para oito às três. Eu tenho o ofício aqui!' },
      { s: 'ED', t: '(pálido, desligando o microfone) Mas eu já falei. Tem gente na fila do posto agora, gritando.' }, { s: 'ARBOVIA', t: 'Ele não sabia.' }, ask(false)]);
  },
  talkNeide: function () {
    var sc = this;
    if (!this.ecoArr.every(function (e) { return e.state !== 'big'; })) { this.say([{ s: 'NEIDE', t: 'Égua... digo, uai! Tem boato demais na minha porta. Limpa aí que eu converso.' }]); return; }
    if (E.flags.feira) { this.say([{ s: 'NEIDE', t: 'Fonte e hora, meu bem. Tá na minha Banca Honesta.' }]); return; }
    function fim() { return [{ s: 'NEIDE', t: 'Ó, a minha Banca Honesta: notícia com selo. Se alguém reclamar que menti, devolvo o dinheiro.' }, { s: 'ARBOVIA', t: 'Ela vai ganhar mais!' }, { s: 'NEIDE', t: 'Ou perder tudo. Mas já ganhei muito com mentira. Cansei de dormir com isso.' },
      { s: 'NEIDE', t: '(sussurrando, entrega um bilhete) Uma coisa que ouvi de verdade: lá no Rio-Mundo, a Rádio-Barco do Mestre Sebastião avisou de papel falso tirando terra de gente. Pode ser boato. Mas é do tipo que a gente tem que ir ver.' },
      { fn: function () { E.flags.feira = true; chg('Rede', 1); note('BANCA HONESTA', 'Toda notícia vendida leva fonte e hora.', 'Regra de checagem (Manchetês)'); E.ui.hud(); } },
      { s: 'ARBOVIA', t: 'A porta da Boca do Igarapé, no mapa, se abriu para você.' }]; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Como você sabe se é verdade?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'NEIDE', t: '(rindo) Eu não sei, meu bem. Eu vendo. Quem compra é quem decide se acredita.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'E se a gente criasse uma regra: toda notícia que você vende tem fonte e hora?', fx: function () { chg('Entendimento', 1); },
        then: [{ s: 'NEIDE', t: 'Fonte e hora? Isso é trabalho dobrado, uai.' }, { s: 'NEIDE', t: '(pensa) Mas se funcionar, o povo paga mais por notícia de confiança. Já pensei nisso.' }, { fn: function () { } }].concat(fim()) });
      o.push({ k: 'C', t: 'Quanto custa um boato sobre o Mirante?', fx: function () { chg('Meios', -1); chg('Entendimento', -1); },
        then: function () { return [{ s: 'NEIDE', t: 'Um Meio, meu bem.' }, { s: 'ARBOVIA', t: 'Comprar boato não é saber. Ele pode voltar contra você.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'NEIDE', t: 'Entra, meu bem! Aqui se vende tudo. Notícia fresca de ontem, boato de hoje e dica quente de amanhã.' }, ask(false)]);
  },
  talkTiao: function () {
    var sc = this;
    if (E.flags.tiaoOk) { this.say([{ s: 'TIÃO', t: 'Égua, bora, mano. O rio tá esperando.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: 'O rio tem um jeito de dizer o caminho.', fx: function () { chg('Entendimento', 1); E.flags.tiaoOk = true; },
        then: [{ s: 'TIÃO', t: 'Égua, tu entende de rio, hein? Bora, então.' }, { s: 'CACILDA', t: 'Meu pai dizia: notícia boa é a que chega inteira. Eu entrego com o remo.' }] },
      { k: 'P', t: 'Vamos a qualquer custo!', fx: function () { chg('Ânimo', -1); },
        then: function () { return [{ s: 'ARBOVIA', t: 'A balsa girou. Quem força o remo perde o rio.' }, ask()]; } }] }; }
    this.say([{ s: 'TIÃO', t: '(falando mais alto que o rio) Quando o rio muda, a gente muda a história. Quando a história muda, a gente muda o rio.' },
      { s: 'CACILDA', t: 'Ele fala assim desde que eu conheço, mano. Eu só levo o que é de levar.' }, ask()]);
  },
  talkSebastiao: function () {
    if (this.lvl === 14) { this.say([{ s: 'SEBASTIÃO', t: '(da proa, no rádio) Égua, chegaram! Vem pra Boca do Igarapé, mano. Tem papel novo com nome velho circulando.' }]); return; }
    this.say([{ s: 'SEBASTIÃO', t: E.flags.igarapeOk ? 'Tá no ar a tua frequência, maninho. Bora.' : 'Fala com a Raiza na ponte, mano. O papel tá com ela.' }]);
  },
  talkJoana: function () {
    var sc = this;
    if (E.flags.igarapeOk) { this.say([{ s: 'RAIZA', t: 'Uma árvore em pé vale mais que mil tábuas, mano. Tu sabe.' }]); return; }
    function fim() { return [{ s: 'RAIZA', t: 'Veja isto: uma árvore em pé vale mais do que mil tábuas. Dá castanha, dá sombra, dá chuva. Cortada, dá uma vez.' },
      { s: 'CADERNO', t: 'Saber de Floresta em Pé: troncos e copas viram plataformas.' }, { s: 'SEBASTIÃO', t: '(pelo rádio) Eu te dou a minha frequência, e a gota.' },
      { fn: function () { E.flags.igarapeOk = true; E.gotas = Math.max(E.gotas, 6); chg('Saberes', 2); note('FLORESTA EM PÉ', 'Uma árvore em pé vale mais do que mil tábuas.', 'Saber de Floresta em Pé (Amazônia)'); E.ui.hud(); } },
      { s: 'ARBOVIA', t: 'O Cantil ganhou a Gota do Rio, azul-escura, com som de água corrida.' }, { s: 'RAIZA', t: 'Mas a notícia está viajando, mano. Se o rumor chega na Chapada antes da verdade, a gente perde.' },
      { fn: function () { sc.telao.setVisible(true); sc.telaoT.setVisible(true); } }, { s: 'ARBOVIA', t: 'Ouvi uma voz. Um telão acendeu na torre de rádio. É a Cléo Nascimento, no Jornal das Alturas.' }]; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Posso ver o papel?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'RAIZA', t: 'Só os olhos do outro lado, mano. Mas eu mostro.' }, ask(true)]; } });
      o.push({ k: 'E', t: '(examinando) O papel é novo, o nome é antigo, o selo é de um lugar que não existe mais. Falta uma assinatura que o seu avô nunca deu.', fx: function () { chg('Entendimento', 1); chg('Rede', 1); },
        then: [{ s: 'RAIZA', t: 'Foi isso que eu disse! Ninguém acreditava, égua.' }].concat(fim()) });
      o.push({ k: 'P', t: 'É só papelada, melhor ceder.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'RAIZA', t: 'Ceder? A floresta não é minha, é de todo mundo que vem depois.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'RAIZA', t: 'Tem gente de fora dizendo que a terra do castanhal é "sem dono". Chegaram com um papel, e na dobra tem o nome do meu avô.' },
      { s: 'SEBASTIÃO', t: '(pelo rádio) O papel é novo e o nome é antigo. Eu falei no ar. Mas o ar se perde no rio.' }, ask(false)]);
  },
  talkAliado: function (k) {
    var sc = this;
    if (E.flags.marco4) { this.say([{ s: 'ARBOVIA', t: 'Rede de Notícias montada. Todo mundo confirma com fonte.' }]); return; }
    var D = { marta: { i: 0, s: 'DUDA', ask: 'Diga o que mudou, com a data.', r: 'Do dia 3, o horário é oito às três. Não há fechamento.' },
      joana: { i: 1, s: 'RAIZA', ask: 'Mostre o papel e a árvore.', r: 'Aqui o papel, aqui a castanheira com o nome do avô.' },
      cacilda: { i: 2, s: 'CACILDA', ask: 'Conte quem esteve nesses caminhos.', r: 'Ninguém de Concretália passou por aqui nos últimos três meses, mano.' } }[k];
    if (!D) { this.say([{ s: 'ED', t: 'Dessa vez eu vou ao ar com fonte, sô. Vai lá, confirma com eles.' }]); return; }
    if (E.flags['luz' + D.i]) { this.say([{ s: D.s, t: 'Já confirmei. Tá de pé a minha parte.' }]); return; }
    function ask() { var o = [{ k: 'E', t: D.ask, fx: function () { chg('Entendimento', 1); E.flags['luz' + D.i] = true; sc.luzes[D.i].setFillStyle(0xffe14a); snd('check'); },
        then: [{ s: D.s, t: D.r }, { s: 'ARBOVIA', t: 'Luz ' + (D.i + 1) + ' acesa.' }, { fn: function () { sc.checkBoato(); } }] },
      { k: 'P', t: 'Desminta tudo, e pronto!', fx: function () { chg('Ânimo', -1); },
        then: function () { return [{ s: 'CLÉO', t: '(rindo, no telão) Cada pedaço vira dois!' }, { s: 'ARBOVIA', t: 'O balão se partiu e voltou maior. Tente confirmar a fonte.' }, ask()]; } }];
      if (D.i === 0) o.push({ k: 'C', t: '(oferece ao Jornal um "patrocínio" da vila)', fx: function () { chg('Entendimento', -1); },
        then: function () { return [{ s: 'CLÉO', t: 'Hum. Isso eu pagaria bem.' }, { s: 'ARBOVIA', t: 'Comprar o jornal não derruba o rumor. Cléo vai cobrar depois.' }, ask()]; } });
      return { ask: o }; }
    this.say([{ s: D.s, t: k === 'marta' ? 'O posto só mudou de horário!' : k === 'joana' ? 'A terra do castanhal é nossa!' : 'Quem fala isso nunca passou aqui.' }, ask()]);
  },
  checkBoato: function () {
    var sc = this; if (![0, 1, 2].every(function (i) { return E.flags['luz' + i]; }) || E.flags.marco4) return;
    this.say([{ s: '', t: 'Três luzes acesas ao mesmo tempo. O balão estoura em milhares de gotas.' }, { fn: function () { sc.balao.setRadius(5); sc.balaoT.setText(''); snd('poof'); } },
      { s: 'CLÉO', t: '(no telão, rosto surpreso por um instante) ...E agora, um esclarecimento... (corta)' },
      { fn: function () { var f = sc.npcs.fabio; f.setVisible(true); f.lbl.setVisible(true); } },
      { s: 'FÁBIO', t: 'Eu fui até lá. Vi o posto. Vi a terra. Se tu não vai, não é notícia: é palpite. Vou levar isso ao ar, mesmo que me demitam.' },
      { s: 'ED', t: '(por rádio, emocionado) Dessa vez eu também vou ao ar. Com fonte.' },
      { fn: function () { E.flags.marco4 = true; chg('Entendimento', 3); chg('Rede', 2); E.gotas = Math.max(E.gotas, 6); note('REDE DE NOTÍCIAS', 'Três fontes diferentes, ao mesmo tempo, derrubam o boato.', 'Língua aprendida: Caminho e Manchetês (parcial)'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
      { s: 'ARBOVIA', t: 'Fábio Pereira agora é aliado em Ecoalto. A porta leva ao mapa.' }]);
  },
  /* ---- Marco 5: A Leitura ---- */
  talkChiquinha: function () {
    this.say([{ s: 'CHIQUINHA', t: 'Aqui a gente não guarda água pra si, oxente. Guarda pra seca. A seca vem, tá sabendo?' }, { ask: [
      { k: '?', t: 'Como vocês sabem quando vai chover?', fx: function () { chg('Saberes', 1); }, then: [{ s: 'CHIQUINHA', t: 'Pergunta ao Valdemar, visse? Ele lê os bichos.' }] },
      { k: 'E', t: 'A cisterna de vocês é um jeito de ler o tempo também.', fx: function () { chg('Rede', 1); }, then: [{ s: 'CHIQUINHA', t: 'É arretado, né? Cada gota conta.' }] }] }]);
  },
  talkValdemar: function () {
    var sc = this;
    if (E.flags.valdemarOk) { this.say([{ s: 'VALDEMAR', t: 'Se a doutora quiser, eu conto todos os anos que acertei. E os que errei, vixe.' }]); return; }
    if (!this.ecoArr.every(function (e) { return e.state !== 'big'; })) { this.say([{ s: 'VALDEMAR', t: 'Tem seca-rachada demais por aqui, cabra. Resolve isso primeiro.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: 'O senhor lê a chuva pelo jeito dos bichos. E os cientistas leem pelos satélites. Os dois dizem a mesma coisa, de maneiras diferentes.', fx: function () { chg('Entendimento', 1); chg('Rede', 1); E.flags.valdemarOk = true; },
        then: [{ s: 'VALDEMAR', t: 'Cientista nunca veio aqui, visse?' }, { s: 'VALDEMAR', t: 'Se a doutora quiser, eu conto todos os anos que acertei. E os que errei.' },
          { fn: function () { E.gotas = Math.max(E.gotas, 7); chg('Saberes', 2); note('SABER DA ESPERA', 'Guardar uma gota para a próxima travessia.', 'Conhecimento de observação (bichos e chuva)'); E.ui.hud(); } },
          { s: 'ARBOVIA', t: 'O Cantil ganhou a Gota da Cisterna, azul-claro. E você aprendeu o Saber da Espera.' }] },
      { k: 'P', t: 'Isso é superstição.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'VALDEMAR', t: 'É observação de sessenta anos. Superstição é a que ninguém confere, vixe.' }, ask()]; } }] }; }
    this.say([{ s: 'VALDEMAR', t: '(olhando o formigueiro) A formiga subiu o ninho. Os sapos cantaram de noite. O joão-de-barro virou a porta pro lado. Vai ter inverno, eita.' }, ask()]);
  },
  talkChapada: function () {
    if (E.flags.chapadaOk) { this.say([{ s: 'CINTHYA', t: 'Hmm. Dona Bernadete e eu temos uma lista de visitas pra cruzar.' }]); return; }
    this.say([{ s: 'CINTHYA', t: 'Dona Bernadete, a senhora tá na minha lista de pessoas que dizem coisas que eu não consigo comprovar.' },
      { s: 'ALBA', t: 'E a senhora tá na minha de gente que acha que doença só existe quando tem número.' }, { s: 'TOMÁS', t: '(baixo) É assim toda vez. Melhor a gente ficar no meio.' },
      { fn: function () { E.flags.chapadaOk = true; chg('Saberes', 1); } }, { s: 'ARBOVIA', t: 'A porta do Observatório se abriu. As duas esperam por você lá dentro.' }]);
  },
  talkCuidadoDado: function () {
    if (E.flags.cuidadoDado) { this.say([{ s: 'CINTHYA', t: 'Dê-me a lista de visitas da Duda. Cruzando com a minha série, estimo o que falta.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Dra. Cinthya, como o dado sabe quem não foi ao posto?', fx: function () { chg('Saberes', 1); },
        then: function () { return [{ s: 'CINTHYA', t: '...Não sabe.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'Os dois têm razão: o dado só vê quem chegou ao posto, e o relato vê quem não chegou. Se juntarmos os dois, vemos o tamanho de verdade.', fx: function () { chg('Entendimento', 2); chg('Rede', 1); },
        then: [{ s: 'CINTHYA', t: 'Juntar? (olha Alba pela primeira vez) Quantos, a senhora acha?' }, { s: 'ALBA', t: 'Uns quarenta.' }, { s: 'ARBOVIA', t: 'A plataforma entre elas se acendeu.' },
          { s: 'TOMÁS', t: '(baixo, a Cinthya) É o que a senhora me ensinou: quando faltar o dado, conte o que falta.' }, { s: 'CINTHYA', t: '(tira os óculos) Eu disse isso?' },
          { s: 'ARBOVIA', t: 'Você recebeu o Leitor de Sinais: cinco lentes para ler o que dizem e o que não dizem.' },
          { fn: function () { note('CONVERGÊNCIA', 'Relato e dado dizem a mesma coisa.', 'Sinal do Leitor de Sinais'); note('ANTECIPAÇÃO', 'O relato vem antes do dado: é um aviso.', 'Sinal do Leitor de Sinais'); note('INVISIBILIDADE', 'Há relato, mas o dado não existe.', 'Sinal do Leitor de Sinais'); note('PONTO CEGO', 'Não há nem um nem outro onde deveria haver.', 'Sinal do Leitor de Sinais'); note('SILÊNCIO', 'Ninguém respondeu.', 'Sinal do Leitor de Sinais'); E.flags.cuidadoDado = true; } },
          { s: 'CINTHYA', t: '(a contragosto) Dê-me a lista de visitas da Duda. Se eu cruzar com a minha série, posso estimar o que falta.' }] });
      o.push({ k: 'P', t: 'Dona Alba, o dado é mais confiável.', fx: function () { chg('Rede', -1); },
        then: function () { return [{ s: 'ALBA', t: 'Aí, a senhora também me desacredita.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'CINTHYA', t: 'O número de casos de febre no Morro das Mangabas é de 14 no trimestre. Estatisticamente baixo para 800 pessoas.' },
      { s: 'ALBA', t: 'Quatorze que chegaram ao posto. Tem muito mais em casa, com chá, sem ir a lugar nenhum.' }, { s: 'CINTHYA', t: 'Sem registro, não há caso.' }, { s: 'ALBA', t: 'Sem caso, não há ajuda. E a gente sem ajuda morre sem número.' },
      { s: 'ARBOVIA', t: 'Silêncio. Cada uma virou de costas. Traduza entre elas.' }, ask(false)]);
  },
  talkPrata: function () {
    var sc = this, q = E.flags.prataQ || (E.flags.prataQ = {});
    if (E.flags.marco5) { this.say([{ s: 'PRATA', t: '(guardando o telão) Os senhores são mais atentos do que eu esperava.' }]); return; }
    function all() { return q.a && q.b && q.c; }
    function fim() { return [{ s: 'PRATA', t: '(tirando um lenço) Os senhores são mais... atentos do que eu esperava.' }, { fn: function () { sc.curva.forEach(function (c) { sc.tweens.add({ targets: c.b, y: 520, duration: 800 }); }); sc.telaoT.setText(''); sc.telao.setFillStyle(0x555555); snd('poof'); } },
      { s: 'ARBOVIA', t: 'A curva se achatou e o telão se apagou.' }, { s: 'CINTHYA', t: '(seca) Eu uso esses números há trinta anos. Eu mesma me enganei. A Duda e a Alba me ensinaram a ver o que eu não via.' },
      { fn: function () { E.flags.marco5 = true; E.gotas = Math.max(E.gotas, 7); chg('Entendimento', 3); chg('Rede', 2); note('LÍNGUA: DADO', 'Dado não fala sozinho: quem o coloca no gráfico fala.', 'Língua aprendida: Dado'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
      { s: 'ARBOVIA', t: 'Cinthya agora é aliada firme, e o Alto da Chapada ajuda a antecipar ameaças. A porta leva ao mapa.' }]; }
    function next() { return all() ? fim() : [ask()]; }
    function ask() { var o = [];
      if (!q.a) o.push({ k: '?', t: '62% de quê? Quantos casos hoje?', fx: function () { chg('Saberes', 1); q.a = true; }, then: function () { return [{ s: 'PRATA', t: 'Em relação à projeção da região.' }, { s: 'ARBOVIA', t: 'A curva baixou: a projeção é inventada.' }].concat(next()); } });
      if (!q.b) o.push({ k: '?', t: 'Quem está contado nesse gráfico?', fx: function () { chg('Saberes', 1); q.b = true; }, then: function () { return [{ s: 'PRATA', t: 'Os moradores da área do projeto... novos.' }, { s: 'ARBOVIA', t: 'A curva revela: os moradores antigos, removidos, sumiram do denominador.' }].concat(next()); } });
      if (!q.c) o.push({ k: 'E', t: '(apontando) Se tirar quem tem febre da área, o número cai. Mas a febre não sumiu, foi para outro lugar.', fx: function () { chg('Entendimento', 1); q.c = true; }, then: function () { return [{ s: 'TOMÁS', t: 'Isso é um ponto cego.' }].concat(next()); } });
      o.push({ k: 'P', t: 'Seu gráfico é mentira.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'PRATA', t: 'Gráfico não mente. Quem lê, às vezes, não entende.' }, { s: 'ARBOVIA', t: 'A curva cresceu. Faça perguntas, não acusações.' }, ask()]; } });
      o.push({ k: 'C', t: '(aceita o gráfico) Se o gráfico ajudar, usamos.', fx: function () { chg('Entendimento', -1); chg('Meios', 1); }, then: function () { return [{ s: 'PRATA', t: 'Ótimo. Podemos conversar sobre apoio.' }, { s: 'ARBOVIA', t: 'Isso é dívida. Quem aceita o gráfico sem perguntar, deve.' }, ask()]; } });
      return { ask: o }; }
    this.say([{ s: 'PRATA', t: '(sorrindo) Resultados claros: o Projeto Mirante, com infraestrutura nova, reduz os casos em 62%. Os dados falam por si.' }, { s: 'CINTHYA', t: '(baixo) Dados não falam. Quem fala é quem os coloca no gráfico.' }, ask()]);
  },
  mkGaps: function (defs) {
    var sc = this;
    this.gaps = defs.map(function (d, i) {
      var w = d.x1 - d.x0, b = sc.solids.create(d.x0 + w / 2, GY + 50, 'px').setVisible(false).setDisplaySize(w, 100).refreshBody();
      var v = sc.add.tileSprite(d.x0, GY, w, 28, 'madeira').setOrigin(0, 0).setTileScale(4, 4).setDepth(2).setAlpha(0.0), done = !!E.flags[d.f];
      var r = { x0: d.x0, x1: d.x1, f: d.f, lbl: d.lbl, rel: d.rel, i: i, b: b, v: v, done: done }; b.body.enable = done; if (done) v.setAlpha(1);
      r.sinal = sc.add.text((d.x0 + d.x1) / 2, GY - 70, 'VÃO', { fontFamily: FONT, fontSize: '18px', fontStyle: 'bold', color: '#fff', backgroundColor: '#c82020', padding: { x: 4, y: 2 } }).setOrigin(0.5).setDepth(4).setVisible(!done); return r; });
  },
  openGap: function (r) { r.done = true; r.b.body.enable = true; r.sinal.setVisible(false); this.tweens.add({ targets: r.v, alpha: 1, duration: 900 }); snd('verter'); E.flags[r.f] = true; },
  talkGap: function (r) {
    var sc = this, ponte = this.lvl === 28;
    if (r.done) { this.say([{ s: 'ARBOVIA', t: ponte ? 'Essa ponte já leva a uma casa.' : 'Essa muda já virou ponte.' }]); return; }
    if (ponte && !E.flags.valdeteOk) { this.say([{ s: 'ARBOVIA', t: 'Antes de construir, converse com a Mestra Letícia: a obra é delas.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: ponte ? 'Cada ponte leva a uma casa.' : 'Cada muda é uma ponte para o próximo pedaço.', fx: function () { chg('Saberes', 1); chg('Entendimento', 1); },
        then: [{ fn: function () { sc.openGap(r); } }, { s: 'ARBOVIA', t: ponte ? 'A ponte foi construída.' : 'A muda cresceu em segundos até virar um galho-ponte.' }].concat(ponte ? [{ s: 'MORADOR', t: r.rel }] : []).concat([{ fn: function () { sc.checkGaps(); } }]) },
      { k: 'P', t: ponte ? 'Dá pra atravessar na tábua velha.' : 'Dá para pular.', fx: function () { chg('Ânimo', -1); },
        then: function () { return [{ s: ponte ? 'ARBOVIA' : 'TEODORO', t: ponte ? 'A tábua velha não aguenta. Construa a ponte.' : 'Calma, meu. A mata ensina devagar.' }, ask()]; } }] }; }
    this.say([{ s: ponte ? 'ARBOVIA' : 'RAQUEL', t: ponte ? 'Um vão entre palafitas. A terra aqui some com a chuva.' : 'Planta aqui, cara.' }, ask()]);
  },
  checkGaps: function () {
    if (this.gaps.every(function (r) { return r.done; })) { E.ui.run([{ s: 'ARBOVIA', t: this.lvl === 28 ? 'Todas as pontes estão feitas. Fale com a Letícia.' : 'Os fragmentos estão ligados. Fale com a Raquel, adiante.' }]); }
  },
  /* ---- Marco 9: A Devolutiva ---- */
  talkIolandaVolta: function () {
    var sc = this;
    if (E.flags.voltaNevoa) { this.say([{ s: 'IOLANDA', t: 'Eu vou com vocês. Pela primeira vez em muito tempo, caminho à luz.' }]); return; }
    if (!this.ecoArr.every(function (e) { return e.state !== 'big'; })) { this.say([{ s: 'IOLANDA', t: '(de longe) Os Brancos ainda fecham o caminho. Verta-os com as lanternas.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'A senhora esteve aqui desde a Confusão?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'IOLANDA', t: 'Tempo é uma coisa estranha aqui. Eu perdi a conta.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'A senhora não falhou. Quis ser a ponte inteira. Ponte é feita de muitas tábuas.', fx: function () { chg('Entendimento', 3); chg('Rede', 2); E.flags.voltaNevoa = true; E.flags.iolandaAliada = true; },
        then: [{ s: 'IOLANDA', t: '(pausa, olha o Cantil) Foi isso que eu esqueci. As tábuas.' }, { s: 'ARBOVIA', t: 'O Cantil respondeu: as duas gotas, a dela e a sua, se encontraram.' },
          { s: 'IOLANDA', t: 'Tem uma coisa que ninguém lhes disse. A Torre guarda a voz única, o Monólogo. Ele só cai quando todas as vozes são ouvidas. Mas não é inimigo: é o medo de que a gente não se entenda.' },
          { s: 'IOLANDA', t: '(se levantando, devagar) Eu vou com vocês.' }, { fn: function () { sc.npcs.iolanda.setTexture('n_iolanda2'); note('IOLANDA, A ÚLTIMA ENTENDENTE', 'Quis ser a ponte inteira. Ponte é feita de muitas tábuas.', 'Aliada: Iolanda (sem a capa)'); } },
          { s: 'ARBOVIA', t: 'A Névoa se dissipa. Os Brancos voltam a ter chão. Vamos à Torre.' }] });
      o.push({ k: 'P', t: 'A senhora devia ter pedido ajuda.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'IOLANDA', t: 'Eu sei.' }, { s: 'ARBOVIA', t: 'Ela se retraiu por um momento, mas continua ouvindo.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'IOLANDA', t: 'Vocês voltaram acompanhados.' }, { s: 'IOLANDA', t: 'Eu era Entendente. A última. Quis traduzir todos, falar por todos, escutar todos. A Névoa me engoliu, e eu virei guardiã do que ninguém respondeu.' }, ask(false)]);
  },
  talkAndar: function (f) {
    var sc = this;
    if (E.flags['andar' + f.i]) { this.say([{ s: 'ARBOVIA', t: 'Andar ' + f.i + ' traduzido: "' + f.k + '" → ' + f.b + '.' }]); return; }
    if (f.i > 0 && !E.flags['andar' + (f.i - 1)]) { this.say([{ s: 'ARBOVIA', t: 'Traduza o andar anterior antes de subir.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: '"' + f.k + '" → ' + f.b, fx: function () { chg('Entendimento', 1); E.flags['andar' + f.i] = true; }, then: [{ s: 'ARBOVIA', t: 'Traduzido em ' + f.l + '. ' + (f.i === 6 ? 'O último andar abre o céu. O Rei espera lá em cima.' : 'Suba mais um andar.') }] },
      { k: 'P', t: '"' + f.k + '" → ' + f.a, fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'ARBOVIA', t: 'Essa é a leitura de quem usa a palavra para fechar. Há outra.' }, ask()]; } }] }; }
    this.say([{ s: '', t: 'Na parede, em ' + f.l + ': "' + f.k + '".' }, ask()]);
  },
  talkCassiano: function () {
    var sc = this;
    if (E.flags.torreOk) { this.say([{ s: 'CASSIANO', t: 'Abre... pra dentro. Eu nunca tinha olhado pra baixo.' }]); return; }
    if (![0, 1, 2, 3, 4, 5, 6].every(function (i) { return E.flags['andar' + i]; })) { this.say([{ s: 'ARBOVIA', t: 'Há andares sem tradução. Suba por todos antes de falar com o Rei.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Por que o senhor quer terminar?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'CASSIANO', t: 'Porque, se ficar assim, é a prova de que ele falhou. E eu sou filho dele.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'A Torre inacabada não é fracasso. É uma pergunta. E a resposta pode ser a Roda.', fx: function () { chg('Entendimento', 3); chg('Rede', 2); },
        then: [{ s: 'CASSIANO', t: 'A Roda?' }, { s: 'IOLANDA', t: '(atrás, calma) Uma Torre que não se fecha. Que abre.' }, { s: 'CASSIANO', t: '(pausa) Abre... pra dentro? (olha o vão no centro, o fosso seco) Eu nunca tinha olhado pra baixo.' },
          { fn: function () { var a = sc.npcs.aristides; a.setVisible(true); a.lbl.setVisible(true); } },
          { s: 'ARISTIDES', t: '(subindo, com o croqui na mão) Majestade. Eu levantei essa laje. Sei onde a água está.' }, { s: 'CASSIANO', t: '...Você?' }, { s: 'ARISTIDES', t: 'Dezoito metros abaixo do Salão.' },
          { s: 'ARBOVIA', t: 'Pela primeira vez, Cassiano olha para o homem que construiu a sua torre.' }, { s: 'CASSIANO', t: 'Mostre.' },
          { fn: function () { E.flags.torreOk = true; note('TORRE QUE ABRE', 'A Torre inacabada não é fracasso: é uma pergunta, e a resposta pode ser a Roda.', 'Cassiano: parceiro'); E.ui.hud(); } }] });
      o.push({ k: 'P', t: 'Seu avô falhou, e o senhor também.', fx: function () { chg('Rede', -1); },
        then: [{ s: 'CASSIANO', t: 'Então eu termino.' }, { fn: function () { sc.p.setPosition(Math.max(150, sc.p.x - 900), 540); } }, { s: 'ARBOVIA', t: 'Você foi lançado de volta ao andar anterior. O Rei ficou mais duro. Volte e pergunte com cuidado.' }] });
      return { ask: o }; }
    this.say([{ s: 'CASSIANO', t: 'Meu avô deixou isto inacabado. Eu só queria terminar.' }, { s: 'CASSIANO', t: '(sem se virar) Chegaram até aqui. A Torre não é minha inimiga, vocês sabem.' }, ask(false)]);
  },
  talkMonologo: function () {
    var sc = this;
    if (E.flags.monologoOk) { this.say([{ s: 'ARISTIDES', t: '(chorando) Estava aqui, sempre esteve.' }]); return; }
    var ph = E.flags.mph || 0;
    var F = [
      { m: 'ORDEM, PROGRESSO, PROTOCOLO.', e: 'Ordem para cuidar, progresso para todos, protocolo que escuta.', r: [{ s: 'ZENI', t: 'Ordem para cuidar!' }, { s: 'ROSINHA', t: 'Progresso para todos!' }, { s: 'RAIZA', t: 'Protocolo que escuta!' }] },
      { m: 'O QUE É DITO ALTO É VERDADE. O QUE É DITO BAIXO É FAVOR.', e: 'O que é dito com fonte é verdade. O que é dito aberto é acordo.', r: [{ s: E.flags.marco4 ? 'ED' : 'ARBOVIA', t: 'O que é dito com fonte é verdade.' }, { s: E.flags.veluOk ? 'EULÁLIA' : 'ARBOVIA', t: 'O que é dito aberto é acordo.' }] },
      { m: 'TRANQUE. LIMITE. CONTE.', e: 'Proteja sem trancar. Limite sem cortar. Conte com todos.', r: [{ s: E.flags.ferrolhoOk ? 'ISMAEL' : 'ARBOVIA', t: '(hesitando) Proteger sem trancar...' }, { s: E.flags.marco7 ? 'VINTÉM' : 'ARBOVIA', t: '(hesitando) Contar com todos...' }] },
      { m: '...', e: '(registra o silêncio no Caderno)', r: [{ s: 'IOLANDA', t: 'Eu me lembro de cada voz que ficou sem resposta. Eu as devolvo.' }, { s: 'ARBOVIA', t: 'O Caderno brilha. As gavetas da Névoa Muda se abrem e papéis voam em volta da Praça.' }] }
    ];
    if (ph < 4) {
      var f = F[ph];
      function ask() { return { ask: [
        { k: 'E', t: f.e, fx: function () { chg('Entendimento', 2); E.flags.mph = ph + 1; if (ph === 3) note('SILÊNCIO REGISTRADO', 'Registrar a ausência também é devolver a voz.', 'Língua aprendida: Ausência'); },
          then: [{ s: 'ARBOVIA', t: 'O Monólogo perdeu uma camada de voz.' }].concat(f.r) },
        { k: 'P', t: 'Cale essa voz!', fx: function () { chg('Ânimo', -1); }, then: function () { return [{ s: 'MONÓLOGO', t: 'UMA SÓ VOZ!' }, { s: 'IOLANDA', t: 'Ele não se cala à força. Ele precisa ser ouvido e traduzido.' }, ask()]; } }] }; }
      this.say([{ s: 'MONÓLOGO', t: f.m }, ask()]); return; }
    var dom = [['VILA MUTIRÃO', 'Foi assim que a gente voltou a ter nome.'], ['BOCA DO IGARAPÉ', 'A floresta em pé vale mais do que mil tábuas.'], ['POUSO DAS GARÇAS', 'A água sobe, a água desce. A gente aprendeu a viver com ela.'], ['CACIMBA GRANDE', 'Guardar é cuidar de quem vem depois.'],
      ['FRAGMENTO DO JEQUITIBÁ', 'Dois pedaços sozinhos morrem. Ligados, se curam.'], ['COXILHA DA FRONTEIRA', 'Onde as línguas se misturam, nascem entendimentos.'], ['ENSEADA DO SIRI', 'A hora certa é a que a maré dá.'], ['BABAÇUAL ALTO', 'O que é de muitos não é de ninguém sozinho.'], ['FAXINAL DO PINHAL', 'Planta-se o que os netos vão colher.']].map(function (d) { return { s: '', t: d[0] + ': "' + d[1] + '"' }; });
    this.say([{ s: 'MONÓLOGO', t: '(o Monólogo se divide em doze vozes, cada uma com a sua Língua, que se entrelaçam)' }, { s: 'COTA', t: '(de longe, no meio da Roda) Agora.' }, { ask: [
      { k: 'E', t: '(levanta o Cantil e verte sobre o chão da Praça)', fx: function () { chg('Entendimento', 3); chg('Rede', 3); },
        then: [{ s: 'ARBOVIA', t: 'A água sobe do chão e toca as vozes. A cada frase, o Monólogo perde uma camada.' }].concat(dom).concat(E.gotas < 9 ? [{ s: 'ARBOVIA', t: 'Ainda faltam vozes: alguns Domínios ficaram em silêncio, com brilho fraco. Mas a Roda se faz.' }] : [{ s: 'ARBOVIA', t: 'As nove gotas! A água desce por todos os rios.' }]).concat([
          { s: 'MONÓLOGO', t: '(vozes se separando em doze, cada uma falando a sua) ...Eu entendi. Eu não precisava ser uma só.' }, { s: 'ARBOVIA', t: 'O Monólogo se desfez em gotas. Do centro da Torre brota o Olho-d\'Água, forte e azul.' },
          { fn: function () { E.flags.monologoOk = true; sc.monolo.setFillStyle(0x4fc3f7, 0.5); sc.monoT.setText(''); sc.add.rectangle(sc.physics.world.bounds.width / 2, GY + 10, sc.physics.world.bounds.width, 30, 0x4fc3f7, 0.6).setDepth(1); note('OLHO-D\'ÁGUA', 'Estava aqui, sempre esteve.', 'A água corre pelo fosso, pelo chão, pelas veredas'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
          { s: 'ARISTIDES', t: '(chorando) Estava aqui, sempre esteve.' }]) }] }]);
  },
  talkDevolutiva: function () {
    var sc = this;
    if (E.flags.marco9) { this.say([{ s: 'ROSINHA', t: 'Relatório lido. O próximo ciclo começa quando a Roda quiser.' }]); return; }
    var ep = [];
    if (E.flags.marco3 && E.flags.marco4) ep.push({ s: 'FERNANDA', t: '(RECONHECIMENTO) A Coordenação adotou o seu mapa como referência. Vila Mutirão escrita pela própria vila.' }, { s: 'FÁBIO', t: 'Vamos ao ar. E dessa vez, com fonte.' });
    if (E.flags.sonhosOk) ep.push({ s: 'ROSINHA', t: '(AUTONOMIA) Eu queria um papel que ninguém rasgasse. Sou eu a que não rasga.' });
    if (E.flags.baixadaOk && E.flags.marco8) ep.push({ s: 'HONÓRIO', t: '(COALIZÃO, para si mesmo) A responsabilidade era de todos. Faz sentido.' });
    ep.push({ s: 'COTA', t: '(SONHO, com o Cantil dourado) Sonhar em voz alta já é fazer metade. A outra metade foi vocês.' });
    var seq = [{ s: 'ROSINHA', t: '(lendo) Relatório do ciclo: o que fizemos, o que não fizemos, o que aprendemos.' }, { s: 'COTA', t: 'O que ficou por fazer?' }, { s: 'DUDA', t: 'A Febre pode voltar.' }, { s: 'LÉO', t: 'As rampas precisam chegar até a Baixada.' }, { s: 'LETÍCIA', t: 'A Baixada precisa de chão firme.' }, { s: 'ED', t: 'A rádio vai ao ar todo dia com a correção da véspera.' },
      { s: 'ARBOVIA', t: 'Cada fala virou uma página em branco que o Caderno guarda, para o próximo ciclo.' },
      { fn: function () { note('PÁGINAS EM BRANCO', 'Febre pode voltar · Rampas até a Baixada · Chão firme na Baixada · Rádio com a correção da véspera.', 'Devolutiva: o que ficou por fazer'); } }].concat(ep);
    if (E.flags.iolandaAliada) seq.push({ s: 'IOLANDA', t: '(sem capa, entregando um traço de luz ao Cantil) Este é o Selo de Entendente. Você já não está só.' }, { fn: function () { note('SELO DE ENTENDENTE', 'Um traço de luz no Cantil.', 'Entregue por Iolanda'); } });
    seq.push({ s: '', t: 'Noite. A Praça das Águas, vazia, com a Roda. O Cantil brilha mais forte do que nunca.' }, { s: 'ARBOVIA', t: 'E agora?' }, { s: 'COTA', t: '(chegando, devagar) Agora começa outro ciclo. O Esquecimento é coisa que não acaba: a gente tem que cuidar da Roda todo dia.' },
      { s: 'ED', t: '(rádio) No ar! Notícia de longe: há outras veredas, além do planalto, pedindo Roda.' }, { s: 'IOLANDA', t: 'Eu conheço o caminho.' },
      { fn: function () { E.flags.marco9 = true; E.lua = 9; E.gotas = 9; chg('Entendimento', 5); chg('Rede', 3); note('NOVO CICLO', 'Outras veredas pedem Roda. Quem entende, cuida.', 'Fim do Ciclo 1 · Entendência'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
      { fn: function () { var fa = finaisAlcancados(), ls = Object.keys(fa).filter(function (k) { return fa[k]; }); E.finais = ls; note('FINAIS ALCANÇADOS', ls.join(' · ') + (ls.length < 4 ? '. Revisite fases para abrir os outros.' : '. Todos abertos!'), 'Visibilidade ' + E.rec.Visibilidade + ' · Voz (Rede) ' + E.rec.Rede + (E.legado ? ' · Memória do Território' : '')); } },
      { s: 'ENTENDÊNCIA', t: 'FIM DO PRIMEIRO CICLO. Obrigado por jogar. Você pode voltar ao mapa e revisitar qualquer lugar.' });
    this.say(seq);
  },
  /* ---- Marco 8: A Porta ---- */
  talkNonato: function () {
    var sc = this;
    if (E.flags.mareOk) { this.say([{ s: 'NONATO', t: 'Uma maré de remos, meu rei. Ainda dá pra ouvir o barulho.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'Quando foi cercada?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'NONATO', t: 'Faz três luas, oxente.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'Se todos os barcos puserem os remos na praia no mesmo dia, ninguém consegue deixar de ver.', fx: function () { chg('Entendimento', 2); chg('Rede', 1); E.flags.mareOk = true; },
        then: [{ s: 'NONATO', t: '(sorri) Uma maré de remos. Gostei.' }, { s: 'LIA', t: 'Tem que ser com tempo, e com gente. A maré dá a hora, painho.' }, { fn: function () { sc.barrierDone(sc.cerca); E.gotas = Math.max(E.gotas, 9); chg('Saberes', 1); note('SABER DE MARÉ', 'Ação coletiva na hora certa: a maré de remos.', 'Saber de Maré (Costa e Mar)'); E.ui.hud(); } },
          { s: 'ARBOVIA', t: 'A cerca virou Cadeado aberto: a ação coletiva já está combinada. Você ganhou o Saber de Maré e a Gota da Maré, turquesa.' }] });
      o.push({ k: 'P', t: 'Corta a cerca.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'NONATO', t: 'Aí vem a polícia, e nós viramos os vilões.' }, ask(skipQ)]; } });
      return { ask: o }; }
    this.say([{ s: 'NONATO', t: 'A cerca é um cadeado gigante, meu rei. Só abre com ação coletiva.' }, ask(false)]);
  },
  talkHonorio: function () {
    var sc = this;
    if (E.flags.honOk) { this.say([{ s: 'HONÓRIO', t: '(sem jeito, quase sorrindo) Dividir a responsabilidade... isso é permitido, afinal.' }]); return; }
    function finale() { return [{ s: 'HONÓRIO', t: 'Dividir... a responsabilidade. Isso é permitido? (pela primeira vez, ele sorri, sem jeito.)' },
      { s: 'ARBOVIA', t: 'Mas a Cadeira Giratória gira: a Eleição aconteceu e um novo Regente vai assumir, com outro Oficialês. Registre o Plano antes!' },
      { s: 'FERNANDA', t: '(passa o Plano por baixo da porta) Registrado. Protocolado. Está na primeira gaveta.' },
      { fn: function () { E.flags.honOk = true; chg('Entendimento', 3); chg('Rede', 1); note('PLANO REGISTRADO', 'Três ações em noventa dias, com responsável em cada uma.', 'Documento público (Ordem)'); E.ui.hud(); } }]; }
    function nxt() { return E.flags.honE2 ? finale() : [ask()]; }
    function ask() { var o = [];
      if (!E.flags.honQ) o.push({ k: '?', t: 'Qual Coordenação, e quando responde?', fx: function () { chg('Saberes', 1); E.flags.honQ = true; }, then: function () { return [{ s: 'HONÓRIO', t: '...A competente.' }, { s: 'ARBOVIA', t: 'Ele não sabe.' }].concat(nxt()); } });
      if (!E.flags.honE1) o.push({ k: 'E', t: 'Nós temos um Plano Popular, com ata e Livro de Leis. O pedido é simples: três ações em noventa dias, com responsável em cada uma.', fx: function () { chg('Entendimento', 1); E.flags.honE1 = true; },
        then: function () { return [{ s: 'HONÓRIO', t: '(olhando para os papéis) Isso... é bem organizado.' }, { s: 'HONÓRIO', t: 'Eu não decido. Eu... encaminho. Se eu decidir e errar, a Cadeira gira e eu vou junto.' }, { s: 'ARBOVIA', t: 'Ele tem medo.' }].concat(nxt()); } });
      if (E.flags.honE1 && !E.flags.honE2) o.push({ k: 'E', t: 'O senhor decidiria mais tranquilo se a decisão fosse de muita gente, com ata e prova. A responsabilidade seria da Roda, e não só sua.', fx: function () { chg('Entendimento', 2); E.flags.honE2 = true; }, then: function () { return nxt(); } });
      o.push({ k: 'P', t: 'Vocês nunca respondem.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'HONÓRIO', t: 'O Regente responde sempre.' }, ask()]; } });
      return { ask: o }; }
    this.say([{ s: 'HONÓRIO', t: 'Ah, os representantes da... Vila... Mutirão. O assunto encontra-se em análise pela Coordenação competente.' }, ask()]);
  },
  talkEulalia: function () {
    var sc = this, rp = E.flags.rosaPath;
    if (E.flags.veluOk) { this.say([{ s: 'EULÁLIA', t: '...Sem condição? (fica em silêncio)' }]); return; }
    if (!rp) {
      function ask(skipQ) { var o = [];
        if (!skipQ) o.push({ k: '?', t: 'O que a senhora acha que vai custar de verdade?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'ROSINHA', t: '...A vila. Eu sei. Eu sei, só queria ouvir de outro.' }, ask(true)]; } });
        o.push({ k: 'E', t: 'A senhora lutou vinte anos para que a vila não dependa de favor. Se aceitar, a vila passa a depender dela.', fx: function () { chg('Entendimento', 2); E.flags.rosaPath = 'recusou'; },
          then: [{ s: 'ROSINHA', t: '(olhando as mãos) Eu lutei vinte anos para não precisar de favor. Baronesa, agradeço. Eu recuso.' }, { s: 'ARBOVIA', t: 'Rosinha recusou. Ela fica mais firme.' }] });
        o.push({ k: 'E', t: 'Só a senhora decide. Mas a Roda estaria com a senhora, qualquer que seja o caminho.', fx: function () { chg('Rede', 2); E.flags.rosaPath = 'roda'; },
          then: [{ s: 'ROSINHA', t: '...Eu quero ouvir a Roda.' }, { s: 'ARBOVIA', t: 'A decisão vai à Roda. Rosinha volta fortalecida.' }] });
        o.push({ k: 'P', t: 'Não aceite. Ela é má.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'ROSINHA', t: 'Má? É generosa. O problema não é ela. O problema é eu estar aqui.' }, ask(skipQ)]; } });
        o.push({ k: 'C', t: 'Aceita só a obra do posto, depois a gente vê.', fx: function () { chg('Entendimento', -1); E.flags.rosaPath = 'aceitou'; },
          then: [{ s: 'EULÁLIA', t: 'Ótimo, querido.' }, { s: 'ARBOVIA', t: 'Rosinha olhou decepcionada. O posto será feito, mas com dívida.' }] });
        return { ask: o }; }
      this.say([{ s: 'EULÁLIA', t: 'Soube do vosso Plano. Lindo. Gostaria de ajudar: a obra do posto, a escola, a cozinha... tudo. Sem burocracia.' }, { s: 'ROSINHA', t: '(suspira, cansada) Tudo? Sem burocracia?' },
        { s: 'EULÁLIA', t: 'Basta que a Associação... deixe de se opor ao Mirante. Uma assinatura. Só isso.' }, { s: 'ROSINHA', t: '(baixo, ao jogador) Faz vinte anos que eu peço isso. Vinte anos. Ela me dá em um dia.' }, ask(false)]);
      return; }
    if (!E.flags.livroFav) { this.say([{ s: 'EULÁLIA', t: 'Vocês me ofendem. Eu só quero... ser querida.' }, { s: 'ARBOVIA', t: 'Há um homem de colete na escada. Fale com o Cassiano.' }]); return; }
    this.say([{ s: 'ARBOVIA', t: 'Ela está triste.' }, { ask: [{ k: 'E', t: 'A senhora pode ser querida sem comprar ninguém. A Roda tem lugar para quem ajuda sem condição.', fx: function () { chg('Entendimento', 2); chg('Rede', 1); E.flags.veluOk = true; },
      then: [{ s: 'EULÁLIA', t: '...Sem condição? (fica em silêncio)' }, { s: 'ARBOVIA', t: 'Primeira rachadura em Veludara.' }, { fn: function () { note('RACHADURA EM VELUDARA', 'Ajuda sem condição: lugar na Roda para quem não compra silêncio.', 'Rosinha: ' + (E.flags.rosaPath === 'recusou' ? 'recusou a Baronesa' : E.flags.rosaPath === 'roda' ? 'decidiu com a Roda' : 'aceitou a obra do posto (dívida)')); } }] }] }]);
  },
  talkCassiano: function () {
    if (!E.flags.rosaPath) { this.say([{ s: 'CASSIANO', t: '(sussurrando) Depois, depois. Primeiro resolvam a mesa da Baronesa.' }]); return; }
    if (E.flags.livroFav) { this.say([{ s: 'CASSIANO', t: 'A Roda protege quem fala. Eu confio.' }]); return; }
    this.say([{ s: 'CASSIANO', t: '(sussurrando) Eu sou o Tesoureiro. Guardo as notas de cada favor. Todo mundo que sobe essa escada deve. Tem prova de tudo.' }, { s: 'CASSIANO', t: 'Eu estou cansado de guardar dívida de gente que não sabe que deve.' },
      { ask: [{ k: 'E', t: 'Se a gente usar essa prova junto com outros territórios, a senhora Vasconcelos perde o poder de comprar silêncio.', fx: function () { chg('Rede', 1); chg('Entendimento', 1); E.flags.livroFav = true; },
        then: [{ s: 'CASSIANO', t: 'Mas ela vai me perseguir.' }, { s: 'ROSINHA', t: '(recuperando-se) A Roda protege quem fala.' }, { fn: function () { note('LIVRO DOS FAVORES', 'Prova de dívidas de favor, usada só em conjunto com outros territórios.', 'Prova para denúncia (com proteção a Cassiano)'); } }, { s: 'ARBOVIA', t: 'Você recebeu o Livro dos Favores. Agora fale de novo com a Baronesa.' }] }] }]);
  },
  talkIsmael: function () {
    var sc = this;
    if (E.flags.ismOk) { this.say([{ s: 'ISMAEL', t: 'Na ponta da mesa, eu posso ficar.' }]); return; }
    function ask(skipQ) { var o = [];
      if (!skipQ) o.push({ k: '?', t: 'O que o senhor perdeu?', fx: function () { chg('Saberes', 1); }, then: function () { return [{ s: 'ISMAEL', t: '(pausa longa) Tudo. Minha rua. Meus vizinhos. Foi porque todo mundo gritou e ninguém escutou.' }, ask(true)]; } });
      o.push({ k: 'E', t: 'Uma Roda não é gritaria, é escuta. E tem testemunhas. O senhor pode ficar na ponta da mesa e ver.', fx: function () { chg('Entendimento', 2); E.flags.ismOk = true; },
        then: [{ s: 'ISMAEL', t: 'Ver? (olha para o portão) Ficar na ponta... posso.' }, { fn: function () { sc.barrierDone(sc.portao[0]); snd('stamp'); } }, { s: 'ARBOVIA', t: 'Um cadeado se abriu. O próximo portão é do Pedro.' }] });
      return { ask: o }; }
    this.say([{ s: 'ISMAEL', t: '(manso, falando baixo) Eu já vi uma cidade pegar fogo. Desde então, tranco. Quem tem a chave tem a paz.' }, ask(false)]);
  },
  talkPedro: function () {
    var sc = this;
    if (E.flags.ferrolhoOk) { this.say([{ s: 'PEDRO', t: 'Deixei o portão encostado. Qualquer coisa, eu abro.' }]); return; }
    if (!E.flags.ismOk) { this.say([{ s: 'PEDRO', t: '(baixo) Fala com o Chaveiro-Mor primeiro.' }]); return; }
    this.say([{ s: 'PEDRO', t: '(baixo) Eu deixei o portão encostado hoje. Quando o senhor me mandar fechar, eu fecho. Mas se alguém bater, eu abro.' }, { ask: [
      { k: 'E', t: 'Obrigado. Ele só quer que ninguém mais perca nada.', fx: function () { chg('Rede', 2); E.flags.ferrolhoOk = true; },
        then: [{ s: 'PEDRO', t: 'Eu sei. Ele me salvou, naquela noite.' }, { fn: function () { sc.barrierDone(sc.portao[1]); snd('stamp'); } }, { s: 'ARBOVIA', t: 'Pedro agora é aliado em Ferrolho. Os portões se abriram.' }] }] }]);
  },
  talkPorta: function (k) {
    var sc = this;
    var D = { rosa: { i: 0, s: 'ROSINHA', e: 'Peçam o Plano Popular registrado.', r: 'Queremos o Plano Popular registrado em lei!' }, nonato: { i: 1, s: 'NONATO', e: 'Peçam o livre acesso à praia.', r: 'A praia é de todos, abram a cerca!' },
      chiquinha: { i: 2, s: 'CHIQUINHA', e: 'Peçam água garantida na seca, sem favor.', r: 'Água sem voto, sem favor, sem prazo!' }, joana: { i: 3, s: 'RAIZA', e: 'Peçam o reconhecimento da terra.', r: 'O castanhal é nosso, e o papel falso cai!' },
      tereza: { i: 4, s: 'TEREZA', e: 'Peçam a revisão da barragem.', r: 'A água pertence a todos que dependem dela!' } }[k];
    if (E.flags.marco8) { this.say([{ s: D.s, t: 'A Porta se abriu. A gente fez junto.' }]); return; }
    if (E.flags['luzp' + D.i]) { this.say([{ s: D.s, t: 'Minha luz tá acesa. Falta o resto, na mesma hora.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: D.e, fx: function () { chg('Entendimento', 1); E.flags['luzp' + D.i] = true; sc.luzes[D.i].setFillStyle(0xffe14a); snd('check'); },
        then: [{ s: D.s, t: D.r }, { s: 'ARBOVIA', t: 'Luz ' + (D.i + 1) + ' acesa.' }, { fn: function () { sc.checkPorta(); } }] },
      { k: 'P', t: 'A gente exige uma coisa de cada vez.', fx: function () { chg('Ânimo', -1); }, then: function () { return [{ s: 'ARBOVIA', t: 'A Porta resistiu. Exigências separadas ela ignora, uma a uma.' }, ask()]; } }] }; }
    this.say([{ s: D.s, t: 'Estou pronto(a) pra exigir. Qual é o pedido do meu território?' }, ask()]);
  },
  talkMarilenePorta: function () {
    var sc = this;
    if (E.flags.marco8) { this.say([{ s: 'FERNANDA', t: 'Registrado e protocolado. Primeira gaveta.' }]); return; }
    this.say([{ s: 'FERNANDA', t: 'Cinco territórios, a mesma exigência, ao mesmo tempo. É só isso que a Porta entende.' }, { ask: [
      { k: '?', t: 'Como a Porta sabe que são cinco ao mesmo tempo?', fx: function () { chg('Saberes', 1); }, then: [{ s: 'FERNANDA', t: 'Pelas luzes. Cada uma acende quando o território fala. Cinco acesas juntas, e o Carimbo racha.' }] },
      { k: 'C', t: 'Posso conversar com o Regente em particular.', fx: function () { chg('Entendimento', -1); }, then: [{ s: 'FERNANDA', t: 'Isso é o que eles querem. Cada um sozinho, em sua sala.' }] }] }]);
  },
  checkPorta: function () {
    var sc = this; if (![0, 1, 2, 3, 4].every(function (i) { return E.flags['luzp' + i]; }) || E.flags.marco8) return;
    this.say([{ s: '', t: 'Cinco luzes acesas ao mesmo tempo. A Porta racha. Um raio de luz atravessa o Carimbo.' }, { fn: function () { sc.porta.setFillStyle(0x8a7a6a, 0.3); snd('poof'); } },
      { s: 'NOVA VOZ', t: '(do outro lado, hesitante) O Regente... recebe os representantes.' }, { fn: function () { var r = sc.npcs.regente; r.setVisible(true); r.lbl.setVisible(true); } },
      { s: 'REGENTE', t: 'Eu... só ocupei a Cadeira hoje. Mas eu li o Plano. Está registrado.' }, { s: 'FERNANDA', t: '(baixo) Registrado e protocolado. Está na primeira gaveta.' },
      { fn: function () { E.flags.marco8 = true; chg('Entendimento', 3); chg('Rede', 3); E.gotas = Math.max(E.gotas, 9); note('PRESSÃO COORDENADA', 'Cinco territórios, a mesma exigência, ao mesmo tempo.', 'Língua aprendida: Meias-palavras e Ordem'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
      { s: 'ARBOVIA', t: 'Pressão Coordenada completa! Língua aprendida: Meias-palavras e Ordem. A porta leva ao mapa.' }]);
  },
  /* ---- Marco 7: O Plano ---- */
  talkTeodoro: function () {
    this.say([{ s: 'TEODORO', t: E.flags.corredorOk ? 'Cada muda é uma ponte, meu. A mata agradece.' : 'A mata ensina devagar, cara. Chega na beirada do vão e planta.' }]);
  },
  talkBruna: function () {
    if (E.flags.corredorOk) { this.say([{ s: 'RAQUEL', t: 'Ouvi falar do seu Plano Popular. Se ele ligar as obras como a gente liga os fragmentos, aguenta o tempo.' }]); return; }
    if (!this.gaps.every(function (r) { return r.done; })) { this.say([{ s: 'RAQUEL', t: 'Ainda tem vão aberto, cara. Liga todos os fragmentos primeiro.' }]); return; }
    this.say([{ s: 'RAQUEL', t: 'O loteamento ali vai cortar o último corredor. A licença saiu rápido demais, pô.' }, { s: 'TEODORO', t: '(chegando) Rápido demais é quando ninguém pergunta.' },
      { fn: function () { E.flags.corredorOk = true; E.flags.corredor = true; E.gotas = Math.max(E.gotas, 9); chg('Saberes', 2); note('SABER DE CORREDOR', 'Fragmentos ligados se curam: segundo pulo e mata em rede.', 'Saber de Corredor (Mata Atlântica)'); E.ui.hud(); } },
      { s: 'ARBOVIA', t: 'Você aprendeu o Saber de Corredor: agora dá um segundo pulo no ar! E o Cantil ganhou a Gota da Muda, verde-escura.' },
      { s: 'RAQUEL', t: 'Ouvi falar do seu Plano Popular. Se ele ligar as obras como a gente liga os fragmentos, aguenta o tempo.' }]);
  },
  talkSonho: function (k) {
    var D = { cota: ['DONA COTA', 'Eu sonho com a escola de portão aberto, e com criança aprendendo a escutar.'], zeni: ['ZENI', 'Uma cozinha comunitária, onde todo mundo cozinha e todo mundo come, uai.'], marta: ['DUDA', 'Um posto que nunca feche, e uma agenda que não me esgote.'],
      rosa: ['ROSINHA', 'Um papel assinado que ninguém consiga rasgar.'], davi: ['ED', 'Uma rádio que ouça mais do que fale.'], aristides: ['ARISTIDES', '(baixo) Uma obra que eu possa dizer "fui eu" sem vergonha, sô.'],
      leo: ['LÉO', 'Uma vila em que o mapa não precise ter uma legenda de quem não passa.'], valdete: ['LETÍCIA', 'Um chão que não suma na chuva.'] }[k];
    var first = !E.flags['sn_' + k]; E.flags['sn_' + k] = true; if (first) chg('Saberes', 1);
    var all = ['cota', 'zeni', 'marta', 'rosa', 'davi', 'aristides', 'leo', 'valdete'].every(function (x) { return E.flags['sn_' + x]; });
    var l = [{ s: D[0], t: D[1] }];
    if (first && all) l.push({ s: 'ARBOVIA', t: 'E eu... eu quero que todo mundo me entenda. Cada sonho virou uma peça luminosa. Vá à mesa do Plano e monte a obra.' });
    this.say(l);
  },
  talkObra: function () {
    var sc = this;
    if (E.flags.sonhosOk) { this.say([{ s: 'COTA', t: 'Sonhar em voz alta já é fazer metade.' }]); return; }
    if (!['cota', 'zeni', 'marta', 'rosa', 'davi', 'aristides', 'leo', 'valdete'].every(function (x) { return E.flags['sn_' + x]; })) { this.say([{ s: 'ARBOVIA', t: 'Escute o sonho de todas as pessoas antes de montar a obra.' }]); return; }
    var R = [{ f: 'ob1', e: 'Se o posto fica perto da escola, as crianças e as mães usam os dois.', sp: 'DUDA', r: 'Isso é... é bom.', t: 'Peça: posto e escola. Onde ligar?' },
      { f: 'ob2', e: 'A horta alimenta a cozinha, e a cozinha alimenta a vila.', sp: 'ZENI', r: 'É a minha cozinha dos sonhos!', t: 'Peça: horta e cozinha. Onde ligar?' }];
    function round() {
      var r = R.filter(function (x) { return !E.flags[x.f]; })[0];
      if (!r) return [{ s: 'COTA', t: '(fechando a Roda) Sonhar em voz alta já é fazer metade.' }, { fn: function () { E.flags.sonhosOk = true; chg('Entendimento', 2); chg('Rede', 1); note('OBRAS DO PLANO', 'Cada peça precisa estar ligada à vizinha, como um corredor.', 'Modo Obra: horta, posto, escola, praça'); E.ui.hud(); } }, { s: 'ARBOVIA', t: 'A porta da praça leva à Baixada do Lamaçal.' }];
      return [{ s: 'ARBOVIA', t: r.t }, { ask: [
        { k: 'E', t: r.e, fx: function () { chg('Entendimento', 1); E.flags[r.f] = true; }, then: function () { return [{ s: r.sp, t: r.r }].concat(round()); } },
        { k: 'P', t: 'Só cabe aqui. (colocar tudo em um canto)', fx: function () { chg('Meios', -1); }, then: function () { return [{ s: 'ARBOVIA', t: 'As peças se atrapalharam. Ligue cada uma à vizinha.' }].concat(round()); } },
        { k: 'C', t: 'Concretália oferece pagar o posto.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'ROSINHA', t: 'Concretália? Com que condição?' }, { s: 'ARBOVIA', t: 'Obra paga por quem não escuta vem com preço escondido.' }].concat(round()); } }] }];
    }
    this.say(round());
  },
  talkValdete: function () {
    var sc = this;
    if (E.flags.baixadaOk) { this.say([{ s: 'LETÍCIA', t: 'A Baixada tem luz e sinal. Vocês vieram.' }]); return; }
    if (E.flags.valdeteOk) {
      if (!this.gaps.every(function (r) { return r.done; })) { this.say([{ s: 'LETÍCIA', t: 'Os moradores esperam as pontes, uai. Constrói.' }]); return; }
      this.say([{ s: 'ARBOVIA', t: 'A Baixada ganhou luzes e sinal de internet. É a primeira Obra do Plano concluída.' }, { s: 'LETÍCIA', t: 'Um chão que não some. Eu vou lembrar.' },
        { fn: function () { E.flags.baixadaOk = true; chg('Rede', 2); chg('Entendimento', 2); chg('Visibilidade', 1); note('COALIZÃO', 'Salvar a Baixada é vitória entre territórios.', 'Primeira Obra do Plano'); E.ui.hud(); } },
        { s: 'ARBOVIA', t: 'Salvar a Baixada conta como vitória entre territórios: Coalizão.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: 'As palafitas ficam, e a gente faz as pontes e um aterro bem planejado, com vocês desenhando.', fx: function () { chg('Rede', 1); E.flags.valdeteOk = true; },
        then: [{ s: 'LETÍCIA', t: 'Com a gente desenhando? (pausa) Ninguém nunca perguntou. Trago os moradores.' }, { s: 'ARBOVIA', t: 'A obra começa. Construa as pontes nos vãos.' }] },
      { k: 'P', t: 'A gente desenha e vocês aprovam depois.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'LETÍCIA', t: 'Aprovar o que já tá pronto não é desenhar.' }, ask()]; } }] }; }
    this.say([{ s: 'LETÍCIA', t: '(sem sorrir, mas sem raiva) Vocês vieram.' }, { s: 'LETÍCIA', t: E.flags.rodaCrises ? 'Eu lembro que vocês vieram na cheia. Eu lembro.' : 'Eu lembro que ninguém veio na cheia. Mas hoje vieram. Isso eu aceito.' },
      { s: 'LETÍCIA', t: 'Aqui o chão some. Eu queria um chão que não sumisse, e pontes que levem a lugar nenhum de molhar.' }, ask()]);
  },
  talkVintem: function () {
    var sc = this;
    if (E.flags.marco7) { this.say([{ s: 'VINTÉM', t: 'Eu nunca tinha pensado em "cuidar junto".' }]); return; }
    function stage() {
      if (E.flags.edCuidar) return [];
      if (E.flags.edE1 && E.flags.edE2 && !E.flags.edDist) return [{ s: 'ARBOVIA', t: 'Os recursos ainda não bastam para todas as obras: a Roda precisa escolher.' }, { ask: [
        { k: 'E', t: 'Cada território propõe duas obras; a Roda escolhe por prioridade (Matriz) e por ligação (Corredor).', fx: function () { chg('Entendimento', 2); E.flags.edDist = true; },
          then: function () { return [{ s: 'RAQUEL', t: '(por rádio) É assim que se liga a mata.' }, { s: 'LETÍCIA', t: 'A Baixada fica com a primeira.' }, { s: 'ARBOVIA', t: 'O grupo concordou.' }, { s: 'VINTÉM', t: 'Não é que eu goste de dizer não. É que o dinheiro nunca é suficiente.' }].concat(stage()); } }] }];
      if (E.flags.edDist) return [{ ask: [{ k: 'E', t: 'Se o recurso for em rede, a falta de um é cobrada pelos outros. A gente passa a cuidar do dinheiro juntos.', fx: function () { chg('Rede', 2); chg('Entendimento', 2); E.flags.edCuidar = true; },
        then: [{ s: 'VINTÉM', t: '(pausa) Eu nunca tinha pensado em "cuidar junto".' }, { s: 'NAIR', t: 'Eu cuido.' },
          { fn: function () { E.flags.marco7 = true; E.gotas = Math.max(E.gotas, 9); note('EDITAL (COMPLETO)', 'Mostrar o bom uso em vez de preencher páginas; mutirão conta como contrapartida.', 'Língua aprendida: Edital (completa)'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
          { s: 'ARBOVIA', t: 'Vintém ficou aliado parcial. Vila Mutirão ganha horta, posto reformado, escola de portão aberto e praça. A porta leva ao mapa.' }] }] }];
      return [ask()];
    }
    function ask() { var o = [];
      if (!E.flags.edQ) o.push({ k: '?', t: 'Qual é o objetivo do edital?', fx: function () { chg('Saberes', 1); E.flags.edQ = true; }, then: function () { return [{ s: 'VINTÉM', t: 'Garantir que o recurso seja bem usado.' }].concat(stage()); } });
      if (!E.flags.edE1) o.push({ k: 'E', t: 'Se o objetivo é garantir bom uso, a gente mostra o bom uso: o Plano, o Livro de Leis, a ata. Em vez de dezoito páginas, três e a Roda assinada.', fx: function () { chg('Entendimento', 1); E.flags.edE1 = true; },
        then: function () { return [{ s: 'VINTÉM', t: 'Hmm. Isso... eu poderia aceitar como "documento equivalente".' }, { s: 'ARBOVIA', t: 'Os Prazos se aliviaram.' }].concat(stage()); } });
      if (!E.flags.edE2) o.push({ k: 'E', t: 'A contrapartida pode ser em trabalho e materiais: mutirão conta como vinte por cento.', fx: function () { chg('Entendimento', 1); E.flags.edE2 = true; },
        then: function () { return [{ s: 'NAIR', t: '(rápida) Há uma previsão para contrapartida em bens e serviços economicamente mensuráveis. Eu preparo a conta.' }].concat(stage()); } });
      o.push({ k: 'P', t: 'Burocracia é isso, a gente se vira.', fx: function () { chg('Meios', -1); }, then: function () { return [{ s: 'ARBOVIA', t: 'O formulário cresceu e o prato da balança caiu.' }].concat(stage()); } });
      o.push({ k: 'C', t: '(aceita um intermediário que "cuida da papelada" por parte do recurso)', fx: function () { chg('Entendimento', -1); }, then: function () { return [{ s: 'NAIR', t: '(baixinho) Isso tem nome. Não faça.' }, { s: 'ARBOVIA', t: 'Dívida criada. Intermediário não é tradução.' }].concat(stage()); } });
      return { ask: o }; }
    var st = stage(); this.say(st.length && !E.flags.edQ && !E.flags.edE1 && !E.flags.edE2 ? [{ s: 'VINTÉM', t: 'O que os senhores querem saber do edital?' }, ask()] : st.length ? st : [ask()]);
  },
  /* ---- Marco 6: A Sala ---- */
  talkTereza: function () {
    if (E.flags.ritmoOk) { this.say([{ s: 'TEREZA', t: 'Vai, que tua vila precisa de ti, cumpadre. A água já subiu lá.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: '(lê o ritmo) Aqui o tempo se conta pela água, e não pelo relógio.', fx: function () { chg('Entendimento', 1); E.flags.ritmoOk = true; }, then: [{ s: 'TEREZA', t: 'Isso mesmo, ixi. Agora fala com o Alcides, lá adiante.' }] },
      { k: 'P', t: '(força passagem) Vamos logo, o tempo é curto.', fx: function () { chg('Ânimo', -1); }, then: function () { return [{ s: 'ARBOVIA', t: 'A cheia subiu. Quem força passagem, a água leva.' }, ask()]; } }] }; }
    this.say([{ s: 'TEREZA', t: 'A água sobe, a água desce. A gente aprendeu a subir e a descer com ela.' }, { s: 'ALCIDES', t: '(de longe) Se tentar travar o rio, o rio leva tudo. Se aprender com ele, ele deixa um pouco.' }, ask()]);
  },
  talkAlcides: function () {
    if (E.flags.cheiaOk) { this.say([{ s: 'ALCIDES', t: 'Tem uma barragem sendo feita rio acima, cumpadre. Quando fechar, a planície toda seca.' }]); return; }
    if (!E.flags.ritmoOk) { this.say([{ s: 'ALCIDES', t: 'Ô de casa! Primeiro conversa com a Mestra Tereza. Ela ensina o tempo da água.' }]); return; }
    this.say([{ s: 'TEREZA', t: '(a distância) A gente aqui divide o que é de todos. Os campos de pasto na seca, os peixes na cheia. Quando um só quer tudo, todos perdem.' },
      { s: 'ALCIDES', t: 'Barragem é o tipo de coisa que faz um só ganhar e muitos perderem. Tem uma sendo feita rio acima. Quando fechar, a planície toda seca.' },
      { fn: function () { E.flags.cheiaOk = true; E.gotas = Math.max(E.gotas, 8); chg('Saberes', 2); note('SABER DA CHEIA', 'O tempo se conta pela água. Quem trava o rio perde tudo.', 'Saber da Cheia (Pantanal)'); E.ui.hud(); } },
      { s: 'ARBOVIA', t: 'O Cantil ganhou a Gota da Cheia, verde-azulada. Tereza avisa: vai, que a tua vila precisa de ti.' }]);
  },
  talkVila: function (k) {
    var sc = this, D = { zeni: { f: 'vilaC', s: 'ZENI', t: 'Zeni, vamos tirar a água parada da vila inteira.', r: 'É pra já, meu bem! Caixa-d\'água tampada, balde emborcado!', n: 'Vila prevenida: a Febre vai diminuir.' },
      marta: { f: 'vilaA', s: 'DUDA', t: 'Dona Cota, fica comigo. Duda, o que a senhora precisa?', r: 'Água limpa, compressa, e que alguém passe a noite aqui.', n: 'Dona Cota estabilizou.' },
      leo: { f: 'vilaB', s: 'LÉO', t: 'Léo, qual é a rota mais rápida pra Baixada?', r: 'A que eu desenhei no Mapa: pela ponte do campinho, uai.', n: 'Resgate da Baixada em andamento.' } }[k];
    if (E.flags[D.f]) { this.say([{ s: D.s, t: 'Tá feito, ' + (k === 'leo' ? 'uai' : 'meu bem') + '. O resto é com a Roda.' }]); return; }
    var acts = ['vilaA', 'vilaB', 'vilaC'].filter(function (f) { return E.flags[f]; }).length;
    if (acts >= 2) { this.say([{ s: D.s, t: 'Você já fez o que dava sozinho. O resto, só a Roda resolve.' }]); return; }
    if (k !== 'marta' && !this.ecoArr.every(function (e) { return e.state !== 'big'; })) { this.say([{ s: D.s, t: 'A Febre-Mosca tá no caminho! Verte as moscas primeiro.' }]); return; }
    this.say([{ s: D.s, t: k === 'marta' ? 'Cota tá com febre alta, é a febre das águas paradas!' : k === 'leo' ? 'A Baixada alagou, tem gente no telhado!' : 'As caixas-d\'água viraram criadouro!' }, { ask: [
      { k: 'E', t: D.t, fx: function () { chg('Rede', 1); chg('Entendimento', 1); E.flags[D.f] = true; if (k === 'leo') chg('Visibilidade', 1); },
        then: [{ s: D.s, t: D.r }, { s: 'ARBOVIA', t: D.n }, { fn: function () { var a = ['vilaA', 'vilaB', 'vilaC'].filter(function (f) { return E.flags[f]; }).length; if (a >= 2 && !E.flags.vilaOk) { E.flags.vilaOk = true; E.ui.run([{ s: 'ARBOVIA', t: 'Duas ações feitas. Sozinho você não faz mais. Só a Roda resolve o resto: vamos ao Centro Comunitário.' }]); } } }] },
      { k: '?', t: 'Qual é a situação aqui?', fx: function () { chg('Saberes', 1); }, then: [{ s: D.s, t: 'Três crises e uma só pessoa pra resolver, uai. Escolhe com cuidado.' }] }] }]);
  },
  talkCrise: function (k) {
    var sc = this, D = { marta: { f: 'crM', s: 'DUDA', t: 'Quando você diz "seis casos", a Rosinha ouve "só seis". Diga: "seis casos em dois dias, e o dobro amanhã".', r: 'Seis em dois dias, dobrando a cada dois dias.' },
      valdete: { f: 'crV', s: 'LETÍCIA', t: 'Quarenta pessoas sem abrigo na chuva é urgência mais alta, porque sem abrigo vira doença.', r: '(seca, direta) É assim.' },
      mari: { f: 'crMa', s: 'FERNANDA', t: 'A Eleição é daqui a três dias, mas o que está em jogo é o que vai ou não ser registrado antes dela. É capacidade nossa, não só dela.', r: 'A gente pode registrar a Rampa e o Posto em ofício agora, com assinatura do Regente atual. Eu levo.' } }[k];
    if (E.flags[D.f]) { this.say([{ s: D.s, t: 'Já traduzido. Bora registrar na mesa.' }]); return; }
    function ask() { return { ask: [
      { k: 'E', t: D.t, fx: function () { chg('Entendimento', 1); E.flags[D.f] = true; }, then: [{ s: D.s, t: D.r }, { s: 'ARBOVIA', t: k === 'mari' ? 'A Demanda 3 virou capacidade da Roda.' : 'Rosinha entendeu a urgência.' }] },
      { k: 'P', t: 'Decidimos a Febre, e o resto espera.', fx: function () { chg('Rede', -1); }, then: function () { return [{ s: 'LETÍCIA', t: 'A Baixada não espera.' }, ask()]; } }] }; }
    this.say([{ s: D.s, t: k === 'marta' ? 'Seis casos novos, nenhum sério.' : k === 'valdete' ? 'Quarenta desabrigados. Falta abrigo e comida.' : 'Em três dias muda o Regente.' }, ask()]);
  },
  talkMesaCrise: function () {
    var sc = this;
    if (E.flags.rodaCrises) { this.say([{ s: 'ROSINHA', t: 'Ata no mural. Se alguém quiser mudar, venha com razão.' }]); return; }
    if (!(E.flags.crM && E.flags.crV && E.flags.crMa)) { this.say([{ s: 'ARBOVIA', t: 'Antes de registrar, traduza a urgência das três demandas: Duda, Letícia e Fernanda.' }]); return; }
    this.say([{ s: 'ROSINHA', t: 'Ordem de prioridade? Cada um vota.' }, { s: 'DUDA', t: 'Febre primeiro: dobra em dois dias.' }, { s: 'LETÍCIA', t: 'Baixada junto. Sem abrigo, vira doença.' }, { s: 'FERNANDA', t: 'Eu faço a terceira: levo o ofício a Mandorra.' }, { s: 'ZENI', t: 'Do Regente é agora. Depois, só em ano, sô.' },
      { s: 'ARBOVIA', t: 'Você não vota: vê o resultado e registra no Livro de Leis. O grupo decide.' },
      { s: 'ROSINHA', t: '(fechando o Livro) Plano B: a Rede de Mutirão leva comida e lonas aos desabrigados; o Regente é avisado por ofício. Registrado. Ata, para todo mundo ver, no mural.' },
      { fn: function () { chg('Rede', 2); chg('Entendimento', 2); note('LIVRO DE LEIS', 'Quem decide registra: a Roda decide e fica escrito.', 'Decisão vinculante da Roda'); } },
      { s: 'ARBOVIA', t: 'O Livro de Leis está vivo! Três Luas passam no relógio...' },
      { s: 'FERNANDA', t: '(cabisbaixa) Enviei o ofício a Mandorra. Ninguém respondeu.' }, { s: 'CINTHYA', t: '(pelo rádio) É regra do método: se ninguém responde em setenta e duas horas, registra-se a ausência de resposta.' },
      { ask: [{ k: 'E', t: '(registra no Caderno) Registro: alerta enviado às ___ horas; sem resposta em 72h.', fx: function () { chg('Entendimento', 1); E.flags.rodaCrises = true; note('AUSÊNCIA', 'Alerta enviado; sem resposta em 72h. Registrar a ausência também é dado.', 'Língua aprendida: Edital (e Ausência)'); },
        then: [{ s: 'ARBOVIA', t: '(baixinho, assustada) A página ficou em branco, com borda cinza. Uma neblina entra pela janela. Tem uma voz.' }] }] }]);
  },
  talkIolanda: function () {
    if (E.flags.nevoaOk) { this.say([{ s: 'IOLANDA', t: 'Volta acompanhado.' }]); return; }
    this.say([{ s: 'IOLANDA', t: '(longe, voz cansada) Já tentei. Fui a última. Eu quis ser a ponte inteira.' }, { s: 'ARBOVIA', t: 'A neblina se fecha. No chão, um papel em branco com o seu nome.' }, { ask: [
      { k: '?', t: 'Quem é você?', fx: function () { chg('Saberes', 1); E.flags.nevoaOk = true; note('PAPEL EM BRANCO', 'Com o nome de ' + (E.nick || E.nome) + '. Convite da Iolanda.', 'Convite para o Marco 9'); }, then: [{ s: 'IOLANDA', t: 'A que ficou. Você vai entender quando voltar acompanhado.' }] },
      { k: 'E', t: 'Você não precisa ser a ponte inteira. A gente atravessa junto.', fx: function () { chg('Rede', 1); E.flags.nevoaOk = true; note('PAPEL EM BRANCO', 'Com o nome de ' + (E.nick || E.nome) + '. Convite da Iolanda.', 'Convite para o Marco 9'); }, then: [{ s: 'IOLANDA', t: '...Quem dera. Você vai entender quando voltar acompanhado.' }] }] }]);
  },
  talkFila: function (k) {
    var sc = this;
    if (k === 'mari') {
      if (E.flags.marco6) { this.say([{ s: 'FERNANDA', t: 'Protocolo 14.382. A resposta vem em sete dias.' }]); return; }
      this.say([{ s: 'FERNANDA', t: '(no último balcão) Registrado. Protocolo 14.382. A Coordenação responderá em até sete dias.' }, { s: 'ROSINHA', t: '(do outro lado) Sete dias é mais do que setenta e duas horas.' }, { s: 'FERNANDA', t: 'Mas é uma resposta. Mais do que a Névoa.' },
        { s: 'ARBOVIA', t: 'O Carimbo ficou no papel e o relógio parou. A Roda venceu o relógio, mas não a espera.' },
        { fn: function () { E.flags.marco6 = true; chg('Entendimento', 3); chg('Rede', 2); note('VOZ DA RODA', 'A decisão da Roda é vinculante e fica no Livro de Leis.', 'Pressão Coordenada (primeira)'); E.ui.hud(); if (window.Snd) Snd.jingle('vitoria'); } },
        { s: 'ARBOVIA', t: 'Língua aprendida: Edital. Você desbloqueou a Voz da Roda e a primeira Pressão Coordenada. A porta leva ao mapa.' }]); return; }
    var r = sc.fila[k === 'zeni' ? 0 : 1];
    if (r.done) { this.say([{ s: k === 'zeni' ? 'ZENI' : 'ED', t: 'Já abri a minha porta. Corre!' }]); return; }
    this.say([{ s: k === 'zeni' ? 'ZENI' : 'ED', t: k === 'zeni' ? 'Tenho primo na portaria, uai! Deixa comigo.' : 'Vou ao ar agora, com fonte e hora. A fila se abre!' },
      { fn: function () { sc.barrierDone(r); E.flags['fila' + r.i] = true; snd('stamp'); chg('Rede', 1); } }, { s: 'ARBOVIA', t: 'Uma porta se abriu na fila.' }]);
  },
  items: function () {
    var sc = this, a = [], N = this.npcs, lvl = this.lvl, req;
    if (GEN[lvl]) {
      GEN[lvl].npcs.forEach(function (n) { a.push({ x: N[n[0]].x, lbl: 'Falar com ' + n[3], fn: function () { sc.talkGen(); } }); }); req = E.flags[GEN[lvl].flag];
    } else if (lvl === 2) {
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.say([{ s: 'ZENI', t: 'Chega perto dos ecos e usa o Q, meu bem. Eles só querem ser ouvidos.' }]); } });
      a.push({ x: N.leo.x, lbl: 'Falar com Léo', fn: function () { sc.say([{ s: 'LÉO', t: 'Se der pra desenhar uma rampa pro Salão, eu desenho. Mas primeiro, escuta.' }]); } });
      if (N.rosa.visible) a.push({ x: N.rosa.x, lbl: 'Falar com Rosinha', fn: function () { sc.talkRosaSalao(); } });
      req = E.flags.salao;
    } else if (lvl === 3) {
      a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.talkMari(); } });
      a.push({ x: N.tomas.x, lbl: 'Falar com Tomás', fn: function () { sc.talkTomas(); } });
      req = E.flags.conv_m && E.flags.conv_i;
    } else if (lvl === 5) {
      a.push({ x: N.cota.x, lbl: 'Falar com Dona Cota', fn: function () { sc.talkCota(); } }); req = E.flags.varanda;
    } else if (lvl === 6) {
      a.push({ x: N.leo.x, lbl: 'Falar com Léo', fn: function () { sc.say([{ s: 'LÉO', t: 'Anda devagar, uai. Nos postes ANOTAR, [E] registra. Só o lugar, a hora e o que viu.' }]); } });
      this.regs.forEach(function (r) { a.push({ x: r.x, lbl: E.flags['reg' + r.i] ? 'Ponto registrado' : 'Anotar o ponto', fn: function () { sc.talkReg(r); } }); }); req = E.flags.rota;
    } else if (lvl === 7) {
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.say([{ s: 'ZENI', t: 'Tanta pergunta e ninguém explica, uai. Fala com o Wagner, meu bem.' }]); } });
      a.push({ x: N.gilvan.x, lbl: 'Falar com Wagner', fn: function () { sc.talkGilvan(); } }); req = E.flags.formulario;
    } else if (lvl === 8) {
      this.mbar.forEach(function (r) { a.push({ x: r.x, lbl: r.done ? 'Ponto marcado' : 'Marcar no mapa', fn: function () { sc.talkBarrier(r); } }); });
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.talkZeniMapa(); } }); req = E.flags.mapaLeo;
    } else if (lvl === 9) {
      this.relatos.forEach(function (r) { a.push({ x: r.x, lbl: 'Escutar a voz', fn: function () { sc.talkRelato(r); } }); });
      a.push({ x: 2350, lbl: 'A pedra marcada', fn: function () { sc.talkPedra(); } }); req = E.flags.nascente;
    } else if (lvl === 10) {
      a.push({ x: N.aristides.x, lbl: 'Falar com Aristides', fn: function () { sc.talkAristides(); } }); req = E.flags.croqui;
    } else if (lvl === 11) {
      a.push({ x: N.nivelino.x, lbl: 'Falar com Nivelino', fn: function () { sc.talkNivelino(); } });
      a.push({ x: N.lucia.x, lbl: 'Falar com Lúcia', fn: function () { sc.talkLucia(); } }); req = E.flags.marco3;
    } else if (lvl === 12) {
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.say([{ s: 'ZENI', t: 'Esse povo do rádio fala e ninguém confere, sô. Chega perto dos ecos e usa o Q.' }]); } });
      a.push({ x: N.davi.x, lbl: 'Falar com Ed', fn: function () { sc.talkDavi(); } });
      a.push({ x: N.marta.x, lbl: 'Falar com Duda', fn: function () { sc.say([{ s: 'DUDA', t: 'O posto só mudou de horário. Eu tenho o ofício aqui, uai.' }]); } }); req = E.flags.rumorOk;
    } else if (lvl === 13) {
      a.push({ x: N.neide.x, lbl: 'Falar com Dona Neide', fn: function () { sc.talkNeide(); } }); req = E.flags.feira;
    } else if (lvl === 14) {
      a.push({ x: N.tiao.x, lbl: 'Falar com Tião', fn: function () { sc.talkTiao(); } });
      a.push({ x: N.cacilda.x, lbl: 'Falar com Cacilda', fn: function () { sc.say([{ s: 'CACILDA', t: 'Pula as tábuas e escuta o rio, mana. Os redemoinhos só querem ser entendidos.' }]); } });
      a.push({ x: N.sebastiao.x, lbl: 'Ouvir a Rádio-Barco', fn: function () { sc.talkSebastiao(); } });
      req = E.flags.tiaoOk && this.ecoArr.every(function (e) { return e.state !== 'big'; });
    } else if (lvl === 15) {
      a.push({ x: N.sebastiao.x, lbl: 'Falar com Sebastião', fn: function () { sc.talkSebastiao(); } });
      a.push({ x: N.joana.x, lbl: 'Falar com Raiza', fn: function () { sc.talkJoana(); } }); req = E.flags.igarapeOk;
    } else if (lvl === 16) {
      ['marta', 'joana', 'cacilda', 'davi'].forEach(function (k) { a.push({ x: N[k].x, lbl: 'Falar com ' + N[k].nome, fn: function () { sc.talkAliado(k); } }); });
      if (N.fabio.visible) a.push({ x: N.fabio.x, lbl: 'Falar com Fábio', fn: function () { sc.say([{ s: 'FÁBIO', t: 'Vou ao ar. Quem tem fonte, tem voz.' }]); } }); req = E.flags.marco4;
    } else if (lvl === 17) {
      a.push({ x: N.chiquinha.x, lbl: 'Falar com Chiquinha', fn: function () { sc.talkChiquinha(); } }); a.push({ x: N.valdemar.x, lbl: 'Falar com Seu Valdemar', fn: function () { sc.talkValdemar(); } }); req = E.flags.valdemarOk;
    } else if (lvl === 18) {
      a.push({ x: N.tomas.x, lbl: 'Falar com Tomás', fn: function () { sc.say([{ s: 'TOMÁS', t: 'Sobe três, desce dois, sobe três. Acompanha o movimento que o resto é pulo.' }]); } });
      a.push({ x: N.irac.x, lbl: 'Falar com Cinthya', fn: function () { sc.talkChapada(); } }); a.push({ x: N.dete.x, lbl: 'Falar com Alba', fn: function () { sc.talkChapada(); } }); req = E.flags.chapadaOk;
    } else if (lvl === 19) {
      a.push({ x: N.irac.x, lbl: 'Falar com Cinthya', fn: function () { sc.talkCuidadoDado(); } }); a.push({ x: N.dete.x, lbl: 'Falar com Alba', fn: function () { sc.talkCuidadoDado(); } });
      a.push({ x: N.tomas.x, lbl: 'Falar com Tomás', fn: function () { sc.say([{ s: 'TOMÁS', t: E.flags.cuidadoDado ? 'Cinco lentes no Caderno: convergência, antecipação, invisibilidade, ponto cego e silêncio.' : 'Fala com as duas, uma de cada lado. Ninguém ouve ninguém.' }]); } }); req = E.flags.cuidadoDado;
    } else if (lvl === 20) {
      a.push({ x: N.prata.x, lbl: 'Falar com Sr. Prata', fn: function () { sc.talkPrata(); } });
      a.push({ x: N.irac.x, lbl: 'Falar com Cinthya', fn: function () { sc.say([{ s: 'CINTHYA', t: 'Pergunte de onde vem o número, e quem sumiu da conta.' }]); } }); req = E.flags.marco5;
    } else if (lvl === 21) {
      a.push({ x: N.tereza.x, lbl: 'Falar com Mestra Tereza', fn: function () { sc.talkTereza(); } }); a.push({ x: N.alcides.x, lbl: 'Falar com Seu Alcides', fn: function () { sc.talkAlcides(); } }); req = E.flags.cheiaOk;
    } else if (lvl === 22) {
      ['zeni', 'marta', 'leo'].forEach(function (k) { a.push({ x: N[k].x, lbl: 'Ajudar: ' + N[k].nome, fn: function () { sc.talkVila(k); } }); }); req = E.flags.vilaOk;
    } else if (lvl === 23) {
      a.push({ x: N.rosa.x, lbl: 'Falar com Rosinha', fn: function () { sc.say([{ s: 'ROSINHA', t: 'Quando tiver as três urgências, registra na mesa.' }]); } });
      a.push({ x: N.marta.x, lbl: 'Falar com Duda', fn: function () { sc.talkCrise('marta'); } }); a.push({ x: N.valdete.x, lbl: 'Falar com Letícia', fn: function () { sc.talkCrise('valdete'); } }); a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.talkCrise('mari'); } });
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.say([{ s: 'ZENI', t: E.flags.zeniPerg ? 'A do Regente. Depois, só em ano.' : '(esperando a pergunta)' }, { ask: [{ k: '?', t: 'Qual delas só pode ser feita agora?', fx: function () { chg('Saberes', 1); E.flags.zeniPerg = true; }, then: [{ s: 'ZENI', t: 'A do Regente. Depois, só em ano.' }] }] }]); } });
      a.push({ x: 1100, lbl: 'A mesa da Roda (registrar)', fn: function () { sc.talkMesaCrise(); } }); req = E.flags.rodaCrises;
    } else if (lvl === 24) {
      a.push({ x: N.iolanda.x, lbl: 'Chamar a figura de capa', fn: function () { sc.talkIolanda(); } }); req = E.flags.nevoaOk;
    } else if (lvl === 25) {
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.talkFila('zeni'); } }); a.push({ x: N.davi.x, lbl: 'Falar com Ed', fn: function () { sc.talkFila('davi'); } }); a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.talkFila('mari'); } }); req = E.flags.marco6;
    } else if (lvl === 26) {
      a.push({ x: N.teodoro.x, lbl: 'Falar com Seu Teodoro', fn: function () { sc.talkTeodoro(); } });
      this.gaps.forEach(function (r) { a.push({ x: r.x0 - 40, lbl: r.done ? 'Ponte pronta' : r.lbl, fn: function () { sc.talkGap(r); } }); });
      a.push({ x: N.bruna.x, lbl: 'Falar com Raquel', fn: function () { sc.talkBruna(); } }); req = E.flags.corredorOk;
    } else if (lvl === 27) {
      ['cota', 'zeni', 'marta', 'rosa', 'davi', 'aristides', 'leo', 'valdete'].forEach(function (k) { a.push({ x: N[k].x, lbl: 'Ouvir o sonho de ' + N[k].nome, fn: function () { sc.talkSonho(k); } }); });
      a.push({ x: 1960, lbl: 'A mesa do Plano (Modo Obra)', fn: function () { sc.talkObra(); } }); req = E.flags.sonhosOk;
    } else if (lvl === 28) {
      a.push({ x: N.valdete.x, lbl: 'Falar com Letícia', fn: function () { sc.talkValdete(); } });
      this.gaps.forEach(function (r) { a.push({ x: r.x0 - 40, lbl: r.done ? 'Ponte pronta' : r.lbl, fn: function () { sc.talkGap(r); } }); }); req = E.flags.baixadaOk;
    } else if (lvl === 29) {
      a.push({ x: N.vintem.x, lbl: 'Falar com Seu Vintém', fn: function () { sc.talkVintem(); } });
      a.push({ x: N.nair.x, lbl: 'Falar com Nair', fn: function () { sc.say([{ s: 'NAIR', t: '(baixo) Dezoito páginas... eu mesma tô perdida. Mas existe previsão pra contrapartida em bens e serviços.' }]); } });
      a.push({ x: N.rosa.x, lbl: 'Falar com Rosinha', fn: function () { sc.say([{ s: 'ROSINHA', t: 'Vinte por cento de quê? Se a gente tivesse dinheiro, não precisava de edital.' }]); } }); req = E.flags.marco7;
    } else if (lvl === 30) {
      a.push({ x: N.nonato.x, lbl: 'Falar com Mestre Nonato', fn: function () { sc.talkNonato(); } }); a.push({ x: N.lia.x, lbl: 'Falar com Dona Lia', fn: function () { sc.say([{ s: 'LIA', t: 'Sem mangue, sem siri. Sem siri, sem prato, meu rei. A maré dá a hora.' }]); } }); req = E.flags.mareOk;
    } else if (lvl === 31) {
      a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.say([{ s: 'FERNANDA', t: 'Cada balcão é um Carimbo. Sobe até o Regente com o Plano na mão.' }]); } });
      a.push({ x: N.gilvan.x, lbl: 'Falar com Wagner', fn: function () { sc.say([{ s: 'WAGNER', t: '(baixo) O de vocês tá no terceiro andar. Eu mandei mais rápido.' }]); } });
      a.push({ x: N.honorio.x, lbl: 'Falar com o Regente', fn: function () { sc.talkHonorio(); } }); req = E.flags.honOk;
    } else if (lvl === 32) {
      a.push({ x: N.rosa.x, lbl: 'Falar com Rosinha', fn: function () { sc.say([{ s: 'ROSINHA', t: E.flags.rosaPath ? 'Siga com o Cassiano. Eu fico com a Roda.' : '(baixo) Fala com a Baronesa. Eu preciso ouvir isso.' }]); } });
      a.push({ x: N.eulalia.x, lbl: 'Falar com a Baronesa', fn: function () { sc.talkEulalia(); } }); a.push({ x: N.cassiano.x, lbl: 'Falar com Cassiano', fn: function () { sc.talkCassiano(); } }); req = E.flags.veluOk;
    } else if (lvl === 33) {
      a.push({ x: N.ismael.x, lbl: 'Falar com Chaveiro Ismael', fn: function () { sc.talkIsmael(); } }); a.push({ x: N.pedro.x, lbl: 'Falar com Pedro', fn: function () { sc.talkPedro(); } }); req = E.flags.ferrolhoOk;
    } else if (lvl === 34) {
      a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.talkMarilenePorta(); } });
      ['rosa', 'nonato', 'chiquinha', 'joana', 'tereza'].forEach(function (k) { a.push({ x: N[k].x, lbl: 'Chamar ' + N[k].nome, fn: function () { sc.talkPorta(k); } }); }); req = E.flags.marco8;
    } else if (lvl === 35) {
      a.push({ x: N.zeni.x, lbl: 'Falar com Zeni', fn: function () { sc.say([{ s: 'ZENI', t: 'Aqui é frio, meu bem. Mas com a lanterna na mão a gente enxerga o chão.' }]); } });
      a.push({ x: N.leo.x, lbl: 'Falar com Léo', fn: function () { sc.say([{ s: 'LÉO', t: 'Mapa sem nome, gavetas sem fim. Alguém precisa ler isso, uai.' }]); } });
      a.push({ x: N.iolanda.x, lbl: 'Falar com a figura de capa', fn: function () { sc.talkIolandaVolta(); } }); req = E.flags.voltaNevoa;
    } else if (lvl === 36) {
      this.torre.forEach(function (f) { a.push({ x: f.x, lbl: 'Traduzir: ' + f.k, fn: function () { sc.talkAndar(f); } }); });
      a.push({ x: N.aurelio.x, lbl: 'Falar com o Rei Cassiano', fn: function () { sc.talkCassiano(); } }); a.push({ x: N.iolanda.x, lbl: 'Falar com Iolanda', fn: function () { sc.say([{ s: 'IOLANDA', t: 'Cada andar é uma Língua. Eu errei ao querer falar todas sozinha.' }]); } });
      if (N.aristides.visible) a.push({ x: N.aristides.x, lbl: 'Falar com Aristides', fn: function () { sc.say([{ s: 'ARISTIDES', t: 'Dezoito metros abaixo do Salão. A água sempre esteve lá.' }]); } }); req = E.flags.torreOk;
    } else if (lvl === 37) {
      a.push({ x: 1200, lbl: E.flags.monologoOk ? 'O Olho-d\'Água' : 'Enfrentar o Monólogo', fn: function () { sc.talkMonologo(); } });
      a.push({ x: N.cota.x, lbl: 'Falar com Dona Cota', fn: function () { sc.say([{ s: 'COTA', t: 'Agora, meu bem. Quando a última voz for ouvida.' }]); } });
      a.push({ x: N.iolanda.x, lbl: 'Falar com Iolanda', fn: function () { sc.say([{ s: 'IOLANDA', t: 'É medo que a gente não se entenda. Traduza, não cale.' }]); } }); req = E.flags.monologoOk;
    } else if (lvl === 38) {
      a.push({ x: N.rosa.x, lbl: 'Ler o relatório do ciclo (Devolutiva)', fn: function () { sc.talkDevolutiva(); } });
      ['cota', 'marta', 'leo', 'valdete', 'davi', 'iolanda2'].forEach(function (k) { a.push({ x: N[k].x, lbl: 'Falar com ' + N[k].nome, fn: function () { sc.say([{ s: N[k].nome, t: E.flags.marco9 ? 'Outro ciclo começa. Cuidemos da Roda todo dia.' : 'Primeiro a Rosinha lê o relatório do ciclo.' }]); } }); }); req = E.flags.marco9;
    } else {
      a.push({ x: N.rosa.x, lbl: 'Falar com Rosinha', fn: function () { sc.stageTalk('rosa'); } });
      a.push({ x: N.mari.x, lbl: 'Falar com Fernanda', fn: function () { sc.stageTalk('mari'); } });
      a.push({ x: N.irac.x, lbl: 'Falar com a Dra. Cinthya', fn: function () { sc.stageTalk('irac'); } });
      a.push({ x: 1750, lbl: 'A mesa da Roda', fn: function () { sc.talkMesa(); } });
      req = E.flags.roda;
    }
    if (COMP[lvl] && N.comp) a.push({ x: N.comp.x, lbl: 'Falar com ' + COMPS[COMP[lvl]].nome, fn: function () { sc.talkComp(); } });
    a.push({ x: this.exitX, lbl: req ? 'Voltar ao mapa (+1 Lua)' : 'Voltar ao mapa', fn: function () { sc.exit(!!req); } });
    return a;
  }
});


/* ---------- Atividades, minijogos e saúde ---------- */
function hojeS() { return new Date().toISOString().slice(0, 10); }
function semanaS() { var d = new Date(), t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())), dd = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dd); var y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return t.getUTCFullYear() + '-W' + ('0' + Math.ceil(((t - y0) / 86400000 + 1) / 7)).slice(-2); }
function atvInfo(id) { E.atv = E.atv || {}; return (E.atv[id] = E.atv[id] || { n: 0, best: 0, dia: '' }); }
function mutHdr() { return { Authorization: 'Bearer ' + E.token, 'Content-Type': 'application/json' }; }
function mutPost(n) { if (!E.token) return Promise.resolve(null); return fetch(E.mundo ? 'api/mundo/mutirao' : 'api/mutirao', { method: 'POST', headers: mutHdr(), body: JSON.stringify({ pontos: n }) }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); }
function mutGet() { if (!E.token) return Promise.resolve(null); return fetch(E.mundo ? 'api/mundo/mutirao' : 'api/mutirao', { headers: mutHdr() }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); }
function mutLocal() { var w = semanaS(); if (!E.mut || E.mut.semana !== w) E.mut = { semana: w, feitos: 0, pts: 0, bonus: false }; return E.mut; }
function rocaGet() { if (!E.roca) E.roca = { p: [0, 0, 0, 0, 0, 0], t: [null, null, null, null, null, null], sem: { pequi: 0, mandioca: 0, milho: 0 }, regador: false, enxada: false, colhidas: 0, rec: {}, col: {} }; return E.roca; }
function rocaTick() { var R = rocaGet(), mudou = false; R.p = R.p.map(function (s) { if (s === 2) { mudou = true; return 3; } return s; }); if (mudou && E.ui) E.ui.toast('Algo amadureceu na Roça da Vila!'); }
function atvPremio(id, pct) {
  var I = atvInfo(id), msg = [], dia = hojeS(), M = mutLocal();
  I.n++; I.best = Math.max(I.best, Math.round(pct * 100));
  if (pct >= 0.6) {
    var pts = Math.max(1, Math.round(pct * 5)); M.feitos++; M.pts += pts; mutPost(pts);
    if (I.dia !== dia) { I.dia = dia; chg('Meios', 1); chg('Saberes', 1); msg.push('Presente do dia: Meios +1, Saberes +1.'); } else msg.push('O presente deste jogo hoje já foi pego.');
    if (!M.bonus && M.feitos >= 3) { M.bonus = true; chg('Rede', 1); msg.push('Desafio da semana: Rede +1!'); }
    msg.push('Mutirão: +' + pts + ' para a meta coletiva.');
  } else msg.push('Com 60% ou mais você ganha o presente do dia e soma no Mutirão.');
  E.persist(); return msg.join(' ');
}
var ESPECIES = [
  ['galinha', 'Galinha', 'Vila Mutirão', 'Galinha de terreiro: avisa quando algo está estranho no quintal.'], ['viralata', 'Vira-lata', 'Vila Mutirão', 'Cada vira-lata tem a sua história; quem cuida ganha um amigo.'],
  ['arara', 'Arara', 'Boca do Igarapé', 'Vive em casal por muitos anos e voa em bando.'], ['macaco', 'Macaco', 'Boca do Igarapé', 'Vive em grupo e avisa o bando com gritos.'],
  ['capivara', 'Capivara', 'Pouso das Garças', 'O maior roedor do mundo; adora água e anda em grupo.'], ['jacare', 'Jacaré', 'Pouso das Garças', 'Ajuda a manter o equilíbrio das águas do Pantanal.'],
  ['bode', 'Bode', 'Cacimba Grande', 'Aguenta bem a seca e sustenta muita família do sertão.'], ['tatu', 'Tatu', 'Cacimba Grande', 'Cava tocas que outros bichos aproveitam.'],
  ['mico', 'Mico', 'Jequitibá', 'Pequeno primata da mata; ajuda a espalhar sementes.'], ['tucano', 'Tucano', 'Jequitibá', 'O bico grande alcança frutos e ajuda a controlar o calor do corpo.'],
  ['siri', 'Siri', 'Enseada do Siri', 'Anda de lado e vive no mangue, berçário do mar.'], ['gaivota', 'Gaivota', 'Enseada do Siri', 'Acompanha os barcos e limpa a praia de restos.'],
  ['ema', 'Ema', 'Coxilha da Fronteira', 'Ave grande que não voa e corre rápido pelo campo.'], ['ovelha', 'Ovelha', 'Coxilha da Fronteira', 'A lã do Pampa aquece o inverno de muita gente.'],
  ['lobo', 'Lobo-guará', 'Planalto Frio', 'O maior canídeo da América do Sul; come frutos e pequenos bichos.'], ['gralha', 'Gralha-azul', 'Planalto Frio', 'Esquece pinhões enterrados e, sem querer, planta araucárias.'],
  ['cutia', 'Cutia', 'Babaçual', 'Enterra sementes e, ao esquecer algumas, planta a floresta.'], ['araraazul', 'Arara-azul', 'Babaçual', 'A maior arara do mundo; come coco de palmeiras.']
];
function diarioMarca(dom) { E.diario = E.diario || {}; (FAUNA[dom] || []).forEach(function (sp) { E.diario[sp] = true; }); }

var ATIV = {
  feira: { nome: 'Feira do Pequi', g: 0, tipo: 'feira', req: 'feira', mus: 'mapa', desc: 'Troque Meios por sementes e ferramentas. Barganhe no ritmo para pagar menos.' },
  roda: { nome: 'Roda de Conversa', g: 0, tipo: 'roda', req: 'roda', mus: 'roda', desc: 'Você é o facilitador: dê a vez a cada pessoa e veja quem ficou de fora.',
    intro: 'Hoje quem facilita a Roda é você. Cada rodada, escolha quem fala. Quem já falou volta a pedir a palavra: dê a vez a quem ainda não falou.', licao: 'Roda boa não é a que tem mais fala: é a que escuta todo mundo.',
    gente: [{ n: 'Seu Orlando', d: 1, f: 'Eu já falei, mas repito: o problema é a prefeitura!' }, { n: 'Dona Cota', f: 'Antigamente a gente se juntava mais. Falta convite.' }, { n: 'Léo', f: 'Tem lugar que eu nem consigo chegar. Rampa, cadê?' }, { n: 'Duda', t: 1, f: '(baixinho) Eu tenho medo de falar errado, mas tenho uma ideia.' }, { n: 'Zeni', f: 'Vamos de mutirão, uai, no sábado, com café.' }] },
  carto: { nome: 'Cartografia do Território', g: 0, tipo: 'carto', req: 'mapaLeo', mus: 'mapaleo', desc: 'Marque no mapa os pontos de risco e de cuidado. Sem dado pessoal.',
    intro: 'Mapa inventado da Vila Mutirão. Aperte 1 para marcar Risco e 2 para Cuidado em cada ponto, e depois [Enter].', marcas: ['Risco', 'Cuidado'], licao: 'Mapa-Corpo-Território: o corpo sente o lugar. Risco e cuidado aparecem juntos no mesmo mapa.',
    pontos: [{ x: 90, y: 90, t: 'Poça de água parada atrás da escola.', k: 0 }, { x: 250, y: 300, t: 'Posto de saúde com rampa e agentes que conhecem as famílias.', k: 1 }, { x: 430, y: 130, t: 'Esquina escura onde mulheres evitam passar à noite.', k: 0 }, { x: 560, y: 340, t: 'Horta comunitária: onde a vizinhança se encontra.', k: 1 }, { x: 150, y: 430, t: 'Calçada quebrada; cadeira de rodas não passa.', k: 0 }, { x: 640, y: 160, t: 'Cisterna coberta, com rodízio de limpeza.', k: 1 }, { x: 360, y: 440, t: 'Lixo acumulado no terreno baldio.', k: 0 }, { x: 700, y: 400, t: 'Praça com sombra e bancos para os mais velhos.', k: 1 }] },
  radio: { nome: 'Rádio Pé-de-Vereda', g: 0, tipo: 'quiz', req: 'rumorOk', mus: 'vila', desc: 'Monte o boletim do dia escolhendo as manchetes verdadeiras.', intro: 'No ar, a Rádio Pé-de-Vereda! Ajude o Ed a montar o boletim: fato verificado primeiro, grito nunca.',
    rounds: [
      { p: 'Boletim das 7h. Qual manchete vai ao ar?', o: ['"Posto fecha para sempre amanhã!"', '"Posto atende em horário normal; vacinação na quinta."', '"Todos devem sair de casa hoje, é ordem!"'], c: 1, f: 'A verdadeira cita o fato e o dia. Manchete que só assusta costuma não ter fonte.' },
      { p: 'Chegou um áudio: "ouvi dizer que a água da cacimba está contaminada". O que o Ed faz?', o: ['Repete o áudio, para avisar logo.', 'Liga para a UBS e para a associação, confirma e só avisa o que foi confirmado.', 'Diz que é mentira, sem checar.'], c: 1, f: 'Checar antes de repetir protege a vila do susto e do erro.' },
      { p: 'Qual texto cuida melhor da fonte?', o: ['"Dizem por aí que haverá obra."', '"Segundo o ofício de segunda, a obra começa dia 12; a Roda discute quinta."', '"Ninguém sabe de nada, mas fiquem atentos."'], c: 1, f: 'Quem disse, quando e onde confere: isso é fonte.' },
      { p: 'Ontem a rádio errou um horário. E agora?', o: ['Esconde e segue.', 'Corrige no ar, com respeito, e diz de onde veio o erro.', 'Culpa quem ouviu.'], c: 1, f: 'Corrigir com respeito vale mais que desmentir com raiva.' },
      { p: 'Qual título é Fato verificado, e não Manchetês?', o: ['"URGENTE: você não vai acreditar!"', '"Reunião sobre a água: quinta, 19h, no salão da Vila."', '"Escândalo na vila!"'], c: 1, f: 'Fato verificado diz o que, quando, onde e quem confirmou.' }] },
  oficina: { nome: 'Oficina de Vozes', g: 0, tipo: 'quiz', req: 'formulario', mus: 'fila', desc: 'Reescreva Ofícios e Formulários Gigantes em linguagem simples.', intro: 'Wagner trouxe os papéis. Escolha a versão que a vizinhança entende de primeira: Oficialês vira Relato.',
    rounds: [
      { p: 'Ofício: "Solicita-se a regularização cadastral do imóvel, mediante comprovação."', o: ['"Precisamos confirmar onde você mora. Traga um comprovante de endereço."', '"Regularize o cadastro do imóvel conforme normativa."', '"Fica a critério do interessado."'], c: 0, f: 'Frase curta, que diz o que fazer e o que levar.' },
      { p: 'Formulário Gigante: "Anexar certidão negativa de débitos, via original."', o: ['"Anexo K pendente."', '"Traga o papel que mostra que você não deve ao município."', '"Documentação inconforme."'], c: 1, f: 'Troque o nome técnico pelo que a pessoa precisa fazer.' },
      { p: 'Edital: "A contrapartida é de vinte por cento do valor global."', o: ['"A vila entra com 20% do valor. Perguntar se vale trabalho e material."', '"Contrapartida obrigatória, vide item 7.2."', '"Vinte por cento, ponto."'], c: 0, f: 'Explicar o número e abrir a pergunta ajuda a Roda a decidir.' },
      { p: 'Aviso: "O atendimento encontra-se suspenso por motivo de força maior."', o: ['"Suspenso."', '"O posto não abre hoje. Volte quinta, às 8h, ou procure a UPA do centro."', '"Força maior."'], c: 1, f: 'Quem lê precisa saber o que acontece e o que fazer agora.' }] },
  roca: { nome: 'Livro de Receitas e Roça', g: 0, tipo: 'roca', req: 'feira', mus: 'varanda', desc: 'Plante, regue e colha entre as fases. A Vila muda com a colheita.' },
  diario: { nome: 'Diário de Campo', g: 0, tipo: 'diario', mus: 'nascente', desc: 'Figurinhas de fauna de cada Reino. Entre nos Reinos para encontrá-las.' },
  mutirao: { nome: 'Mutirão da Semana', g: 0, tipo: 'mutirao', mus: 'roda', desc: 'Meta coletiva de todos os jogadores do Vigiante, sem dado pessoal.' },
  festa: { nome: 'Festa de Roda', g: 1, tipo: 'ritmo', mus: 'roda', desc: 'Siga o ritmo da festa com as setas.', lanes: ['Esq.', 'Cima', 'Dir.'], notas: 30, gap: 600, falas: ['Boa!', 'No ritmo!', 'Isso!'] },
  coco: { nome: 'Quebra-cocos', g: 1, tipo: 'ritmo', mus: 'sertao', desc: 'Bata o coco na hora certa com [Espaço].', lanes: ['Bater'], notas: 24, gap: 700, falas: ['Rachou!', 'Beleza!', 'Égua!'] },
  barganha: { nome: 'Barganha da Feira', g: 9, tipo: 'ritmo', mus: 'mapa', desc: 'Pechinche no ritmo.', lanes: ['Preço', 'Prosa', 'Troco'], notas: 20, gap: 650, falas: ['Pechincha!', 'Fechou!', 'Tá barato!'], after: true },
  pesca: { nome: 'Pesca de Maré', g: 1, tipo: 'pega', mus: 'costa', desc: 'Pegue os siris e desvie das pedras. Setas ← →.', bom: 'an_siri_0', ruim: 'bn_pedra', dur: 40, pr: 0.3, meta: 16 },
  tropeiro: { nome: 'Tropeiro do Pinhão', g: 1, tipo: 'pega', mus: 'rota', desc: 'Junte pinhões e desvie das pedras da estrada.', bom: 'bn_fruta', ruim: 'bn_pedra', dur: 40, pr: 0.35, meta: 16 },
  balsa: { nome: 'Balsa no Rio-Mundo', g: 1, tipo: 'pega', mus: 'rio', desc: 'Desvie dos troncos na correnteza; as gotas valem pontos.', bom: 'ic_gota', ruim: 'bn_pedra', dur: 40, pr: 0.65, meta: 12 },
  cipo: { nome: 'Cipó e Cachoeira', g: 1, tipo: 'pega', mus: 'mata', desc: 'Pegue as frutas que caem da cachoeira.', bom: 'bn_fruta', ruim: 'bn_pedra', dur: 40, pr: 0.4, meta: 14 },
  corrida: { nome: 'Corrida do Mapa', g: 1, tipo: 'pega', mus: 'mapaleo', desc: 'Junte os pontos de cuidado e fuja dos riscos.', bom: 'ic_mapa', ruim: 'bn_pedra', dur: 40, pr: 0.4, meta: 16 },
  memoria: { nome: 'Memória dos Bichos', g: 1, tipo: 'memoria', mus: 'nascente', desc: 'Ache os pares de bichos de Veredália.' },
  palavras: { nome: 'Caça-palavras da Água-Fala', g: 1, tipo: 'palavras', mus: 'igarape', desc: 'Ache as palavras da água. Clique na primeira e na última letra.' },
  pingpong: { nome: 'Ping-pong de Boatos', g: 1, tipo: 'quiz', mus: 'mapa_pronto', desc: 'Fato verificado ou boato? Responda rápido.', intro: 'Cada frase vem de um lado: confira se ela tem fonte, data e lugar.',
    rounds: [{ p: '"Vacina na quinta, no posto, segundo o cartaz da UBS."', o: ['Fato verificado', 'Boato'], c: 0, f: 'Tem fonte, dia e lugar.' }, { p: '"Disseram que a água acaba amanhã e ninguém sabe quem disse."', o: ['Fato verificado', 'Boato'], c: 1, f: 'Sem fonte, só "disseram".' }, { p: '"A prefeitura publicou: a obra começa dia 12."', o: ['Fato verificado', 'Boato'], c: 0, f: 'Tem autor e data para conferir.' }, { p: '"O primo do vizinho contou que o posto fecha para sempre."', o: ['Fato verificado', 'Boato'], c: 1, f: 'Fonte de terceira mão.' }, { p: '"A cisterna foi limpa ontem: foto e ata no mural."', o: ['Fato verificado', 'Boato'], c: 0, f: 'Prova que qualquer um confere.' }, { p: '"Compartilhe antes que apaguem!"', o: ['Fato verificado', 'Boato'], c: 1, f: 'Pressa para repassar é sinal de boato.' }] },
  s1: { nome: 'Água Parada', g: 2, tipo: 'quiz', mus: 'rota', desc: 'Onde o mosquito nasce e como acabar com isso.', intro: 'Duda chama você ao quintal: depois da chuva, a água ficou parada.',
    rounds: [{ p: 'Há um pneu no quintal com água da chuva.', o: ['Deixar, a chuva seca sozinha.', 'Guardar coberto ou virar para baixo.', 'Jogar perfume.'], c: 1, f: 'Água parada vira criadouro em poucos dias. Virar ou cobrir resolve.' }, { p: 'A caixa-d\'água está sem tampa.', o: ['Tampar bem e limpar de tempos em tempos.', 'Deixar aberta para pegar mais chuva.', 'Cobrir só um pedaço.'], c: 0, f: 'Caixa bem fechada não vira criadouro.' }, { p: 'Pratinho de vaso cheio de água.', o: ['Encher mais.', 'Pôr areia até a borda ou esvaziar toda semana.', 'Trocar o vaso de lugar.'], c: 1, f: 'Areia até a borda ou esvaziar toda semana evita ovos do mosquito.' }, { p: 'O vizinho viajou e o quintal ficou largado.', o: ['Ninguém, é problema dele.', 'Combinar na vila um mutirão de vistoria, com licença do vizinho.', 'Entrar sem avisar.'], c: 1, f: 'Cuidado coletivo, combinado e com licença.' }] },
  s2: { nome: 'Semana do Mosquito', g: 2, tipo: 'quiz', mus: 'rota', desc: 'Uma semana de tarefas para derrubar os focos.', intro: 'Sete dias para a vila inteira cuidar dos focos. Escolha a melhor tarefa de cada dia.',
    rounds: [{ p: 'Segunda. Qual tarefa tira mais criadouros?', o: ['Olhar calhas, ralos e garrafas.', 'Esperar só a prefeitura.', 'Fazer fumaça sozinho.'], c: 0, f: 'A vistoria semanal da casa derruba criadouros. A vila e o poder público fazem o resto juntos.' }, { p: 'Quarta. A rua tem lixo acumulado.', o: ['Queimar tudo.', 'Mutirão de coleta e aviso à prefeitura.', 'Jogar no terreno baldio.'], c: 1, f: 'Lixo acumulado junta água; queimar faz mal à saúde e ao ar.' }, { p: 'Sexta. A vizinha está com febre e dor no corpo.', o: ['Dar qualquer remédio que tiver.', 'Levar à UBS para avaliação.', 'Dizer que é gripe e pronto.'], c: 1, f: 'Febre com dor no corpo precisa de avaliação. Nada de automedicação.' }, { p: 'Domingo. O balanço da semana.', o: ['Anotar o que foi feito e dividir na Roda.', 'Guardar só para si.', 'Esquecer.'], c: 0, f: 'Contar de volta é a Devolutiva do bairro.' }] },
  s3: { nome: 'Febre sem Nome', g: 2, tipo: 'quiz', mus: 'nascente', desc: 'Febre, manchas e sinais de alerta. Quando procurar o serviço.', intro: 'Educativo: este jogo não substitui atendimento. Quem decide o que a pessoa tem é o serviço de saúde.',
    rounds: [{ p: 'Uma criança está com febre há dois dias e manchas na pele.', o: ['Esperar passar.', 'Levar à UBS ou UPA hoje.', 'Fazer chá e ver amanhã.'], c: 1, f: 'Febre com manchas pede avaliação rápida.' }, { p: 'O vizinho diz: "é dengue, toma aspirina".', o: ['Seguir o conselho.', 'Não dar aspirina nem anti-inflamatório sem orientação; procurar atendimento.', 'Dar o dobro.'], c: 1, f: 'Alguns remédios são perigosos em caso de dengue. Só com orientação de profissional.' }, { p: 'Quais sinais pedem pressa?', o: ['Dor forte na barriga, vômito que não para, sangramento.', 'Sono bom.', 'Fome.'], c: 0, f: 'Sinais de alerta pedem atendimento imediato.' }, { p: 'No ônibus alguém diz que "é tudo mentira dos postos".', o: ['Responder com a informação da UBS e convidar para a Roda.', 'Gritar.', 'Ficar em silêncio.'], c: 0, f: 'Conversa calma e fonte conhecida desfazem boato.' }] },
  s4: { nome: 'Fila da Vacina', g: 2, tipo: 'quiz', mus: 'fila', desc: 'Carteirinha, fila e cuidado com quem espera.', intro: 'Dia de vacinação no posto. A fila é longa, e tem muita gente de todo jeito.',
    rounds: [{ p: 'A carteirinha da mãe está velha e amassada.', o: ['Levar à UBS: eles conferem o que falta.', 'Jogar fora.', 'Pedir a um desconhecido.'], c: 0, f: 'A equipe da UBS confere o histórico e orienta.' }, { p: 'A fila é longa e há idosos esperando em pé.', o: ['Furar a fila.', 'Organizar senhas e cuidar de quem tem prioridade.', 'Desistir.'], c: 1, f: 'Organizar a fila é cuidar.' }, { p: 'As vacinas do calendário nacional são...', o: ['Pagas.', 'Gratuitas no SUS.', 'Só para adultos.'], c: 1, f: 'O calendário nacional de vacinação é gratuito no SUS.' }, { p: 'A criança chora de medo.', o: ['Acolher e explicar com calma o que vai acontecer.', 'Mentir que não vai sentir nada.', 'Gritar.'], c: 0, f: 'Explicar com carinho tira o medo.' }] },
  s5: { nome: 'Boato da Seringa', g: 2, tipo: 'quiz', mus: 'mapa_pronto', desc: 'Como enfrentar boatos sobre vacinas sem humilhar ninguém.', intro: 'Uma corrente de mensagens fala mal da vacina. Cléo quer ver audiência; Ed quer ver verdade.',
    rounds: [{ p: 'Corrente: "vacina faz mal, compartilhe!" Sem fonte.', o: ['Compartilhar por precaução.', 'Checar a fonte (UBS, Ministério da Saúde) antes.', 'Apagar sem ler.'], c: 1, f: 'Sem fonte, não repasse. Confira com quem é da saúde.' }, { p: 'Cléo mostra um print "de médico famoso".', o: ['Procurar o nome e a fonte e perguntar ao posto.', 'Acreditar pelo jaleco.', 'Mandar a todos.'], c: 0, f: 'Prestígio não é prova.' }, { p: 'Dona Cota tem medo de agulha.', o: ['Zombar.', 'Escutar o medo e explicar o que acontece na sala de vacina.', 'Dizer que não é nada.'], c: 1, f: 'Escutar vem antes de explicar.' }, { p: 'Como o Ed corrige no rádio?', o: ['Fato verificado, quem confirmou e onde procurar.', 'Só desmentir com raiva.', 'Silenciar.'], c: 0, f: 'Corrigir com respeito e deixar o caminho aberto.' }] },
  s6: { nome: 'Mesa do Pequi', g: 2, tipo: 'quiz', mus: 'varanda', desc: 'Comida de verdade, do prato à feira.', intro: 'Hora do almoço na Vila. A mesa está posta e a conversa também.',
    rounds: [{ p: 'Qual prato é mais completo?', o: ['Arroz, feijão, legumes e um pouco de pequi ou carne.', 'Só refrigerante e biscoito.', 'Só arroz.'], c: 0, f: 'Variedade e comida de verdade formam um prato completo.' }, { p: 'O pequi tem espinhos dentro do caroço.', o: ['Roer a polpa com cuidado, sem morder o caroço.', 'Morder o caroço inteiro.', 'Engolir o caroço.'], c: 0, f: 'Raspe a polpa com cuidado: os espinhos machucam.' }, { p: 'Merenda da roça: o que vale mais?', o: ['Fruta que dá no quintal.', 'Salgadinho de pacote.', 'Nada.'], c: 0, f: 'Fruta do quintal é barata, fresca e dá orgulho.' }, { p: 'Sobrou comida da festa.', o: ['Dividir com a vizinhança, bem guardada.', 'Jogar no mato.', 'Deixar no sol.'], c: 0, f: 'Dividir e guardar direito evita desperdício e doença.' }] },
  s7: { nome: 'Água que Cura', g: 2, tipo: 'quiz', mus: 'sertao', desc: 'Cisterna, filtro e mãos limpas.', intro: 'A cisterna da Cacimba é de todos. Quem cuida dela cuida da vila.',
    rounds: [{ p: 'A cisterna ficou aberta.', o: ['Tampar, limpar e usar o hipoclorito da UBS.', 'Beber assim mesmo.', 'Ferver só a roupa.'], c: 0, f: 'Limpeza e tratamento da água tornam a cisterna segura.' }, { p: 'A água veio barrenta.', o: ['Deixar assentar, filtrar e tratar antes de beber.', 'Beber, que é natural.', 'Dar aos bichos primeiro.'], c: 0, f: 'Água barrenta precisa ser filtrada e tratada.' }, { p: 'Lavar as mãos antes de comer.', o: ['Água e sabão por uns 20 segundos.', 'Passar na roupa.', 'Não precisa.'], c: 0, f: 'Água, sabão e uns 20 segundos protegem de muita doença.' }, { p: 'Quem cuida da cisterna?', o: ['A vila, num rodízio combinado na Roda.', 'Ninguém.', 'Uma pessoa só, sempre.'], c: 0, f: 'Rodízio combinado em Roda não cansa ninguém.' }] },
  s8: { nome: 'Posto Fechado', g: 2, tipo: 'quiz', mus: 'canteiro', desc: 'Quando o serviço falta: o que fazer e a quem levar.', intro: 'O posto está fechado há dias. A vila precisa agir sem perder a calma.',
    rounds: [{ p: 'O posto está fechado por falta de profissional.', o: ['Xingar no portão.', 'Registrar o problema e levar ao conselho de saúde e à ouvidoria (Disque Saúde 136).', 'Ficar em casa.'], c: 1, f: 'Registro com data e destino certo dá força ao pedido.' }, { p: 'Alguém passa mal agora.', o: ['Procurar a UPA mais próxima ou ligar 192 (SAMU).', 'Esperar o posto abrir semana que vem.', 'Fazer promessa.'], c: 0, f: 'Em urgência, UPA ou SAMU 192.' }, { p: 'Como juntar dados do problema?', o: ['Anotar o nome de cada doente.', 'Anotar datas e dias fechados e quantas pessoas ficaram sem atendimento, sem nomes.', 'Gravar escondido.'], c: 1, f: 'Dado sem dado pessoal protege quem reclama.' }, { p: 'Onde levar o pedido?', o: ['Só ao grupo de mensagens.', 'À reunião do conselho de saúde e ao ofício para a secretaria.', 'A lugar nenhum.'], c: 1, f: 'Pedido formal e coletivo abre caminho.' }] },
  s9: { nome: 'Calor', g: 2, tipo: 'quiz', mus: 'sertao', desc: 'Dias de calor forte: água, sombra e atenção a quem precisa.', intro: 'A onda de calor chegou à Cacimba. O ar parece parado.',
    rounds: [{ p: 'Dia de 40 graus.', o: ['Beber água ao longo do dia e evitar o sol do meio-dia.', 'Esperar ter sede.', 'Trabalhar no sol forte.'], c: 0, f: 'Beba antes de ter sede e fuja do sol forte.' }, { p: 'Idosos e crianças.', o: ['Dar atenção especial: água, sombra e roupa leve.', 'Deixar fechados no carro.', 'Nada.'], c: 0, f: 'Os mais velhos e os pequenos sentem mais o calor.' }, { p: 'Tontura, confusão e pele quente e seca.', o: ['Levar à sombra, dar água em goles e chamar atendimento.', 'Dar banho de gelo de uma vez.', 'Ignorar.'], c: 0, f: 'É sinal de alerta: sombra, água e atendimento.' }, { p: 'Como a vila se prepara?', o: ['Abrir um ponto de sombra e água na praça.', 'Fechar tudo.', 'Esperar chuva.'], c: 0, f: 'Um ponto de sombra e água na praça cuida de todos.' }] },
  s10: { nome: 'Cuidar de quem Cuida', g: 2, tipo: 'quiz', mus: 'varanda', desc: 'Cansaço e apoio entre quem cuida dos outros.', intro: 'Duda quase não dorme. Quem cuida da gente também precisa de cuidado.',
    rounds: [{ p: 'Duda está exausta.', o: ['Dizer que ela tem de aguentar.', 'Oferecer revezamento e descanso.', 'Ignorar.'], c: 1, f: 'Revezar é cuidar de quem cuida.' }, { p: 'Quem cuida também pode adoecer.', o: ['Esconder o cansaço.', 'Pedir ajuda e dividir tarefas.', 'Se culpar.'], c: 1, f: 'Pedir ajuda é força, não fraqueza.' }, { p: 'Um sinal de que alguém precisa de apoio:', o: ['Sono ruim, irritação e tristeza que não passam.', 'Fome.', 'Alegria.'], c: 0, f: 'Se durar, procure a UBS ou um serviço de saúde mental da região.' }, { p: 'Boa ideia para a vila:', o: ['Cobrar mais.', 'Roda de cuidado, com café e escuta.', 'Esperar acabar.'], c: 1, f: 'Escuta coletiva alivia.' }] },
  vigil: { nome: 'Modo Vigilância', g: 2, tipo: 'quiz', mus: 'mapa_pronto', desc: 'Cuidado ou vigilância? Use as Lentes sem espionar ninguém.', intro: 'O Leitor de Sinais ajuda a ver o território. A pergunta é: isso serve a quem foi observado?',
    rounds: [{ p: 'Contar quantas casas têm caixa-d\'água sem tampa na vila.', o: ['Cuidado: dado coletivo, sem nomes.', 'Vigilância: dá para multar cada um.'], c: 0, f: 'Dado agregado ajuda a vila a agir.' }, { p: 'Anotar o nome e o endereço de quem está doente para divulgar.', o: ['Cuidado.', 'Vigilância: expõe as pessoas.'], c: 1, f: 'Divulgar nomes de doentes expõe e afasta as pessoas do serviço.' }, { p: 'Mapa dos pontos de alagamento, sem identificar famílias.', o: ['Cuidado.', 'Vigilância.'], c: 0, f: 'O ponto no mapa serve para agir, não para apontar.' }, { p: 'Filmar escondido quem busca o posto.', o: ['Cuidado.', 'Vigilância: viola a privacidade.'], c: 1, f: 'Sem consentimento, é vigilância.' }, { p: 'Perguntar só o essencial, com licença, e dizer para quê.', o: ['Cuidado.', 'Vigilância.'], c: 0, f: 'Licença e finalidade clara fazem o registro ético.' }] },
  cacador: { nome: 'Caçador de Focos', g: 2, tipo: 'carto', mus: 'rota', desc: 'Ache os focos de água parada no quintal.', intro: 'Percorra o quintal. [1] marca Foco e [2] marca Sem foco, e depois [Enter].', marcas: ['Foco', 'Sem foco'], licao: 'Foco achado e resolvido a tempo é um caso de dengue a menos.',
    pontos: [{ x: 110, y: 90, t: 'Pneu com água de chuva.', k: 0 }, { x: 300, y: 330, t: 'Balde virado para baixo.', k: 1 }, { x: 480, y: 120, t: 'Vaso com pratinho cheio.', k: 0 }, { x: 610, y: 340, t: 'Caixa-d\'água bem tampada.', k: 1 }, { x: 170, y: 420, t: 'Calha entupida com folhas.', k: 0 }, { x: 400, y: 430, t: 'Garrafas guardadas de boca para baixo.', k: 1 }, { x: 660, y: 150, t: 'Tampa de lata com água.', k: 0 }, { x: 720, y: 400, t: 'Piscininha esvaziada e seca.', k: 1 }] },
  vacina: { nome: 'Vacina em Roda', g: 2, tipo: 'roda', mus: 'fila', desc: 'Dê a vez a quem tem prioridade na fila da vacina.', intro: 'Na fila da vacina, cada pessoa tem uma necessidade. Chame cada uma sem deixar ninguém de fora.', licao: 'Fila com cuidado atende primeiro quem mais precisa e não esquece ninguém.',
    gente: [{ n: 'Seu Teodoro', d: 1, f: 'Eu cheguei primeiro, devia ser o primeiro de novo!' }, { n: 'Dona Gertrudes (idosa)', f: 'Meu joelho não aguenta ficar em pé.' }, { n: 'Rosa (gestante)', f: 'Minha carteirinha está aqui, tô de oito meses.' }, { n: 'Pedro (com bebê)', t: 1, f: '(baixinho) Meu bebê está dormindo, não quero atrapalhar.' }, { n: 'Léo', f: 'Preciso da rampa lateral, a escada não dá.' }] },
  prato: { nome: 'Prato Feito', g: 2, tipo: 'pega', mus: 'varanda', desc: 'Pegue as frutas e desvie dos ultraprocessados (as pedras).', bom: 'bn_fruta', ruim: 'bn_pedra', dur: 40, pr: 0.35, meta: 16 },
  quizfeira: { nome: 'Quiz da Feira', g: 2, tipo: 'quiz', mus: 'mapa', desc: 'Perguntas de saúde e território na Feira do Pequi.', intro: 'Dona Neide abriu a banca de perguntas: acertou, ganhou fruta.',
    rounds: [{ p: 'Mosquito da dengue nasce onde?', o: ['Em água parada limpa.', 'Em terra seca.', 'No vento.'], c: 0, f: 'Em água parada, mesmo limpa.' }, { p: 'Onde a vacina é de graça?', o: ['No SUS.', 'Só em clínicas particulares.', 'Em lugar nenhum.'], c: 0, f: 'O SUS vacina de graça.' }, { p: 'Mapa-Corpo-Território liga o quê?', o: ['Corpo, lugar e vida da comunidade.', 'Só estradas.', 'Só dinheiro.'], c: 0, f: 'O corpo sente o lugar onde vive.' }, { p: 'Primeiro passo contra um boato:', o: ['Conferir a fonte.', 'Repassar.', 'Apagar.'], c: 0, f: 'Conferir a fonte vem antes de repassar.' }, { p: 'Para decidir em grupo, a base é:', o: ['Roda: todo mundo fala e todo mundo escuta.', 'Quem grita mais.', 'Quem chega primeiro.'], c: 0, f: 'A Roda dá a vez a todos.' }] }
};
var ATIV_ABAS = [['Atividades', ['feira', 'roda', 'carto', 'radio', 'oficina', 'roca', 'diario', 'mutirao']], ['Jogos', ['festa', 'coco', 'pesca', 'tropeiro', 'balsa', 'cipo', 'corrida', 'memoria', 'palavras', 'pingpong']], ['Saúde', ['s1', 's2', 's3', 's4', 's5', 's6', 's7', 's8', 's9', 's10', 'vigil', 'cacador', 'vacina', 'prato', 'quizfeira']]];
function ativTrava(id) { var r = ATIV[id].req; return r && !E.flags[r] ? 'Abre depois de uma fase da Vila' : ''; }
var PINS = [{ id: 'feira', x: 1780, y: 330, ic: 'barraca' }, { id: 'radio', x: 1780, y: 600, ic: 'antena' }, { id: 'oficina', x: 120, y: 520, ic: 'carta' }, { id: 'roda', x: 120, y: 760, ic: 'roda' }, { id: 'carto', x: 400, y: 1230, ic: 'mapa' }, { id: 'roca', x: 700, y: 1230, ic: 'arvore' }, { id: 'diario', x: 1550, y: 1260, ic: 'lupa' }, { id: 'mutirao', x: 1780, y: 1090, ic: 'estrela' }];

var Ativ = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Ativ() { Phaser.Scene.call(this, { key: 'Ativ' }); },
  init: function (d) { this.id = d.id; this.from = d.from || { scene: 'World' }; this.C = ATIV[this.id]; },
  create: function () {
    var sc = this, C = this.C;
    if (corrJogavel(C) && !E.flags.ativClassica) { this.corr = true; this.leaving = true; this.scene.start('Corrida', { id: this.id, from: this.from }); return; } // versão em movimento lateral (a clássica: tecla T)
    this.corr = false; E.curLvl = -3; music(C.mus || 'mapa'); this.ctl = new Ctl(this); this.done = false; this.el = 0; this.leaving = false;
    this.kk = this.input.keyboard.addKeys('UP,DOWN,LEFT,RIGHT,ENTER,SPACE,ESC,E,ONE,TWO,THREE,B,R,W,A,S,D,T');
    this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setDepth(-40);
    ['colinas1', 'colinas2'].forEach(function (h, i) { sc.add.image(0, 0, h).setOrigin(0, 0).setScale(4).setDepth(-30 + i); });
    this.add.rectangle(W / 2, H / 2, W, H, 0xf6ecd0, 0.3).setDepth(-20);
    this.add.text(W / 2, 90, C.nome, { fontFamily: FONT, fontSize: '34px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 6 }).setOrigin(0.5).setDepth(50);
    this.foot = this.add.text(W / 2, 700, '[Esc] sair', { fontFamily: FONT, fontSize: '16px', color: '#fff', backgroundColor: '#00000099', padding: { x: 6, y: 2 } }).setOrigin(0.5, 1).setDepth(50);
    this.msg = this.add.text(W / 2, 128, '', { fontFamily: FONT, fontSize: '18px', color: '#3b2a2a', backgroundColor: '#fff3c4', padding: { x: 8, y: 3 } }).setOrigin(0.5, 0).setDepth(50);
    this['b_' + C.tipo]();
  },
  J: function (k) { return !!(this.jd && this.jd[k]); },
  leave: function () { if (this.leaving) return; this.leaving = true; this.scene.start(this.from.scene, this.from.data); },
  finish: function (pct, extra) {
    if (this.done) return; this.done = true; var C = this.C, txt;
    if (C.after) { if (pct >= 0.7) { E.desc = 1; txt = 'Barganha feita! Desconto de 1 Meio na próxima compra.'; } else txt = 'Não rendeu desconto desta vez. Tente de novo.'; }
    else txt = atvPremio(this.id, pct);
    snd(pct >= 0.6 ? 'saber' : 'bad'); if (window.Snd && pct >= 0.6) Snd.jingle('vitoria');
    var p = pxPanel(this, 240, 190, 800, 330, '#f6ecd0', '#3b2a2a', 4).setDepth(90);
    this.add.text(W / 2, 220, 'Resultado: ' + Math.round(pct * 100) + '%', { fontFamily: FONT, fontSize: '36px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5, 0).setDepth(91);
    this.add.text(W / 2, 285, (extra ? extra + ' ' : '') + txt, { fontFamily: FONT, fontSize: '20px', color: '#3b2a2a', align: 'center', wordWrap: { width: 740 } }).setOrigin(0.5, 0).setDepth(91);
    this.foot.setText('[Enter] voltar · [R] jogar de novo').setDepth(95);
  },
  update: function (t, dt) {
    if (this.corr) return;
    var self = this; this.jd = {}; Object.keys(this.kk).forEach(function (k) { self.jd[k] = Phaser.Input.Keyboard.JustDown(self.kk[k]); });
    var s = this.ctl.poll(); if (this.leaving) return;
    if (this.J('T') && corrJogavel(this.C)) { E.flags.ativClassica = false; E.persist(); this.leaving = true; this.scene.start('Corrida', { id: this.id, from: this.from }); return; }
    if (this.done) { if (this.J('ENTER') || this.J('ESC') || this.J('E')) this.leave(); else if (this.J('R') && !this.C.after) this.scene.restart({ id: this.id, from: this.from }); return; }
    if (this.J('ESC')) { this.leave(); return; }
    this.el += dt; var u = this['u_' + this.C.tipo]; if (u) u.call(this, dt, s);
  },
  /* ---- quiz ---- */
  b_quiz: function () {
    var sc = this, C = this.C; this.qi = -1; this.score = 0; this.sel = 0; this.stage = 'intro';
    pxPanel(this, 110, 160, 1060, 480, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.qT = this.add.text(150, 190, '', { fontFamily: FONT, fontSize: '24px', color: '#3b2a2a', wordWrap: { width: 980 } }).setDepth(2);
    this.qO = [0, 1, 2].map(function (i) { var t = sc.add.text(170, 340 + i * 62, '', { fontFamily: FONT, fontSize: '21px', color: '#3b2a2a', wordWrap: { width: 920 }, backgroundColor: '#ffffffcc', padding: { x: 10, y: 6 } }).setDepth(2).setInteractive({ useHandCursor: true }); t.on('pointerdown', function () { if (sc.stage === 'ask') { sc.sel = i; sc.qPick(); } }); return t; });
    this.qF = this.add.text(150, 540, '', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#1f6a2c', wordWrap: { width: 980 } }).setDepth(2);
    this.qT.setText(C.intro || ''); this.foot.setText('[Enter] começar · [Esc] sair'); this.qO.forEach(function (o) { o.setVisible(false); });
  },
  qNext: function () {
    var C = this.C; this.qi++; if (this.qi >= C.rounds.length) { this.finish(this.score / C.rounds.length); return; }
    var r = C.rounds[this.qi]; this.ord = Phaser.Utils.Array.Shuffle(r.o.map(function (o, i) { return i; })); this.sel = 0; this.stage = 'ask';
    this.qT.setText((this.qi + 1) + '/' + C.rounds.length + '  ' + r.p); this.qF.setText('');
    var self = this; this.qO.forEach(function (o, i) { if (i < self.ord.length) { o.setVisible(true).setText((i + 1) + '. ' + r.o[self.ord[i]]); } else o.setVisible(false); });
    this.foot.setText('↑↓ ou 1-3 escolhem · [Enter] confirma · [Esc] sai'); this.qHi();
  },
  qHi: function () { var self = this; this.qO.forEach(function (o, i) { if (o.visible) o.setBackgroundColor(i === self.sel ? '#ffe08a' : '#ffffffcc'); }); },
  qPick: function () {
    var r = this.C.rounds[this.qi], ok = this.ord[this.sel] === r.c; if (ok) this.score++; this.stage = 'fb';
    this.qF.setColor(ok ? '#1f6a2c' : '#a02c2c').setText((ok ? 'Certo! ' : 'Quase! ') + r.f); snd(ok ? 'saber' : 'bad'); this.foot.setText('[Enter] continuar');
    var self = this; this.qO.forEach(function (o, i) { if (o.visible && self.ord[i] === r.c) o.setBackgroundColor('#b8f0b8'); });
  },
  u_quiz: function () {
    var n = this.ord ? this.ord.length : 0;
    if (this.stage === 'intro') { if (this.J('ENTER') || this.J('E')) this.qNext(); return; }
    if (this.stage === 'ask') { if (this.J('UP')) { this.sel = (this.sel + n - 1) % n; this.qHi(); snd('move'); } if (this.J('DOWN')) { this.sel = (this.sel + 1) % n; this.qHi(); snd('move'); }
      if (this.J('ONE') && n > 0) { this.sel = 0; this.qPick(); } else if (this.J('TWO') && n > 1) { this.sel = 1; this.qPick(); } else if (this.J('THREE') && n > 2) { this.sel = 2; this.qPick(); } else if (this.J('ENTER') || this.J('E')) this.qPick(); }
    else if (this.stage === 'fb' && (this.J('ENTER') || this.J('E') || this.J('SPACE'))) this.qNext();
  },
  /* ---- ritmo ---- */
  b_ritmo: function () {
    var sc = this, C = this.C, n = C.lanes.length; this.fall = 1300; this.yH = 580; this.hit = 0; this.judged = 0; this.notas = [];
    this.keys = n === 1 ? ['SPACE'] : n === 3 ? ['LEFT', 'UP', 'RIGHT'] : ['LEFT', 'DOWN', 'UP', 'RIGHT'];
    this.lx = C.lanes.map(function (l, i) { return W / 2 + (i - (n - 1) / 2) * 170; });
    this.lx.forEach(function (x, i) { sc.add.rectangle(x, 360, 130, 480, 0xffffff, 0.22).setDepth(1); pxRect(sc, x, sc.yH, 130, 34, '#ffd23a', '#7a5a00', 0.55).setDepth(2); sc.add.text(x, 640, C.lanes[i] + ' ' + { LEFT: '←', RIGHT: '→', UP: '↑', DOWN: '↓', SPACE: '␣' }[sc.keys[i]], { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 4 }).setOrigin(0.5).setDepth(3); });
    var seed = 7 + this.id.length; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    for (var i = 0; i < C.notas; i++) this.notas.push({ lane: Math.floor(rnd() * n), t: 1800 + i * C.gap, o: null, st: 0 });
    this.total = C.notas; this.fb = this.add.text(W / 2, 200, '', { fontFamily: FONT, fontSize: '34px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 6 }).setOrigin(0.5).setDepth(60);
    this.foot.setText('Aperte a tecla da faixa quando a nota chegar na linha dourada · [Esc] sai');
  },
  u_ritmo: function () {
    var sc = this, C = this.C, el = this.el, sp = (this.yH - 150) / this.fall;
    this.notas.forEach(function (n) {
      if (n.st) { return; }
      var y = 150 + (el - (n.t - sc.fall)) * sp;
      if (!n.o && y > 120 && y < 700) n.o = pxDisc(sc, sc.lx[n.lane], y, 26, '#ff7a5a', '#7a2a1a').setDepth(5);
      if (n.o) n.o.y = y;
      if (el - n.t > 150) { n.st = 2; sc.judged++; if (n.o) { n.o.destroy(); n.o = null; } }
    });
    for (var i = 0; i < this.keys.length; i++) {
      if (this.J(this.keys[i]) || (this.keys.length === 1 && this.J('E'))) {
        var best = null, bd = 160; this.notas.forEach(function (n) { if (!n.st && n.lane === i && Math.abs(el - n.t) < bd) { bd = Math.abs(el - n.t); best = n; } });
        if (best) { best.st = 1; this.hit++; this.judged++; if (best.o) { best.o.destroy(); best.o = null; } this.fb.setText(C.falas[this.hit % C.falas.length]); snd('saber'); }
      }
    }
    this.msg.setText('Acertos ' + this.hit + ' / ' + this.total);
    if (this.judged >= this.total) this.finish(this.hit / this.total);
  },
  /* ---- pega ---- */
  b_pega: function () {
    var C = this.C; this.player = this.add.image(W / 2, 650, 'av0').setOrigin(0.5, 1).setScale(4).setDepth(10); this.its = []; this.good = 0; this.bad = 0; this.sp = 0; this.nx = 400;
    this.hud = this.add.text(W / 2, 128, '', { fontFamily: FONT, fontSize: '20px', color: '#fff', backgroundColor: '#000000aa', padding: { x: 8, y: 3 } }).setOrigin(0.5, 0).setDepth(50);
    this.msg.setVisible(false); this.foot.setText('← → movem · [Esc] sai');
  },
  u_pega: function (dt, s) {
    var C = this.C, p = this.player, sec = this.el / 1000; p.x = Phaser.Math.Clamp(p.x + ((s.right ? 1 : 0) - (s.left ? 1 : 0)) * dt * 0.5, 100, W - 100);
    if (this.el > this.nx && sec < C.dur - 2) { this.nx += 650; var bad = Math.random() < C.pr, o = this.add.image(120 + Math.random() * (W - 240), 150, bad ? C.ruim : C.bom).setScale(bad ? 4 : 3).setDepth(8); o.bad = bad; o.vy = 190 + Math.random() * 80; this.its.push(o); }
    var self = this; this.its = this.its.filter(function (o) {
      o.y += o.vy * dt / 1000; o.angle += 0.5;
      if (Math.abs(o.x - p.x) < 56 && Math.abs(o.y - (p.y - 50)) < 56) { if (o.bad) { self.bad++; snd('bad'); p.setTint(0xff8888); self.time.delayedCall(250, function () { p.clearTint(); }); } else { self.good++; snd('saber'); } o.destroy(); return false; }
      if (o.y > 700) { o.destroy(); return false; } return true; });
    this.hud.setText('Tempo ' + Math.max(0, Math.ceil(C.dur - sec)) + 's · Pegou ' + this.good + ' · Tropeços ' + this.bad);
    if (sec >= C.dur) this.finish(Phaser.Math.Clamp((this.good - this.bad * 0.5) / C.meta, 0, 1));
  },
  /* ---- memória ---- */
  b_memoria: function () {
    var sc = this, sp = []; ESPECIES.forEach(function (e) { if (sc.textures.exists('an_' + e[0] + '_0')) sp.push(e[0]); });
    this.deck = Phaser.Utils.Array.Shuffle(Phaser.Utils.Array.Shuffle(sp).slice(0, 6).concat(sp.slice(0, 0))); this.deck = Phaser.Utils.Array.Shuffle(this.deck.concat(this.deck)); this.cards = []; this.moves = 0; this.open = []; this.found = 0; this.cur = 0; this.lock = false;
    this.deck.forEach(function (k, i) {
      var cx = 290 + (i % 4) * 230, cy = 230 + Math.floor(i / 4) * 150, bg = pxPanel(sc, cx - 90, cy - 60, 180, 120, '#c8a060', '#3b2a2a', 3).setDepth(2).setInteractive({ useHandCursor: true });
      var q = sc.add.text(cx, cy, '?', { fontFamily: FONT, fontSize: '48px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(3), im = sc.add.image(cx, cy + 30, 'an_' + k + '_0').setScale(4).setOrigin(0.5, 1).setDepth(3).setVisible(false);
      bg.on('pointerdown', function () { sc.cur = i; sc.flip(i); }); sc.cards.push({ k: k, bg: bg, q: q, im: im, up: false, ok: false });
    });
    this.hiC(); this.foot.setText('Setas movem · [Enter] vira · ou clique · [Esc] sai');
  },
  hiC: function () { var self = this; this.cards.forEach(function (c, i) { c.bg.setStrokeStyle(i === self.cur ? 5 : 3, i === self.cur ? '#ffffff' : '#3b2a2a'); }); },
  flip: function (i) {
    var c = this.cards[i], sc = this; if (this.lock || c.up || c.ok) return; c.up = true; c.q.setVisible(false); c.im.setVisible(true); this.open.push(i); snd('move');
    if (this.open.length === 2) { this.moves++; var a = this.cards[this.open[0]], b = this.cards[this.open[1]]; this.lock = true;
      if (a.k === b.k) { a.ok = b.ok = true; this.found++; snd('saber'); this.open = []; this.lock = false; if (this.found >= 6) this.time.delayedCall(500, function () { sc.finish(Math.min(1, 9 / sc.moves), 'Em ' + sc.moves + ' jogadas.'); }); }
      else this.time.delayedCall(700, function () { [a, b].forEach(function (x) { x.up = false; x.q.setVisible(true); x.im.setVisible(false); }); sc.open = []; sc.lock = false; }); }
    this.msg.setText('Jogadas ' + this.moves + ' · Pares ' + this.found + '/6');
  },
  u_memoria: function () {
    var c = this.cur; if (this.J('LEFT')) c = c % 4 === 0 ? c + 3 : c - 1; if (this.J('RIGHT')) c = c % 4 === 3 ? c - 3 : c + 1; if (this.J('UP')) c = (c + 8) % 12; if (this.J('DOWN')) c = (c + 4) % 12;
    if (c !== this.cur) { this.cur = c; this.hiC(); snd('move'); } if (this.J('ENTER') || this.J('E')) this.flip(this.cur);
  },
  /* ---- caça-palavras ---- */
  b_palavras: function () {
    var sc = this, W0 = [['CISTERNA', 0, 0, 0], ['FONTE', 2, 2, 0], ['CHUVA', 4, 1, 0], ['TAMPA', 6, 3, 0], ['FILTRO', 1, 0, 1], ['AGUA', 2, 7, 1]];
    this.grid = []; for (var r = 0; r < 8; r++) { this.grid.push([]); for (var c = 0; c < 8; c++) this.grid[r].push(''); }
    W0.forEach(function (w) { for (var i = 0; i < w[0].length; i++) { var rr = w[1] + (w[3] ? i : 0), cc = w[2] + (w[3] ? 0 : i); sc.grid[rr][cc] = w[0][i]; } });
    var seed = 3; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; } var AL = 'AEIOUSRTLNMCP';
    for (r = 0; r < 8; r++) for (c = 0; c < 8; c++) if (!this.grid[r][c]) this.grid[r][c] = AL[Math.floor(rnd() * AL.length)];
    this.words = W0.map(function (w) { return w[0]; }); this.foundW = {}; this.cells = []; this.start = null; this.cur = { r: 0, c: 0 }; this.hiL = [];
    for (r = 0; r < 8; r++) for (c = 0; c < 8; c++) (function (r, c) {
      var x = 180 + c * 58, y = 170 + r * 58, bg = pxRect(sc, x, y, 54, 54, '#fff7dc', '#3b2a2a', 1).setDepth(2).setInteractive({ useHandCursor: true }), t = sc.add.text(x, y, sc.grid[r][c], { fontFamily: FONT, fontSize: '28px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(3);
      bg.on('pointerdown', function () { sc.cur = { r: r, c: c }; sc.pickCell(); }); sc.cells.push({ bg: bg, t: t });
    })(r, c);
    this.lst = this.add.text(720, 170, '', { fontFamily: FONT, fontSize: '24px', color: '#3b2a2a', backgroundColor: '#fff3c4', padding: { x: 12, y: 8 }, lineSpacing: 6 }).setDepth(5);
    this.refreshL(); this.foot.setText('Clique na primeira e na última letra (ou setas + [Enter]) · [Esc] sai');
  },
  refreshL: function () { var self = this; this.lst.setText(this.words.map(function (w) { return (self.foundW[w] ? '✓ ' : '· ') + w; }).join('\n')); this.cells.forEach(function (c, i) { c.bg.setStrokeStyle(self.cur && Math.floor(i / 8) === self.cur.r && i % 8 === self.cur.c ? 4 : 1, self.cur && Math.floor(i / 8) === self.cur.r && i % 8 === self.cur.c ? '#c8561a' : '#3b2a2a'); }); },
  pickCell: function () {
    var self = this; if (!this.start) { this.start = { r: this.cur.r, c: this.cur.c }; this.cells[this.start.r * 8 + this.start.c].bg.setFillStyle('#ffe08a'); this.refreshL(); return; }
    var a = this.start, b = this.cur, dr = Math.sign(b.r - a.r), dc = Math.sign(b.c - a.c), n = Math.max(Math.abs(b.r - a.r), Math.abs(b.c - a.c)) + 1, s = '', ok = (a.r === b.r || a.c === b.c || Math.abs(b.r - a.r) === Math.abs(b.c - a.c)), i;
    this.cells[a.r * 8 + a.c].bg.setFillStyle('#fff7dc'); this.start = null;
    if (ok) { var idx = []; for (i = 0; i < n; i++) { s += this.grid[a.r + dr * i][a.c + dc * i]; idx.push((a.r + dr * i) * 8 + a.c + dc * i); } var rs = s.split('').reverse().join('');
      this.words.forEach(function (w) { if (!self.foundW[w] && (w === s || w === rs)) { self.foundW[w] = true; idx.forEach(function (j) { self.cells[j].bg.setFillStyle('#b8f0b8'); }); snd('saber'); } }); }
    this.refreshL(); var nf = Object.keys(this.foundW).length; this.msg.setText('Achadas ' + nf + '/' + this.words.length);
    if (nf >= this.words.length) { var me = this; this.time.delayedCall(500, function () { me.finish(1); }); }
  },
  u_palavras: function () {
    var c = this.cur; if (this.J('LEFT')) c = { r: c.r, c: (c.c + 7) % 8 }; if (this.J('RIGHT')) c = { r: c.r, c: (c.c + 1) % 8 }; if (this.J('UP')) c = { r: (c.r + 7) % 8, c: c.c }; if (this.J('DOWN')) c = { r: (c.r + 1) % 8, c: c.c };
    if (c !== this.cur) { this.cur = c; this.refreshL(); } if (this.J('ENTER') || this.J('E')) this.pickCell();
    if (this.el > 150000) { this.finish(Object.keys(this.foundW).length / this.words.length); }
  },
  /* ---- Roda de Conversa / Vacina em Roda ---- */
  b_roda: function () {
    var sc = this, C = this.C; this.g = C.gente; this.sp = {}; this.rd = 0; this.sel = 0; this.stage = 'intro';
    pxPanel(this, 110, 160, 1060, 480, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.rT = this.add.text(150, 190, C.intro, { fontFamily: FONT, fontSize: '22px', color: '#3b2a2a', wordWrap: { width: 980 } }).setDepth(2);
    this.rL = this.g.map(function (p, i) { var t = sc.add.text(170, 300 + i * 52, '', { fontFamily: FONT, fontSize: '21px', color: '#3b2a2a', backgroundColor: '#ffffffcc', padding: { x: 10, y: 5 } }).setDepth(2).setInteractive({ useHandCursor: true }); t.on('pointerdown', function () { if (sc.stage === 'ask') { sc.sel = i; sc.rPick(); } }); return t; });
    this.rF = this.add.text(150, 570, '', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#1f6a2c', wordWrap: { width: 980 } }).setDepth(2);
    this.rL.forEach(function (t) { t.setVisible(false); }); this.foot.setText('[Enter] começar · [Esc] sai');
  },
  rShow: function () {
    var self = this; this.rT.setText('Rodada ' + (this.rd + 1) + '/' + this.g.length + ': quem tem a palavra? ' + '(Quem já falou aparece com ✓)');
    this.rL.forEach(function (t, i) { var p = self.g[i], st = self.sp[i] ? '✓ ' : '   '; t.setVisible(true).setText(st + p.n + (p.d ? '  (levanta a mão de novo)' : p.t ? '  (quieta, de cabeça baixa)' : '  (olhando)')).setBackgroundColor(i === self.sel ? '#ffe08a' : '#ffffffcc'); });
  },
  rPick: function () {
    var p = this.g[this.sel], ja = this.sp[this.sel]; this.stage = 'fb';
    if (ja) { this.rF.setColor('#a02c2c').setText(p.n + ' já tinha falado: a rodada foi perdida.'); snd('bad'); } else { this.sp[this.sel] = true; this.rF.setColor('#1f6a2c').setText(p.n + ': ' + p.f); snd('saber'); }
    this.foot.setText('[Enter] continuar');
  },
  u_roda: function () {
    var n = this.g.length;
    if (this.stage === 'intro') { if (this.J('ENTER') || this.J('E')) { this.stage = 'ask'; this.rShow(); this.foot.setText('↑↓ escolhem · [Enter] dá a vez · [Esc] sai'); } return; }
    if (this.stage === 'ask') { var ch = false; if (this.J('UP')) { this.sel = (this.sel + n - 1) % n; ch = true; } if (this.J('DOWN')) { this.sel = (this.sel + 1) % n; ch = true; } if (ch) { this.rShow(); snd('move'); } if (this.J('ENTER') || this.J('E')) this.rPick(); }
    else if (this.stage === 'fb' && (this.J('ENTER') || this.J('E'))) { this.rd++; if (this.rd >= n) { var f = this.g.filter(function (p, i) { return !this.sp[i]; }, this).map(function (p) { return p.n; }); this.finish(Object.keys(this.sp).length / n, f.length ? 'Ficaram de fora: ' + f.join(', ') + '.' : 'Ninguém ficou de fora.' + ' ' + this.C.licao); } else { this.stage = 'ask'; this.rF.setText(''); this.rShow(); } }
  },
  /* ---- Cartografia e Caçador de Focos ---- */
  b_carto: function () {
    var sc = this, C = this.C; this.pi = 0; this.mk = C.pontos.map(function () { return -1; }); this.stage = 'intro';
    this.add.tileSprite(90, 160, 760, 500, 'grama').setOrigin(0, 0).setTileScale(4, 4).setDepth(1); pxPanel(this, 880, 160, 310, 500, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.pt = C.pontos.map(function (p, i) { var d = pxDisc(sc, 90 + p.x, 160 + p.y, 24, '#777777', '#ffffff').setDepth(5).setInteractive({ useHandCursor: true }); d.on('pointerdown', function () { sc.pi = i; sc.cHi(); }); var t = sc.add.text(90 + p.x, 160 + p.y, String(i + 1), { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff' }).setOrigin(0.5).setDepth(6); return d; });
    this.cT = this.add.text(900, 180, '', { fontFamily: FONT, fontSize: '19px', color: '#3b2a2a', wordWrap: { width: 270 } }).setDepth(2);
    this.msg.setText(C.intro); this.cHi(); this.foot.setText('←→ trocam de ponto · [1] ' + C.marcas[0] + ' · [2] ' + C.marcas[1] + ' · [Enter] termina · [Esc] sai');
  },
  cHi: function () {
    var C = this.C, self = this; this.pt.forEach(function (d, i) { d.setFillStyle(self.mk[i] < 0 ? '#777777' : self.mk[i] === 0 ? '#d84a3a' : '#3aa85a'); d.setStrokeStyle(2, i === self.pi ? '#ffd23a' : '#ffffff'); d.setScale(i === self.pi ? 3.6 : 3); });
    var p = C.pontos[this.pi]; this.cT.setText('Ponto ' + (this.pi + 1) + '\n\n' + p.t + '\n\nMarca: ' + (this.mk[this.pi] < 0 ? 'nenhuma' : C.marcas[this.mk[this.pi]]));
  },
  u_carto: function () {
    var n = this.C.pontos.length, ch = false;
    if (this.J('RIGHT') || this.J('DOWN')) { this.pi = (this.pi + 1) % n; ch = true; } if (this.J('LEFT') || this.J('UP')) { this.pi = (this.pi + n - 1) % n; ch = true; }
    if (this.J('ONE')) { this.mk[this.pi] = 0; ch = true; snd('move'); } if (this.J('TWO')) { this.mk[this.pi] = 1; ch = true; snd('move'); } if (ch) this.cHi();
    if (this.J('ENTER')) { var self = this, ok = 0; this.C.pontos.forEach(function (p, i) { if (self.mk[i] === p.k) ok++; }); if (this.mk.indexOf(-1) >= 0) { this.msg.setText('Marque todos os pontos antes de terminar.'); snd('bad'); } else this.finish(ok / n, ok + ' de ' + n + ' certos. ' + this.C.licao); }
  },
  /* ---- Feira do Pequi ---- */
  b_feira: function () {
    var sc = this, R = rocaGet(); this.itens = [{ id: 'pequi', n: 'Semente de pequi', p: 2 }, { id: 'mandioca', n: 'Muda de mandioca', p: 2 }, { id: 'milho', n: 'Semente de milho', p: 2 }, { id: 'regador', n: 'Regador de lata', p: 3, u: 1 }, { id: 'enxada', n: 'Enxada', p: 3, u: 1 }]; this.sel = 0;
    pxPanel(this, 140, 160, 1000, 470, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.add.text(180, 185, 'Dona Neide: "Meios na mão, semente no chão!"', { fontFamily: FONT, fontSize: '22px', color: '#3b2a2a' }).setDepth(2);
    this.fL = this.itens.map(function (it, i) { var t = sc.add.text(180, 250 + i * 56, '', { fontFamily: FONT, fontSize: '22px', color: '#3b2a2a', backgroundColor: '#ffffffcc', padding: { x: 10, y: 6 } }).setDepth(2).setInteractive({ useHandCursor: true }); t.on('pointerdown', function () { sc.sel = i; sc.compra(); }); return t; });
    this.fI = this.add.text(180, 540, '', { fontFamily: FONT, fontSize: '19px', color: '#3b2a2a', wordWrap: { width: 900 } }).setDepth(2); this.foot.setText('↑↓ escolhem · [Enter] compra · [B] barganha no ritmo · [Esc] sai'); this.fShow();
  },
  preco: function (it) { return Math.max(1, it.p - (E.desc ? 1 : 0)); },
  fShow: function () {
    var self = this, R = rocaGet(); this.fL.forEach(function (t, i) { var it = self.itens[i], tem = it.u ? (R[it.id] ? ' (você tem)' : '') : ' (você tem ' + R.sem[it.id] + ')'; t.setText(it.n + ' · ' + self.preco(it) + ' Meios' + tem).setBackgroundColor(i === self.sel ? '#ffe08a' : '#ffffffcc'); });
    this.fI.setText('Seus Meios: ' + E.rec.Meios + (E.desc ? ' · Desconto de barganha ativo (-1 na próxima compra)' : '') + '\nSementes plantadas na Roça crescem quando você conclui fases.'); this.msg.setText('Meios ' + E.rec.Meios);
  },
  compra: function () {
    var it = this.itens[this.sel], R = rocaGet(), pr = this.preco(it); if (it.u && R[it.id]) { this.fI.setText('Você já tem: ' + it.n + '.'); return; }
    if (E.rec.Meios < pr) { this.fI.setText('Meios insuficientes.'); snd('bad'); return; }
    chg('Meios', -pr); if (it.u) R[it.id] = true; else R.sem[it.id]++; if (E.desc) E.desc = 0; snd('saber'); E.persist(); this.fShow();
  },
  u_feira: function () {
    var n = this.itens.length, ch = false; if (this.J('UP')) { this.sel = (this.sel + n - 1) % n; ch = true; } if (this.J('DOWN')) { this.sel = (this.sel + 1) % n; ch = true; } if (ch) { this.fShow(); snd('move'); }
    if (this.J('ENTER') || this.J('E')) this.compra(); if (this.J('B') && !this.leaving) { this.leaving = true; this.scene.start('Ativ', { id: 'barganha', from: { scene: 'Ativ', data: { id: 'feira', from: this.from } } }); }
  },
  /* ---- Roça e Livro de Receitas ---- */
  b_roca: function () {
    var sc = this, R = rocaGet(); this.sel = 0; this.sd = 'pequi'; this.livro = false;
    pxPanel(this, 110, 160, 1060, 470, '#e8f0c8', '#3b2a2a', 4).setDepth(1); this.plots = [];
    for (var i = 0; i < 6; i++) (function (i) { var x = 280 + (i % 3) * 260, y = 270 + Math.floor(i / 3) * 190, bg = pxRect(sc, x, y, 200, 150, '#8a5a2a', '#4a2a0a').setDepth(2).setInteractive({ useHandCursor: true }), t = sc.add.text(x, y + 50, '', { fontFamily: FONT, fontSize: '16px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 4 }).setOrigin(0.5).setDepth(4), im = sc.add.image(x, y + 20, 'arbusto').setScale(3).setOrigin(0.5, 1).setDepth(3).setVisible(false); bg.on('pointerdown', function () { sc.sel = i; sc.agir(); }); sc.plots.push({ bg: bg, t: t, im: im }); })(i);
    this.rI = this.add.text(900, 190, '', { fontFamily: FONT, fontSize: '18px', color: '#3b2a2a', wordWrap: { width: 250 } }).setDepth(2);
    this.lv = this.add.text(W / 2, 360, '', { fontFamily: FONT, fontSize: '20px', color: '#3b2a2a', backgroundColor: '#fff3c4', padding: { x: 14, y: 10 }, wordWrap: { width: 800 }, lineSpacing: 8 }).setOrigin(0.5).setDepth(30).setVisible(false);
    this.rShow2(); this.foot.setText('Setas escolhem o canteiro · [Enter] planta/rega/colhe · [1][2][3] semente · [R] receitas · [Esc] sai');
  },
  rShow2: function () {
    var R = rocaGet(), self = this; this.plots.forEach(function (p, i) { var s = R.p[i]; p.im.setVisible(s > 0).setTexture(s === 3 ? 'bn_fruta' : 'arbusto').setScale(s === 1 ? 2 : 3).setAlpha(s === 2 ? 0.8 : 1); p.t.setText(['vazio', 'plantado: falta regar', 'regado: cresce nas próximas fases', 'maduro: colha!'][s] + (R.t[i] ? '\n' + R.t[i] : '')); p.bg.setStrokeStyle(i === self.sel ? 5 : 3, i === self.sel ? '#ffffff' : '#4a2a0a'); });
    this.rI.setText('Semente: ' + this.sd + '\npequi ' + R.sem.pequi + ' · mandioca ' + R.sem.mandioca + ' · milho ' + R.sem.milho + '\nRegador: ' + (R.regador ? 'sim' : 'não (Feira)') + '\nEnxada: ' + (R.enxada ? 'sim' : 'não (Feira)') + '\nColhidas: ' + R.colhidas + '\n\nA Vila muda quando a roça rende.');
  },
  agir: function () {
    var R = rocaGet(), i = this.sel, s = R.p[i];
    if (s === 0) { if (!R.enxada) { this.msg.setText('Falta a enxada. Compre na Feira do Pequi.'); snd('bad'); } else if (R.sem[this.sd] < 1) { this.msg.setText('Sem semente de ' + this.sd + '. Compre na Feira.'); snd('bad'); } else { R.sem[this.sd]--; R.p[i] = 1; R.t[i] = this.sd; snd('saber'); this.msg.setText('Plantado: ' + this.sd + '.'); } }
    else if (s === 1) { if (!R.regador) { this.msg.setText('Falta o regador. Compre na Feira.'); snd('bad'); } else { R.p[i] = 2; snd('verter'); this.msg.setText('Regado! Conclua uma fase para amadurecer.'); } }
    else if (s === 2) this.msg.setText('Cresce nas próximas fases. Volte depois de concluir uma.');
    else { var k = R.t[i], nome = { pequi: 'Galinhada com pequi', mandioca: 'Beiju de mandioca', milho: 'Pamonha de milho' }[k]; R.p[i] = 0; R.t[i] = null; R.colhidas++; R.col[k] = true; chg('Meios', 2); if (!R.rec[k]) { R.rec[k] = true; chg('Saberes', 1); this.msg.setText('Colhido! Nova receita: ' + nome + '. Meios +2, Saberes +1.'); } else this.msg.setText('Colhido! Meios +2.'); snd('saber'); }
    E.persist(); this.rShow2();
  },
  u_roca: function () {
    var c = this.sel; if (this.J('LEFT')) c = c % 3 === 0 ? c + 2 : c - 1; if (this.J('RIGHT')) c = c % 3 === 2 ? c - 2 : c + 1; if (this.J('UP') || this.J('DOWN')) c = (c + 3) % 6; if (c !== this.sel) { this.sel = c; this.rShow2(); snd('move'); }
    if (this.J('ONE')) { this.sd = 'pequi'; this.rShow2(); } if (this.J('TWO')) { this.sd = 'mandioca'; this.rShow2(); } if (this.J('THREE')) { this.sd = 'milho'; this.rShow2(); }
    if (this.J('ENTER') || this.J('E')) { if (this.livro) { this.livro = false; this.lv.setVisible(false); } else this.agir(); }
    if (this.J('R')) { var R = rocaGet(); this.livro = !this.livro; this.lv.setVisible(this.livro).setText('LIVRO DE RECEITAS\n\n' + [['pequi', 'Galinhada com pequi: o pequi se rói com cuidado, sem morder o caroço.'], ['mandioca', 'Beiju de mandioca: comida de raiz, feita em roda.'], ['milho', 'Pamonha de milho: festa junina o ano inteiro.']].map(function (r) { return (R.rec[r[0]] ? '✓ ' + r[1] : '? Colha ' + r[0] + ' para abrir a receita'); }).join('\n')); }
  },
  /* ---- Diário de Campo ---- */
  b_diario: function () {
    var sc = this; E.diario = E.diario || {}; this.sel = 0; this.dc = [];
    pxPanel(this, 70, 150, 760, 490, '#f6ecd0', '#3b2a2a', 4).setDepth(1); pxPanel(this, 850, 150, 360, 490, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    ESPECIES.forEach(function (e, i) { var x = 150 + (i % 6) * 120, y = 240 + Math.floor(i / 6) * 150, bg = pxPanel(sc, x - 50, y - 60, 100, 120, '#c8a060', '#3b2a2a', 3).setDepth(2).setInteractive({ useHandCursor: true }), ok = !!E.diario[e[0]] && sc.textures.exists('an_' + e[0] + '_0'), im = ok ? sc.add.image(x, y + 30, 'an_' + e[0] + '_0').setScale(3).setOrigin(0.5, 1).setDepth(3) : sc.add.text(x, y, '?', { fontFamily: FONT, fontSize: '40px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(3); bg.on('pointerdown', function () { sc.sel = i; sc.dShow(); }); sc.dc.push({ bg: bg, ok: ok }); });
    this.dI = this.add.text(870, 170, '', { fontFamily: FONT, fontSize: '19px', color: '#3b2a2a', wordWrap: { width: 320 } }).setDepth(2); this.dShow(); this.foot.setText('Setas escolhem · [Esc] sai · Entre em cada Reino para encontrar os bichos');
    var n = ESPECIES.filter(function (e) { return E.diario[e[0]]; }).length; this.msg.setText('Figurinhas ' + n + '/' + ESPECIES.length);
    var dm = {}; ESPECIES.forEach(function (e) { dm[e[2]] = dm[e[2]] || []; dm[e[2]].push(e[0]); });
    Object.keys(dm).forEach(function (d) { if (dm[d].every(function (k) { return E.diario[k]; }) && !E.flags['dia_' + d]) { E.flags['dia_' + d] = true; chg('Saberes', 1); E.ui.toast('Página completa: ' + d + '. Saberes +1'); } });
  },
  dShow: function () {
    var e = ESPECIES[this.sel], ok = this.dc[this.sel].ok, self = this; this.dc.forEach(function (c, i) { c.bg.setStrokeStyle(i === self.sel ? 5 : 3, i === self.sel ? '#ffffff' : '#3b2a2a'); });
    var bio = e[2] === 'Vila Mutirão' ? 'Planalto das Veredas' : (DOMINIOS.filter(function (d) { return d.n === e[2]; })[0] || { b: '' }).b;
    this.dI.setText(ok ? e[1] + '\n' + e[2] + ' · ' + bio + '\n\n' + e[3] : '???\n\nAinda não encontrado. Entre em ' + e[2] + ' para ver este bicho.');
  },
  u_diario: function () { var c = this.sel; if (this.J('LEFT')) c = (c + 17) % 18; if (this.J('RIGHT')) c = (c + 1) % 18; if (this.J('UP')) c = (c + 12) % 18; if (this.J('DOWN')) c = (c + 6) % 18; if (c !== this.sel) { this.sel = c; this.dShow(); snd('move'); } },
  /* ---- Mutirão da semana ---- */
  b_mutirao: function () {
    var sc = this, M = mutLocal(); pxPanel(this, 140, 160, 1000, 470, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.mT = this.add.text(180, 190, 'Buscando a meta da semana...', { fontFamily: FONT, fontSize: '24px', color: '#3b2a2a', wordWrap: { width: 920 }, lineSpacing: 8 }).setDepth(2);
    this.bar = pxRect(this, 180, 330, 920, 34, '#cccccc', '#3b2a2a').setOrigin(0, 0.5).setDepth(2); this.bar2 = pxRect(this, 180, 330, 8, 34, '#3aa85a', null).setOrigin(0, 0.5).setDepth(3);
    this.foot.setText('[Esc] sair');
    mutGet().then(function (r) {
      if (!sc.mT || !sc.mT.scene) return; var tot = r ? r.total : M.pts, meta = r ? r.meta : (E.mundo ? E.mundo.meta : 1000);
      sc.mT.setText('Meta coletiva da semana: ' + tot + ' de ' + meta + ' pontos' + (r ? '' : ' (sem conexão: mostrando só o seu)') + '\n\nCada atividade concluída com 60% ou mais soma de 1 a 5 pontos para a meta de ' + (E.mundo ? 'todo mundo da Veredália de ' + E.mundo.nome : 'todo mundo do Vigiante') + '. Só o número é enviado: nenhum dado pessoal.');
      sc.bar2.setDisplaySize(Math.max(8, 920 * Math.min(1, tot / meta)), 34);
      sc.add.text(180, 400, 'Sua parte esta semana: ' + M.pts + ' pontos em ' + M.feitos + ' atividades.\nDesafio opcional: concluir 3 atividades na semana (Rede +1) ' + (M.bonus ? '✓ cumprido!' : '(' + Math.min(3, M.feitos) + '/3)') + '\nJogue em Atividades, Jogos ou Saúde.', { fontFamily: FONT, fontSize: '22px', color: '#3b2a2a', lineSpacing: 8, wordWrap: { width: 920 } }).setDepth(2);
    });
  }
});

var AtivMenu = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function AtivMenu() { Phaser.Scene.call(this, { key: 'AtivMenu' }); },
  init: function (d) { this.from = (d && d.from) || { scene: 'World' }; this.aba = (d && d.aba) || 0; this.sel = (d && d.sel) || 0; },
  create: function () {
    var sc = this; E.curLvl = -3; music('mapa'); this.leaving = false;
    this.kk = this.input.keyboard.addKeys('UP,DOWN,LEFT,RIGHT,ENTER,ESC,E'); this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setDepth(-40); this.add.image(0, 0, 'colinas2').setOrigin(0, 0).setScale(4).setDepth(-30);
    this.add.text(W / 2, 86, 'Atividades', { fontFamily: FONT, fontSize: '34px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 6 }).setOrigin(0.5).setDepth(5);
    pxPanel(this, 70, 120, 1140, 540, '#f6ecd0', '#3b2a2a', 4).setDepth(1);
    this.tabs = ATIV_ABAS.map(function (a, i) { var t = sc.add.text(110 + i * 220, 138, a[0], { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#3b2a2a', backgroundColor: '#ffffffcc', padding: { x: 12, y: 6 } }).setDepth(2).setInteractive({ useHandCursor: true }); t.on('pointerdown', function () { sc.aba = i; sc.sel = 0; sc.draw(); }); return t; });
    this.items = []; for (var i = 0; i < 16; i++) (function (i) { var t = sc.add.text(110 + (i % 2) * 540, 200 + Math.floor(i / 2) * 44, '', { fontFamily: FONT, fontSize: '19px', color: '#3b2a2a', backgroundColor: '#ffffffcc', padding: { x: 8, y: 4 }, fixedWidth: 500 }).setDepth(2).setInteractive({ useHandCursor: true }); t.on('pointerdown', function () { sc.sel = i; sc.go(); }); sc.items.push(t); })(i);
    this.info = this.add.text(110, 560, '', { fontFamily: FONT, fontSize: '18px', color: '#3b2a2a', wordWrap: { width: 1060 } }).setDepth(2);
    this.add.text(W / 2, 700, '←→ trocam de aba · ↑↓ escolhem · [Enter] joga · [Esc] volta · Conteúdo de saúde é educativo e não substitui atendimento', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 6, y: 2 } }).setOrigin(0.5, 1).setDepth(5);
    this.draw();
  },
  ids: function () { return ATIV_ABAS[this.aba][1]; },
  draw: function () {
    var self = this, ids = this.ids(); this.tabs.forEach(function (t, i) { t.setBackgroundColor(i === self.aba ? '#ffe08a' : '#ffffffcc'); });
    this.items.forEach(function (t, i) { if (i < ids.length) { var a = ATIV[ids[i]], I = atvInfo(ids[i]), lk = ativTrava(ids[i]); t.setVisible(true).setText((lk ? '🔒 ' : '') + a.nome).setBackgroundColor(i === self.sel ? '#ffe08a' : '#ffffffcc'); } else t.setVisible(false); });
    var a = ATIV[ids[this.sel]], lk = ativTrava(ids[this.sel]); this.info.setText(a.desc + (lk ? '  [' + lk + ']' : ''));
  },
  go: function () {
    var id = this.ids()[this.sel], lk = ativTrava(id); if (lk) { snd('bad'); this.info.setText('Fechado: ' + lk + '.'); return; }
    this.leaving = true; this.scene.start('Ativ', { id: id, from: { scene: 'AtivMenu', data: { from: this.from, aba: this.aba, sel: this.sel } } });
  },
  update: function () {
    if (this.leaving) return; var J = Phaser.Input.Keyboard.JustDown, k = this.kk, n = this.ids().length, ch = false;
    if (J(k.LEFT)) { this.aba = (this.aba + 2) % 3; this.sel = 0; ch = true; } if (J(k.RIGHT)) { this.aba = (this.aba + 1) % 3; this.sel = 0; ch = true; }
    if (J(k.UP)) { this.sel = (this.sel + n - 2) % n; ch = true; } if (J(k.DOWN)) { this.sel = (this.sel + 2) % n; ch = true; } if (this.sel >= n) this.sel = n - 1;
    if (ch) { this.draw(); snd('move'); } if (J(k.ENTER) || J(k.E)) this.go();
    if (J(k.ESC)) { this.leaving = true; this.scene.start(this.from.scene, this.from.data); }
  }
});

/* ---------- Bônus: Mutirão de Colheita (opcional, nunca bloqueia a história) ---------- */
var Bonus = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Bonus() { Phaser.Scene.call(this, { key: 'Bonus' }); },
  create: function () {
    var sc = this, LB = 5000; E.curLvl = -2; music('sala22'); this.ctl = new Ctl(this); this.hillsL = [];
    this.physics.world.gravity.y = GRAV; this.cameras.main.setBounds(0, 0, LB, H); this.physics.world.setBounds(0, -400, LB, H + 800);
    this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setScrollFactor(0).setDepth(-40);
    [['colinas1', 0.1], ['colinas2', 0.2], ['colinas3', 0.35]].forEach(function (h, i) { var t = sc.add.tileSprite(0, 320, W, 400, h[0]).setOrigin(0, 0).setScrollFactor(0).setTileScale(4, 4).setDepth(-30 + i); t.tilePositionY = 80; sc.hillsL.push([t, h[1]]); });
    this.solids = this.physics.add.staticGroup(); this.obst = this.physics.add.staticGroup(); this.fruits = this.physics.add.staticGroup();
    function solid(x, y, w, h, key, vh) { sc.solids.create(x + w / 2, y + h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody(); return sc.add.tileSprite(x, y, w, vh || h, key).setOrigin(0, 0).setTileScale(4, 4).setDepth(2); }
    this.total = 0;
    function fruit(x, y) { var f = sc.fruits.create(x, y, 'bn_fruta').setScale(3).setDepth(3); f.refreshBody(); sc.total++; sc.tweens.add({ targets: f, y: y - 8, yoyo: true, repeat: -1, duration: 600 + (x % 5) * 60 }); }
    solid(0, GY, LB, 100, 'solo');
    var seed = 5; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    var x = 800, n = 0, j;
    while (x < LB - 600) {
      n++;
      if (n % 4 === 0) { solid(x, 470, 180, 20, 'plat', 64); for (j = 0; j < 4; j++) fruit(x + 22 + j * 46, 432); x += 340; }
      else { var o = this.obst.create(x, GY - 16, 'bn_pedra').setScale(4).setDepth(3); o.refreshBody(); for (j = 0; j < 5; j++) { var t = j / 4; fruit(x - 70 + t * 140, GY - 60 - Math.sin(t * Math.PI) * 120); } x += 280 + Math.floor(rnd() * 160); }
    }
    this.finX = LB - 260; this.add.image(this.finX, GY + 4, 'bandeira').setOrigin(0.5, 1).setScale(4).setDepth(3);
    this.add.text(this.finX, GY - 190, 'CHEGADA', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', backgroundColor: '#00000088', padding: { x: 6, y: 2 } }).setOrigin(0.5).setDepth(4);
    this.p = this.physics.add.sprite(120, GY - 60, 'av0').setScale(4).setDepth(5); this.p.body.setSize(10, 23).setOffset(7, 3);
    this.physics.add.collider(this.p, this.solids);
    this.physics.add.overlap(this.p, this.fruits, function (pl, f) { f.destroy(); sc.frutas++; snd('saber'); sc.hud(); });
    this.physics.add.overlap(this.p, this.obst, function () { sc.hit(); });
    this.cameras.main.startFollow(this.p, true, 0.1, 0.1); this.cameras.main.setDeadzone(120, 80); spawnFaunaLado(this, 'Vila Mutirão', LB, true);
    this.frutas = 0; this.tempo = 80000; this.inv = 0; this.knock = 0; this.coy = 0; this.over = false; this.leaving = false;
    this.hudT = this.add.text(W / 2, 74, '', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 5 }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(100);
    this.add.text(W / 2, 108, 'Setas andam · Espaço pula (segure = mais alto) · [Esc] sai', { fontFamily: FONT, fontSize: '14px', color: '#fff', backgroundColor: '#00000088', padding: { x: 5, y: 1 } }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(100);
    this.hud();
    if (!E.flags.bonusIntro) { E.flags.bonusIntro = true; this.time.delayedCall(300, function () { E.ui.run([{ s: 'ARBOVIA', t: 'Mutirão de Colheita! É só diversão: corra, pule as pedras e junte as frutas de pequi até a bandeira. Pedra no caminho custa 3 segundos.' }, { s: 'ARBOVIA', t: 'Quem junta bastante leva Meios de presente (uma vez por dia). Não é obrigatório para a história.' }]); }); }
  },
  hud: function () { this.hudT.setText('Frutas ' + this.frutas + '/' + this.total + '    Tempo ' + Math.max(0, Math.ceil(this.tempo / 1000)) + ' s'); },
  hit: function () { if (this.inv > 0 || this.over) return; this.inv = 900; this.knock = 250; this.tempo -= 3000; this.p.setVelocityY(-380); snd('bad'); E.ui.toast('Tropeçou! −3 s'); this.hud(); },
  update: function (time, delta) {
    var s = this.ctl.poll(), p = this.p, ui = E.ui; if (!ui || !ui.hudT || this.leaving) return;
    var scx = this.cameras.main.scrollX; this.hillsL.forEach(function (h) { h[0].tilePositionX = scx * h[1] / 4; });
    if (this.over) { p.setVelocityX(0); if (this.overAt === undefined) this.overAt = time; if (!ui.busy && time - this.overAt > 600) this.leave(); return; } // sai quando a mensagem final fecha (E ou 7 s)
    if (ui.busy) { p.setVelocityX(0); return; }
    this.inv -= delta; this.knock -= delta; this.tempo -= delta; this._h = (this._h || 0) + delta; if (this._h > 250) { this._h = 0; this.hud(); }
    var onG = p.body.blocked.down; this.coy = onG ? 120 : this.coy - delta;
    var vx = this.knock > 0 ? -220 : ((s.right ? 1 : 0) - (s.left ? 1 : 0)) * SPD; p.setVelocityX(vx);
    if (s.jump && this.coy > 0) { p.setVelocityY(JUMP); this.coy = 0; snd('jump'); }
    if (!s.jumpHeld && p.body.velocity.y < -250) p.setVelocityY(p.body.velocity.y * 0.85);
    p.setTexture(!onG ? 'avj' : vx ? (Math.floor(time / 110) % 2 ? 'av1' : 'av2') : 'av0'); if (vx) p.setFlipX(vx < 0);
    p.setAlpha(this.inv > 0 && Math.floor(time / 80) % 2 ? 0.4 : 1);
    if (p.x > this.finX) this.finish(true); else if (this.tempo <= 0) this.finish(false);
    if (s.esc) this.leave();
  },
  finish: function (done) {
    if (this.over) return; this.over = true; this.p.setVelocityX(0); var sc = this, f = this.frutas, rw = f >= 30 ? 2 : f >= 15 ? 1 : 0;
    var hoje = new Date().toISOString().slice(0, 10), novo = E.flags.bonusDia !== hoje, ganho = 0;
    if (rw > 0 && novo) { ganho = rw; E.flags.bonusDia = hoje; chg('Meios', rw); }
    E.flags.bonusBest = Math.max(E.flags.bonusBest || 0, f); E.persist(); if (window.Snd) Snd.jingle(rw > 0 ? 'vitoria' : 'roda');
    var msg = (done ? 'Você cruzou a bandeira' : 'O tempo acabou') + ' com ' + f + ' de ' + this.total + ' frutas. Seu recorde: ' + E.flags.bonusBest + '. ' + (ganho ? 'Presente: Meios +' + ganho + '!' : rw > 0 ? 'Hoje você já ganhou o presente deste bônus; volte amanhã.' : 'Com 15 frutas ou mais você ganha Meios (uma vez por dia).');
    E.ui.run([{ s: 'ARBOVIA', t: msg }], function () { sc.leave(); });
  },
  leave: function () { if (this.leaving) return; this.leaving = true; E.ui.prompt(); this.scene.start('Regiao', { dom: E.bonusDom || 'Vila Mutirão' }); }
});

/* ---------- Corrida: as atividades em movimento lateral (estilo plataforma) ----------
   Um motor só, com um "cenário de regra" por tipo: pega, quiz, ritmo, memória e caça-palavras.
   A versão clássica (telas fixas) continua disponível com [T] (E.flags.ativClassica). */
var CORR_TIPOS = { pega: 1, quiz: 1, ritmo: 1, memoria: 1, palavras: 1 };
function corrJogavel(C) { return !!(C && CORR_TIPOS[C.tipo] && !C.after); }
var PAL_LISTA = ['CISTERNA', 'FONTE', 'CHUVA', 'TAMPA', 'FILTRO', 'AGUA'];
var Corrida = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function Corrida() { Phaser.Scene.call(this, { key: 'Corrida' }); },
  init: function (d) { this.id = d.id; this.from = d.from || { scene: 'World' }; this.C = ATIV[this.id]; },
  norm: function (key, px) { if (!this.textures.exists(key)) key = 'bn_fruta'; var f = this.textures.get(key).getSourceImage(); return px / Math.max(f.width || 16, f.height || 16); },
  solid: function (x, y, w, h, key, vh) { this.solids.create(x + w / 2, y + h / 2, 'px').setVisible(false).setDisplaySize(w, h).refreshBody(); return this.add.tileSprite(x, y, w, vh || h, key).setOrigin(0, 0).setTileScale(4, 4).setDepth(2); },
  rnd: function () { this.seed = (this.seed * 9301 + 49297) % 233280; return this.seed / 233280; },
  create: function () {
    var sc = this, C = this.C, T = C.tipo; E.curLvl = -3; music(C.mus || 'mapa'); this.ctl = new Ctl(this);
    this.kk = this.input.keyboard.addKeys('ENTER,E,R,T,ONE,TWO,THREE'); this.jd = {};
    this.over = false; this.leaving = false; this.inv = 0; this.knock = 0; this.coy = 0; this.el = 0; this.hillsL = []; this.seed = 11 + this.id.length * 7;
    var LB = T === 'quiz' ? C.rounds.length * 1500 + 1700 : T === 'ritmo' ? Math.round(C.notas * Math.max(C.gap * 1.5, 1100) * 0.24) + 1800 : T === 'memoria' ? 12 * 290 + 1800 : T === 'palavras' ? PAL_LISTA.length * 1000 + 1600 : 5600;
    this.LB = LB; this.physics.world.gravity.y = GRAV; this.cameras.main.setBounds(0, 0, LB, H); this.physics.world.setBounds(0, -400, LB, H + 800);
    this.add.image(0, 0, 'ceu').setOrigin(0, 0).setScale(4).setScrollFactor(0).setDepth(-40);
    [['colinas1', 0.1], ['colinas2', 0.2], ['colinas3', 0.35]].forEach(function (h, i) { var t = sc.add.tileSprite(0, 320, W, 400, h[0]).setOrigin(0, 0).setScrollFactor(0).setTileScale(4, 4).setDepth(-30 + i); t.tilePositionY = 80; sc.hillsL.push([t, h[1]]); });
    this.solids = this.physics.add.staticGroup(); this.solid(0, GY, LB, 100, 'solo');
    this.finX = LB - 260; this.add.image(this.finX, GY + 4, 'bandeira').setOrigin(0.5, 1).setScale(4).setDepth(3);
    this.add.text(this.finX, GY - 190, 'CHEGADA', { fontFamily: FONT, fontSize: '22px', fontStyle: 'bold', color: '#fff', backgroundColor: '#00000088', padding: { x: 6, y: 2 } }).setOrigin(0.5).setDepth(4);
    this.p = this.physics.add.sprite(120, GY - 60, 'av0').setScale(4).setDepth(5); this.p.body.setSize(10, 23).setOffset(7, 3);
    this.physics.add.collider(this.p, this.solids);
    this.cameras.main.startFollow(this.p, true, 0.1, 0.1); this.cameras.main.setDeadzone(120, 80);
    try { spawnFaunaLado(this, (this.from.data && this.from.data.dom) || 'Vila Mutirão', LB, true); } catch (e) {}
    this.add.text(W / 2, 60, C.nome, { fontFamily: FONT, fontSize: '24px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 5 }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(100);
    this.hudT = this.add.text(W / 2, 90, '', { fontFamily: FONT, fontSize: '20px', fontStyle: 'bold', color: '#fff', stroke: '#3b2a2a', strokeThickness: 5 }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(100);
    this.foot = this.add.text(W / 2, 712, '', { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#00000099', padding: { x: 6, y: 2 } }).setOrigin(0.5, 1).setScrollFactor(0).setDepth(100);
    this.foot.setText((T === 'ritmo' ? 'Espaço/↑ pula no compasso' : '←→ andam · Espaço pula (segure = mais alto)') + ' · [Esc] sai · [T] versão clássica');
    this['b_' + T](); this.hud();
  },
  hit: function (msg) {
    if (this.inv > 0 || this.over) return; this.inv = 900; this.knock = 220; this.p.setVelocityY(-340); snd('bad'); if (this.tempo !== undefined) this.tempo -= 3000; if (msg && E.ui) E.ui.toast(msg); this.hud();
  },
  leave: function () { if (this.leaving) return; this.leaving = true; E.ui.prompt(); this.scene.start(this.from.scene, this.from.data); },
  fim: function (pct, extra) {
    if (this.over) return; this.over = true; this.p.setVelocityX(0); pct = Phaser.Math.Clamp(pct, 0, 1);
    var txt = atvPremio(this.id, pct); snd(pct >= 0.6 ? 'saber' : 'bad'); if (window.Snd && pct >= 0.6) Snd.jingle('vitoria');
    var sc = this, P = this.add.container(0, 0).setScrollFactor(0).setDepth(200);
    P.add([pxPanel(this, 240, 190, 800, 330, '#f6ecd0', '#3b2a2a', 4), this.add.text(W / 2, 220, 'Resultado: ' + Math.round(pct * 100) + '%', { fontFamily: FONT, fontSize: '36px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5, 0),
      this.add.text(W / 2, 285, (extra ? extra + ' ' : '') + txt, { fontFamily: FONT, fontSize: '20px', color: '#3b2a2a', align: 'center', wordWrap: { width: 740 } }).setOrigin(0.5, 0)]);
    this.foot.setText('[Enter] voltar · [R] jogar de novo · [T] versão clássica');
  },
  hud: function () {
    var T = this.C.tipo, s = '';
    if (T === 'pega') s = 'Tempo ' + Math.max(0, Math.ceil(this.tempo / 1000)) + ' s · Pegou ' + this.good + '/' + this.C.meta + ' · Tropeços ' + this.bad;
    else if (T === 'quiz') s = 'Perguntas ' + this.answered + '/' + this.C.rounds.length + ' · Acertos ' + this.score;
    else if (T === 'ritmo') s = 'No compasso ' + this.passed + '/' + this.obs.length + ' · Tropeços ' + this.bad;
    else if (T === 'memoria') s = 'Jogadas ' + this.moves + ' · Pares ' + this.found + '/6 (bata nos blocos por baixo)';
    else if (T === 'palavras') { var w = Math.min(PAL_LISTA.length - 1, Math.max(0, Math.floor((this.p.x - 800) / 1000))); s = 'Achadas ' + this.nfound + '/' + PAL_LISTA.length + ' · ' + PAL_LISTA[w] + ': ' + PAL_LISTA[w].slice(0, this.prog[w]) + '_'.repeat(PAL_LISTA[w].length - this.prog[w]); }
    this.hudT.setText(s);
  },
  update: function (time, delta) {
    var ui = E.ui; if (!ui || !ui.hudT || this.leaving) return;
    var self = this, s = this.ctl.poll(), p = this.p, scx = this.cameras.main.scrollX; this.hillsL.forEach(function (h) { h[0].tilePositionX = scx * h[1] / 4; });
    Object.keys(this.kk).forEach(function (k) { self.jd[k] = Phaser.Input.Keyboard.JustDown(self.kk[k]); });
    if (this.over) { p.setVelocityX(0); if (this.jd.ENTER || this.jd.E) this.leave(); else if (this.jd.R) { this.leaving = true; this.scene.restart({ id: this.id, from: this.from }); } else if (this.jd.T) { E.flags.ativClassica = true; E.persist(); this.leaving = true; this.scene.start('Ativ', { id: this.id, from: this.from }); } return; }
    if (this.jd.T) { E.flags.ativClassica = true; E.persist(); this.leaving = true; this.scene.start('Ativ', { id: this.id, from: this.from }); return; }
    if (ui.busy) { p.setVelocityX(0); return; }
    if (s.esc) { this.leave(); return; }
    this.inv -= delta; this.knock -= delta; this.el += delta;
    var auto = this.C.tipo === 'ritmo' ? (this.el > 1200 ? 240 : 0) : 0, onG = p.body.blocked.down; this.coy = onG ? 120 : this.coy - delta;
    var vx = this.knock > 0 && !auto ? -200 : auto ? auto : ((s.right ? 1 : 0) - (s.left ? 1 : 0)) * SPD; p.setVelocityX(vx);
    if (s.jump && this.coy > 0) { p.setVelocityY(JUMP); this.coy = 0; snd('jump'); }
    if (!s.jumpHeld && p.body.velocity.y < -250) p.setVelocityY(p.body.velocity.y * 0.85);
    p.setTexture(!onG ? 'avj' : vx ? (Math.floor(time / 110) % 2 ? 'av1' : 'av2') : 'av0'); if (vx) p.setFlipX(vx < 0);
    p.setAlpha(this.inv > 0 && Math.floor(time / 80) % 2 ? 0.4 : 1);
    var fn = this['u_' + this.C.tipo]; if (fn) fn.call(this, time, delta, s);
    this._h = (this._h || 0) + delta; if (this._h > 200) { this._h = 0; this.hud(); }
  },
  /* ---- pega: junte o que é bom, pule o que é ruim ---- */
  b_pega: function () {
    var sc = this, C = this.C, x = 700, n = 0; this.good = 0; this.bad = 0; this.tempo = (C.dur + 30) * 1000; this.itens = this.physics.add.staticGroup(); this.perig = this.physics.add.staticGroup();
    function item(x, y, bad) { var key = bad ? C.ruim : C.bom, o = (bad ? sc.perig : sc.itens).create(x, y, key).setScale(sc.norm(key, bad ? 64 : 44)).setDepth(3); o.refreshBody(); if (!bad) sc.tweens.add({ targets: o, y: y - 8, yoyo: true, repeat: -1, duration: 600 + (x % 5) * 60 }); }
    while (x < this.LB - 700) {
      n++;
      if (n % 3 === 0) { this.solid(x, GY - 120, 200, 20, 'plat', 64); for (var j = 0; j < 3; j++) item(x + 40 + j * 60, GY - 165, false); x += 420; }
      else if (this.rnd() < C.pr + 0.2) { item(x, GY - 32, true); for (j = 0; j < 4; j++) { var t = j / 3; item(x - 90 + t * 180, GY - 70 - Math.sin(t * Math.PI) * 120, false); } x += 320 + Math.floor(this.rnd() * 140); }
      else { var hy = GY - 50 - Math.floor(this.rnd() * 70); for (j = 0; j < 3; j++) item(x + j * 56, hy, false); x += 260; }
    }
    this.physics.add.overlap(this.p, this.itens, function (pl, f) { f.destroy(); sc.good++; snd('saber'); sc.hud(); });
    this.physics.add.overlap(this.p, this.perig, function () { if (sc.inv <= 0) sc.bad++; sc.hit('Tropeçou! −3 s'); });
  },
  u_pega: function (time, delta) {
    this.tempo -= delta; if (this.p.x > this.finX || this.tempo <= 0) this.fim((this.good - this.bad * 0.5) / this.C.meta, 'Você pegou ' + this.good + ' e tropeçou ' + this.bad + ' vezes.');
  },
  /* ---- ritmo: corrida automática, pule no compasso ---- */
  b_ritmo: function () {
    var sc = this, C = this.C, sp = Math.max(C.gap * 1.5, 1100) * 0.24, x = 900; this.obs = []; this.passed = 0; this.bad = 0; this.perig = this.physics.add.staticGroup();
    for (var i = 0; i < C.notas; i++) {
      var longo = C.lanes.length > 1 && this.rnd() < 0.25, o = this.perig.create(x, longo ? GY - 40 : GY - 32, longo ? 'ct_cerca' : 'bn_pedra').setScale(this.norm(longo ? 'ct_cerca' : 'bn_pedra', longo ? 62 : 60)).setDepth(3); o.refreshBody(); o.n = { x: x, hit: false, ok: false }; this.obs.push(o.n);
      if (this.rnd() < 0.6) { var f = this.add.image(x, GY - 150, 'bn_fruta').setScale(this.norm('bn_fruta', 34)).setDepth(3); this.tweens.add({ targets: f, y: GY - 160, yoyo: true, repeat: -1, duration: 500 }); }
      x += sp;
    }
    this.finX = x + 500; this.cameras.main.setFollowOffset(-260, 0); this.cameras.main.setDeadzone(0, 80);
    this.physics.add.overlap(this.p, this.perig, function (pl, o) { if (Math.abs(pl.x - o.x) > o.displayWidth / 2 + 8 || pl.body.bottom < o.y - o.displayHeight / 2 + 10) return; if (!o.n.hit) { o.n.hit = true; sc.bad++; } sc.hit(); }); // folga: encostar de leve não conta
  },
  u_ritmo: function () {
    var p = this.p, self = this; this.obs.forEach(function (o) { if (!o.ok && !o.hit && p.x > o.x + 50) { o.ok = true; self.passed++; snd('saber'); } });
    if (p.x > this.finX) this.fim(this.passed / this.obs.length, 'No compasso: ' + this.passed + ' de ' + this.obs.length + '.');
  },
  /* ---- quiz: bata no bloco da resposta certa ---- */
  b_quiz: function () {
    var sc = this, C = this.C; this.gates = []; this.score = 0; this.answered = 0; this.blocos = this.physics.add.staticGroup(); this.perig = this.physics.add.staticGroup();
    C.rounds.forEach(function (r, i) {
      var x0 = 900 + i * 1500, g = { x0: x0, x1: x0 + 1250, r: r, ord: Phaser.Utils.Array.Shuffle(r.o.map(function (o, k) { return k; })), done: false, bl: [] };
      var pd = sc.perig.create(x0 + 330, GY - 32, 'bn_pedra').setScale(sc.norm('bn_pedra', 60)).setDepth(3); pd.refreshBody();
      for (var f = 0; f < 4; f++) { var fr = sc.add.image(x0 + 120 + f * 60, GY - 120 - Math.sin(f / 3 * Math.PI) * 60, 'bn_fruta').setScale(sc.norm('bn_fruta', 34)).setDepth(3); }
      g.ord.forEach(function (oi, j) {
        var bx = x0 + 650 + j * 170, by = GY - 215, rc = sc.add.rectangle(bx, by, 110, 60, 0xffd23a).setStrokeStyle(4, 0x3b2a2a).setDepth(3); sc.physics.add.existing(rc, true); sc.blocos.add(rc);
        rc.g = g; rc.j = j; rc.lbl = sc.add.text(bx, by, String(j + 1), { fontFamily: FONT, fontSize: '34px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(4); g.bl.push(rc);
      });
      g.bar = sc.add.rectangle(g.x1, GY - 200, 36, 400, 0x8b5a2b).setStrokeStyle(4, 0x3b2a2a).setDepth(3); sc.physics.add.existing(g.bar, true); sc.solids.add(g.bar);
      g.sign = sc.add.text(g.x1, GY - 420, 'Responda\npara passar', { fontFamily: FONT, fontSize: '16px', color: '#fff', backgroundColor: '#00000099', align: 'center', padding: { x: 4, y: 2 } }).setOrigin(0.5).setDepth(4);
      sc.gates.push(g);
    });
    this.qP = this.add.container(0, 0).setScrollFactor(0).setDepth(90).setVisible(false);
    this.qBg = pxPanel(this, 60, 124, 1160, 190, '#f6ecd0', '#3b2a2a', 4); this.qTx = this.add.text(90, 138, '', { fontFamily: FONT, fontSize: '20px', color: '#3b2a2a', wordWrap: { width: 1100 }, lineSpacing: 4 });
    this.qP.add([this.qBg, this.qTx]);
    this.physics.add.collider(this.p, this.blocos, function (pl, b) { if (pl.body.touching.up || pl.body.blocked.up) sc.pick(b.g, b.j); });
    this.physics.add.overlap(this.p, this.perig, function () { sc.hit(); });
    if (C.intro && E.ui) this.time.delayedCall(250, function () { E.ui.run([{ s: 'ARBOVIA', t: C.intro + ' Corra e bata por baixo no bloco da resposta certa (ou aperte 1, 2 ou 3).' }]); });
  },
  pick: function (g, j) {
    if (!g || g.done || this.over) return; g.done = true; var r = g.r, ok = g.ord[j] === r.c; this.answered++; if (ok) this.score++; this.lastG = g; this.fbT = this.time.now;
    snd(ok ? 'saber' : 'bad'); g.bl.forEach(function (b, k) { b.setFillStyle(k === j ? (ok ? 0x6fd36f : 0xe05a5a) : g.ord[k] === r.c ? 0x6fd36f : 0xc9b98a); });
    g.fb = (ok ? 'Certo! ' : 'Quase! ') + r.f; g.fbOk = ok; g.bar.destroy(); g.sign.destroy(); this.hud();
  },
  u_quiz: function () {
    var p = this.p, g = null, i; for (i = 0; i < this.gates.length; i++) if (!this.gates[i].done) { g = this.gates[i]; break; }
    var k = this.jd.ONE ? 0 : this.jd.TWO ? 1 : this.jd.THREE ? 2 : -1;
    if (g && k >= 0 && k < g.ord.length && p.x > g.x0 - 450) this.pick(g, k);
    var show = null, txt = '', col = '#3b2a2a';
    if (this.lastG && p.x < this.lastG.x1 + 250 && (!g || p.x < g.x0 - 450)) { show = this.lastG; txt = this.lastG.fb; col = this.lastG.fbOk ? '#1f6a2c' : '#a02c2c'; }
    else if (g && p.x > g.x0 - 450) { show = g; txt = (this.gates.indexOf(g) + 1) + '/' + this.gates.length + '  ' + g.r.p + '\n\n' + g.ord.map(function (oi, j) { return (j + 1) + '. ' + g.r.o[oi]; }).join('\n'); }
    this.qP.setVisible(!!show); if (show) this.qTx.setText(txt).setColor(col);
    if (p.x > this.finX) this.fim(this.score / this.C.rounds.length, 'Você acertou ' + this.score + ' de ' + this.C.rounds.length + '.');
  },
  /* ---- memória: blocos de bichos, bata por baixo para virar ---- */
  b_memoria: function () {
    var sc = this, sp = []; ESPECIES.forEach(function (e) { if (sc.textures.exists('an_' + e[0] + '_0')) sp.push(e[0]); });
    var deck = Phaser.Utils.Array.Shuffle(Phaser.Utils.Array.Shuffle(sp).slice(0, 6)); deck = Phaser.Utils.Array.Shuffle(deck.concat(deck));
    this.cards = []; this.moves = 0; this.found = 0; this.open = []; this.lockM = false; this.blocos = this.physics.add.staticGroup(); this.perig = this.physics.add.staticGroup();
    deck.forEach(function (k, i) {
      var bx = 800 + i * 290, by = GY - 215, rc = sc.add.rectangle(bx, by, 110, 60, 0xc8a060).setStrokeStyle(4, 0x3b2a2a).setDepth(3); sc.physics.add.existing(rc, true); sc.blocos.add(rc);
      var q = sc.add.text(bx, by, '?', { fontFamily: FONT, fontSize: '40px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(4), im = sc.add.image(bx, by - 40, 'an_' + k + '_0').setScale(sc.norm('an_' + k + '_0', 80)).setOrigin(0.5, 1).setDepth(4).setVisible(false);
      rc.c = { k: k, rc: rc, q: q, im: im, up: false, ok: false }; sc.cards.push(rc.c);
      if (i % 2 === 1) { var pd = sc.perig.create(bx + 145, GY - 32, 'bn_pedra').setScale(sc.norm('bn_pedra', 56)).setDepth(3); pd.refreshBody(); }
    });
    this.physics.add.collider(this.p, this.blocos, function (pl, b) { if (pl.body.touching.up || pl.body.blocked.up) sc.flip(b.c); });
    this.physics.add.overlap(this.p, this.perig, function () { sc.hit(); });
  },
  flip: function (c) {
    var sc = this; if (this.lockM || c.up || c.ok || this.over) return; c.up = true; c.q.setVisible(false); c.im.setVisible(true); c.rc.setFillStyle(0xffe08a); this.open.push(c); snd('move');
    if (this.open.length === 2) {
      this.moves++; var a = this.open[0], b = this.open[1]; this.lockM = true;
      if (a.k === b.k) { a.ok = b.ok = true; a.rc.setFillStyle(0x6fd36f); b.rc.setFillStyle(0x6fd36f); this.found++; snd('saber'); this.open = []; this.lockM = false; if (this.found >= 6) this.time.delayedCall(700, function () { sc.fim(Math.min(1, 9 / sc.moves), 'Em ' + sc.moves + ' jogadas.'); }); }
      else this.time.delayedCall(900, function () { [a, b].forEach(function (x) { x.up = false; x.q.setVisible(true); x.im.setVisible(false); x.rc.setFillStyle(0xc8a060); }); sc.open = []; sc.lockM = false; });
    }
    this.hud();
  },
  u_memoria: function () { if (this.p.x > this.finX) this.fim(this.found / 6 * 0.9, 'Você achou ' + this.found + ' de 6 pares.'); },
  /* ---- caça-palavras: junte as letras na ordem, fuja das letras erradas ---- */
  b_palavras: function () {
    var sc = this, AL = 'AEIOUSRTLNMCP'; this.prog = PAL_LISTA.map(function () { return 0; }); this.nfound = 0; this.letras = []; this.lg = this.physics.add.staticGroup(); var ys = [GY - 60, GY - 130, GY - 200];
    PAL_LISTA.forEach(function (w, wi) {
      var x0 = 800 + wi * 1000, passo = 780 / w.length;
      sc.add.text(x0 + 60, GY - 330, 'Palavra ' + (wi + 1) + ': ' + w.length + ' letras', { fontFamily: FONT, fontSize: '18px', color: '#fff', backgroundColor: '#00000088', padding: { x: 6, y: 2 } }).setDepth(4);
      for (var j = 0; j < w.length; j++) sc.letra(x0 + 120 + j * passo, ys[(j + wi) % 3], w[j], wi, j);
      for (var d = 0; d < 2; d++) { var dl = AL[Math.floor(sc.rnd() * AL.length)], k = 1 + d * 3 + Math.floor(sc.rnd() * 2); sc.letra(x0 + 120 + (Math.min(k, w.length - 2) + 0.5) * passo, ys[(k + wi + 1) % 3], dl, wi, -1); }
    });
    this.physics.add.overlap(this.p, this.lg, function (pl, o) { sc.toca(o.L); });
  },
  letra: function (x, y, ch, wi, j) {
    var dec = j < 0, o = this.add.circle(x, y, 26, dec ? 0xe0a040 : 0xfff7dc).setStrokeStyle(4, 0x3b2a2a).setDepth(3); this.physics.add.existing(o, true); this.lg.add(o);
    o.L = { o: o, t: this.add.text(x, y, ch, { fontFamily: FONT, fontSize: '28px', fontStyle: 'bold', color: '#3b2a2a' }).setOrigin(0.5).setDepth(4), w: wi, j: j, got: false }; this.letras.push(o.L);
  },
  toca: function (L) {
    if (L.got || this.over) return;
    if (L.j < 0) { if (this.inv > 0) return; this.inv = 900; snd('bad'); var self = this, w = L.w; if (this.prog[w] >= PAL_LISTA[w].length) return; this.prog[w] = 0; this.letras.forEach(function (x) { if (x.w === w && x.j >= 0) { x.got = false; x.o.setFillStyle(0xfff7dc); x.t.setAlpha(1); } }); if (E.ui) E.ui.toast('Letra errada! A palavra recomeça.'); return; }
    if (L.j === this.prog[L.w]) { L.got = true; this.prog[L.w]++; L.o.setFillStyle(0x6fd36f); snd('move'); if (this.prog[L.w] === PAL_LISTA[L.w].length) { this.nfound++; snd('saber'); if (E.ui) E.ui.toast('Palavra: ' + PAL_LISTA[L.w] + '!'); } this.hud(); }
  },
  u_palavras: function () { if (this.p.x > this.finX) this.fim(this.nfound / PAL_LISTA.length, 'Palavras achadas: ' + this.nfound + ' de ' + PAL_LISTA.length + '.'); }
});


/* ---------- Veredália (multiplayer do território) ---------- */
// Só existe com E.mundo (entrada pela Sala de Cooperação). Contato por presença, Mutirão, mural de frases prontas e
// "como o grupo decidiu". Sem chat livre; só a gestão da sala publica avisos em texto.
function mundoApi(path, opt) {
  opt = opt || {}; opt.headers = Object.assign({ Authorization: 'Bearer ' + E.token, 'Content-Type': 'application/json' }, opt.headers || {});
  return fetch('api/mundo/' + path, opt).then(function (r) { return r.json().then(function (j) { j._ok = r.ok; j._st = r.status; return j; }); }).catch(function () { return null; });
}
function mundoIniciar() {
  if (!E.mundo || E._mundoOn) return; E._mundoOn = true;
  var bat = function () {
    mundoApi('presenca', { method: 'POST', body: '{}' });
    mundoApi('caixa').then(function (c) { if (!c || !c._ok) return; (c.itens || []).forEach(function (it) { chg(it.tipo, 1); if (E.ui) E.ui.toast(it.de + ' te presenteou com 1 ' + it.tipo + '.'); }); });
  };
  bat(); setInterval(bat, 30000);
  // renova o token (validade curta); se a pessoa saiu da sala ou a Veredália fechou, o acesso se encerra
  setInterval(function () {
    fetch('renovar/?sala=' + E.mundo.id, { credentials: 'same-origin' }).then(function (r) { if (r.status === 403) { E.token = null; if (E.ui) E.ui.toast('Seu acesso à Veredália terminou. Seu progresso está guardado.'); } else if (r.ok) return r.json().then(function (j) { if (j.token) E.token = j.token; }); }).catch(function () {});
  }, 40 * 60 * 1000);
  setTimeout(function () { mundoApi('presenca').then(function (p) { if (p && E.ui) E.ui.toast('Veredália de ' + E.mundo.nome + ': ' + p.n + (p.n === 1 ? ' pessoa na Vila agora' : ' pessoas na Vila agora') + '. Mural em [N]'); }); }, 2500);
}
function quandoLivre(fn, tent) { tent = tent || 0; if (!E.ui) return; if (E.ui.busy && tent < 25) { setTimeout(function () { quandoLivre(fn, tent + 1); }, 600); return; } fn(); }
var _okId = function (x) { return String(x || '').toLowerCase().replace(/[^0-9a-z_-]/g, '').slice(0, 20); };
function grupoDecidiu(lvl, r) { // registra a decisão da fase e mostra como o território decidiu (só com amostra mínima)
  var p = probDe(lvl); if (!p || !E.mundo) return;
  var ID = function (x) { x = String(x || ''); x = { 'poder público': 'poder', 'médio': 'medio' }[x] || x; return _okId(x); };
  var dec = [[lvl * 10 + 1, ID(r.ag), 'Quem puxa a ação'], [lvl * 10 + 2, ID(r.pz), 'Prazo'], [lvl * 10 + 3, ID(r.cls), 'Classificação']].filter(function (d) { return d[1]; });
  var nomes = { comunidade: 'comunidade', poder: 'poder público', parceria: 'parceria', curto: 'curto', medio: 'médio', longo: 'longo', ameaca: 'ameaça', vuln: 'vulnerabilidade', resil: 'resiliência', incerta: 'incerteza' };
  Promise.all(dec.map(function (d) { return mundoApi('decisao', { method: 'POST', body: JSON.stringify({ prob: d[0], opcao: d[1] }) }); })).then(function (res) {
    var linhas = [], n = 0, pouco = false;
    res.forEach(function (j, i) {
      if (!j || !j._ok) return; n = Math.max(n, j.n);
      if (j.pouco) { pouco = true; return; }
      var ops = Object.keys(j.opcoes).sort(function (a, b) { return j.opcoes[b] - j.opcoes[a]; }).map(function (k) { return (nomes[k] || k) + ' ' + j.opcoes[k] + '%'; });
      linhas.push(dec[i][2] + ': ' + ops.join(' · '));
    });
    var msg = linhas.length ? 'Como a Veredália de ' + E.mundo.nome + ' decidiu (' + n + ' pessoas): ' + linhas.join('. ') + '.' : (pouco ? 'Sua decisão entrou no grupo. Quando mais gente da sala decidir este problema (' + n + ' de ' + 5 + ' até agora), você vê como a Veredália pensou.' : null);
    if (msg) quandoLivre(function () { E.ui.run([{ s: MES, t: msg }]); });
  });
}
E.grupoDecidiu = grupoDecidiu; // exposto para testes
// Vila: visitantes como figuras de sombra azul, com o primeiro nome; gestos [H = acenar] ou pelo Mural (N)
var GESTOS_TXT = { oi: 'Oi!', valeu: 'Valeu!', bora: 'Bora!', parabens: 'Parabéns!', ajuda: 'Preciso de ajuda' };
function vilaIniciar(sc) {
  if (!E.mundo || !E.token) return;
  var gh = {}, bolha = function (x, y, tx, cor) { var t = sc.add.text(x, y, tx, { fontFamily: FONT, fontSize: '18px', color: '#14213d', backgroundColor: cor || '#ffd23a', padding: { x: 6, y: 3 } }).setOrigin(0.5, 1).setDepth(2100); sc.time.delayedCall(3500, function () { t.destroy(); }); return t; };
  E.gesto = function (g) { E.gestoPend = g; bolha(sc.p.x, sc.p.y - 90, GESTOS_TXT[g] || g); };
  sc.input.keyboard.on('keydown-H', function () { if (!E.ui || !E.ui.busy) E.gesto('oi'); });
  function tick() {
    if (!E.token || !sc.p || !sc.p.active) return;
    var g = E.gestoPend; E.gestoPend = null;
    mundoApi('pos', { method: 'POST', body: JSON.stringify({ x: Math.round(sc.p.x), y: Math.round(sc.p.y), cena: 'World', g: g || undefined }) }).then(function (r) {
      if (!r || !r._ok || !sc.sys || !sc.sys.isActive()) return; var vistos = {};
      (r.outros || []).forEach(function (o) {
        vistos[o.q] = 1; var f = gh[o.q];
        if (!f) { f = gh[o.q] = { img: sc.add.image(o.x, o.y, 'av0').setScale(4).setDepth(499).setTint(0x9ec8ff).setAlpha(0.85), lb: sc.add.text(o.x, o.y - 80, o.nome, { fontFamily: FONT, fontSize: '15px', color: '#fff', backgroundColor: '#14213d', padding: { x: 5, y: 2 } }).setOrigin(0.5, 1).setDepth(2000), tx: o.x, ty: o.y, gs: null }; }
        f.tx = o.x; f.ty = o.y;
        if (o.g && f.gs !== o.g) { f.gs = o.g; bolha(f.img.x, f.img.y - 110, o.g); sc.time.delayedCall(5000, function () { f.gs = null; }); }
      });
      Object.keys(gh).forEach(function (q) { if (!vistos[q]) { gh[q].img.destroy(); gh[q].lb.destroy(); delete gh[q]; } });
    });
  }
  sc.time.addEvent({ delay: 1500, loop: true, callback: tick }); tick();
  function lerp() { Object.keys(gh).forEach(function (q) { var f = gh[q]; f.img.x += (f.tx - f.img.x) * 0.15; f.img.y += (f.ty - f.img.y) * 0.15; f.lb.setPosition(f.img.x, f.img.y - 80); }); }
  sc.events.on('update', lerp);
  sc.events.once('shutdown', function () { sc.events.off('update', lerp); gh = {}; });
}

var _moTab = 'mural';
function mundoMural(forcaAbrir, aba) {
  var ov = document.getElementById('mundoOv');
  if (ov) { mundoFecha(); if (!forcaAbrir) return; }
  if (aba) _moTab = aba;
  if (!document.getElementById('mundoCss')) { var st = document.createElement('style'); st.id = 'mundoCss';
    st.textContent = '#mundoOv{position:fixed;inset:0;background:#0009;z-index:50;display:flex;align-items:center;justify-content:center;font-family:"Pixelify Sans",system-ui,sans-serif}#mundoOv .mopn{background:#f6ecd0;border:4px solid #3b2a2a;color:#3b2a2a;width:min(780px,94vw);max-height:90vh;overflow:auto;padding:16px 20px;box-shadow:6px 6px 0 #0006}#mundoOv h2{margin:0 0 4px;font-size:22px}#mundoOv .mosub{font-size:14px;margin:6px 0}#mundoOv .mobar{height:22px;background:#ccc;border:3px solid #3b2a2a;margin:4px 0 10px}#mundoOv .mobar i{display:block;height:100%;background:#3aa85a}#mundoOv .moit{border-left:5px solid #3b2a2a;background:#fff8;padding:5px 9px;margin:5px 0;font-size:15px}#mundoOv .moit.moav{border-color:#d9822b;background:#ffe9c2}#mundoOv .moit small{display:block;font-size:12px;opacity:.75}#mundoOv .mofr{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}#mundoOv button{font:inherit;font-size:14px;background:#ffd23a;border:3px solid #3b2a2a;color:#3b2a2a;padding:4px 9px;cursor:pointer}#mundoOv button:hover,#mundoOv button:focus{background:#ffe680;outline:3px solid #14213d}#mundoOv button.on{background:#14213d;color:#fff}#mundoOv button[disabled]{opacity:.45;cursor:default}#mundoOv input,#mundoOv select{font:inherit;padding:4px;border:3px solid #3b2a2a;box-sizing:border-box;max-width:100%}#mundoOv input{width:100%}#mundoOv .mox{float:right}#mundoOv .motabs{display:flex;gap:6px;margin:6px 0 10px;flex-wrap:wrap}';
    document.head.appendChild(st); }
  ov = document.createElement('div'); ov.id = 'mundoOv'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Veredália');
  var pn = document.createElement('div'); pn.className = 'mopn'; ov.appendChild(pn); document.body.appendChild(ov);
  try { E.game.input.keyboard.enabled = false; } catch (e) {}
  ov.addEventListener('keydown', function (e) { if (e.key === 'Escape') { e.preventDefault(); mundoFecha(); } });
  ov.addEventListener('click', function (e) { if (e.target === ov) mundoFecha(); });
  function el(t, c, tx) { var x = document.createElement(t); if (c) x.className = c; if (tx != null) x.textContent = tx; return x; }
  function btn(tx, fn, on) { var b = el('button', on ? 'on' : '', tx); b.onclick = fn; return b; }
  function sel(opts, val) { var s2 = el('select'); opts.forEach(function (o) { var op = el('option', '', o[1]); op.value = o[0]; s2.appendChild(op); }); if (val) s2.value = val; return s2; }
  var ST = { M: null, P: null, D: null, R: null };
  var AG = [['comunidade', 'A própria comunidade'], ['poder', 'O poder público'], ['parceria', 'Uma parceria dos dois']], PZ = [['curto', 'Curto prazo'], ['medio', 'Médio prazo'], ['longo', 'Longo prazo']];
  var NG = { comunidade: 'a própria comunidade', poder: 'o poder público', parceria: 'uma parceria', curto: 'curto prazo', medio: 'médio prazo', longo: 'longo prazo' };
  function recarrega(qual) { var ps = []; if (!qual || qual === 'mural') ps.push(mundoApi('mural').then(function (j) { ST.D = j && j._ok ? j : ST.D; })); if (!qual || qual === 'rodas') ps.push(mundoApi('rodas').then(function (j) { ST.R = j && j._ok ? j : ST.R; })); if (!qual || qual === 'pres') ps.push(mundoApi('presenca', { method: 'POST', body: '{}' }).then(function (j) { ST.P = j && j._ok ? j : ST.P; })); ps.push(mundoApi('mutirao').then(function (j) { ST.M = j && j._ok ? j : ST.M; })); return Promise.all(ps).then(desenha); }
  function aviso(tx) { if (E.ui) E.ui.toast(tx); }
  function desenha() {
    if (!document.getElementById('mundoOv')) return; var M = ST.M, P = ST.P, D = ST.D; pn.innerHTML = '';
    pn.appendChild(btn('Fechar [Esc]', mundoFecha)).className = 'mox';
    pn.appendChild(el('h2', '', 'Veredália de ' + E.mundo.nome));
    pn.appendChild(el('div', 'mosub', P ? ('Na Vila agora: ' + P.n + (P.nomes && P.nomes.length ? ' (' + P.nomes.join(', ') + ')' : '')) : 'Sem conexão com a Veredália.'));
    if (M) { var pc = Math.min(100, Math.round(100 * M.total / M.meta)); pn.appendChild(el('div', 'mosub', 'Mutirão da Veredália nesta semana: ' + M.total + ' de ' + M.meta + ' pontos (' + pc + '%)')); var bar = el('div', 'mobar'); var i = el('i'); i.style.width = pc + '%'; bar.appendChild(i); pn.appendChild(bar); }
    var tabs = el('div', 'motabs'); [['mural', 'Mural'], ['rodas', 'Rodas'], ['pres', 'Presentes e gestos']].forEach(function (t) { tabs.appendChild(btn(t[1], function () { _moTab = t[0]; recarrega(t[0]); }, _moTab === t[0])); }); pn.appendChild(tabs);
    if (_moTab === 'mural') {
      var lista = (D && D.itens) || [];
      if (!lista.length) pn.appendChild(el('div', 'mosub', 'Ainda não há recados. Seja a primeira pessoa a falar.'));
      lista.forEach(function (it) {
        var d = el('div', 'moit' + (it.tipo === 'aviso' ? ' moav' : ''), (it.tipo === 'aviso' ? 'AVISO DA GESTÃO: ' : '') + it.texto);
        d.appendChild(el('small', '', it.nome + ' · ' + new Date(it.ts * 1000).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })));
        if (D.gestor) d.appendChild(btn('Remover', function () { mundoApi('mural?id=' + it.id, { method: 'DELETE' }).then(function (j) { if (j && j.itens) { D.itens = j.itens; desenha(); } }); }));
        pn.appendChild(d);
      });
      pn.appendChild(el('div', 'mosub', 'Diga algo à Vila (frases prontas, uma por minuto):'));
      var fr = el('div', 'mofr');
      Object.keys((D && D.frases) || {}).forEach(function (k) { fr.appendChild(btn(D.frases[k], function () { mundoApi('mural', { method: 'POST', body: JSON.stringify({ frase: k }) }).then(function (j) { if (j && j.itens) { D.itens = j.itens; if (j._ok) snd('saber'); else aviso('Calma: uma frase por minuto.'); desenha(); } }); })); });
      pn.appendChild(fr);
      if (D && D.gestor) { pn.appendChild(el('div', 'mosub', 'Aviso oficial da gestão (texto livre):')); var inp = el('input'); inp.maxLength = 200; inp.placeholder = 'Escreva o aviso e aperte Enter'; inp.addEventListener('keydown', function (e) { e.stopPropagation(); if (e.key === 'Enter' && inp.value.trim()) { mundoApi('mural', { method: 'POST', body: JSON.stringify({ aviso: inp.value }) }).then(function (j) { if (j && j.itens) { D.itens = j.itens; desenha(); } }); } }); pn.appendChild(inp); }
    } else if (_moTab === 'rodas') {
      pn.appendChild(el('div', 'mosub', 'A Roda é uma conversa por turnos: até 4 pessoas, cada uma com uma perspectiva, decidem juntas quem puxa a ação e em que prazo. Fica aberta por 24 horas.'));
      var rodas = (ST.R && ST.R.rodas) || [], F = window.FAT;
      var novo = el('div', 'mofr'); var sp = sel((F ? F.probs : []).map(function (p, i) { return [String(i + 1), p.nome]; })); novo.appendChild(sp);
      novo.appendChild(btn('Abrir uma Roda', function () { var i = +sp.value; mundoApi('roda', { method: 'POST', body: JSON.stringify({ prob: i, nome: F.probs[i - 1].nome }) }).then(function (j) { if (j && !j._ok) aviso(j.erro === 'rodas_abertas' ? 'Já há Rodas demais abertas. Participe de uma.' : 'Limite de Rodas por dia atingido.'); recarrega('rodas'); }); }));
      pn.appendChild(novo);
      if (!rodas.length) pn.appendChild(el('div', 'mosub', 'Nenhuma Roda ainda.'));
      rodas.forEach(function (r) {
        var d = el('div', 'moit', 'Roda: ' + r.nome + (r.estado === 'aberta' ? ' (aberta, ' + r.n + ' de 4)' : ' (encerrada)'));
        d.appendChild(el('small', '', r.participantes.length ? r.participantes.map(function (p) { return p.nome + ' — ' + p.persp; }).join(' · ') : 'Ninguém participou ainda.'));
        if (r.resultado) d.appendChild(el('small', '', 'Tendência: quem puxa = ' + (NG[r.resultado.ag] || r.resultado.ag) + ' (' + r.resultado.ag_n + ' de ' + r.n + '); prazo = ' + (NG[r.resultado.pz] || r.resultado.pz) + ' (' + r.resultado.pz_n + ' de ' + r.n + ')' + (r.resultado.consenso ? ' · CONSENSO' : '')));
        if (r.estado === 'aberta' && !r.voce && r.n < 4 && r.livres.length) {
          var f = el('div', 'mofr'), sP = sel(r.livres.map(function (k) { return [k, ST.R.perspectivas[k]]; })), sA = sel(AG), sZ = sel(PZ);
          f.appendChild(sP); f.appendChild(sA); f.appendChild(sZ);
          f.appendChild(btn('Participar', function () { mundoApi('roda/voto', { method: 'POST', body: JSON.stringify({ id: r.id, persp: sP.value, ag: sA.value, pz: sZ.value }) }).then(function (j) { if (j && j._ok) { if (j.novo) { chg('Rede', 1); chg('Entendimento', 1); snd('saber'); aviso('Você participou da Roda: Rede +1, Entendimento +1.'); } } else aviso(j && j.erro === 'perspectiva_ocupada' ? 'Essa perspectiva já foi escolhida.' : 'Não foi possível participar.'); recarrega('rodas'); }); }));
          d.appendChild(f);
        } else if (r.voce) d.appendChild(el('small', '', 'Você participou desta Roda.'));
        if (r.estado === 'aberta' && (r.dono || (D && D.gestor) || E.mundo.papel === 'gestor')) d.appendChild(btn('Encerrar a Roda', function () { mundoApi('roda/fechar', { method: 'POST', body: JSON.stringify({ id: r.id }) }).then(function () { recarrega('rodas'); }); }));
        pn.appendChild(d);
      });
    } else {
      pn.appendChild(el('div', 'mosub', 'Gestos (aparecem sobre o seu personagem para quem está no mapa; atalho [H] acena):'));
      var g = el('div', 'mofr'); Object.keys(GESTOS_TXT).forEach(function (k) { g.appendChild(btn(GESTOS_TXT[k], function () { if (E.gesto) E.gesto(k); mundoFecha(); })); }); pn.appendChild(g);
      pn.appendChild(el('div', 'mosub', 'Presentear quem está na Vila (até 3 por dia; você mantém ao menos 1 de cada):'));
      var gente = ((P && P.pessoas) || []).filter(function (p) { return p.q !== P.eu; });
      if (!gente.length) pn.appendChild(el('div', 'moit', 'Ninguém mais na Vila agora.'));
      gente.forEach(function (p) {
        var d = el('div', 'moit', p.nome);
        ['Saberes', 'Meios'].forEach(function (tp) { var b = btn('Dar 1 ' + (tp === 'Saberes' ? 'Saber' : 'Meio'), function () { mundoApi('presente', { method: 'POST', body: JSON.stringify({ para: p.q, tipo: tp }) }).then(function (j) { if (j && j._ok) { chg(tp, -1); aviso('Presente enviado a ' + p.nome + '.'); } else aviso(j && j._st === 429 ? 'Limite de presentes atingido por ora.' : 'A pessoa saiu da Vila.'); recarrega('pres'); }); }); if ((E.rec[tp] || 0) < 2) b.disabled = true; d.appendChild(b); });
        pn.appendChild(d);
      });
    }
    var f0 = pn.querySelector('.motabs button'); if (f0) f0.focus();
  }
  pn.appendChild(el('div', 'mosub', 'Carregando…'));
  recarrega();
}
function mundoFecha() { var ov = document.getElementById('mundoOv'); if (ov) ov.remove(); try { E.game.input.keyboard.enabled = true; } catch (e) {} }

/* ---------- start ---------- */
window.EntStart = function (info) {
  E.nome = info.nome; E.nick = info.nome; E.token = info.token; E.mundo = info.mundo || null;
  if (E.mundo) E.nome = info.nome + '@m' + E.mundo.id; // chave de save separada da jornada pessoal
  mundoIniciar();
  function boot() {
    E.game = new Phaser.Game({
      type: Phaser.AUTO, parent: 'game', width: W, height: H, backgroundColor: '#8fd0ff', pixelArt: true, roundPixels: true,
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      physics: { default: 'arcade', arcade: { gravity: { y: 0 }, debug: false } },
      input: { gamepad: true },
      scene: [Boot, Creator, World, Regiao, Trecho, Sala, Bonus, Ativ, Corrida, AtivMenu, UI]
    });
  }
  var local = null; try { local = JSON.parse(localStorage.getItem('entendencia_' + E.nome)); } catch (e) {}
  // espera a fonte pixel (máx. 2 s) antes de subir o jogo, para o texto não nascer com a fonte errada
  var fontsOk = Promise.race([Promise.all([document.fonts.load('20px "Pixelify Sans"'), document.fonts.load('bold 20px "Pixelify Sans"')]), new Promise(function (r) { setTimeout(r, 2000); })]).catch(function () {});
  function go() { fontsOk.then(boot); }
  if (!E.token) { applySave(local); go(); return; }
  fetch('api/save' + (E.mundo ? '?slot=mundo' : ''), { headers: { Authorization: 'Bearer ' + E.token } }).then(function (r) { return r.json(); })
    .then(function (j) {
      // usa o salvamento mais recente (local x servidor); se o local for mais novo, reenvia ao servidor
      var srv = j.save, pick = srv;
      if (local && (!srv || (local._ts || 0) > (srv._ts || 0))) { pick = local; E._pendLocal = true; }
      applySave(pick || local); go();
      if (E._pendLocal) setTimeout(function () { E._dirty = true; E.sendSave(false); }, 3000);
    }).catch(function () { applySave(local); go(); setTimeout(function () { E._dirty = true; E.sendSave(false); }, 5000); });
};
})();
