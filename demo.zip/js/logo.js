/* Logo do jogo: "Roda ao pé do Buriti" (proposta B). Pixel art desenhada em código, sem arquivo de imagem.
   Uso: EntLogo.canvas(escala) devolve um <canvas>; EntLogo.favicon() troca o ícone da aba. */
(function(){
var S=40, K='#3b2a2a', RAD=Math.PI/180;
function G(){var g=[];for(var y=0;y<S;y++)g.push(new Array(S).fill(null));return g}
function px(g,x,y,c){x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<S&&y<S)g[y][x]=c}
function rect(g,x0,y0,x1,y1,c){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)px(g,x,y,c)}
function circ(g,cx,cy,r,c){for(var y=-r;y<=r;y++)for(var x=-r;x<=r;x++)if(x*x+y*y<=r*r+r*0.6)px(g,cx+x,cy+y,c)}
function ell(g,cx,cy,rx,ry,c){for(var y=-ry;y<=ry;y++)for(var x=-rx;x<=rx;x++)if((x*x)/(rx*rx)+(y*y)/(ry*ry)<=1.08)px(g,cx+x,cy+y,c)}
function line(g,x0,y0,x1,y1,c,t){x0=Math.round(x0);y0=Math.round(y0);x1=Math.round(x1);y1=Math.round(y1);var dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1,e=dx+dy;while(true){px(g,x0,y0,c);if(t)px(g,x0+1,y0,c);if(x0==x1&&y0==y1)break;var e2=2*e;if(e2>=dy){e+=dy;x0+=sx}if(e2<=dx){e+=dx;y0+=sy}}}
function outline(g){var o=g.map(function(r){return r.slice()});for(var y=0;y<S;y++)for(var x=0;x<S;x++)if(!g[y][x]){var n=[[1,0],[-1,0],[0,1],[0,-1]].some(function(d){var yy=y+d[1],xx=x+d[0];return yy>=0&&xx>=0&&yy<S&&xx<S&&g[yy][xx]});if(n)o[y][x]=K}return o}
function draw(cv,g,k){cv.width=S*k;cv.height=S*k;var c=cv.getContext('2d');for(var y=0;y<S;y++)for(var x=0;x<S;x++)if(g[y][x]){c.fillStyle=g[y][x];c.fillRect(x*k,y*k,k,k)}}
var SK=['#a8682c','#ffd6ae','#7a4a24','#d89048','#8a5a2a','#c58a5a','#ffd6ae','#a8682c'], SH=['#e03a3a','#ffd23a','#4da83a','#c77dff','#ff8a3a','#3ad0ff','#ff6fa8','#2a7ee0'];
function person(g,x,y,k){ell(g,x,y+2,2,2,SH[k%8]);circ(g,x,y-2,2,SK[k%8])}
function ring(g,cx,cy,rx,ry,col,every){for(var k=0;k<240;k++){if(every&&k%every)continue;var X=Math.round(cx+Math.cos(k*RAD*1.5)*rx),Y=Math.round(cy+Math.sin(k*RAD*1.5)*ry);if(X>=0&&Y>=0&&X<S&&Y<S&&!g[Y][X])px(g,X,Y,col)}}
function palm(g,cx,by,h,fl,lean){ /* buriti: tronco + copa de folhas */
  var top=by-h;line(g,cx,by,cx+(lean||0),top,'#8a5a2a',1);line(g,cx,by-1,cx+(lean||0),top+1,'#8a5a2a');
  for(var y=by-2;y>top;y-=3)px(g,cx+Math.round((lean||0)*(by-y)/h),y,'#c8884a');
  var tx=cx+(lean||0),F=[[-1,-.25],[-.85,-.75],[-.4,-1],[0,-1.05],[.4,-1],[.85,-.75],[1,-.25],[-.9,.25],[.9,.25]];
  F.forEach(function(f){line(g,tx,top,tx+f[0]*fl,top+f[1]*fl,'#2e8a3a',1)});
  F.slice(0,7).forEach(function(f){line(g,tx,top-1,tx+f[0]*fl,top+f[1]*fl-1,'#6bc84a')});
  circ(g,tx,top,1,'#2e8a3a');px(g,tx-1,top+1,'#ff7a5a');px(g,tx+1,top+1,'#ff7a5a')}

/* B. Roda ao pé do Buriti: o buriti alto e a roda de gente no chão */
function logo(){var g=G();circ(g,32,7,3,'#ffd23a');
  ell(g,20,34,18,5,'#4da83a');ell(g,20,33,16,3,'#6bc84a');
  line(g,20,39,23,36,'#3a9cff',1);line(g,23,36,19,34,'#3a9cff',1);
  palm(g,20,33,19,9,0);
  [[5,32],[10,35],[30,35],[35,32],[14,28]].forEach(function(p,k){person(g,p[0],p[1],k)});person(g,26,28,5);
  return outline(g)}

window.EntLogo={
  canvas:function(k){var cv=document.createElement('canvas');draw(cv,logo(),k||4);cv.style.imageRendering='pixelated';return cv},
  favicon:function(){try{var cv=document.createElement('canvas');draw(cv,logo(),2);var l=document.querySelector('link[rel=icon]')||document.createElement('link');l.rel='icon';l.type='image/png';l.href=cv.toDataURL('image/png');document.head.appendChild(l)}catch(e){}}
};
})();
