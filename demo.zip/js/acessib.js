/* Entendência — acessibilidade: ajustes salvos, texto maior, alto contraste, fonte legível, menos movimento, pausa. */
(function () {
'use strict';
var KEY = 'entendencia_acc', SC = [1, 1.15, 1.3], LEG = 'Verdana, "Trebuchet MS", Arial, sans-serif';
var A = { tam: 0, contraste: false, auto: false, assist: false, mov: false, fonte: false, tut: true };
try { var s = JSON.parse(localStorage.getItem(KEY) || '{}'); for (var k in s) if (k in A) A[k] = s[k]; } catch (e) {}
var EA = window.EntAcc = { p: A };
function save() { try { localStorage.setItem(KEY, JSON.stringify(A)); } catch (e) {} }
function game() { return window.E && E.ui && E.ui.game; }

/* ---------- texto do Phaser: escala, mínimo de 18 px, fonte legível, dicas de teclado só quando há teclado ---------- */
var GF = Phaser.GameObjects.GameObjectFactory.prototype, TP = Phaser.GameObjects.Text.prototype;
var t0 = GF.text, sf0 = TP.setFontSize, st0 = TP.setText, ff0 = TP.setFontFamily;
function eff(o, bs) { return o._fx ? bs : Math.max(18, Math.round(bs * (SC[A.tam] || 1))); }
function fam(o) { return A.fonte && !o._fx ? LEG : o._ff; }
function limpa(s) {
  if (!(window.E && E.touch) || typeof s !== 'string' || /^\s*▶|^\s+\[/.test(s)) return s;
  return s.replace(/\s?\[(?:[A-Z]|Esc|Enter|Espaço|Tab)\]/g, '').replace(/^ +/, '');
}
GF.text = function (x, y, text, style) {
  style = Object.assign({}, style || {});
  var fx = !!style.fixed || /mono/.test(style.fontFamily || ''), bs = parseFloat(style.fontSize) || 16, ff = style.fontFamily;
  var o = { _fx: fx, _ff: ff };
  style.fontSize = eff(o, bs) + 'px'; if (ff && !fx) style.fontFamily = fam(o);
  var t = t0.call(this, x, y, limpa(text), style); t._bs = bs; t._fx = fx; t._ff = ff; return t;
};
TP.setFontSize = function (v) { var bs = parseFloat(v); if (!isNaN(bs)) { this._bs = bs; v = eff(this, bs) + 'px'; } return sf0.call(this, v); };
TP.setText = function (v) { return st0.call(this, Array.isArray(v) ? v : limpa(v)); };
function walk(list, fn) { (list || []).forEach(function (o) { fn(o); if (o.list) walk(o.list, fn); }); }
function reaplica() {
  var g = game(); if (!g) return;
  g.scene.scenes.forEach(function (sc) {
    walk(sc.children && sc.children.list, function (o) {
      if (o instanceof Phaser.GameObjects.Text && o._bs && !o._fx) { sf0.call(o, eff(o, o._bs) + 'px'); if (o._ff) ff0.call(o, fam(o)); }
    });
  });
  if (E && E.ui && E.ui.hud) { try { E.ui.hud(); } catch (e) {} if (E.ui.encaixa) E.ui.encaixa(); }
}
/* menos movimento: sem tremor nem flash de tela */
(function () { var C = Phaser.Cameras.Scene2D.Camera.prototype, sh = C.shake, fl = C.flash;
  C.shake = function () { return A.mov ? this : sh.apply(this, arguments); }; C.flash = function () { return A.mov ? this : fl.apply(this, arguments); }; })();

/* ---------- aplicar ---------- */
EA.aplica = function () {
  var h = document.documentElement; h.classList.toggle('acc-hc', !!A.contraste); h.classList.toggle('acc-leg', !!A.fonte);
  h.setAttribute('data-tam', A.tam);
  if (window.E) { if (A.assist !== !!E.assist) { E.assist = A.assist; if (E.persist) E.persist(); } }
  reaplica();
};
EA.set = function (k, v) { A[k] = v; save(); EA.aplica(); EA.desenha(); };
EA.auto = function () { return !!A.auto; };

/* ---------- painel Acessibilidade (DOM) ---------- */
var css = document.createElement('style');
css.textContent = '#accP{position:fixed;inset:0;z-index:99990;background:rgba(10,16,32,.72);display:none;align-items:center;justify-content:center;font-family:Verdana,Arial,sans-serif}' +
  '#accP .cx{background:#fff3c4;color:#2a1f2d;border:4px solid #e8a45a;border-radius:10px;width:min(640px,94vw);max-height:92vh;overflow:auto;padding:20px 24px;position:relative;box-shadow:0 6px 0 #2a1f2d}' +
  '#accP h2{margin:0 0 10px;font-size:26px;color:#9a3d10}#accP .x{position:absolute;right:10px;top:10px;width:48px;height:48px;border:3px solid #2a1f2d;background:#c0392b;color:#fff;font-size:26px;font-weight:700;cursor:pointer;border-radius:6px}' +
  '#accP .l{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-top:2px solid #e8c98a;font-size:19px}#accP .l small{display:block;font-size:15px;color:#5a3b1a}' +
  '#accP button.o{min-height:48px;min-width:64px;font-size:19px;font-weight:700;border:3px solid #2a1f2d;border-radius:6px;background:#fff;color:#2a1f2d;cursor:pointer;padding:6px 14px;margin-left:6px}' +
  '#accP button.o.on{background:#c8561a;color:#fff}#accP .ok{display:block;margin:14px auto 0;min-height:52px;font-size:21px;font-weight:700;background:#ffd23a;border:3px solid #2a1f2d;border-radius:6px;padding:8px 30px;cursor:pointer;color:#2a1f2d}' +
  '#accPausa{position:fixed;inset:0;z-index:99980;background:rgba(10,16,32,.7);display:none;align-items:center;justify-content:center;flex-direction:column;gap:16px;font-family:Verdana,Arial,sans-serif;color:#fff}' +
  '#accPausa h2{font-size:38px;margin:0}#accPausa button{min-height:56px;font-size:22px;font-weight:700;background:#ffd23a;border:3px solid #2a1f2d;border-radius:6px;padding:8px 32px;cursor:pointer;color:#2a1f2d}' +
  'html.acc-hc canvas{filter:contrast(1.3) saturate(1.1)}html.acc-hc #accP .cx{border-color:#000}';
document.head.appendChild(css);
var P = document.createElement('div'); P.id = 'accP'; P.setAttribute('role', 'dialog'); P.setAttribute('aria-label', 'Acessibilidade');
document.body.appendChild(P);
var Q = document.createElement('div'); Q.id = 'accPausa'; Q.innerHTML = '<h2>Jogo pausado</h2><button id="accRet">▶ Continuar (P)</button><button id="accAj">⚙ Ajustes</button>'; document.body.appendChild(Q);
function linha(tit, sub, ctl) { return '<div class="l"><div>' + tit + (sub ? '<small>' + sub + '</small>' : '') + '</div><div>' + ctl + '</div></div>'; }
function onoff(k) { return '<button class="o' + (!A[k] ? ' on' : '') + '" data-k="' + k + '" data-v="0">Não</button><button class="o' + (A[k] ? ' on' : '') + '" data-k="' + k + '" data-v="1">Sim</button>'; }
EA.desenha = function () {
  if (P.style.display !== 'flex') return;
  var tam = ['Normal', 'Grande', 'Muito grande'].map(function (n, i) { return '<button class="o' + (A.tam === i ? ' on' : '') + '" data-k="tam" data-v="' + i + '">' + n + '</button>'; }).join('');
  P.innerHTML = '<div class="cx"><button class="x" id="accX" aria-label="Fechar">X</button><h2>Acessibilidade</h2>' +
    linha('Tamanho do texto', 'Aumenta as letras do jogo', tam) +
    linha('Alto contraste', 'Cores mais fortes', onoff('contraste')) +
    linha('Letra mais fácil de ler', 'Troca a letra de pixel por uma comum', onoff('fonte')) +
    linha('Conversas fecham sozinhas', 'Desligado: a conversa só fecha quando você quiser', onoff('auto')) +
    linha('Erros sem custo de Ânimo', 'Para jogar com calma, sem perder corações', onoff('assist')) +
    linha('Menos movimento', 'Sem tremor e sem clarões na tela', onoff('mov')) +
    linha('Dicas de como jogar', 'Mostra a ajuda curta na primeira vez', onoff('tut')) +
    '<button class="ok" id="accOk">Pronto</button></div>';
};
EA.abre = function () { P.style.display = 'flex'; if (window.E && E.assist !== undefined) A.assist = !!E.assist; EA.desenha(); var b = document.getElementById('accOk'); if (b) b.focus(); };
EA.fecha = function () { P.style.display = 'none'; var c = document.querySelector('canvas'); if (c) c.focus && c.focus(); };
P.addEventListener('click', function (e) {
  var t = e.target; if (t === P || t.id === 'accX' || t.id === 'accOk') { EA.fecha(); return; }
  var k = t.getAttribute && t.getAttribute('data-k'); if (!k) return;
  var v = t.getAttribute('data-v'); EA.set(k, k === 'tam' ? +v : v === '1');
});
['keydown', 'keyup'].forEach(function (n) { P.addEventListener(n, function (e) { e.stopPropagation(); if (n === 'keydown' && e.key === 'Escape') EA.fecha(); }); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && P.style.display === 'flex') EA.fecha(); }, true);

/* ---------- pausa ---------- */
var PAUSA = ['Trecho', 'Sala', 'Bonus', 'Ativ', 'Corrida'], pausadas = null;
EA.emFase = function () { var g = game(); return !!g && g.scene.getScenes(true).some(function (s) { return PAUSA.indexOf(s.scene.key) >= 0; }); };
EA.pausar = function () {
  var g = game(); if (!g || pausadas || (window.E && E.ui && E.ui.busy)) return;
  pausadas = g.scene.getScenes(true).filter(function (s) { return PAUSA.indexOf(s.scene.key) >= 0; });
  if (!pausadas.length) { pausadas = null; return; }
  pausadas.forEach(function (s) { s.scene.pause(); }); Q.style.display = 'flex'; document.getElementById('accRet').focus();
};
EA.retomar = function () { if (!pausadas) return; pausadas.forEach(function (s) { try { s.scene.resume(); } catch (e) {} }); pausadas = null; Q.style.display = 'none'; };
EA.alterna = function () { if (pausadas) EA.retomar(); else EA.pausar(); };
document.getElementById('accRet').onclick = EA.retomar;
document.getElementById('accAj').onclick = function () { EA.abre(); };
window.addEventListener('keydown', function (e) {
  if ((e.key === 'p' || e.key === 'P') && !e.ctrlKey && !e.metaKey && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '') && P.style.display !== 'flex') EA.alterna();
});

/* botão da tela inicial */
var b0 = document.getElementById('bAcc'); if (b0) { b0.addEventListener('click', EA.abre); b0.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); EA.abre(); } }); }
EA.aplica();
})();
