/* Camada de toque da Entendência. Só atua em telas de toque (pointer:coarse); no computador não faz nada.
   Não altera a mecânica: os controles virtuais disparam as MESMAS teclas que o jogo já lê (setas, E, Q, Espaço, Esc). */
(function () {
  var touch = (window.matchMedia && matchMedia('(pointer:coarse)').matches) || 'ontouchstart' in window && navigator.maxTouchPoints > 1;
  if (!touch) return;
  var root = document.documentElement; root.classList.add('touch'); if (window.E) window.E.touch = true;
  var KC = { ENTER: 13, LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, E: 69, Q: 81, SPACE: 32, ESC: 27, G: 71, C: 67, F: 70, O: 79, N: 78 };
  var KEY = { ENTER: 'Enter', LEFT: 'ArrowLeft', UP: 'ArrowUp', RIGHT: 'ArrowRight', DOWN: 'ArrowDown', E: 'e', Q: 'q', SPACE: ' ', ESC: 'Escape', G: 'g', C: 'c', F: 'f', O: 'o', N: 'n' };
  var CODE = { ENTER: 'Enter', LEFT: 'ArrowLeft', UP: 'ArrowUp', RIGHT: 'ArrowRight', DOWN: 'ArrowDown', E: 'KeyE', Q: 'KeyQ', SPACE: 'Space', ESC: 'Escape', G: 'KeyG', C: 'KeyC', F: 'KeyF', O: 'KeyO', N: 'KeyN' };
  var down = {};
  function fire(type, k) {
    var ev = new KeyboardEvent(type, { key: KEY[k], code: CODE[k], keyCode: KC[k], which: KC[k], bubbles: true, cancelable: true });
    if (ev.keyCode !== KC[k]) { try { Object.defineProperty(ev, 'keyCode', { value: KC[k] }); Object.defineProperty(ev, 'which', { value: KC[k] }); } catch (e) {} }
    window.dispatchEvent(ev);
  }
  function press(k) { if (down[k]) return; down[k] = 1; fire('keydown', k); }
  function release(k) { if (!down[k]) return; down[k] = 0; fire('keyup', k); }
  function tap(k) { press(k); setTimeout(function () { release(k); }, 70); }

  // aviso de rotação (retrato) no lugar do bloqueio "só computador"
  var av = document.querySelector('#mobile p'); if (av) av.textContent = 'Gire o aparelho para a horizontal para jogar a Entendência.';

  // joystick virtual (esquerda)
  var box = document.createElement('div'); box.id = 'tcJoy'; box.innerHTML = '<div id="tcThumb"></div>';
  var pad = document.createElement('div'); pad.id = 'tcPad';
  pad.appendChild(box);
  var bt = document.createElement('div'); bt.id = 'tcBtns';
  function btn(label, k, cls, hold) {
    var b = document.createElement('button'); b.type = 'button'; b.className = 'tcB ' + (cls || ''); b.textContent = label; b.setAttribute('aria-label', label);
    b.addEventListener('pointerdown', function (e) { e.preventDefault(); b.setPointerCapture(e.pointerId); b.classList.add('on'); hold ? press(k) : tap(k); });
    function up(e) { b.classList.remove('on'); if (hold) release(k); }
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
    return b;
  }
  bt.appendChild(btn('Q', 'Q', 'sm')); bt.appendChild(btn('Pular', 'SPACE', 'md', true)); bt.appendChild(btn('E', 'E', 'lg'));
  // cruz de menu (toques discretos): aparece em menus, Caderno, Guia, ODS, Atividades e mini-jogos
  var cross = document.createElement('div'); cross.id = 'tcCross';
  [['\u25B2', 'UP', 'u'], ['\u25C0', 'LEFT', 'l'], ['\u25B6', 'RIGHT', 'r'], ['\u25BC', 'DOWN', 'd']].forEach(function (a) { var b = btn(a[0], a[1], 'cx ' + a[2]); cross.appendChild(b); });
  pad.appendChild(cross);
  var ent = btn('Enter', 'ENTER', 'md ent'); ent.style.display = 'none'; bt.insertBefore(ent, bt.firstChild);
  var top = document.createElement('div'); top.id = 'tcTop';
  top.appendChild(btn('Esc', 'ESC', 'xs'));
  var wrap = document.createElement('div'); wrap.id = 'tcWrap'; wrap.appendChild(pad); wrap.appendChild(bt); wrap.appendChild(top);
  document.addEventListener('DOMContentLoaded', function () { document.body.appendChild(wrap); });
  if (document.body) document.body.appendChild(wrap);

  var thumb = box.firstChild, pid = null, cx = 0, cy = 0, R = 60;
  function dirs(dx, dy) {
    var d = Math.sqrt(dx * dx + dy * dy), th = R * 0.3;
    var l = dx < -th, r = dx > th, u = dy < -th, dn = dy > th;
    if (d < th) l = r = u = dn = false;
    l ? press('LEFT') : release('LEFT'); r ? press('RIGHT') : release('RIGHT'); u ? press('UP') : release('UP'); dn ? press('DOWN') : release('DOWN');
  }
  function move(e) {
    var dx = e.clientX - cx, dy = e.clientY - cy, d = Math.sqrt(dx * dx + dy * dy); if (d > R) { dx *= R / d; dy *= R / d; }
    thumb.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; dirs(dx, dy);
  }
  box.addEventListener('pointerdown', function (e) { e.preventDefault(); pid = e.pointerId; box.setPointerCapture(pid); var r = box.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; R = r.width / 2; move(e); });
  box.addEventListener('pointermove', function (e) { if (e.pointerId === pid) move(e); });
  function fim(e) { if (e.pointerId !== pid) return; pid = null; thumb.style.transform = ''; dirs(0, 0); }
  box.addEventListener('pointerup', fim); box.addEventListener('pointercancel', fim);

  // só aparece com o jogo rodando e sem janela HTML aberta (Mural etc.)
  function vis() {
    var t = document.getElementById('titulo'), rodando = t && t.style.display === 'none';
    wrap.style.display = (rodando && !document.getElementById('mundoOv')) ? 'block' : 'none';
    var menu = false;
    try {
      var g = window.E && window.E.game, ui = window.E && window.E.ui;
      if (g) { var ks = g.scene.getScenes(true).map(function (x) { return x.scene.key; }); menu = ks.some(function (k) { return k === 'Ativ' || k === 'AtivMenu' || k === 'Creator'; }); }
      if (ui && ((ui.guia && ui.guia.visible) || (ui.som && ui.som.visible) || (ui.cad && ui.cad.visible) || (ui.ods && ui.ods.visible) || ui.mode === 'choice')) menu = true;
    } catch (x) {}
    box.style.display = menu ? 'none' : ''; cross.style.display = menu ? 'grid' : 'none'; ent.style.display = menu ? '' : 'none';
    if (menu !== lastMenu) { lastMenu = menu; Object.keys(down).forEach(release); }
    if (!rodando) { Object.keys(down).forEach(release); }
  }
  var lastMenu = false; setInterval(vis, 250); vis();

  // toque direto no jogo: avança conversas e escolhe opções sem usar o botão E
  document.addEventListener('pointerdown', function (e) {
    var cv = e.target && e.target.tagName === 'CANVAS' && e.target.closest && e.target.closest('#game'); if (!cv) return;
    var ui = window.E && window.E.ui; if (!ui || !ui.box || !ui.box.visible) return;
    var r = e.target.getBoundingClientRect(), gx = (e.clientX - r.left) * 1280 / r.width, gy = (e.clientY - r.top) * 720 / r.height;
    if (gx < 40 || gx > 1240 || gy < 520 || gy > 700) return;
    if (ui.mode === 'line') { tap('E'); return; }
    if (ui.mode === 'choice' && ui.opts && ui.opts.length) {
      var lh = ui.bodyT.height / ui.opts.length, row = Math.floor((gy - ui.bodyT.y) / lh); if (row < 0 || row >= ui.opts.length) return;
      if (row === ui.sel) tap('E'); else { ui.sel = row; ui.drawChoices(); }
    }
  }, true);

  // tela cheia no primeiro toque (o navegador só libera após um gesto); no iPhone use "Adicionar à Tela de Início" (manifest)
  var fsDone = false;
  document.addEventListener('pointerup', function () {
    if (fsDone) return; fsDone = true;
    var e = document.documentElement, f = e.requestFullscreen || e.webkitRequestFullscreen;
    if (f && !document.fullscreenElement) { try { var p = f.call(e); if (p && p.catch) p.catch(function () {}); } catch (x) {} }
  }, true);
  // aparelho fraco: já começa em modo leve (o jogo também liga sozinho se o FPS cair)
  try { if (window.E && ((navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4))) window.E.lite = true; } catch (x) {}
  // evita rolagem/zoom/menu de pressão longa
  ['gesturestart', 'dblclick'].forEach(function (n) { document.addEventListener(n, function (e) { e.preventDefault(); }); });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  // paisagem travada quando o navegador deixa (após tela cheia)
  document.addEventListener('fullscreenchange', function () { try { if (document.fullscreenElement && screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(function () {}); } catch (e) {} });
})();
