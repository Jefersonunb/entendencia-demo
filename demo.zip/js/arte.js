/* Entendência — arte procedural em pixel art: marcos dos Reinos (50x40), ícones das fases (16x16) e itens do bônus. */
(function () {
'use strict';
var OL = '#2a1f2d', g;
function mk(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; g = c.getContext('2d'); return c; }
function r(x, y, w, h, c) { g.fillStyle = c; g.fillRect(x, y, w, h); }
function box(x, y, w, h, c) { // caixa com contorno e cantos chanfrados (sem quina reta)
  r(x, y, w, h, OL); r(x + 1, y + 1, w - 2, h - 2, c);
  if (w >= 5 && h >= 5) { g.clearRect(x, y, 1, 1); g.clearRect(x + w - 1, y, 1, 1); g.clearRect(x, y + h - 1, 1, 1); g.clearRect(x + w - 1, y + h - 1, 1, 1); }
}
/* acabamento 16 bits: contorno interno colorido (sel-out), contorno externo escuro, luz no canto superior esquerdo e textura nos planos chapados */
function polish(cv, tex) {
  var W = cv.width, H = cv.height, c = cv.getContext('2d'), id = c.getImageData(0, 0, W, H), d = id.data, o = new Uint8ClampedArray(d);
  function A(x, y) { return (x < 0 || y < 0 || x >= W || y >= H) ? 0 : d[(y * W + x) * 4 + 3]; }
  function solid(x, y) { return A(x, y) >= 200; }
  function isOL(i) { return d[i] === 0x2a && d[i + 1] === 0x1f && d[i + 2] === 0x2d && d[i + 3] >= 200; }
  function same(x, y, x2, y2) { if (!solid(x2, y2)) return false; var i = (y * W + x) * 4, j = (y2 * W + x2) * 4; return d[i] === d[j] && d[i + 1] === d[j + 1] && d[i + 2] === d[j + 2]; }
  var x, y, i, k;
  for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
    i = (y * W + x) * 4; if (!solid(x, y)) continue;
    if (isOL(i)) { // contorno interno: toma a cor vizinha, escurecida
      var nb = [[1, 0], [-1, 0], [0, 1], [0, -1]], tr = 0, sr = 0, sg = 0, sb = 0, n = 0;
      nb.forEach(function (q) { var xx = x + q[0], yy = y + q[1]; if (!solid(xx, yy)) { tr++; return; } var j = (yy * W + xx) * 4; if (!isOL(j)) { sr += d[j]; sg += d[j + 1]; sb += d[j + 2]; n++; } });
      if (tr === 0 && n > 0) { o[i] = sr / n * 0.52 + 0x2a * 0.2; o[i + 1] = sg / n * 0.48 + 0x1f * 0.2; o[i + 2] = sb / n * 0.52 + 0x2d * 0.25; }
      continue;
    }
    var f = 1; if (!same(x, y, x - 1, y - 1)) f = 1.13; if (!same(x, y, x + 1, y + 1)) f = 0.8;
    if (tex && f === 1 && same(x, y, x - 1, y) && same(x, y, x + 1, y) && same(x, y, x, y - 1) && same(x, y, x, y + 1) && ((x * 3 + y * 7) % 5 === 0)) f = ((x + y) & 1) ? 1.07 : 0.93;
    for (k = 0; k < 3; k++) o[i + k] = Math.min(255, d[i + k] * f);
  }
  for (y = 0; y < H; y++) for (x = 0; x < W; x++) { // contorno externo
    i = (y * W + x) * 4; if (solid(x, y) || A(x, y) > 0) continue;
    var near = false;
    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (q) { var xx = x + q[0], yy = y + q[1]; if (solid(xx, yy) && !isOL((yy * W + xx) * 4)) near = true; });
    if (near) { o[i] = 0x2a; o[i + 1] = 0x1f; o[i + 2] = 0x2d; o[i + 3] = 255; }
  }
  id.data.set(o); c.putImageData(id, 0, 0); return cv;
}
function ell(cx, cy, rx, ry, c) {
  g.fillStyle = c;
  for (var y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) for (var x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
    var dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry; if (dx * dx + dy * dy <= 1) g.fillRect(x, y, 1, 1);
  }
}
function roof(x0, x1, yt, yb, c, outline) { // triângulo preenchido linha a linha
  var cx = (x0 + x1) / 2;
  for (var y = yt; y <= yb; y++) {
    var t = (y - yt + 1) / (yb - yt + 1), l = Math.round(cx - (cx - x0) * t), rr = Math.round(cx + (x1 - cx) * t);
    r(l, y, rr - l + 1, 1, c); if (outline !== false) { r(l, y, 1, 1, OL); r(rr, y, 1, 1, OL); }
  }
  if (outline !== false) r(x0, yb, x1 - x0 + 1, 1, OL);
}
function shadow(cx, cy, rx) { ell(cx, cy, rx, 3, 'rgba(0,0,0,0.22)'); }

var LM = {
  vila: function () {
    mk(50, 40); shadow(25, 35, 22);
    for (var x = 2; x < 48; x++) r(x, 6 + Math.round(2.5 * Math.sin((x - 2) / 45 * Math.PI)), 1, 1, '#3b2a2a');
    ['#d1442e', '#ffd23a', '#3a8cff', '#2ecf5a', '#d1442e', '#ffd23a', '#3a8cff'].forEach(function (c, i) { var x = 5 + i * 6; r(x, 8 + Math.round(2.5 * Math.sin((x - 2) / 45 * Math.PI)), 3, 3, c); });
    box(12, 19, 26, 15, '#f3e3b0'); roof(8, 42, 10, 19, '#d1442e'); box(23, 4, 5, 6, '#c9a02a'); r(25, 8, 1, 2, OL);
    box(22, 25, 6, 9, '#7a4a24'); box(15, 22, 5, 5, '#8fd0ff'); box(30, 22, 5, 5, '#8fd0ff'); return g.canvas;
  },
  boca: function () {
    mk(50, 40); ell(25, 35, 24.5, 5, '#4aa3d8'); r(6, 35, 6, 1, '#bfe8ff'); r(36, 36, 7, 1, '#bfe8ff');
    r(21, 13, 8, 15, '#7a4a24'); r(18, 28, 14, 3, '#7a4a24'); r(19, 24, 12, 4, '#7a4a24'); r(23, 14, 1, 14, '#8e5a2e');
    ell(25, 9, 17, 8, '#1f7a3a'); ell(15, 14, 9, 4, '#2f9a4a'); ell(35, 14, 9, 4, '#2f9a4a'); ell(25, 6, 8, 3, '#2f9a4a');
    box(3, 22, 11, 6, '#c9a05a'); roof(2, 15, 16, 22, '#8a5a2a'); r(4, 28, 1, 5, '#6a4a2a'); r(12, 28, 1, 5, '#6a4a2a');
    r(31, 30, 14, 3, '#a8682c'); r(33, 33, 10, 1, '#a8682c'); r(31, 29, 2, 1, '#a8682c'); r(43, 29, 2, 1, '#a8682c'); return g.canvas;
  },
  pouso: function () {
    mk(50, 40); ell(25, 34, 24.5, 6, '#3fa7a0'); r(8, 34, 8, 1, '#bfe8ff'); r(32, 36, 9, 1, '#bfe8ff');
    r(25, 24, 1, 9, '#6a4a2a'); r(33, 24, 1, 9, '#6a4a2a'); roof(21, 37, 12, 18, '#b8742a'); box(23, 18, 12, 6, '#d8b878'); r(27, 20, 3, 4, '#7a4a24');
    ell(11, 23, 4, 2, '#ffffff'); r(14, 16, 1, 7, '#ffffff'); box(13, 14, 4, 3, '#ffffff'); r(17, 15, 4, 1, '#f5a623'); r(10, 25, 1, 7, '#e8a090'); r(13, 25, 1, 7, '#e8a090');
    ell(42, 26, 3, 2, '#ffffff'); r(40, 21, 1, 5, '#ffffff'); box(38, 20, 4, 3, '#ffffff'); r(35, 21, 3, 1, '#f5a623'); r(41, 28, 1, 5, '#e8a090');
    r(3, 24, 1, 6, '#2f9a4a'); r(5, 22, 1, 8, '#2f9a4a'); r(46, 27, 1, 5, '#2f9a4a'); return g.canvas;
  },
  cacimba: function () {
    mk(50, 40); ell(25, 34, 23, 4, '#e8c878'); ell(25, 29, 11, 4, '#9a8a7a'); ell(25, 28, 8, 2, '#3a5a7a');
    r(17, 14, 2, 14, '#7a4a24'); r(31, 14, 2, 14, '#7a4a24'); r(16, 13, 18, 2, '#7a4a24'); r(25, 15, 1, 4, OL); box(24, 19, 3, 3, '#5a4a3a');
    r(40, 16, 3, 18, '#3f8a3a'); r(36, 21, 4, 2, '#3f8a3a'); r(36, 18, 2, 5, '#3f8a3a'); r(43, 24, 4, 2, '#3f8a3a'); r(45, 20, 2, 6, '#3f8a3a');
    r(6, 16, 1, 18, '#888888'); r(2, 15, 9, 1, '#e0e0e0'); r(6, 11, 1, 9, '#e0e0e0'); return g.canvas;
  },
  jeq: function () {
    mk(50, 40); shadow(25, 36, 20);
    ell(25, 8, 22, 8, '#2f6b2f'); ell(10, 13, 10, 5, '#3c8a3c'); ell(40, 13, 10, 5, '#3c8a3c'); ell(25, 4, 10, 3, '#3c8a3c');
    box(16, 10, 18, 25, '#7a4a24'); r(18, 12, 2, 21, '#8e5a2e'); r(30, 14, 2, 19, '#6a3e1c'); r(24, 12, 1, 8, '#6a3e1c');
    r(22, 23, 6, 12, OL); ell(25, 23, 3, 2, OL); r(8, 19, 1, 1, '#2f6b2f'); r(42, 24, 1, 1, '#2f6b2f'); r(4, 28, 1, 1, '#3c8a3c'); r(45, 17, 1, 1, '#3c8a3c'); return g.canvas;
  },
  enseada: function () {
    mk(50, 40); ell(25, 35, 24, 4, '#f0dca0'); ell(37, 31, 11, 4, '#4aa3d8'); r(32, 32, 6, 1, '#bfe8ff');
    for (var y = 14; y <= 33; y++) { var h = Math.round(3 + (y - 14) * 0.2); r(14 - h, y, 2 * h + 1, 1, '#f4f4f4'); r(14 - h, y, 1, 1, OL); r(14 + h, y, 1, 1, OL); }
    r(11, 19, 7, 3, '#d1442e'); r(10, 26, 9, 3, '#d1442e'); box(10, 9, 9, 5, '#ffd23a'); roof(9, 19, 4, 9, '#d1442e');
    for (y = 8; y <= 13; y++) r(20, y, 8 + (y - 8) * 2, 1, 'rgba(255,230,128,0.45)');
    r(34, 26, 11, 2, '#d1442e'); r(35, 28, 9, 1, '#d1442e'); r(39, 19, 1, 7, OL); r(40, 20, 4, 5, '#ffffff'); return g.canvas;
  },
  coxilha: function () {
    mk(50, 40); ell(25, 37, 25, 6, '#8bb356'); ell(14, 34, 12, 4, '#9cc462');
    box(12, 19, 22, 14, '#a8682c'); roof(10, 36, 10, 19, '#6a4a2a'); r(20, 25, 6, 8, '#3a2a1a');
    [37, 41, 45].forEach(function (x) { r(x, 25, 1, 8, '#e8d8b0'); }); r(36, 27, 11, 1, '#e8d8b0'); r(36, 30, 11, 1, '#e8d8b0');
    box(3, 28, 5, 4, '#8a5a2a'); r(5, 23, 1, 4, 'rgba(255,255,255,0.75)'); r(7, 21, 1, 5, 'rgba(255,255,255,0.75)'); return g.canvas;
  },
  planalto: function () {
    mk(50, 40); ell(25, 35, 23, 4, '#f2f5f8'); box(11, 21, 19, 13, '#8a8f98'); r(14, 24, 4, 2, '#a6abb4'); r(24, 24, 4, 2, '#a6abb4'); r(19, 29, 4, 2, '#a6abb4');
    roof(9, 32, 12, 21, '#5a6a7a'); box(26, 8, 3, 8, '#6a6a6a'); r(27, 5, 2, 2, '#ffffff'); r(29, 3, 2, 2, '#ffffff'); r(18, 26, 5, 8, '#5a3a22');
    r(38, 19, 2, 15, '#5a3a22'); roof(33, 45, 14, 20, '#2f6b4f'); roof(35, 43, 11, 15, '#3c8a62', false); r(0, 29, 16, 2, 'rgba(255,255,255,0.65)'); r(30, 32, 20, 2, 'rgba(255,255,255,0.65)'); return g.canvas;
  },
  babacual: function () {
    mk(50, 40); ell(25, 36, 22, 3, '#6fa05a'); box(10, 24, 16, 10, '#d8b878'); roof(7, 29, 13, 24, '#c9a02a'); r(11, 18, 14, 1, '#a8841a'); r(9, 21, 18, 1, '#a8841a'); r(16, 28, 4, 6, '#6a4a2a');
    r(34, 13, 2, 21, '#8a5a2a'); ell(30, 12, 6, 2, '#2f8a3a'); ell(40, 12, 6, 2, '#2f8a3a'); ell(35, 9, 2, 5, '#2f8a3a');
    r(44, 23, 1, 11, '#8a5a2a'); ell(42, 22, 3, 1, '#2f8a3a'); ell(47, 22, 3, 1, '#2f8a3a'); return g.canvas;
  }
};

var IC = {
  casa: function () { box(2, 7, 12, 8, '#f3e3b0'); roof(1, 15, 2, 7, '#d1442e'); r(7, 10, 3, 5, '#7a4a24'); },
  salao: function () { box(2, 5, 12, 10, '#c9b88a'); roof(1, 15, 1, 5, '#8a5a2a'); r(6, 9, 4, 6, '#7a4a24'); box(6, 8, 4, 3, '#ffd23a'); },
  carta: function () { box(1, 4, 14, 9, '#ffffff'); r(3, 5, 2, 1, '#c8561a'); r(5, 6, 2, 1, '#c8561a'); r(7, 7, 2, 1, '#c8561a'); r(9, 6, 2, 1, '#c8561a'); r(11, 5, 2, 1, '#c8561a'); r(11, 9, 3, 3, '#d1442e'); },
  roda: function () { [[7, 1], [12, 4], [12, 10], [7, 13], [2, 10], [2, 4]].forEach(function (p, i) { box(p[0] - 1, p[1] - 1, 3, 3, ['#ff8a65', '#4fc3f7', '#81c784', '#ffd54f', '#ce93d8', '#f48fb1'][i]); }); r(6, 6, 4, 4, '#ffd23a'); },
  livro: function () { box(2, 3, 12, 11, '#8a4a22'); r(3, 4, 5, 9, '#f3e3b0'); r(9, 4, 4, 9, '#f3e3b0'); r(8, 3, 1, 11, OL); },
  placa: function () { r(7, 5, 2, 10, '#7a4a24'); box(2, 2, 9, 4, '#e8c878'); box(7, 7, 8, 4, '#e8c878'); },
  guiche: function () { box(1, 5, 14, 10, '#8fb0d8'); box(3, 8, 10, 4, '#ffffff'); box(0, 2, 16, 3, '#d1442e'); },
  mapa: function () { box(1, 3, 14, 11, '#f3e3b0'); r(5, 4, 1, 9, '#c9b88a'); r(10, 4, 1, 9, '#c9b88a'); r(6, 6, 1, 1, '#d1442e'); r(8, 6, 1, 1, '#d1442e'); r(7, 7, 1, 1, '#d1442e'); r(6, 8, 1, 1, '#d1442e'); r(8, 8, 1, 1, '#d1442e'); },
  gota: function () { roof(4, 12, 1, 7, '#4aa3d8'); ell(8, 10, 5, 5, '#4aa3d8'); r(6, 9, 2, 2, '#bfe8ff'); },
  obra: function () { roof(5, 11, 2, 13, '#ff8a3a'); r(3, 13, 10, 2, '#ff8a3a'); r(6, 7, 4, 1, '#ffffff'); r(5, 10, 6, 1, '#ffffff'); },
  antena: function () { r(7, 4, 2, 11, '#888888'); r(4, 6, 8, 1, '#888888'); r(5, 9, 6, 1, '#888888'); box(4, 13, 8, 2, '#6a6a6a'); r(2, 1, 1, 3, '#ffd23a'); r(13, 1, 1, 3, '#ffd23a'); r(4, 0, 1, 2, '#ffd23a'); r(11, 0, 1, 2, '#ffd23a'); },
  barraca: function () { box(2, 8, 12, 7, '#f3e3b0'); roof(1, 15, 2, 8, '#d1442e'); roof(6, 10, 2, 8, '#ffffff', false); r(5, 10, 6, 3, '#ffa826'); r(6, 11, 2, 2, '#ffd23a'); },
  onda: function () { r(0, 8, 16, 6, '#4aa3d8'); r(1, 6, 3, 2, '#4aa3d8'); r(5, 5, 3, 3, '#4aa3d8'); r(9, 6, 3, 2, '#4aa3d8'); r(13, 7, 3, 1, '#4aa3d8'); r(2, 9, 2, 1, '#bfe8ff'); r(8, 11, 3, 1, '#bfe8ff'); },
  arvore: function () { ell(8, 6, 6, 5, '#2f9a4a'); r(7, 10, 2, 5, '#7a4a24'); r(5, 4, 2, 2, '#4fbf6a'); },
  balao: function () { box(1, 2, 14, 9, '#ffffff'); r(4, 12, 3, 2, '#ffffff'); r(4, 6, 2, 2, OL); r(7, 6, 2, 2, OL); r(10, 6, 2, 2, OL); },
  sol: function () { ell(8, 8, 4, 4, '#ffd23a'); [[7, 0, 2, 3], [7, 13, 2, 3], [0, 7, 3, 2], [13, 7, 3, 2], [2, 2, 2, 2], [12, 2, 2, 2], [2, 12, 2, 2], [12, 12, 2, 2]].forEach(function (a) { r(a[0], a[1], a[2], a[3], '#ffb300'); }); },
  montanha: function () { roof(1, 15, 3, 14, '#8a8f98'); roof(5, 11, 3, 7, '#ffffff', false); r(0, 14, 16, 2, '#6a6a6a'); },
  lupa: function () { ell(6, 6, 5, 5, OL); ell(6, 6, 3, 3, '#bfe8ff'); r(10, 10, 2, 2, '#7a4a24'); r(12, 12, 2, 2, '#7a4a24'); r(14, 14, 2, 2, '#7a4a24'); },
  grafico: function () { box(1, 1, 14, 14, '#ffffff'); r(3, 9, 2, 5, '#3a8cff'); r(7, 5, 2, 9, '#2ecf5a'); r(11, 7, 2, 7, '#d1442e'); },
  tabua: function () { r(0, 13, 16, 3, '#4aa3d8'); box(0, 9, 5, 3, '#a8682c'); box(6, 7, 5, 3, '#a8682c'); box(11, 9, 5, 3, '#a8682c'); },
  nevoa: function () { ell(5, 9, 4, 3, '#cfd8dc'); ell(10, 7, 5, 4, '#e0e6ea'); ell(12, 10, 3, 3, '#cfd8dc'); r(1, 12, 14, 2, '#cfd8dc'); },
  relogio: function () { ell(8, 8, 7, 7, OL); ell(8, 8, 6, 6, '#ffffff'); r(8, 4, 1, 5, OL); r(8, 8, 4, 1, OL); },
  estrela: function () { r(7, 1, 2, 14, '#ffd23a'); r(1, 7, 14, 2, '#ffd23a'); r(4, 4, 8, 8, '#ffd23a'); r(7, 6, 2, 2, '#fff3a0'); },
  moeda: function () { ell(8, 8, 6, 6, '#c9a02a'); ell(8, 8, 5, 5, '#ffd23a'); r(7, 5, 2, 6, '#c9a02a'); },
  portao: function () { r(2, 3, 3, 12, '#cfcfcf'); r(11, 3, 3, 12, '#cfcfcf'); r(1, 2, 14, 2, '#9a9a9a'); r(6, 5, 1, 10, '#555555'); r(9, 5, 1, 10, '#555555'); r(6, 9, 4, 1, '#555555'); },
  torre: function () { box(5, 2, 6, 13, '#9aa0aa'); r(4, 0, 2, 3, '#9aa0aa'); r(7, 0, 2, 3, '#9aa0aa'); r(10, 0, 2, 3, '#9aa0aa'); r(7, 6, 2, 3, OL); r(7, 11, 2, 4, OL); },
  porta: function () { box(4, 2, 8, 13, '#c8561a'); r(9, 9, 1, 1, '#ffd23a'); },
  bonus: function () { box(2, 8, 12, 7, '#f3e3b0'); roof(1, 15, 2, 8, '#6a3ab8'); roof(6, 10, 2, 8, '#ffffff', false); ell(8, 11, 3, 3, '#ffd23a'); r(8, 10, 1, 1, OL); r(9, 11, 1, 1, OL); r(8, 12, 1, 1, OL); }
};

var BN = {
  portao: function () {
    mk(36, 34); shadow(18, 32, 16);
    box(1, 8, 10, 24, '#c8c0b0'); box(25, 8, 10, 24, '#c8c0b0'); [1, 5, 9].forEach(function (x) { r(x, 5, 3, 3, '#b0a898'); r(x + 24, 5, 3, 3, '#b0a898'); });
    box(8, 8, 20, 8, '#d8d0c0'); r(10, 16, 16, 16, OL); r(11, 17, 14, 15, '#8a6a3a'); r(12, 19, 12, 13, '#e0bc78'); r(17, 1, 2, 7, '#7a4a24'); r(19, 1, 5, 3, '#d1442e');
    r(4, 14, 3, 3, '#5a4a3a'); r(29, 14, 3, 3, '#5a4a3a'); return g.canvas;
  },
  pedra: function () { mk(12, 8); ell(6, 5, 5.5, 3.5, OL); ell(6, 5, 4.5, 2.7, '#9a9aa0'); r(3, 4, 3, 1, '#c0c0c8'); return g.canvas; },
  fruta: function () { mk(10, 10); ell(5, 5, 4.5, 4.5, '#b8860b'); ell(5, 5, 3.5, 3.5, '#ffd23a'); r(3, 3, 2, 2, '#fff3a0'); r(4, 0, 2, 2, '#3f8a3a'); return g.canvas; }
};

/* bichos: 18x14, de perfil olhando para a direita; f = quadro da animação (0/1) */
var AN = {
  galinha: function (f) { ell(8, 8, 5, 4, '#f8f4e8'); r(2, 4, 3, 4, '#e0d8c0'); r(12, 3, 3, 3, '#f8f4e8'); r(13, 2, 2, 1, '#d1442e'); r(15, 4, 2, 1, '#f5a623'); r(14, 4, 1, 1, OL); r(7 + f, 12, 1, 2, '#f5a623'); r(10 - f, 12, 1, 2, '#f5a623'); },
  viralata: function (f) { r(3, 6, 9, 4, '#c08850'); r(11, 3, 5, 4, '#c08850'); r(11, 2, 2, 3, '#7a4a24'); r(15, 5, 2, 2, '#7a4a24'); r(14, 4, 1, 1, OL); r(1, 4, 2, 2, '#c08850'); r(3, 5, 1, 1, '#c08850'); r(4 + f, 10, 2, 4, '#a8703a'); r(9 - f, 10, 2, 4, '#a8703a'); },
  arara: function (f) { r(6, 6, 6, 3, '#d1442e'); r(11, 5, 3, 3, '#d1442e'); r(14, 6, 2, 2, '#f5f0e0'); r(1, 7, 5, 1, '#3a8cff'); r(12, 5, 1, 1, OL); if (f) { r(6, 2, 4, 4, '#3a8cff'); r(7, 3, 2, 2, '#ffd23a'); } else { r(6, 9, 4, 4, '#3a8cff'); r(7, 10, 2, 2, '#ffd23a'); } },
  macaco: function (f) { r(5, 6, 6, 5, '#8a5a2a'); r(10, 3, 4, 4, '#a8743a'); r(12, 4, 2, 2, '#e8c9a0'); r(13, 4, 1, 1, OL); r(2, 3, 2, 7, '#8a5a2a'); r(3, 2, 2, 2, '#8a5a2a'); r(5 + f, 11, 2, 3, '#7a4a24'); r(9 - f, 11, 2, 3, '#7a4a24'); },
  capivara: function (f) { r(3, 6, 11, 6, '#a8743a'); r(13, 5, 4, 5, '#a8743a'); r(16, 7, 2, 2, '#7a4a24'); r(14, 4, 1, 1, '#7a4a24'); r(15, 6, 1, 1, OL); r(4 + f, 12, 2, 2, '#7a4a24'); r(11 - f, 12, 2, 2, '#7a4a24'); },
  jacare: function (f) { r(1, 9, 14, 3, '#4a7a3a'); r(14, 8, 4, 3, '#4a7a3a'); r(15, 8, 1, 1, '#ffd23a'); r(0, 10, 2, 2, '#3a6a2a'); r(5, 8, 1, 1, '#3a6a2a'); r(8, 8, 1, 1, '#3a6a2a'); r(4 + f, 12, 2, 2, '#3a6a2a'); r(10 - f, 12, 2, 2, '#3a6a2a'); },
  bode: function (f) { r(4, 5, 8, 5, '#e8e0d0'); r(11, 2, 4, 4, '#e8e0d0'); r(12, 1, 1, 2, '#7a6a5a'); r(14, 1, 1, 2, '#7a6a5a'); r(14, 6, 1, 2, '#c8c0b0'); r(14, 3, 1, 1, OL); r(5 + f, 10, 1, 4, '#8a7a6a'); r(10 - f, 10, 1, 4, '#8a7a6a'); r(7, 10, 1, 4, '#8a7a6a'); },
  tatu: function (f) { ell(8, 9, 6, 3, '#8a8a90'); r(6, 6, 1, 6, '#6a6a70'); r(9, 6, 1, 6, '#6a6a70'); r(13, 8, 3, 3, '#8a8a90'); r(15, 9, 1, 1, OL); r(1, 9, 3, 1, '#8a8a90'); r(5 + f, 12, 2, 2, '#6a6a70'); r(10 - f, 12, 2, 2, '#6a6a70'); },
  mico: function (f) { r(5, 7, 6, 4, '#ff9a2a'); ell(13, 5, 3, 3, '#ff9a2a'); r(13, 5, 2, 2, '#7a4a24'); r(1, 4, 4, 2, '#ff9a2a'); r(3, 6, 2, 3, '#ff9a2a'); r(5 + f, 11, 2, 3, '#e07a1a'); r(9 - f, 11, 2, 3, '#e07a1a'); },
  tucano: function (f) { r(6, 6, 6, 3, '#2a1f2d'); r(10, 6, 2, 3, '#ffffff'); r(11, 4, 3, 3, '#2a1f2d'); r(13, 4, 5, 2, '#ffa826'); r(2, 7, 4, 1, '#2a1f2d'); if (f) r(6, 2, 4, 4, '#3a3a4a'); else r(6, 9, 4, 4, '#3a3a4a'); },
  siri: function (f) { ell(9, 9, 5, 3, '#d1442e'); r(3, 5 + f, 2, 4, '#e8683e'); r(14, 5 + (1 - f), 2, 4, '#e8683e'); r(7, 6, 1, 2, '#ffffff'); r(11, 6, 1, 2, '#ffffff'); r(4 + f, 12, 1, 2, '#b83a2a'); r(8 - f, 12, 1, 2, '#b83a2a'); r(11 + f, 12, 1, 2, '#b83a2a'); },
  gaivota: function (f) { ell(9, 7, 4, 2, '#ffffff'); r(12, 6, 2, 2, '#ffffff'); r(14, 7, 2, 1, '#ffa826'); if (f) r(3, 3, 10, 2, '#e0e8f0'); else r(3, 9, 10, 2, '#e0e8f0'); },
  ema: function (f) { ell(8, 7, 5, 4, '#8a7a6a'); r(12, 2, 2, 6, '#8a7a6a'); r(12, 1, 4, 2, '#8a7a6a'); r(16, 1, 2, 1, '#f5a623'); r(7 + f, 11, 1, 3, '#6a5a4a'); r(10 - f, 11, 1, 3, '#6a5a4a'); },
  ovelha: function (f) { ell(8, 8, 6, 4, '#f4f4f4'); r(13, 6, 3, 4, '#3a3a3a'); r(15, 7, 1, 1, '#ffffff'); r(5 + f, 11, 1, 3, '#3a3a3a'); r(10 - f, 11, 1, 3, '#3a3a3a'); },
  lobo: function (f) { r(4, 6, 8, 3, '#d8782a'); r(12, 4, 4, 3, '#d8782a'); r(12, 2, 1, 2, '#d8782a'); r(14, 2, 1, 2, '#d8782a'); r(16, 6, 1, 1, OL); r(15, 5, 1, 1, OL); r(1, 6, 3, 2, '#d8782a'); r(4 + f, 9, 1, 5, '#3a2a1a'); r(7 - f, 9, 1, 5, '#3a2a1a'); r(10 + f, 9, 1, 5, '#3a2a1a'); },
  gralha: function (f) { r(7, 6, 5, 3, '#2a4a9a'); r(11, 4, 3, 3, '#1a1a3a'); r(14, 5, 2, 1, '#2a1f2d'); r(3, 7, 4, 1, '#2a4a9a'); if (f) r(7, 2, 4, 4, '#3a5ab0'); else r(7, 9, 4, 4, '#3a5ab0'); },
  cutia: function (f) { ell(8, 9, 5, 3, '#a8743a'); r(12, 8, 3, 3, '#a8743a'); r(14, 9, 1, 1, OL); r(13, 7, 1, 1, '#7a4a24'); r(5 + f, 12, 1, 2, '#7a4a24'); r(10 - f, 12, 1, 2, '#7a4a24'); },
  araraazul: function (f) { r(6, 6, 6, 3, '#2a5ad8'); r(7, 8, 4, 1, '#ffd23a'); r(11, 5, 3, 3, '#2a5ad8'); r(14, 6, 2, 2, '#2a2a2a'); r(1, 7, 5, 1, '#1a3a9a'); if (f) r(6, 2, 4, 4, '#3a6ae8'); else r(6, 9, 4, 4, '#3a6ae8'); },
  garca: function (f) { ell(8, 8, 4, 2, '#ffffff'); r(12, 3, 1, 5, '#ffffff'); r(12, 2, 3, 2, '#ffffff'); r(15, 3, 2, 1, '#ffc42a'); r(13, 2, 1, 1, OL); r(7, 10, 1, 4, '#8a7a52'); r(9, 10, 1, 4, '#8a7a52'); if (f) r(3, 3, 9, 2, '#e8eef4'); else r(3, 9, 9, 2, '#e8eef4'); },
  preguica: function (f) { r(3, 5, 9, 5, '#8a7a62'); r(11, 6, 4, 4, '#b8a888'); r(12, 7, 1, 1, '#3a2a1a'); r(14, 8, 1, 1, '#3a2a1a'); r(2, 4, 2, 2, '#6a5a42'); r(4 + f, 10, 2, 4, '#6a5a42'); r(9 - f, 10, 2, 4, '#6a5a42'); r(5, 6, 1, 3, '#a8987a'); },
  veado: function (f) { r(4, 6, 8, 4, '#b0783a'); r(11, 3, 2, 4, '#b0783a'); r(12, 2, 4, 3, '#b0783a'); r(15, 4, 1, 1, OL); r(12, 0, 1, 2, '#e8dcc0'); r(14, 0, 1, 2, '#e8dcc0'); r(3, 6, 1, 2, '#ffffff'); r(5 + f, 10, 1, 4, '#7a4a24'); r(10 - f, 10, 1, 4, '#7a4a24'); r(7, 10, 1, 4, '#7a4a24'); },
  calango: function (f) { r(3, 10, 9, 2, '#8aa83a'); r(11, 9, 4, 3, '#a8c84a'); r(14, 10, 1, 1, OL); r(0, 11, 4, 1, '#6a8a2a'); r(4 + f, 12, 1, 2, '#6a8a2a'); r(9 - f, 12, 1, 2, '#6a8a2a'); r(6, 9, 1, 1, '#d8e07a'); r(8, 9, 1, 1, '#d8e07a'); }
};


/* construções, árvores e portais por bioma (cidades dos Reinos) */
function winK(x, y) { box(x, y, 5, 5, '#8fd0ff'); r(x + 2, y + 1, 1, 3, '#ffffff'); }
function door(x, y, w, h, c) { box(x, y, w, h, c || '#7a4a24'); r(x + w - 2, y + Math.floor(h / 2), 1, 1, '#ffd23a'); }
var CT = {
  portao: function () {
    mk(30, 26); shadow(15, 24, 13);
    box(1, 8, 6, 17, '#c8c0b0'); box(23, 8, 6, 17, '#c8c0b0'); r(0, 6, 8, 3, '#9a9288'); r(22, 6, 8, 3, '#9a9288');
    r(2, 4, 4, 2, '#b0a898'); r(24, 4, 4, 2, '#b0a898');
    box(5, 5, 20, 5, '#7a4a24'); r(7, 7, 16, 1, '#a86a34'); r(9, 10, 2, 3, '#5a3a1c'); r(19, 10, 2, 3, '#5a3a1c');
    r(14, 0, 2, 5, '#7a4a24'); r(16, 0, 5, 3, '#d1442e'); r(16, 3, 5, 1, '#9a2a1e');
    r(7, 22, 16, 3, '#e0bc78');
    return g.canvas;
  },
  portal0: function () { return CT._portal(0); },
  portal1: function () { return CT._portal(1); },
  _portal: function (f) {
    mk(26, 36); shadow(13, 33, 11);
    box(1, 30, 24, 4, '#8a8a9a'); box(3, 8, 5, 23, '#aab0c0'); box(18, 8, 5, 23, '#aab0c0'); box(1, 3, 24, 7, '#c8ccd8'); r(11, 1, 4, 3, '#ffd23a'); r(12, 0, 2, 1, '#ffd23a');
    r(8, 10, 10, 20, '#4a8ad8'); r(9, 11, 8, 18, '#6fc8f0'); r(10, 13, 6, 14, '#9fe0ff');
    var sp = f ? [[11, 14], [14, 18], [12, 23], [15, 26]] : [[14, 14], [11, 19], [15, 23], [12, 27]]; sp.forEach(function (q) { r(q[0], q[1], 1, 2, '#ffffff'); });
    r(5, 12, 1, 3, '#8a90a0'); r(20, 12, 1, 3, '#8a90a0'); r(4, 5, 2, 1, '#e8ecf4'); r(20, 5, 2, 1, '#e8ecf4'); return g.canvas;
  },
  palafita: function () {
    mk(40, 36); shadow(20, 34, 18);
    [7, 14, 25, 32].forEach(function (x) { r(x, 24, 2, 10, '#6a4a2a'); }); r(5, 32, 30, 1, '#6a4a2a');
    box(6, 14, 28, 11, '#d8b878'); roof(3, 36, 5, 14, '#8a5a2a'); door(17, 17, 6, 8, '#7a4a24'); winK(9, 17); winK(27, 17);
    r(36, 25, 1, 9, '#7a4a24'); [26, 28, 30, 32].forEach(function (y) { r(35, y, 3, 1, '#7a4a24'); }); return g.canvas;
  },
  taipa: function () {
    mk(36, 30); shadow(18, 28, 16);
    box(4, 12, 28, 16, '#f0e0c0'); roof(2, 34, 3, 12, '#c8642a'); door(15, 17, 6, 11, '#7a4a24'); winK(7, 16); winK(25, 16); r(4, 26, 28, 2, '#d8c8a0');
    r(31, 17, 1, 11, '#3f8a3a'); r(33, 20, 2, 8, '#3f8a3a'); return g.canvas;
  },
  sobrado: function () {
    mk(32, 40); shadow(16, 38, 14);
    box(3, 20, 26, 17, '#f3e3b0'); box(5, 9, 22, 12, '#e8d498'); roof(2, 30, 2, 9, '#d1442e'); r(4, 20, 24, 2, '#8a5a2a');
    winK(8, 12); winK(19, 12); door(13, 26, 6, 11, '#7a4a24'); winK(6, 25); winK(21, 25); r(11, 14, 10, 1, '#7a4a24'); return g.canvas;
  },
  galpao: function () {
    mk(46, 32); shadow(23, 30, 21);
    box(3, 12, 40, 17, '#a8682c'); roof(1, 45, 3, 12, '#9aa0a8'); box(14, 17, 18, 12, '#6a4020'); r(14, 17, 18, 1, '#3a2a1a'); r(22, 17, 2, 12, '#3a2a1a');
    for (var i = 0; i < 6; i++) r(4 + i * 7, 13, 1, 15, '#8a5420'); r(40, 18, 1, 1, '#ffd23a'); return g.canvas;
  },
  oca: function () {
    mk(38, 32); shadow(19, 30, 17);
    box(5, 18, 28, 11, '#c89850'); roof(1, 37, 3, 18, '#d8b868'); for (var y = 6; y < 18; y += 3) r(4 + (y - 6), y, 30 - (y - 6) * 2, 1, '#b8983a');
    door(16, 20, 6, 9, '#4a2a10'); r(18, 1, 2, 3, '#7a4a24'); r(7, 22, 1, 6, '#7a4a24'); r(30, 22, 1, 6, '#7a4a24'); return g.canvas;
  },
  chale: function () {
    mk(36, 36); shadow(18, 34, 16);
    box(5, 17, 26, 16, '#a8743a'); roof(1, 35, 4, 17, '#4a6a5a'); r(26, 4, 4, 8, '#8a8a90'); r(25, 3, 6, 1, '#6a6a70'); r(26, 0, 2, 2, 'rgba(240,240,240,0.7)');
    door(15, 22, 6, 11, '#5a3a1a'); winK(8, 21); winK(24, 21); for (var y = 19; y < 33; y += 3) r(6, y, 24, 1, '#8a5a2a'); r(1, 15, 34, 2, '#f4f4f4'); return g.canvas;
  },
  igreja: function () {
    mk(36, 44); shadow(18, 42, 15);
    box(6, 22, 24, 19, '#f4f0e0'); roof(3, 33, 14, 22, '#c8642a'); box(13, 4, 10, 16, '#f4f0e0'); roof(11, 25, 0, 5, '#b8442a'); r(17, 8, 2, 4, '#ffd23a'); r(14, 8, 1, 4, OL); r(21, 8, 1, 4, OL);
    door(15, 30, 6, 11, '#5a3a1a'); winK(9, 28); winK(22, 28); r(17, 15, 2, 1, '#8a5a2a'); return g.canvas;
  },
  farol: function () {
    mk(20, 46); shadow(10, 44, 9);
    for (var y = 12; y <= 42; y++) { var h = Math.round(3 + (y - 12) * 0.1); r(10 - h, y, 2 * h, 1, (y % 8 < 4) ? '#f4f4f4' : '#d1442e'); }
    box(5, 6, 10, 6, '#ffd23a'); roof(4, 16, 1, 6, '#d1442e'); r(2, 5, 3, 1, 'rgba(255,230,128,0.8)'); r(15, 5, 3, 1, 'rgba(255,230,128,0.8)'); door(8, 34, 4, 8, '#4a2a10'); return g.canvas;
  },
  caixa: function () { mk(16, 34); shadow(8, 32, 7); r(3, 14, 2, 18, '#6a4a2a'); r(11, 14, 2, 18, '#6a4a2a'); r(3, 22, 10, 1, '#6a4a2a'); box(1, 3, 14, 12, '#4a8ad8'); r(3, 5, 2, 7, '#9fd0ff'); r(0, 2, 16, 2, '#8a90a0'); return g.canvas; },
  poco: function () { mk(18, 20); shadow(9, 18, 8); box(3, 11, 12, 7, '#9a8a7a'); r(4, 12, 10, 2, '#4a6a8a'); r(3, 4, 1, 8, '#6a4a2a'); r(14, 4, 1, 8, '#6a4a2a'); roof(2, 16, 0, 4, '#a8682c'); return g.canvas; },
  canoa: function () { mk(30, 12); shadow(15, 10, 13); r(2, 6, 26, 3, '#a8682c'); r(4, 9, 22, 1, '#7a4a24'); r(0, 5, 3, 1, '#a8682c'); r(27, 5, 3, 1, '#a8682c'); r(8, 4, 14, 1, '#c8884c'); r(20, 2, 1, 4, '#7a4a24'); return g.canvas; },
  fogueira: function () { mk(14, 14); shadow(7, 12, 6); r(2, 10, 10, 2, '#6a4a2a'); r(4, 8, 6, 2, '#8a5a2a'); r(5, 4, 4, 4, '#ff9a2a'); r(6, 2, 2, 3, '#ffd23a'); r(6, 6, 2, 2, '#fff2a0'); return g.canvas; },
  cerca: function () { mk(20, 12); for (var i = 0; i < 4; i++) r(1 + i * 5, 2, 2, 9, '#8a5a2a'); r(0, 4, 20, 1, '#a8743a'); r(0, 8, 20, 1, '#a8743a'); return g.canvas; },
  pinheiro: function () { mk(24, 46); shadow(12, 44, 8); r(11, 20, 3, 24, '#6a4a2a'); [[2, 6, 20, 5], [4, 12, 16, 5], [6, 18, 12, 4]].forEach(function (b) { ell(12, b[1] + 3, b[2] / 2 + 2, 3, '#1f6a3a'); ell(12, b[1] + 2, b[2] / 2, 2, '#2f8a4a'); }); ell(12, 3, 9, 4, '#1f6a3a'); ell(12, 2, 6, 2, '#2f8a4a'); r(8, 8, 8, 1, '#1f6a3a'); return g.canvas; },
  palmeira: function () { mk(30, 46); shadow(15, 44, 8); r(14, 14, 3, 30, '#7a5a2a'); r(15, 16, 1, 26, '#9a7a3a'); [[3, 8, 10, 2], [17, 8, 10, 2], [5, 4, 8, 2], [17, 4, 8, 2], [9, 1, 12, 2]].forEach(function (f) { r(f[0], f[1], f[2], f[3], '#3a9a3a'); r(f[0] + 1, f[1] + 2, f[2] - 2, 1, '#2a7a2a'); }); r(13, 11, 5, 3, '#a8682c'); return g.canvas; },
  mandacaru: function () { mk(20, 34); shadow(10, 32, 7); r(8, 6, 4, 26, '#3f8a3a'); r(3, 12, 6, 3, '#3f8a3a'); r(3, 8, 3, 7, '#3f8a3a'); r(11, 16, 6, 3, '#3f8a3a'); r(15, 11, 3, 8, '#3f8a3a'); r(9, 8, 1, 22, '#5aaa5a'); r(9, 4, 2, 2, '#ff7aa0'); return g.canvas; },
  ipe: function () { mk(30, 40); shadow(15, 38, 10); r(13, 20, 4, 18, '#6a4a2a'); ell(15, 12, 13, 9, '#e8c82a'); ell(8, 16, 7, 5, '#f4d84a'); ell(22, 16, 7, 5, '#f4d84a'); r(6, 8, 2, 1, '#fff2a0'); r(20, 6, 2, 1, '#fff2a0'); r(14, 14, 2, 1, '#c8a21a'); return g.canvas; },
  coqueiro: function () { mk(28, 44); shadow(14, 42, 8); r(12, 14, 3, 28, '#a8743a'); r(13, 16, 1, 24, '#c8944a'); r(11, 20, 1, 1, '#8a5a2a'); [[2, 9, 10], [15, 9, 10], [4, 5, 9], [15, 5, 9], [9, 2, 10]].forEach(function (f) { r(f[0], f[1], f[2], 2, '#2f9a4a'); r(f[0] + 1, f[1] + 2, f[2] - 2, 1, '#1f7a3a'); }); r(12, 11, 4, 3, '#6a4a2a'); return g.canvas; },
  jequi: function () { mk(44, 48); shadow(22, 46, 14); r(18, 18, 9, 28, '#7a4a24'); r(20, 20, 2, 24, '#8e5a2e'); ell(22, 12, 20, 11, '#2f6b2f'); ell(10, 18, 10, 6, '#3c8a3c'); ell(34, 18, 10, 6, '#3c8a3c'); ell(22, 6, 12, 4, '#3c8a3c'); return g.canvas; },
  arbustoF: function () { mk(18, 12); shadow(9, 10, 7); ell(9, 6, 8, 5, '#3c8a3c'); ell(6, 5, 4, 3, '#5aaa4a'); r(5, 3, 1, 1, '#ff7aa0'); r(11, 5, 1, 1, '#ffd23a'); r(13, 7, 1, 1, '#ff7aa0'); return g.canvas; },
  pedra: function () { mk(18, 12); shadow(9, 10, 8); ell(9, 7, 8, 4, '#9a9aa8'); ell(7, 6, 4, 2, '#b8b8c8'); return g.canvas; },
  /* Cerrado: pequizeiro (tronco torto, copa larga e baixa, frutos verde-amarelados) */
  pequizeiro: function () { mk(44, 44); shadow(22, 42, 15); r(19, 24, 5, 18, '#6a4a2a'); r(21, 26, 1, 14, '#85603a'); r(14, 24, 6, 2, '#6a4a2a'); r(13, 21, 2, 4, '#6a4a2a'); r(23, 21, 8, 2, '#6a4a2a'); r(30, 18, 2, 4, '#6a4a2a');
    ell(22, 15, 19, 10, '#5a8a3a'); ell(10, 20, 9, 6, '#4f7f33'); ell(34, 20, 9, 6, '#4f7f33'); ell(22, 8, 12, 5, '#6e9e42'); ell(14, 12, 6, 3, '#7aae4a'); ell(30, 11, 6, 3, '#7aae4a');
    [[12, 19], [19, 22], [28, 18], [33, 22], [24, 12], [16, 14]].forEach(function (p) { r(p[0], p[1], 2, 2, '#d6dc4a'); r(p[0], p[1], 1, 1, '#f0f08a'); }); r(26, 9, 1, 1, '#f4efd0'); r(10, 16, 1, 1, '#f4efd0'); return g.canvas; },
  /* Cerrado: buriti (palmeira alta das veredas, copa em leque e cacho avermelhado) */
  buriti: function () { mk(34, 60); shadow(17, 58, 8); r(16, 16, 3, 42, '#8a7a4a'); r(17, 18, 1, 38, '#a89858'); for (var y = 20; y < 56; y += 5) r(16, y, 3, 1, '#6a5a32');
    [[1, 11, 14, 2, -1], [19, 11, 14, 2, 1], [0, 15, 11, 2, -1], [23, 15, 11, 2, 1], [5, 6, 24, 2, 0], [9, 2, 16, 2, 0]].forEach(function (f) { r(f[0], f[1], f[2], f[3], '#33a04a'); r(f[0] + 1, f[1] + f[3], f[2] - 2, 1, '#237a38'); });
    r(15, 12, 5, 4, '#b8402a'); r(16, 13, 1, 1, '#e87a4a'); r(13, 17, 2, 3, '#b8402a'); r(20, 17, 2, 3, '#b8402a'); return g.canvas; }
};

/* Portais étnicos: um por bioma (substituem o portal metálico). Cada um tem 2 quadros (balanço dos pendentes). */
CT._pt = function (kind, f) {
  mk(30, 38); shadow(15, 36, 13);
  var s = f ? 1 : 0, y, x;
  function palha(x0, x1, yt, yb, c, c2) {
    roof(x0, x1, yt, yb, c); var cx = (x0 + x1) / 2;
    for (var yy = yt; yy < yb; yy++) { var t = (yy - yt + 1) / (yb - yt + 1), l = Math.round(cx - (cx - x0) * t) + 1, rr = Math.round(cx + (x1 - cx) * t) - 1; for (var xx = l; xx <= rr; xx++) if ((xx + yy * 2) % 5 === 0) r(xx, yy, 1, 1, c2); }
  }
  if (kind === 'cerrado') { // buriti e pequizeiro: palha, madeira do cerrado, urucum e jenipapo
    box(3, 11, 5, 25, '#8a5a2a'); box(22, 11, 5, 25, '#8a5a2a'); r(5, 13, 1, 21, '#b07a3c'); r(24, 13, 1, 21, '#b07a3c');
    r(2, 34, 7, 2, '#b0a898'); r(21, 34, 7, 2, '#b0a898');
    box(1, 9, 28, 4, '#a8682c'); palha(0, 29, 1, 9, '#e8c458', '#c89a3a');
    [15, 19, 23, 27].forEach(function (yy) { r(4, yy, 3, 1, '#c8421e'); r(5, yy + 1, 1, 1, OL); r(23, yy, 3, 1, '#c8421e'); r(24, yy + 1, 1, 1, OL); });
    for (var j = 0; j < 8; j++) r(9 + Math.floor(j * 2.5), 13, 1, 6 + ((j + s) % 2) * 3, '#e8c458');
    r(13, 4, 4, 4, '#e8d040'); r(14, 5, 2, 2, '#c89a3a');
  } else if (kind === 'amazonia') { // madeira pintada com grafismo, cobertura de palma, cocar e cuias
    box(3, 11, 5, 25, '#d8b078'); box(22, 11, 5, 25, '#d8b078');
    for (y = 14; y < 33; y += 4) { r(4, y + 1, 3, 1, '#d1442e'); r(5, y, 1, 3, OL); r(23, y + 1, 3, 1, '#d1442e'); r(24, y, 1, 3, OL); }
    box(1, 9, 28, 4, '#8a5a2a'); palha(0, 29, 3, 9, '#3f8a3a', '#2a6a2a');
    [[10, '#d1442e'], [12, '#ffd23a'], [14, '#2a6acf'], [16, '#ffd23a'], [18, '#d1442e']].forEach(function (q, i) { r(q[0] + 1, i % 2 ? 0 : 1, 2, 4, q[1]); });
    box(8, 14 + s, 4, 4, '#c8862a'); box(18, 15 - s, 4, 4, '#c8862a'); r(10, 13, 1, 1 + s, OL); r(20, 13, 1, 2 - s, OL);
  } else if (kind === 'caatinga') { // aroeira seca, couro, caveira de boi, cruz sertaneja
    box(3, 11, 4, 25, '#7a5a3a'); box(23, 11, 4, 25, '#7a5a3a'); r(4, 14, 1, 18, '#5a3a22'); r(24, 16, 1, 16, '#5a3a22');
    box(1, 9, 28, 3, '#9a6a3a'); r(14, 9, 2, 1, '#ffd23a');
    box(11, 3, 8, 5, '#f0e8d8'); r(13, 5, 1, 1, OL); r(16, 5, 1, 1, OL); r(14, 7, 2, 1, OL);
    r(7, 4, 4, 1, '#f0e8d8'); r(5, 3, 3, 1, '#f0e8d8'); r(19, 4, 4, 1, '#f0e8d8'); r(22, 3, 3, 1, '#f0e8d8');
    box(12 - s, 13, 6, 9, '#a8683a'); r(13 - s, 15, 4, 1, '#d8a860'); r(13 - s, 18, 4, 1, '#d8a860');
    r(8, 24, 1, 4, '#c8421e'); r(7, 25, 3, 1, '#c8421e'); r(21, 24, 1, 4, '#c8421e'); r(20, 25, 3, 1, '#c8421e');
  } else if (kind === 'pantanal') { // palafita baixa, sapé, tuiuiú e rede de pesca
    r(3, 17, 5, 19, '#6a4a2a'); r(22, 17, 5, 19, '#6a4a2a'); r(2, 17, 7, 1, OL); r(21, 17, 7, 1, OL); r(4, 20, 1, 14, '#8a6a45'); r(23, 20, 1, 14, '#8a6a45');
    box(1, 15, 28, 3, '#7a4a24'); palha(0, 29, 8, 15, '#d8c070', '#b89a40');
    box(11, 3, 8, 4, '#f4f4f4'); r(17, 0, 2, 4, '#f4f4f4'); r(17, 0, 3, 1, OL); r(17, 3, 2, 1, '#d1442e'); r(20, 1, 3, 1, OL); r(13, 7, 1, 2, OL); r(16, 7, 1, 2, OL);
    r(9, 18, 12, 1, '#8a6a45'); for (x = 9; x < 21; x += 2) r(x, 19, 1, 4 + ((x + s) % 2) * 2, '#8a6a45');
  } else if (kind === 'mata') { // troncos de jequitibá, cipós, bromélias e grafismo guarani
    box(2, 10, 6, 26, '#6a4a2a'); box(22, 10, 6, 26, '#6a4a2a'); r(2, 16, 3, 5, '#3f8a3a'); r(25, 24, 3, 6, '#3f8a3a'); r(5, 12, 1, 22, '#8a6a3a');
    box(1, 8, 28, 4, '#4a7a32'); r(3, 6, 4, 3, '#2f6b2f'); r(12, 5, 6, 4, '#2f6b2f'); r(22, 6, 4, 3, '#2f6b2f');
    r(5, 5, 3, 2, '#d1442e'); r(21, 5, 3, 2, '#d1442e'); r(14, 3, 2, 2, '#ffb0d0');
    for (x = 3; x < 27; x += 4) { r(x, 10, 2, 1, '#d1442e'); r(x + 2, 9, 2, 1, OL); }
    r(10, 12, 1, 6 + s * 2, '#3f8a3a'); r(19, 12, 1, 8 - s * 2, '#3f8a3a'); r(11, 18 + s * 2, 2, 2, '#d1442e');
  } else { // costa: mastros de jangada, vela de palha, rede e conchas
    box(3, 6, 3, 30, '#a8743a'); box(24, 6, 3, 30, '#a8743a'); box(1, 13, 28, 2, '#8a5a2a');
    roof(6, 23, 1, 12, '#f4e8c8'); r(14, 6, 2, 6, '#d1442e'); r(14, 0, 2, 2, '#ffd0c0');
    for (x = 7; x < 23; x += 3) r(x, 15, 1, 5 + ((x + s) % 2) * 2, '#c8b898');
    r(4, 34, 3, 2, '#ffd0c0'); r(23, 34, 3, 2, '#ffd0c0'); r(9, 35, 12, 1, '#4aa3d8');
  }
  return g.canvas;
};
['cerrado', 'amazonia', 'caatinga', 'pantanal', 'mata', 'costa'].forEach(function (k) { [0, 1].forEach(function (f) { CT['pt_' + k + f] = function () { return CT._pt(k, f); }; }); });

window.ARTE = {
  build: function () {
    var out = {};
    function pad(cv, l, t, rr, b) { var n = document.createElement('canvas'); n.width = cv.width + l + rr; n.height = cv.height + t + b; n.getContext('2d').drawImage(cv, l, t); return n; }
    Object.keys(AN).forEach(function (k) { [0, 1].forEach(function (f) { mk(18, 14); AN[k](f); out['an_' + k + '_' + f] = polish(pad(g.canvas, 1, 1, 1, 0), false); }); });
    Object.keys(LM).forEach(function (k) { out['lm_' + k] = polish(pad(LM[k](), 2, 2, 2, 0), true); });
    Object.keys(IC).forEach(function (k) { mk(18, 18); g.translate(1, 1); IC[k](); g.setTransform(1, 0, 0, 1, 0, 0); out['ic_' + k] = polish(g.canvas, false); });
    Object.keys(CT).forEach(function (k) { if (k[0] === '_') return; out['ct_' + k] = polish(pad(CT[k](), 1, 1, 1, 1), true); });

    /* ilustração das cidades dos Reinos (Mapa-Mundo): composição das peças já prontas */
    var CID = {
      vila: ['#e0c890', [['igreja', 70, 54], ['sobrado', 32, 60], ['sobrado', 108, 60], ['taipa', 46, 77], ['taipa', 94, 77], ['arbustoF', 12, 82], ['arbustoF', 128, 82]]],
      boca: ['#4a9a6a', [['jequi', 70, 52], ['palafita', 28, 66], ['palafita', 112, 66], ['oca', 48, 80], ['canoa', 98, 86], ['palmeira', 126, 74]]],
      pouso: ['#6fc0b8', [['palafita', 34, 62], ['palafita', 106, 62], ['galpao', 70, 68], ['palmeira', 12, 68], ['palmeira', 128, 68], ['canoa', 82, 88], ['taipa', 50, 82]]],
      cacimba: ['#e8c878', [['igreja', 70, 54], ['taipa', 34, 62], ['taipa', 106, 62], ['galpao', 50, 80], ['mandacaru', 14, 74], ['mandacaru', 128, 76], ['poco', 96, 86], ['caixa', 118, 62]]],
      jeq: ['#5a9a4a', [['jequi', 70, 56], ['sobrado', 28, 66], ['sobrado', 112, 66], ['chale', 50, 82], ['igreja', 92, 82], ['ipe', 10, 76], ['ipe', 130, 78]]],
      enseada: ['#f0dca0', [['farol', 112, 60], ['palafita', 30, 64], ['taipa', 62, 68], ['sobrado', 86, 80], ['coqueiro', 12, 74], ['canoa', 38, 90], ['coqueiro', 128, 84]]],
      coxilha: ['#a8c868', [['sobrado', 70, 58], ['galpao', 32, 64], ['galpao', 108, 64], ['taipa', 52, 80], ['cerca', 96, 86], ['ipe', 14, 76], ['cerca', 122, 88]]],
      babacual: ['#7ab05a', [['palafita', 70, 60], ['oca', 30, 66], ['oca', 110, 66], ['oca', 50, 82], ['palmeira', 12, 68], ['palmeira', 128, 70], ['fogueira', 90, 88]]],
      planalto: ['#d8e0ea', [['igreja', 70, 54], ['chale', 32, 64], ['chale', 108, 64], ['galpao', 50, 82], ['pinheiro', 12, 70], ['pinheiro', 128, 70], ['fogueira', 92, 88]]]
    };
    Object.keys(CID).forEach(function (n) {
      var cv = document.createElement('canvas'); cv.width = 140; cv.height = 106; var c = cv.getContext('2d'), cfg = CID[n];
      function el(cx, cy, rx, ry, col) { c.fillStyle = col; for (var y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) for (var x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) { var dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry; if (dx * dx + dy * dy <= 1) c.fillRect(x, y, 1, 1); } }
      el(70, 86, 69, 17, '#2a1f2d'); el(70, 86, 68, 16, cfg[0]); el(70, 84, 62, 12, 'rgba(255,255,255,0.18)'); c.fillStyle = '#e0bc78'; c.fillRect(64, 86, 12, 20); c.fillStyle = '#c9a05a'; c.fillRect(64, 86, 1, 20); c.fillRect(75, 86, 1, 20);
      cfg[1].slice().sort(function (p, q) { return p[2] - q[2]; }).forEach(function (it) { var im = out['ct_' + it[0]]; if (im) c.drawImage(im, Math.round(it[1] - im.width / 2), Math.round(it[2] - im.height)); });
      var gt = out['ct_portao']; if (gt) c.drawImage(gt, 70 - Math.round(gt.width / 2), 106 - gt.height);
      out['cid_' + n] = cv;
    });
    Object.keys(BN).forEach(function (k) { out['bn_' + k] = polish(pad(BN[k](), 1, 1, 1, 1), false); });
    return out;
  }
};
})();
